"""dedup: data_center.duplicate_of

Revision ID: e5f6a7b8c9d0
Revises: d4e5f6a7b8c9
Create Date: 2026-07-21

The 2026-07-21 capacity audit measured what the unbuilt Phase-C dedup costs: 27 locations
hold 66 data_center rows at IDENTICAL coordinates, carrying 11,401 MW beyond the largest row
at each ("El Paso Data Center" x3 at 1,000 MW on one lat/lng; "CoreWeave Plano" x3 at 13 MW;
"QTS Turkey Data Center Campus" x2 at 1,000 MW). The published capacity column double-counts
by that much.

`duplicate_of` holds the SURVIVOR's id. It is a mark, not a delete:
  - emit drops marked rows from the read-model,
  - `dcv dedup --undo` clears it and the row returns unchanged.

Nullable with no backfill and no FK constraint — a self-referencing FK would make the undo
order-dependent, and the value is always a data_center id that dedup.py resolves. Additive,
so it applies forward/back safely.
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "e5f6a7b8c9d0"
down_revision: Union[str, None] = "d4e5f6a7b8c9"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("data_center", sa.Column("duplicate_of", sa.String(), nullable=True))
    op.create_index("ix_data_center_duplicate_of", "data_center", ["duplicate_of"])


def downgrade() -> None:
    op.drop_index("ix_data_center_duplicate_of", table_name="data_center")
    op.drop_column("data_center", "duplicate_of")

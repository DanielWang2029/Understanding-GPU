"""band2 dc role names (tenant_name / operator_name)

Revision ID: d4e5f6a7b8c9
Revises: c1d2e3f4a5b6
Create Date: 2026-07-20

Band 2 #2 (L2-dcroles). Additive, nullable columns on `data_center`:
  - tenant_name   : raw tenant company name as written by the source
  - operator_name : raw operator company name as written by the source

`data_center` already had the raw/resolved PAIR for two of the four role fields
(developer_name+developer_id, end_user_name+end_user_id) but only the resolved half
for the other two (tenant_id, operator_id, with no *_name). PhaseB's extractor has
always returned `tenant` and `operator` (schema.py), and persist.py's upsert had
nowhere to put them — so every extracted tenant was silently dropped at the store
boundary. That is the largest single cause of `tenant` sitting at 0.5%.

These columns restore the symmetry: raw name persisted on ingest, FK resolved later
by the deterministic resolver. Nullable with no backfill (the values must come from
a re-extract, not be invented here), so this applies forward/back safely.
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "d4e5f6a7b8c9"
down_revision: Union[str, None] = "c1d2e3f4a5b6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("data_center", sa.Column("tenant_name", sa.String(), nullable=True))
    op.add_column("data_center", sa.Column("operator_name", sa.String(), nullable=True))


def downgrade() -> None:
    op.drop_column("data_center", "operator_name")
    op.drop_column("data_center", "tenant_name")

"""p2 entity financials + layer

Revision ID: c1d2e3f4a5b6
Revises: f58e4ad3433e
Create Date: 2026-07-19

P2.0 (financial spine / L9). Additive, nullable columns on `entity`:
  - layer      : chain layer (foundry…enduser) for the supply-sankey / SPLC altitudes
  - financials : per-metric Field<T> JSONB (market_cap / revenue / capex + currency),
                 each carrying its own as_of / basis(disclosed|estimated|n/a) / sources.
`ticker` already lives in entity.identifiers JSONB — no column needed.
Nullable with no backfill here (P2.2 populates via the FMP connector), so this is
safe to apply forward/back with no data migration.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = 'c1d2e3f4a5b6'
down_revision: Union[str, None] = 'f58e4ad3433e'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_JSONB = postgresql.JSONB(none_as_null=True, astext_type=sa.Text()).with_variant(
    sa.JSON(), 'sqlite'
)


def upgrade() -> None:
    op.add_column('entity', sa.Column('layer', sa.String(), nullable=True))
    op.add_column('entity', sa.Column('financials', _JSONB, nullable=True))


def downgrade() -> None:
    op.drop_column('entity', 'financials')
    op.drop_column('entity', 'layer')

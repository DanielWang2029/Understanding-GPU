// Make a FRESH CLONE runnable without standing up the pipeline.
//
// `web/public/data.json` is gitignored — it is generated output, and committing both it and
// the repo-root `data.json` would mean two copies of 3.3 MB drifting apart. But the app reads
// ONLY that path (app/api/data/route.ts), so a clone that has never run `dcv emit` serves a
// 503 telling the reader to run a pipeline they have not set up yet. The first thing a new
// collaborator sees is an error about Postgres.
//
// The repo-root `data.json` IS committed and is the same contract. Copy it into place.
//
// Deliberately NEVER overwrites a newer public/data.json: after `dcv emit` the generated file
// is the fresher one, and clobbering it on every `npm run dev` would silently roll the app
// back to whatever was last committed. Freshness decides, not existence.
import { copyFileSync, existsSync, statSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const src = join(here, "..", "..", "data.json");
const dest = join(here, "..", "public", "data.json");

if (!existsSync(src)) {
  // Not fatal: a pipeline-driven setup may legitimately have only the generated file.
  console.log(`[sync-data] no ${src} — skipping (run \`python -m dcv emit\` to generate one)`);
  process.exit(0);
}

if (existsSync(dest) && statSync(dest).mtimeMs >= statSync(src).mtimeMs) {
  console.log("[sync-data] public/data.json is up to date — leaving it alone");
  process.exit(0);
}

copyFileSync(src, dest);
const mb = (statSync(dest).size / 1e6).toFixed(1);
console.log(`[sync-data] copied repo-root data.json -> public/data.json (${mb} MB)`);

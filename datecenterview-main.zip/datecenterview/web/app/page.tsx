"use client";
import dynamic from "next/dynamic";

// Load the UI client-side only (MapLibre/d3 touch window on import).
const DcvApp = dynamic(() => import("@/components/DcvApp"), {
  ssr: false,
  loading: () => (
    <div style={{ padding: 24, fontFamily: "system-ui", color: "#6b7280" }}>Loading dataCenterView…</div>
  ),
});

export default function Page() {
  return <DcvApp />;
}

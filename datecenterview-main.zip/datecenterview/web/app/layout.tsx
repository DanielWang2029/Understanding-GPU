import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "dataCenterView",
  description:
    "Data centers, power, news, supply chain, and the players around them — comprehensive, up-to-date, verified. A pure function of the pipeline-emitted data.json.",
};

// Apply any saved light/dark preference before first paint to avoid a flash.
// No saved preference => the CSS follows the OS via prefers-color-scheme.
const THEME_INIT = `try{var t=localStorage.getItem('dcv-theme');if(t==='dark'||t==='light')document.documentElement.setAttribute('data-theme',t);}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <script dangerouslySetInnerHTML={{ __html: THEME_INIT }} />
        {children}
      </body>
    </html>
  );
}

import { NextResponse } from "next/server";
import { appendFile, mkdir, readFile } from "node:fs/promises";
import path from "node:path";

// POST /api/review — the U2 dispute wire (Band-1 #3).
//
// The reader is a sensor into L2: a dispute filed here is appended to an append-only inbox
// that `dcv review-drain` ingests into `review_log` and uses to RE-OPEN the record for
// cross-vendor re-verification. Before this route existed the UI's dispute button only
// relabelled itself — the signal was thrown away (the retro's "trust loop has no drain").
//
// Deliberate boundary: the web tier holds NO database credentials and cannot write a verdict.
// It appends a fact ("a reader disputed X"); only the pipeline (and, for approve/reject, a
// human at the CLI) may change a record's review_status. That is also the hysteresis rule —
// a dispute can re-open a record but can never reject it.
//
// Anti-windup: an in-process rate limiter caps disputes per record and per client window so a
// burst (or a loop in the client) cannot flood the review queue.

export const dynamic = "force-dynamic";

const INBOX = path.join(process.cwd(), "..", "pipeline", "inbox", "disputes.jsonl");
const RECORD_TYPES = new Set(["data_center", "power_project"]);
const ID_RE = /^[A-Za-z0-9_.:-]{1,120}$/;
const MAX_REASON = 500;
const MAX_FIELD = 60;
const MAX_BODY = 4000;

// rate limits (per process, resets on restart — this is a local single-operator tool)
const WINDOW_MS = 60 * 60 * 1000;
const PER_RECORD = 3; // the same record can be disputed 3× an hour; repeats coalesce anyway
const PER_CLIENT = 40;
const hits = new Map<string, number[]>();

function rateLimited(key: string, max: number): boolean {
  const now = Date.now();
  const prev = (hits.get(key) || []).filter((t) => now - t < WINDOW_MS);
  if (prev.length >= max) {
    hits.set(key, prev);
    return true;
  }
  prev.push(now);
  hits.set(key, prev);
  return false;
}

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    const text = await req.text();
    if (text.length > MAX_BODY) return NextResponse.json({ error: "body too large" }, { status: 413 });
    body = JSON.parse(text);
  } catch {
    return NextResponse.json({ error: "invalid JSON body" }, { status: 400 });
  }

  const recordType = String(body.record_type ?? "");
  const recordId = String(body.record_id ?? "");
  if (!RECORD_TYPES.has(recordType))
    return NextResponse.json({ error: `record_type must be one of ${[...RECORD_TYPES].join(", ")}` }, { status: 400 });
  if (!ID_RE.test(recordId))
    return NextResponse.json({ error: "record_id is missing or malformed" }, { status: 400 });

  const client = req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "local";
  if (rateLimited(`r:${recordId}`, PER_RECORD) || rateLimited(`c:${client}`, PER_CLIENT))
    return NextResponse.json({ error: "rate limited — this record was disputed recently" }, { status: 429 });

  // stored as data, never executed or rendered back as markup
  const entry = {
    ts: new Date().toISOString(),
    record_type: recordType,
    record_id: recordId,
    field: String(body.field ?? "").slice(0, MAX_FIELD) || null,
    reason: String(body.reason ?? "").slice(0, MAX_REASON),
    reporter: "web-ui",
  };

  try {
    await mkdir(path.dirname(INBOX), { recursive: true });
    await appendFile(INBOX, JSON.stringify(entry) + "\n", "utf8");
  } catch (e) {
    // never report success we didn't achieve — the stub's sin was a green message with no write
    return NextResponse.json({ error: "could not queue the dispute", detail: String(e) }, { status: 503 });
  }
  return NextResponse.json({ ok: true, queued: entry.record_id, pending: await pending() });
}

// GET /api/review — how many disputes are waiting for `dcv review-drain`.
export async function GET() {
  return NextResponse.json({ pending: await pending() });
}

async function pending(): Promise<number> {
  try {
    const text = await readFile(INBOX, "utf8");
    return text.split("\n").filter((l) => l.trim()).length;
  } catch {
    return 0;
  }
}

import { NextResponse } from "next/server";
import { readFile } from "node:fs/promises";
import path from "node:path";

// /api/data — the read-model endpoint (plan §4). Today it proxies the same bytes the
// pipeline emits to public/data.json, so the client can fetch either path. Once the
// store is multi-user this handler becomes the seam that queries Postgres + a change
// feed instead of the static file. Kept dynamic so the latest contract is returned.
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const file = path.join(process.cwd(), "public", "data.json");
    const text = await readFile(file, "utf8");
    return new NextResponse(text, {
      headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "no-store",
      },
    });
  } catch (e) {
    return NextResponse.json(
      { error: "data.json unavailable — run `python -m dcv emit` (or pipeline/build_p0_data.py)", detail: String(e) },
      { status: 503 },
    );
  }
}

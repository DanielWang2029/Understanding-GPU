// @ts-nocheck
// Compute Terminal UI runtime — ported from compute-terminal-demo.html, then P1-wired
// to the REAL pipeline graph where the data supports it. Runs once on the client after
// the skeleton is injected. Fed by data.json v1.2 (D). d3 / d3-sankey / MapLibre come
// from npm imports (deps). Every view stays a pure function of the contract.
//
// Data wiring:
//   • Explorer (geography) + Newsfeed → REAL pipeline output: D.datasets.data_center
//     (428), D.datasets.power_project (3.5k), D.edges (547 role edges), D.entities,
//     D.datasets.news (272). Upstream supply-chain asset LAYERS stay illustrative
//     (D.assets), pending the P5 assets connector.
//   • Overview company supply-sankey · Chain Analysis (SPLC) · Price Board → the
//     ILLUSTRATIVE compute-chain seed (D.chain / D.skus / D.prices / D.forwards),
//     because they need financials (P2) + supplier→buyer %COGS/%rev edges (P3) the
//     real role-graph doesn't carry yet. Flagged in the UI as illustrative.
//   • Overview "project value chain" drill → REAL DC role chains (D.edges).
export function initApp(D, deps) {
  const root = deps.root;
  if (!root || root.dataset.dcvInit) return () => {};
  root.dataset.dcvInit = "1";

  const maplibregl = deps.maplibregl;
  const d3 = Object.assign({}, deps.d3, {
    sankey: deps.sankey,
    sankeyLinkHorizontal: deps.sankeyLinkHorizontal,
  });
  const $id = (id) => document.getElementById(id);

  /* ==================== ILLUSTRATIVE compute-chain seed (Overview flow · SPLC · Board) ==================== */
  const LAYERS = D.layers || [];
  const CATLABEL = { foundry: "Foundry", packaging: "Packaging", hbm: "HBM", accelerator: "Accelerator", systems: "Systems", colo: "Colocation", power: "Power", hyperscaler: "Hyperscaler", neocloud: "Neocloud", ai_lab: "AI lab", wholesale_colo: "Wholesale colo", retail_colo: "Retail colo", developer: "Developer", utility: "Utility", enterprise: "Enterprise", other: "Other" };
  const CAT2LAYER = { equipment: "equipment", foundry: "foundry", packaging: "packaging", hbm: "hbm", accelerator: "accelerator", systems: "systems", colo: "datacenter", power: "power", hyperscaler: "cloud", neocloud: "cloud", ai_lab: "enduser" };
  const SENT = {}; // seed entities (financial graph)
  ((D.chain && D.chain.entities) || []).forEach((e) => {
    SENT[e.id] = { name: e.name, layer: e.layer, cat: e.category, ticker: e.ticker, mcap: e.market_cap, rev: e.revenue, cap: e.cap_index, peers: e.peers || [], est: !!e.estimated, mc_est: !!e.mc_estimated, rev_est: !!e.rev_estimated, unit_note: e.unit_note || "" };
  });
  const SUP = ((D.chain && D.chain.edges) || []).map((e) => [e.from, e.to, e.value.pct_cogs, e.value.pct_revenue, e.value]);
  const UP = (D.assets || []).map((a) => [a.id, a.entity, a.layer, a.name, a.region, a.lat, a.lng, a.cap]);
  const SKUS = (D.skus || []).map((s) => [s.id, s.name]);
  const TREND = {};
  (D.skus || []).forEach((s) => (TREND[s.id] = s.trend));
  const PROV = (D.providers || []).map((p) => [p.id, p.name]);
  const PX = {};
  (D.providers || []).forEach((p) => (PX[p.id] = {}));
  (D.prices || []).forEach((pr) => ((PX[pr.provider] = PX[pr.provider] || {})[pr.sku] = pr.usd_per_gpu_hr));
  const TERMMULT = D.price_terms || { on_demand: 1, reserved_1yr: 0.62, spot: 0.48 };
  const FWD = {}, FWD_COVERED = {};
  (D.forwards || []).forEach((f) => { FWD[f.sku] = f.usd_per_gpu_hr; if (f.covered) FWD_COVERED[f.sku] = 1; });

  /* ==================== REAL pipeline graph (Explorer · project drill · Newsfeed) ==================== */
  const DC = ((D.datasets && D.datasets.data_center) || []).map((d) => ({ ...d, dataset: "dc" }));
  const PWR = ((D.datasets && D.datasets.power_project) || []).map((d) => ({ ...d, dataset: "power" }));
  const REDGES = D.edges || [];
  const RENT = {};
  (D.entities || []).forEach((e) => (RENT[e.id] = e));
  const NEWS = (D.datasets && D.datasets.news) || [];
  const FEEDS = Object.fromEntries((D.feeds || []).map((f) => [f.id, f.name]));
  const DCBYID = Object.fromEntries(DC.map((d) => [d.id, d]));
  const NAME_BY_ID = {};
  [...DC, ...PWR].forEach((d) => (NAME_BY_ID[d.id] = d.project_name));
  const CHAIN_PROJECTS = [...new Set(REDGES.map((e) => e.project))].filter((id) => DCBYID[id]);

  /* ==================== shared utils ==================== */
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const layerColor = (id) => getComputedStyle(document.documentElement).getPropertyValue("--L-" + id).trim() || "#888";
  const layerLabel = (id) => (LAYERS.find((l) => l.id === id) || {}).label || id;
  const fmt = (n) => (n == null ? "—" : n.toLocaleString());
  const money = (n) => (n == null ? "—" : "$" + (n >= 1e9 ? (n / 1e9).toFixed(1) + "B" : (n / 1e6).toFixed(0) + "M"));
  const catLabel = (c) => CATLABEL[c] || c || "—";
  const CATCOLOR = { hyperscaler: "#007aff", neocloud: "#af52de", wholesale_colo: "#34c759", retail_colo: "#30b0c7", developer: "#ff9500", utility: "#8e8e93", enterprise: "#a2845e", ai_lab: "#ff2d55", other: "#aeaeb2" };
  // Every value of the schema's `status` enum is matched EXPLICITLY. The old form fell through
  // to "pl" for anything it didn't recognise, which silently repainted all 31 "On hold" rows as
  // Planned — a fall-through default that invents a status is the map equivalent of inventing a
  // number. An unrecognised status now reads as unknown rather than borrowing another's colour.
  const statusToken = (s) => {
    s = (s || "").toLowerCase();
    if (s.startsWith("oper")) return "op";
    if (s.includes("under")) return "uc";
    if (s.includes("cancel") || s.includes("retire")) return "ca";
    if (s.includes("hold")) return "oh";
    if (s.startsWith("plan")) return "pl";
    return "un";
  };
  const STATUS_COLOR = { op: "#34c759", uc: "#007aff", pl: "#ff9500", ca: "#8e8e93", oh: "#af52de", un: "#c7c7cc" };
  const STATUS_LABEL = { op: "Operating", uc: "Under construction", pl: "Planned", ca: "Cancelled / retired", oh: "On hold", un: "Status unknown" };
  const statusColor = (s) => STATUS_COLOR[statusToken(s)];
  // ONE scale for both layers. The old code divided data-center MW by 10 and power MW by 40
  // before the sqrt, so the same 100 MW drew a data-center dot with 1.7x the area of a power
  // dot — two different rulers on one map, with no legend to reveal it.
  const R_BASE = 3.5;
  const radiusForMw = (mw) => (mw ? R_BASE + Math.sqrt(mw) / 4.5 : R_BASE);
  const isCentroid = (p) => !!p && p !== "exact";
  const PRECISION_LABEL = { exact: "site coordinates", city: "city centroid", county: "county centroid", state: "state centroid" };
  const isConfirmed = (d) => d.confidence != null && d.confidence >= 0.75;
  const RELLABEL = { develops: "Develops", operates: "Operates", leases_to: "Leases to (tenant)", provides_compute: "Provides compute", serves: "Serves (end-user)", powers: "Powers" };
  const ageDays = (iso) => { if (!iso) return null; const a = Math.round((new Date(D.generated_at) - new Date(iso)) / 864e5); return isNaN(a) ? null : a; };
  function sourceMeta(url) {
    const u = (url || "").toLowerCase();
    const dom = (url || "").replace(/^https?:\/\//, "").split("/")[0].replace(/^www\./, "");
    let type = "trade press", trust = 0.75;
    if (/eia\.gov|census\.gov|ercot\.com|caiso\.com|misoenergy|spp\.org|pjm\.com|nyiso|iso-ne/.test(u)) { type = "gov/iso"; trust = 1.0; }
    else if (/sec\.gov/.test(u)) { type = "SEC"; trust = 0.95; }
    else if (/permit|planning|zoning/.test(u)) { type = "permit"; trust = 0.9; }
    else if (/\/investor|ir\.|openai\.com|corescientific\.com|entergy\.com/.test(u)) { type = "company"; trust = 0.7; }
    else if (/cleanview\.co|orennia|belfercenter|interconnection\.fyi|peeringdb/.test(u)) { type = "research/dir"; trust = 0.75; }
    return { dom, type, trust };
  }
  const TRUSTCOLOR = (t) => (t >= 0.95 ? "#34c759" : t >= 0.85 ? "#007aff" : t >= 0.7 ? "#ff9500" : "#8e8e93");
  const REGION = { TX: "Texas", CA: "West", NV: "West", AZ: "West", OR: "West", WA: "West", UT: "West", CO: "West", NM: "West", ID: "West", MT: "West", WY: "West", HI: "West", AK: "West", IL: "Midwest", IN: "Midwest", IA: "Midwest", KS: "Midwest", MI: "Midwest", MN: "Midwest", MO: "Midwest", NE: "Midwest", ND: "Midwest", OH: "Midwest", SD: "Midwest", WI: "Midwest", AL: "South", AR: "South", FL: "South", GA: "South", KY: "South", LA: "South", MS: "South", NC: "South", OK: "South", SC: "South", TN: "South", VA: "South", WV: "South", MD: "South", DE: "South", CT: "Northeast", ME: "Northeast", MA: "Northeast", NH: "Northeast", NJ: "Northeast", NY: "Northeast", PA: "Northeast", RI: "Northeast", VT: "Northeast" };

  function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function mul(a) { return function () { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function series(seed, tr) { const r = mul(seed); let v = 1; const a = []; for (let i = 0; i < 30; i++) { v *= 1 + tr + (r() - 0.5) * 0.03; a.push(v); } return a; }
  const $B = (v) => (v >= 1000 ? "$" + (v / 1000).toFixed(1) + "T" : "$" + Math.round(v) + "B");
  function sparkline(s, down) { const w = 52, h = 16, p = 2, mn = Math.min(...s), mx = Math.max(...s), r = mx - mn || 1; const pts = s.map((v, i) => (p + (i / (s.length - 1)) * (w - 2 * p)).toFixed(1) + "," + (h - p - ((v - mn) / r) * (h - 2 * p)).toFixed(1)).join(" "); const c = down ? "var(--op)" : "var(--pl)"; return `<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><polyline points="${pts}" fill="none" stroke="${c}" stroke-width="1.5" stroke-linejoin="round" opacity=".85"/></svg>`; }

  let WEIGHT = "mcap", GROUP = "company", central = SENT["nvidia"] ? "nvidia" : Object.keys(SENT)[0];

  /* ==================== OVERVIEW: company supply sankey (seed) ==================== */
  // sankey column index. `equipment` (Band 2 #1) sits upstream of the foundries that buy from
  // it, so every downstream stage shifts one right.
  const STAGE = { equipment: 0, foundry: 1, packaging: 1, hbm: 1, accelerator: 2, systems: 3, power: 3, colo: 3, neocloud: 4, hyperscaler: 4, ai_lab: 5 };
  function buildGraph() {
    const key = (id) => (GROUP === "company" ? id : SENT[id].cat);
    const nodeLayer = (k) => (GROUP === "company" ? SENT[k].layer : CAT2LAYER[k]);
    const colOf = (k) => STAGE[GROUP === "company" ? SENT[k].cat : k];
    const wOf = (id) => SENT[id][WEIGHT] || 1;
    const nodeSet = {}, linkMap = {};
    SUP.forEach(([s, b, cogs, rev]) => {
      // `!(rev > 0)` (not `rev <= 0`) so a DISCOVERED topology edge with no magnitude yet
      // (undefined) is skipped rather than producing a NaN link width. Such edges still show
      // in the SPLC as "—": we know who supplies whom, not yet how much.
      if (!(rev > 0)) return;
      const ks = key(s), kb = key(b); if (ks === kb) return;
      if (colOf(kb) <= colOf(ks)) return;
      nodeSet[ks] = 1; nodeSet[kb] = 1;
      const val = wOf(s) * (rev / 100);
      const kk = ks + "|" + kb; linkMap[kk] = (linkMap[kk] || 0) + val;
    });
    const ids = Object.keys(nodeSet);
    // Compact STAGE indices to contiguous 0..n-1 depths. d3-sankey indexes its column array by
    // depth, so a GAP (or a run that doesn't start at 0) throws "flow layout error". That is
    // not hypothetical: `equipment` occupies STAGE 0 but every equipment edge is currently
    // named-without-magnitude, so the whole column drops out of the graph and the used depths
    // start at 1. Any layer can go unquantified, so normalize rather than assume a dense range.
    const used = [...new Set(ids.map(colOf))].sort((a, b) => a - b);
    const depth = new Map(used.map((c, i) => [c, i]));
    const nodes = ids.map((id) => ({ id, name: GROUP === "company" ? SENT[id].name : CATLABEL[id] || id, lyr: nodeLayer(id), col: depth.get(colOf(id)) }));
    const idx = {}; nodes.forEach((n, i) => (idx[n.id] = i));
    const links = Object.keys(linkMap).map((k) => { const [a, b] = k.split("|"); return { source: idx[a], target: idx[b], value: linkMap[k] }; });
    return { nodes, links };
  }
  function renderSankey() {
    const el = $id("sankey"); if (!el) return; el.innerHTML = "";
    const W = el.clientWidth || 1000, H = 430;
    const g = buildGraph();
    if (!g.nodes.length) { el.innerHTML = '<p class="muted">no flows</p>'; return; }
    if (typeof d3.sankey !== "function") { el.innerHTML = '<p class="muted">flow chart needs d3-sankey</p>'; return; }
    const sankey = d3.sankey().nodeWidth(13).nodePadding(11).nodeAlign((node) => node.col).extent([[4, 8], [W - 4, H - 8]]);
    let graph; try { graph = sankey({ nodes: g.nodes.map((d) => Object.assign({}, d)), links: g.links.map((d) => Object.assign({}, d)) }); }
    catch (e) { el.innerHTML = '<p class="muted">flow layout error</p>'; return; }
    const svg = d3.select(el).append("svg").attr("class", "sankey").attr("height", H).attr("viewBox", `0 0 ${W} ${H}`);
    svg.append("g").selectAll("path").data(graph.links).join("path").attr("class", "slink")
      .attr("d", d3.sankeyLinkHorizontal()).attr("stroke", (d) => layerColor(d.source.lyr)).attr("stroke-width", (d) => Math.max(1, d.width))
      .append("title").text((d) => `${d.source.name} → ${d.target.name}`);
    const node = svg.append("g").selectAll("g").data(graph.nodes).join("g").attr("class", "snode");
    node.append("rect").attr("x", (d) => d.x0).attr("y", (d) => d.y0).attr("height", (d) => Math.max(1, d.y1 - d.y0)).attr("width", (d) => d.x1 - d.x0)
      .attr("fill", (d) => layerColor(d.lyr)).attr("rx", 2)
      .style("cursor", GROUP === "company" ? "pointer" : "default")
      .on("click", (e, d) => { if (GROUP === "company") goChain(d.id); })
      .append("title").text((d) => `${d.name}`);
    node.append("text").attr("x", (d) => (d.x0 < W / 2 ? d.x1 + 5 : d.x0 - 5)).attr("y", (d) => (d.y0 + d.y1) / 2).attr("dy", ".35em")
      .attr("text-anchor", (d) => (d.x0 < W / 2 ? "start" : "end")).text((d) => d.name).style("cursor", GROUP === "company" ? "pointer" : "default")
      .on("click", (e, d) => { if (GROUP === "company") goChain(d.id); });
  }

  /* ==================== CHAIN ANALYSIS: SITE DOSSIER (REAL role edges) ====================
     Replaces the old Overview "project value chain" role-flow, which worked on 9 of 424
     edge-bearing sites (2.1%): it was designed against a 10-row seed where all four roles were
     filled, so against the real graph — 1.11 edges per DC — 82.8% rendered "— not yet mapped"
     on one side and 11.1% showed the same org on both. Worse, it reported a STRUCTURAL fact
     (retail colo has no single tenant) as our own data gap. The dossier keeps the role-flow as
     an A/B toggle but leads with two bands that hold on sparse data:
       1 · Deal shape      — how many distinct parties, and how rare that is across the base
       2 · Chain position  — what this site's participants buy upstream, via the backbone
     Every count below is measured off the live read-model or the gate-checked rollups; nothing
     about coverage is hardcoded. */
  let selProject = null, SDMODE = "dossier";
  const ROLELBL = { develops: "develops", powers: "powers", operates: "operates", leases_to: "tenant", provides_compute: "compute", serves: "end-user" };
  const SUPRELS = ["develops", "powers"], DEMRELS = ["operates", "leases_to", "provides_compute", "serves"];
  const CSUP = (D.chain && D.chain.edges) || [];
  const EDGES_BY_PROJ = {}; REDGES.forEach((e) => (EDGES_BY_PROJ[e.project] = EDGES_BY_PROJ[e.project] || []).push(e));
  // sites ordered by capacity — the select, and the default selection, both follow it
  const SDLIST = CHAIN_PROJECTS.slice().sort((a, b) => (DCBYID[b].capacity_mw || 0) - (DCBYID[a].capacity_mw || 0));
  const nParties = (d) => new Set([d.developer, d.operator, d.tenant, d.end_user].filter(Boolean).map((x) => x.trim().toLowerCase())).size;
  // distribution of distinct counterparties across the whole tracked base — the denominator
  // that turns "this site has 2 parties" into "only N of M sites do".
  const DIST = [0, 0, 0, 0]; DC.forEach((d) => { const n = nParties(d); if (n >= 1 && n <= 4) DIST[n - 1]++; });
  // Prefer the pipeline's own gate-checked rollup (validate.py gate 8 blocks publish if it
  // disagrees with the records); fall back to computing it if an older data.json lacks it.
  const RC = (D.meta && D.meta.rollups && D.meta.rollups.dc_role_coverage) || {};
  const isRetail = (d) => !d.developer_category || d.developer_category === "retail_colo";
  const NA_TENANT = (RC.not_applicable && RC.not_applicable.tenant) ?? DC.filter(isRetail).length;
  const ELIG_TENANT = (RC.eligible && RC.eligible.tenant) ?? DC.filter((d) => !isRetail(d)).length;
  const ELIG_FILLED = (RC.eligible_filled && RC.eligible_filled.tenant) ?? DC.filter((d) => !isRetail(d) && d.tenant).length;
  // sites whose participants include at least one of the chain-backbone companies — i.e. the
  // sites for which band 2 has anything at all to show
  const BACKBONE_SITES = SDLIST.filter((id) => (EDGES_BY_PROJ[id] || []).some((e) => SENT[e.org])).length;

  /* ---- A: the ORIGINAL role-flow, kept as an A/B toggle ---- */
  function renderRoleflow(d) {
    const es = EDGES_BY_PROJ[d.id] || [];
    const cards = (rels) => {
      const m = {};
      es.filter((e) => rels.includes(e.relation)).forEach((e) => { const o = (m[e.org] = m[e.org] || { roles: [], conf: [], src: null }); o.roles.push(ROLELBL[e.relation] || e.relation); o.conf.push(e.confidence); if (!o.src) o.src = (e.sources || [])[0]; });
      return Object.entries(m).map(([id, i]) => {
        const en = RENT[id] || { name: id, category: "other" }; const c = i.conf.reduce((a, b) => a + b, 0) / i.conf.length;
        return `<div class="vc-org" style="cursor:default"><b><span class="ld" style="background:${CATCOLOR[en.category] || "#8e8e93"}"></span>${esc(en.name)}</b><div class="vc-roles">${esc(catLabel(en.category))} · ${i.roles.join(" · ")}</div><div class="muted" style="font-size:11px;margin-top:2px">conf ${c.toFixed(2)}${i.src ? ` · <a href="${esc(i.src)}" target="_blank" rel="noopener">src ↗</a>` : ""}</div></div>`;
      }).join("") || '<span class="muted" style="font-style:italic;font-size:11.5px">— not yet mapped</span>';
    };
    const hasS = es.some((e) => SUPRELS.includes(e.relation)), hasD = es.some((e) => DEMRELS.includes(e.relation));
    const note = hasS && hasD ? "" : `<div class="muted" style="font-style:italic;font-size:11px;margin-top:5px">${hasS ? "operator &amp; tenant" : "developer &amp; power"} — not yet mapped</div>`;
    return `<div class="vc-sum" style="font-size:13px;background:var(--panel-2);border:.5px solid var(--line);border-radius:10px;padding:9px 12px;margin-bottom:12px;line-height:1.5">${esc(d.project_name)}</div>
      <div class="vc-flow"><div class="vc-side"><div class="vc-h">Builds &amp; powers</div>${cards(SUPRELS)}</div>
        <div class="vc-proj"><div class="vc-h">Project</div><div class="vc-projcard"><b>${esc(d.project_name)}</b><div style="opacity:.7;font-size:11px;margin-top:3px">${d.capacity_mw != null ? d.capacity_mw + " MW" : "— MW"} · ${esc(d.status)} · ${esc(d.state || "")}</div>${note}</div></div>
        <div class="vc-side"><div class="vc-h">Runs &amp; consumes</div>${cards(DEMRELS)}</div></div>`;
  }

  /* ---- B: the SITE DOSSIER ---- */
  function sdDist(active) {
    const t = DC.length, mx = Math.max(...DIST, 1);
    const rows = DIST.map((c, i) => {
      const on = i + 1 === active;
      // labeled horizontal bars, not one proportional stacked strip: the distribution is ~90%
      // concentrated in the first bucket, so segment labels for the other three were slivers
      return `<div class="sd-row ${on ? "on" : ""}"><div class="sd-rl">${i + 1} part${i ? "ies" : "y"}</div>
        <div class="sd-rt"><i style="width:${Math.max((c / mx) * 100, c ? 0.7 : 0)}%"></i></div>
        <div class="sd-rv">${c}<span class="muted" style="font-weight:400"> · ${((c / t) * 100).toFixed(1)}%</span></div></div>`;
    }).join("");
    return `<div class="sd-dist">${rows}
      <div class="muted" style="font-size:11px;margin-top:8px">Distinct organisations across developer · operator · tenant · end-user, over all ${t} tracked sites. This site is highlighted.</div></div>`;
  }
  // Three DISTINCT absence states, never one "—": structurally inapplicable, applicable but
  // unextracted, and present. Reporting the first as a data gap was the old panel's real bug.
  function sdRoleAbsence(d) {
    const out = []; const retail = isRetail(d);
    if (!d.tenant) out.push(retail
      ? `<span class="k">by construction</span><span>Multi-tenant ${esc(catLabel(d.developer_category)).toLowerCase()} — many customers, no single one. A scalar <code>tenant</code> has nothing to hold here; <b>${NA_TENANT} of ${DC.length}</b> sites are in this class. This is not a gap we can close.</span>`
      : `<span class="k">not extracted</span><span>Tenant-eligible but unresolved — needs discovery spend, not a bug fix. <b>${ELIG_FILLED} of ${ELIG_TENANT}</b> eligible sites carry a tenant today.</span>`);
    if (!d.end_user && !retail) out.push(`<span class="k">not extracted</span><span>End-user unresolved on a tenant-eligible site.</span>`);
    return out.length ? out.map((o) => `<div class="sd-abs" style="margin-top:9px">${o}</div>`).join("") : "";
  }
  function sdChain(d) {
    const es = EDGES_BY_PROJ[d.id] || [];
    const ids = [...new Set(es.map((e) => e.org))].filter((id) => SENT[id]);
    if (!ids.length) return `<div class="sd-abs"><span class="k">out of scope</span><span>No participant here is one of the ${Object.keys(SENT).length} companies in the financial chain backbone — this is a regional operator, so there is no upstream to climb. <b>${BACKBONE_SITES} of ${SDLIST.length}</b> edge-bearing sites do have such a participant.</span></div>`;
    return ids.map((id) => {
      const e = SENT[id];
      const sup = CSUP.filter((x) => x.to === id).sort((a, b) => ((b.value || {}).pct_cogs || 0) - ((a.value || {}).pct_cogs || 0)).slice(0, 5);
      const rows = sup.length ? sup.map((x) => {
        const v = x.value || {}, f = SENT[x.from] || { name: x.from };
        const hook = SENT[x.from] ? ` data-sup="${esc(x.from)}" style="cursor:pointer" title="Re-center the chain map on ${esc(f.name)}"` : "";
        // magnitude and link carry separate provenance — a named-but-unquantified edge must not
        // borrow the DISCLOSED badge from a % it doesn't have
        const badge = v.pct_cogs == null
          ? (v.topology_basis === "named" ? '<span class="badge b-disc" title="relationship named in the buyer\'s filing">named link</span>' : "")
          : `<span class="badge ${v.cogs_basis === "disclosed" ? "b-disc" : "b-est"}">${v.cogs_basis === "disclosed" ? "DISCLOSED" : "EST"}</span>`;
        return `<div class="sd-sup"${hook}><span class="ld" style="background:${layerColor(CAT2LAYER[f.cat] || f.layer || "systems")}"></span>
          <div><b style="font-size:12.5px">${esc(f.name)}</b> ${badge}<div class="muted" style="font-size:10.5px">${esc(layerLabel(f.layer) || "—")}${v.as_of ? " · as of " + esc(v.as_of) : ""}</div></div>
          <div class="pc">${v.pct_cogs != null ? v.pct_cogs + "%" : "—"}<div class="muted" style="font-size:10px;font-weight:400">${v.pct_cogs != null ? "of COGS" : "not quantified"}</div></div></div>`;
      }).join("")
        : `<div class="sd-abs"><span class="k">no edges</span><span>${esc(e.name)} is in the backbone but has no filing-evidenced suppliers yet.</span></div>`;
      return `<div style="margin-bottom:12px"><div style="font-size:12.5px;margin-bottom:8px">Via <b>${esc(e.name)}</b> — its disclosed suppliers:</div>${rows}</div>`;
    }).join("");
  }
  function renderDossier(d) {
    const es = EDGES_BY_PROJ[d.id] || [], n = nParties(d), share = ((DIST[n - 1] / DC.length) * 100).toFixed(1);
    const shape = { 1: "Single-party self-build", 2: "Two-party structure", 3: "Three-party structure", 4: "Four-party structure" }[n] || "No roles resolved";
    const lede = n <= 1
      ? `<b>${DIST[0]} of ${DC.length}</b> tracked sites (${((DIST[0] / DC.length) * 100).toFixed(1)}%) are single-party — one company in every role. That concentration <i>is</i> the market-structure finding; it is not a missing-data problem.`
      // the "…and N have three or more" clause only earns its place when it says something the
      // first half didn't — otherwise a 3-party site reads "14 … — 14 have three or more"
      : `Only <b>${DIST[n - 1]} of ${DC.length}</b> sites (${share}%) have ${n} distinct counterparties${DIST[2] + DIST[3] > DIST[n - 1] ? `; <b>${DIST[2] + DIST[3]}</b> have three or more` : ""}. This is a rare, information-dense structure.`;
    const orgs = {}; es.forEach((e) => { const o = (orgs[e.org] = orgs[e.org] || { roles: [], conf: [] }); o.roles.push(ROLELBL[e.relation] || e.relation); o.conf.push(e.confidence); });
    const chips = Object.entries(orgs).map(([id, i]) => {
      const en = RENT[id] || { name: id, category: "other" };
      return `<div class="sd-chip"><b><span class="ld" style="background:${CATCOLOR[en.category] || "#8e8e93"}"></span>${esc(en.name)}</b><div class="r">${i.roles.join(" · ")} · conf ${(i.conf.reduce((a, b) => a + b, 0) / i.conf.length).toFixed(2)}</div></div>`;
    }).join("") || '<span class="muted" style="font-size:12px;font-style:italic">no edges on this site</span>';
    const ok = d.review_status === "approved";
    return `<div class="sd-hd"><span class="sd-nm">${esc(d.project_name)}</span>
        <span class="sd-meta">${d.capacity_mw != null ? "<b>" + fmt(d.capacity_mw) + "</b> MW" : "capacity unknown"} · ${esc(d.status)} · ${esc([d.county, d.state].filter(Boolean).join(", "))}${d.operating_year ? " · online " + esc(d.operating_year) : ""}</span>
        <span class="conf ${ok ? "c-hi" : "c-lo"}" style="margin-left:auto">${Math.round((d.confidence || 0) * 100)}% · ${esc(d.review_status || "—")}</span></div>
      <div class="muted" style="font-size:11.5px;margin-top:4px">${(d.sources || []).length} source${(d.sources || []).length === 1 ? "" : "s"}${d.last_verified ? " · verified " + esc(d.last_verified) : ""} · ${esc(catLabel(d.developer_category))}</div>

      <div class="sd-band"><div class="sd-bh">1 · Deal shape</div>
        <div class="sd-shape">${shape}</div><div class="sd-lede">${lede}</div>
        <div class="sd-chips">${chips}</div>${sdRoleAbsence(d)}${sdDist(n)}</div>

      <div class="sd-band"><div class="sd-bh">2 · Position in the compute chain</div>${sdChain(d)}</div>`;
  }

  function renderProject() {
    const el = $id("projchain"); if (!el) return;
    const d = DCBYID[selProject] || DCBYID[SDLIST[0]];
    if (!d) { el.innerHTML = '<div class="sd-load">no mapped site chains</div>'; return; }
    el.innerHTML = SDMODE === "dossier" ? renderDossier(d) : renderRoleflow(d);
    /* band 2 → re-center the SPLC further up this same tab (no navigation) */
    root.querySelectorAll("#projchain [data-sup]").forEach((x) => (x.onclick = () => {
      central = x.dataset.sup; $id("central-sel").value = central; renderChain();
      $id("central").closest(".card").scrollIntoView({ behavior: "smooth", block: "start" });
    }));
    renderRail();
  }
  function sdSelect(id) { if (!DCBYID[id]) return; selProject = id; const s = $id("proj-sel"); if (s) s.value = id; renderProject(); }

  /* ==================== CHAIN ANALYSIS (SPLC, seed) ==================== */
  let qOnly = false;
  // The DISCLOSED/EST badge describes the ENTITY value shown ($ market cap / revenue for
  // the active weight) — NOT the seed edge % (which is illustrative until P3). Binding it to
  // the edge flag was the review's C1 bug (real disclosed $4.2T rendered "EST").
  const metricEst = (id) => (WEIGHT === "cap" ? true : WEIGHT === "rev" ? SENT[id].rev_est : SENT[id].mc_est);
  const valueBadge = (id) => (metricEst(id) ? '<span class="badge b-est">EST</span>' : '<span class="badge b-disc">DISCLOSED</span>');
  // Right side (the edge %) carries the EDGE metric's own provenance, distinct from the
  // left value badge (provenance-rendering: mixed sources labelled separately). %COGS/%rev
  // basis is disclosed|estimated; a disclosed % links to its filing; inferred counterparty flagged.
  function edgeProv(ev, metric) {
    const b = ev && ev[metric + "_basis"];
    const disc = b === "disclosed";
    // A DISCOVERED topology edge names a real relationship whose magnitude isn't quantified yet.
    // Showing "est" there would imply we hold an estimate we don't — say so plainly instead,
    // while still surfacing the named-counterparty evidence.
    const pct = ev && ev[metric === "cogs" ? "pct_cogs" : "pct_revenue"];
    if (ev && pct == null && ev.topology_basis === "named") {
      const ls0 = ev.link_sources && ev.link_sources[0];
      const who0 = ls0 && ls0.url ? ` <a href="${ls0.url}" target="_blank" rel="noopener" title="${(ls0.type || "").replace(/_/g, " ")}">who↗</a>` : "";
      return `<span class="muted">not quantified</span> · <span class="badge b-disc" title="relationship named in the buyer's filing">named link</span>${who0}`;
    }
    // link half (L2 / L2-identity): inferred → flagged; named → counterparty named by a
    // buyer filing / press, with a who↗ to the naming source (distinct from the magnitude src↗).
    let link = "";
    if (ev && ev.link_basis === "inferred") link = ' · <span class="muted">inferred link</span>';
    else if (ev && ev.link_basis === "named") {
      const ls = ev.link_sources && ev.link_sources[0];
      const who = ls && ls.url ? ` <a href="${ls.url}" target="_blank" rel="noopener" title="${(ls.type || "").replace(/_/g, " ")}">who↗</a>` : "";
      link = ` · <span class="badge b-disc" title="counterparty named by buyer filing / press">named link</span>${who}`;
    }
    const src = disc && ev.sources && ev.sources[0] ? ` · <a href="${ev.sources[0]}" target="_blank" rel="noopener">src↗</a>` : "";
    // cross-vendor verdict (chain_quant L2): confirmed → ✓ cross-verified; needs_review → ⚠
    let v = "";
    if (ev && ev.review_status === "confirmed") v = ' · <span class="badge b-disc" title="cross-vendor confirmed">✓ verified</span>';
    else if (ev && ev.review_status === "needs_review") v = ` · <span class="muted" title="cross-vendor: link uncertain${ev.link_confidence != null ? ", conf " + ev.link_confidence : ""}">⚠ review</span>`;
    return `${disc ? '<span class="badge b-disc">disclosed</span>' : '<span class="muted">est</span>'}${link}${src}${v}`;
  }
  function nodeCard(id, pct, basis, ev, metric) { const e = SENT[id]; const c = layerColor(e.layer); const wv = e[WEIGHT];
    return `<div class="node" data-e="${id}"><span class="ld" style="background:${c}"></span>
      <div><div class="nm">${e.name}${valueBadge(id)}</div>
      <div class="sm">${e.ticker} · ${layerLabel(e.layer)} · ${WEIGHT === "cap" ? wv + " cap" : $B(wv)}${e.unit_note ? ` · <span class="muted">${e.unit_note}</span>` : ""}</div></div>
      <div class="rt"><div class="pct">${pct != null ? pct + "%" : "—"}</div><div class="sm">${basis} · ${edgeProv(ev, metric)}</div>
      <div class="bar"><i style="width:${Math.min(100, pct || 0)}%;background:${c}"></i></div></div></div>`; }
  function renderChain() {
    const e = SENT[central]; if (!e) return;
    const lbl = WEIGHT === "cap" ? "capacity index (illustrative)" : WEIGHT === "mcap" ? (metricEst(central) ? "est. valuation" : "market cap") : (metricEst(central) ? "est. revenue" : "revenue");
    $id("central").innerHTML = `<div class="cn">${e.name}</div><div class="cm">${e.ticker} · ${layerLabel(e.layer)}</div><div class="mc">${WEIGHT === "cap" ? e.cap + " cap" : $B(e[WEIGHT])}</div><div class="sm muted">${lbl}${e.unit_note ? ` · ${e.unit_note}` : ""}</div>`;
    // `|| 0` keeps magnitude-less discovered topology edges sortable (they sink to the bottom)
    let sup = SUP.filter((x) => x[1] === central).sort((a, b) => (b[2] || 0) - (a[2] || 0));
    let cus = SUP.filter((x) => x[0] === central).sort((a, b) => (b[3] || 0) - (a[3] || 0));
    if (qOnly) { sup = sup.filter((x) => x[2] > 0); cus = cus.filter((x) => x[3] > 0); }
    $id("suppliers").innerHTML = sup.length ? sup.map((x) => nodeCard(x[0], x[2], "% of COGS", x[4], "cogs")).join("") : '<div class="sm muted" style="text-align:center;padding:10px">no mapped suppliers</div>';
    $id("customers").innerHTML = cus.length ? cus.map((x) => nodeCard(x[1], x[3], "% of revenue", x[4], "rev")).join("") : '<div class="sm muted" style="text-align:center;padding:10px">no mapped customers</div>';
    $id("peers").innerHTML = (e.peers || []).filter((p) => SENT[p]).map((p) => `<span class="peer" data-e="${p}"><span class="ld" style="background:${layerColor(SENT[p].layer)}"></span>${SENT[p].name}</span>`).join("");
    root.querySelectorAll("#suppliers .node,#customers .node,#peers .peer").forEach((el) => (el.onclick = () => { central = el.dataset.e; $id("central-sel").value = central; renderChain(); }));
    renderRail(); // the centred company is half the rail's context
  }
  function goChain(id) { if (!SENT[id]) return; central = id; $id("central-sel").value = id; switchView("chain"); renderChain(); closeDrawer(); }

  /* ==================== EXPLORER (REAL data centers + power + illustrative asset layers) ==================== */
  // Layer chips are an ISOLATE filter, not a row of independent on/off switches. Default is
  // everything on; clicking a layer narrows to just it; clicking the active one restores all.
  // Independent toggling stays available on shift/⌘-click for building a custom subset.
  // The TABLE follows the layers — previously the chips moved the map only, and a separate
  // segmented control moved the table, so isolating "Foundry" left a table of data centers.
  let map = null, expLayers = null, tblMode = "dc";   // expLayers seeded from the data at init
  let expF = { q: "", state: "all", status: "all", type: "all", minmw: 0, btm: false };
  const UPSTREAM = new Set(["equipment", "foundry", "packaging", "hbm", "accelerator", "systems", "cloud", "enduser"]);
  const tableOfLayer = (id) => (id === "datacenter" ? "dc" : id === "power" ? "power" : "asset");
  const TABLE_LABEL = { dc: "Data centers", power: "Power", asset: "Upstream assets" };
  // counted AFTER the search/state/status/MW filters, so a chip says how many points it will
  // actually put on the map rather than how many exist in the dataset
  function layerCounts() {
    const dcIds = new Set(dcFiltered().map((p) => p.id)), pwIds = new Set(powerFiltered().map((p) => p.id));
    const c = {};
    allMapAssets().forEach((a) => {
      if (a.layer === "datacenter" && !dcIds.has(a.id)) return;
      if (a.layer === "power" && !pwIds.has(a.id)) return;
      c[a.layer] = (c[a.layer] || 0) + 1;
    });
    return c;
  }
  const allLayerIds = () => LAYERS.map((l) => l.id).filter((id) => layersPresent.has(id));
  let layersPresent = new Set();   // layers the data actually has, computed once at init
  function tablesVisible() {
    const t = [];
    if (expLayers.has("datacenter")) t.push("dc");
    if (expLayers.has("power")) t.push("power");
    if ([...expLayers].some((l) => UPSTREAM.has(l))) t.push("asset");
    return t;
  }
  function setLayers(next) {
    // never allow an empty selection — an empty map with no way back is a dead end
    expLayers = next.size ? next : new Set(allLayerIds());
    const vis = tablesVisible();
    if (!vis.includes(tblMode)) { tblMode = vis[0] || "dc"; }
    renderExpLayers(); renderExpFilters(); renderExpTable(); refreshMap();
  }
  function dcFiltered() {
    return DC.filter((p) => (!expF.q || (p.project_name + " " + (p.developer || "")).toLowerCase().includes(expF.q)) && (expF.state === "all" || p.state === expF.state) && (expF.status === "all" || p.status === expF.status) && (expF.type === "all" || p.developer_category === expF.type) && (p.capacity_mw || 0) >= expF.minmw);
  }
  function powerFiltered() {
    return PWR.filter((p) => (!expF.q || (p.project_name + " " + (p.developer || "")).toLowerCase().includes(expF.q)) && (expF.state === "all" || p.state === expF.state) && (expF.status === "all" || p.status === expF.status) && (expF.type === "all" || p.technology === expF.type) && (p.capacity_mw || 0) >= expF.minmw && (!expF.btm || p.btm));
  }
  function uniqSort(a) { return [...new Set(a)].filter(Boolean).sort(); }
  function optHTML(v, cur) { return `<option value="${v}" ${v === cur ? "selected" : ""}>${v === "all" ? "All" : v}</option>`; }
  function renderExpFilters() {
    const isAsset = tblMode === "asset", isDC = tblMode === "dc", rows = isDC ? DC : PWR;
    // The upstream asset layers carry none of these fields, and `expFeatures` deliberately
    // leaves them unfiltered — so showing live-looking controls over them would be a lie.
    $id("expfilters").style.display = isAsset ? "none" : "flex";
    $id("exp-asset-note").style.display = isAsset ? "block" : "none";
    if (isAsset) return;
    // Preserve a still-valid selection across a table switch. Blanket-resetting all three (the
    // old behaviour) now fires whenever a layer click changes the table, silently wiping a
    // filter the user set.
    const states = uniqSort(rows.map((p) => p.state));
    const statuses = uniqSort(rows.map((p) => p.status));
    const types = uniqSort(isDC ? DC.map((p) => p.developer_category) : PWR.map((p) => p.technology));
    if (expF.state !== "all" && !states.includes(expF.state)) expF.state = "all";
    if (expF.status !== "all" && !statuses.includes(expF.status)) expF.status = "all";
    if (expF.type !== "all" && !types.includes(expF.type)) expF.type = "all";
    $id("exp-state").innerHTML = ["all", ...states].map((v) => optHTML(v, expF.state)).join("");
    $id("exp-status").innerHTML = ["all", ...statuses].map((v) => optHTML(v, expF.status)).join("");
    $id("exp-type-lbl").textContent = isDC ? "Type" : "Technology";
    $id("exp-type").innerHTML = ["all", ...types].map((v) => `<option value="${v}" ${v === expF.type ? "selected" : ""}>${v === "all" ? "All" : isDC ? catLabel(v) : v}</option>`).join("");
    $id("exp-btm-wrap").style.display = isDC ? "none" : "inline-flex";
  }
  // Only the layers currently shown get a table tab — the control can no longer offer a view
  // of something the map is hiding.
  function renderTableSeg() {
    const vis = tablesVisible();
    $id("tbl-seg").innerHTML = vis.map((t) => `<button data-t="${t}" class="${t === tblMode ? "on" : ""}">${TABLE_LABEL[t]}</button>`).join("");
    root.querySelectorAll("#tbl-seg button").forEach((b) => (b.onclick = () => {
      tblMode = b.dataset.t; renderTableSeg(); renderExpFilters(); renderExpTable();
    }));
  }
  function assetRows() {
    return UP.filter((a) => expLayers.has(a[2]))
      .filter((a) => !expF.q || (a[3] + " " + ((SENT[a[1]] || {}).name || a[1])).toLowerCase().includes(expF.q))
      .sort((a, b) => (b[7] || 0) - (a[7] || 0));
  }
  // `mw` is carried NULLABLE and sized by `radiusForMw`. The old code substituted 60 MW for a
  // data center with no capacity and 40 MW for a power project, so 133 of 398 mapped data
  // centers (33.4%) were drawn at the size of a 60 MW site on the strength of a number nobody
  // recorded. Unknown capacity now draws at the base radius and says so in the legend.
  function allMapAssets() {
    const arr = [];
    UP.forEach((a) => arr.push({ id: a[0], ent: a[1], layer: a[2], name: a[3], region: a[4], lat: a[5], lng: a[6], mw: a[7], prec: "exact", kind: "asset" }));
    DC.forEach((p) => { if (p.lat != null && p.lng != null) arr.push({ id: p.id, layer: "datacenter", name: p.project_name, region: p.state, lat: p.lat, lng: p.lng, mw: p.capacity_mw, prec: p.geo_precision, status: p.status, kind: "dc" }); });
    PWR.forEach((p) => { if (p.lat != null && p.lng != null) arr.push({ id: p.id, layer: "power", name: p.project_name, region: p.state, lat: p.lat, lng: p.lng, mw: p.capacity_mw, prec: p.geo_precision, status: p.status, kind: "power" }); });
    return arr;
  }
  function mapStyle() { const dark = (document.documentElement.getAttribute("data-theme") || (matchMedia("(prefers-color-scheme:dark)").matches ? "dark" : "light")) === "dark"; const t = dark ? "dark_all" : "light_all"; return { version: 8, sources: { c: { type: "raster", tiles: ["https://a.basemaps.cartocdn.com/" + t + "/{z}/{x}/{y}@2x.png", "https://b.basemaps.cartocdn.com/" + t + "/{z}/{x}/{y}@2x.png"], tileSize: 256, attribution: "© OSM © CARTO" } }, layers: [{ id: "bg", type: "raster", source: "c" }] }; }
  function expFeatures() {
    const dcIds = new Set(dcFiltered().map((p) => p.id)), pwIds = new Set(powerFiltered().map((p) => p.id));
    return allMapAssets().filter((a) => {
      if (!expLayers.has(a.layer)) return false;
      if (a.layer === "datacenter") return dcIds.has(a.id);
      if (a.layer === "power") return pwIds.has(a.id);
      return true;
    }).map((a) => ({
      type: "Feature",
      geometry: { type: "Point", coordinates: [a.lng, a.lat] },
      properties: {
        id: a.id, layer: a.layer, name: a.name, region: a.region || "", ent: a.ent || "", kind: a.kind,
        color: a.status ? statusColor(a.status) : layerColor(a.layer),
        r: radiusForMw(a.mw),
        // drives the hollow-ring render below: a centroid is a stand-in for a location, not one
        centroid: isCentroid(a.prec),
        sized: a.mw != null,
      },
    }));
  }
  function addMap() {
    map.addSource("a", { type: "geojson", data: { type: "FeatureCollection", features: expFeatures() } });
    // A CENTROID IS NOT A LOCATION. A filled dot reads as "the site is here"; 2,239 of the 2,254
    // mapped power projects are county centroids, so they render as a hollow ring — the colour
    // and size still carry status and MW, but the fill that asserts a position is withheld.
    // Explicit boolean compare rather than a bare ["get","centroid"] as the `case` condition.
    // Both validate against the style spec; this one states the intent and does not depend on
    // `get` returning a real boolean rather than a truthy value.
    const isC = ["==", ["get", "centroid"], true];
    map.addLayer({
      id: "pts", type: "circle", source: "a",
      paint: {
        "circle-radius": ["get", "r"],
        "circle-color": ["get", "color"],
        "circle-opacity": ["case", isC, 0.12, 0.8],
        "circle-stroke-width": ["case", isC, 1.4, 0.8],
        "circle-stroke-color": ["case", isC, ["get", "color"],
          getComputedStyle(document.documentElement).getPropertyValue("--panel").trim()],
      },
    });
    map.on("click", "pts", (e) => {
      const p = e.features[0].properties;
      if (p.kind === "dc" || p.kind === "power") { openDrawer(p.id); return; }
      new maplibregl.Popup({ offset: 12 }).setLngLat(e.lngLat).setHTML(`<div class="pop"><b>${p.name}</b><div class="pm">${layerLabel(p.layer)} · ${p.region}</div>${p.ent && SENT[p.ent] ? `<button onclick="goChain('${p.ent}')">Chain analysis ↗</button>` : ""}</div>`).addTo(map);
    });
    map.on("mouseenter", "pts", () => (map.getCanvas().style.cursor = "pointer")); map.on("mouseleave", "pts", () => (map.getCanvas().style.cursor = ""));
  }
  function initMap() {
    map = new maplibregl.Map({ container: "map", style: mapStyle(), center: [-95, 38.5], zoom: 3.2, attributionControl: { compact: true } });
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");
    // A rejected paint expression renders an EMPTY map and says nothing — the basemap still
    // draws, so it reads as "no data matched the filter" rather than "the layer was refused".
    // Surfacing it is the difference between a five-minute fix and a wrong conclusion.
    map.on("error", (e) => console.error("[dcv map]", e && e.error ? e.error.message : e));
    // `load` fires only after every necessary resource has downloaded AND the first complete
    // render has happened — which includes the CARTO raster basemap. Our points do not depend
    // on that basemap, so binding them to `load` makes the data hostage to a third-party tile
    // CDN: if it is slow or blocked, the layer is never added and the panel shows an empty map
    // while reporting nothing wrong. Attach on `style.load` (fires once the style spec itself
    // is parsed), keeping `load` as a backstop, guarded on the source so the second is a no-op.
    const attach = () => { if (map && !map.getSource("a")) addMap(); };
    map.on("style.load", attach);
    map.on("load", attach);
  }
  /* The map had NO key at all: dots are coloured by status, but the only swatches on screen
     were the layer chips, which are coloured by layer. So the dominant orange — 1,342 Planned
     rows, mostly ERCOT-queue solar — meant nothing to a reader.

     The legend COUNTS the features it is describing rather than asserting a fixed key, on the
     same rule as the Clearing-price badge and the newsfeed rail: a panel states what it is
     standing on. If a filter leaves no centroids on screen, the centroid row disappears
     instead of implying a caveat that no longer applies. */
  function renderMapLegend() {
    const el = $id("maplegend"); if (!el) return;
    const f = expFeatures();
    const n = f.length;
    if (!n) { el.innerHTML = ""; return; }
    const byTok = {};
    f.forEach((x) => { if (x.properties.kind === "asset") return; const t = Object.keys(STATUS_COLOR).find((k) => STATUS_COLOR[k] === x.properties.color); if (t) byTok[t] = (byTok[t] || 0) + 1; });
    const centroid = f.filter((x) => x.properties.centroid).length;
    const unsized = f.filter((x) => !x.properties.sized).length;
    const pts = new Set(f.map((x) => x.geometry.coordinates.join(","))).size;
    const sw = (c, hollow) => `<span class="lgd-sw" style="${hollow ? `border:1.5px solid ${c};background:${c}1a` : `background:${c}`}"></span>`;
    const statusRow = Object.keys(STATUS_COLOR).filter((t) => byTok[t])
      .map((t) => `<span class="lgd-i">${sw(STATUS_COLOR[t])}${STATUS_LABEL[t]} <b>${fmt(byTok[t])}</b></span>`).join("");
    let h = `<div class="lgd-row"><span class="lgd-t">Colour = status</span>${statusRow}</div>`;
    h += `<div class="lgd-row"><span class="lgd-t">Size = capacity</span>`
      + `<span class="lgd-i">${sw("var(--muted)")}circle area ∝ MW, one scale for both layers</span>`
      + (unsized ? `<span class="lgd-i">${sw("var(--muted)")}smallest dot = <b>capacity not recorded</b> (${fmt(unsized)})</span>` : "")
      + `</div>`;
    h += `<div class="lgd-row"><span class="lgd-t">Fill = what the point locates</span>`
      + `<span class="lgd-i">${sw("var(--ca)")}filled = site coordinates <b>${fmt(n - centroid)}</b></span>`
      + (centroid ? `<span class="lgd-i">${sw("var(--ca)", true)}hollow = <b>centroid, not a site</b> ${fmt(centroid)}</span>` : "")
      + `</div>`;
    if (centroid) {
      h += `<p class="lgd-note">${fmt(centroid)} of ${fmt(n)} points shown are county/state centroids — every project in a county lands on that county's centre, so they stack. The ${fmt(n)} points occupy <b>${fmt(pts)}</b> distinct locations. Click any ring for what it really contains.</p>`;
    }
    el.innerHTML = h;
  }
  function refreshMap() { if (map && map.getSource("a")) map.getSource("a").setData({ type: "FeatureCollection", features: expFeatures() }); renderMapLegend(); }
  function renderExpLayers() {
    const counts = layerCounts(), all = allLayerIds();
    const isAll = all.every((id) => expLayers.has(id));
    const solo = expLayers.size === 1 ? [...expLayers][0] : null;
    $id("explayers").innerHTML =
      '<span class="fl" style="align-self:center;margin:0 2px 0 0">Layers</span>' +
      `<span class="chip lyrchip ${isAll ? "on" : ""}" data-l="__all">All <b>${all.reduce((s, id) => s + (counts[id] || 0), 0)}</b></span>` +
      LAYERS.filter((l) => layersPresent.has(l.id)).map((l) =>
        `<span class="chip lyrchip ${expLayers.has(l.id) ? "" : "off"}" data-l="${l.id}" title="Show only ${l.label}${solo === l.id ? " — click again for all" : ""} (⇧-click to add/remove)"><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:${layerColor(l.id)};vertical-align:-1px;margin-right:5px"></span>${l.label} <b>${counts[l.id] || 0}</b></span>`).join("");
    root.querySelectorAll("#explayers .lyrchip").forEach((el) => (el.onclick = (ev) => {
      const id = el.dataset.l;
      if (id === "__all") return setLayers(new Set(all));
      if (ev.shiftKey || ev.metaKey || ev.ctrlKey) {          // additive: build a custom subset
        const n = new Set(expLayers);
        n.has(id) ? n.delete(id) : n.add(id);
        return setLayers(n);
      }
      // plain click = isolate; clicking the already-isolated layer restores everything
      setLayers(expLayers.size === 1 && expLayers.has(id) ? new Set(all) : new Set([id]));
    }));
  }
  function statusPill(s) { return `<span class="pill ${statusToken(s)}">${s}</span>`; }
  function provCell(d) {
    const s = d.sources || [], c = d.confidence, age = ageDays(d.last_verified);
    const badge = c != null ? `<span class="conf ${isConfirmed(d) ? "c-hi" : "c-lo"}">${isConfirmed(d) ? "confirmed" : "reported"} ${c.toFixed(2)}</span>` : "";
    const link = s.length ? `<a href="${s[0]}" target="_blank" rel="noopener">${s.length} src ↗</a>` : '<span class="muted">—</span>';
    return `${badge} ${link}${age != null ? ` · <span class="muted">${age}d</span>` : ""}`;
  }
  function renderExpTable() {
    const t = $id("exptable"); let n = 0;
    renderTableSeg();
    if (tblMode === "asset") {
      const rows = assetRows(); n = rows.length;
      t.innerHTML = "<thead><tr><th>Asset</th><th>Company</th><th>Layer</th><th>Region</th><th>Scale</th></tr></thead><tbody>" +
        rows.map((a) => {
          const e = SENT[a[1]];
          return `<tr data-ent="${esc(a[1])}"><td><b>${esc(a[3])}</b></td><td>${esc(e ? e.name : a[1])}</td>` +
            `<td><span class="ld" style="background:${layerColor(a[2])}"></span>${esc(layerLabel(a[2]))}</td>` +
            `<td>${esc(a[4] || "—")}</td><td>${a[7] != null ? a[7] : "—"}</td></tr>`;
        }).join("") +
        (rows.length ? "" : '<tr><td colspan="5" class="muted" style="text-align:center">no assets in the selected layers</td></tr>') +
        "</tbody>";
      root.querySelectorAll("#exptable tr[data-ent]").forEach((r) => (r.onclick = () => goChain(r.dataset.ent)));
      const c0 = $id("exp-count");
      if (c0) c0.textContent = `${n} shown · illustrative seed, not filtered by state/status/MW`;
      return;
    }
    if (tblMode === "dc") {
      const rows = dcFiltered().sort((a, b) => (b.capacity_mw || 0) - (a.capacity_mw || 0)); n = rows.length;
      t.innerHTML = "<thead><tr><th>Project</th><th>Developer</th><th>Type</th><th>MW</th><th>Status</th><th>Location</th><th>Provenance</th></tr></thead><tbody>" +
        rows.slice(0, 400).map((p) => `<tr data-id="${p.id}"><td><b>${p.project_name}</b></td><td>${p.developer || "—"}</td><td>${catLabel(p.developer_category)}</td><td>${fmt(p.capacity_mw)}</td><td>${statusPill(p.status)}</td><td>${p.county ? p.county + " Co., " : ""}${p.state || ""}</td><td>${provCell(p)}</td></tr>`).join("") +
        (rows.length > 400 ? `<tr><td colspan="7" class="muted" style="text-align:center">… top 400 of ${fmt(rows.length)} by capacity</td></tr>` : "") + "</tbody>";
    } else {
      const rows = powerFiltered().sort((a, b) => (b.capacity_mw || 0) - (a.capacity_mw || 0)); n = rows.length;
      t.innerHTML = "<thead><tr><th>Power project</th><th>Technology</th><th>MW</th><th>Status</th><th>Location</th><th>Powers</th><th>Provenance</th></tr></thead><tbody>" +
        rows.slice(0, 400).map((p) => `<tr data-id="${p.id}"><td><b>${p.project_name}</b></td><td>${p.technology}</td><td>${fmt(p.capacity_mw)}</td><td>${statusPill(p.status)}</td><td>${p.county ? p.county + " Co., " : ""}${p.state || ""}</td><td>${p.btm ? "⚡ " + (p.linked && NAME_BY_ID[p.linked] ? NAME_BY_ID[p.linked].split(" ")[0] : "BTM") : "grid"}</td><td>${provCell(p)}</td></tr>`).join("") +
        (rows.length > 400 ? `<tr><td colspan="7" class="muted" style="text-align:center">… top 400 of ${fmt(rows.length)} by capacity</td></tr>` : "") + "</tbody>";
    }
    root.querySelectorAll("#exptable tr[data-id]").forEach((r) => (r.onclick = () => openDrawer(r.dataset.id)));
    // The layer chips count MAP POINTS and this counts TABLE ROWS; they differ by the rows with
    // no coordinates. Saying both is the difference between "the filter is broken" and "5 of
    // these have no location" — the chip reading 31 beside a table of 36 looks like a bug.
    const src = tblMode === "dc" ? dcFiltered() : powerFiltered();
    const mapped = src.filter((p) => p.lat != null && p.lng != null).length;
    const c = $id("exp-count");
    if (c) c.textContent = n + " shown" + (mapped !== n ? ` · ${mapped} on the map (${n - mapped} have no coordinates)` : "");
  }
  function openDrawer(id) {
    const d = DCBYID[id] || PWR.find((x) => x.id === id); if (!d) return;
    const isDC = d.dataset !== "power", conf = isConfirmed(d), age = ageDays(d.last_verified), srcs = d.sources || [];
    const loc = `${d.county ? d.county + " Co., " : ""}${d.state || ""}`;
    // Capacity and location each get an explicit ABSENCE state. "— MW" and a bare county name
    // both used to read as facts; the map sized the first and plotted the second.
    const capCell = d.capacity_mw != null ? fmt(d.capacity_mw) + " MW"
      : '<span class="muted" style="font-style:italic;font-weight:400">not recorded</span>';
    const locCell = d.lat == null
      ? `${loc || "—"} <span class="muted" style="font-weight:400">· no coordinate</span>`
      : isCentroid(d.geo_precision)
        ? `${loc} <span class="gp-warn">${PRECISION_LABEL[d.geo_precision] || d.geo_precision}</span>`
        : `${loc} <span class="muted" style="font-weight:400">· site coordinates</span>`;
    const fields = isDC
      ? [["Capacity", capCell], ["Status", d.status], ["Developer", d.developer || "—"], ["Operator", d.operator || "—"], ["Tenant", d.tenant || "—"], ["End-user", d.end_user || "—"], ["Cap-ex", money(d.cap_ex)], ["Operating year", d.operating_year || "TBD"], ["Location", locCell], ["Provider type", catLabel(d.developer_category)]]
      : [["Capacity", capCell], ["Technology", d.technology], ["Status", d.status], ["Developer", d.developer || "—"], ["Powers", d.btm ? "⚡ " + (d.linked && NAME_BY_ID[d.linked] ? NAME_BY_ID[d.linked] : "a data center") : "grid"], ["Feed", d.source || "—"], ["Location", locCell]];
    let h = `<div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em">${isDC ? "Data center" : "Power project"} · live pipeline</div>`;
    h += `<h3 style="margin:2px 0 8px">${d.project_name}</h3>`;
    h += `<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">${statusPill(d.status)}<span class="conf ${conf ? "c-hi" : "c-lo"}">${conf ? "confirmed" : "reported"} ${d.confidence != null ? d.confidence.toFixed(2) : ""}</span><span class="muted" style="font-size:11.5px">review: ${d.review_status || "—"}</span></div>`;
    h += `<div class="dw-sec"><h4>Fields</h4>${fields.map((f) => `<div class="frow"><span class="muted">${f[0]}</span><span><b>${f[1]}</b></span></div>`).join("")}</div>`;
    // A ring on the map can hide dozens of projects. Say how many and what they total, so the
    // reader is never left inferring one project from one dot.
    if (isCentroid(d.geo_precision) && d.lat != null) {
      const peers = (isDC ? DC : PWR).filter((x) => x.lat === d.lat && x.lng === d.lng);
      const mw = peers.reduce((s, x) => s + (x.capacity_mw || 0), 0);
      h += `<div class="dw-sec"><h4>What this point actually is</h4>`
        + `<p class="gp-expl">This is the <b>${PRECISION_LABEL[d.geo_precision] || d.geo_precision}</b> for ${d.county ? esc(d.county) + " Co." : "this area"}, not a surveyed position — the real site is somewhere inside it.`
        + (peers.length > 1 ? ` <b>${fmt(peers.length)}</b> ${isDC ? "data centers" : "power projects"} totalling <b>${fmt(Math.round(mw))} MW</b> share this exact coordinate for the same reason.` : "")
        + `</p></div>`;
    }
    h += `<div class="dw-sec"><h4>Provenance &amp; freshness</h4><div class="frow"><span class="muted">Confidence</span><span><b>${d.confidence != null ? d.confidence.toFixed(2) : "—"}</b> · ${conf ? "confirmed" : "reported"}</span></div><div class="frow"><span class="muted">Last verified</span><span>${d.last_verified || "—"}${age != null ? ` · ${age}d ago` : ""}</span></div><div class="frow"><span class="muted">Independent sources</span><span>${srcs.length}${srcs.length < 2 ? ' <span class="muted" style="font-style:italic">(needs ≥2)</span>' : ""}</span></div></div>`;
    h += `<div class="dw-sec"><h4>Sources</h4>${srcs.map((u) => { const m = sourceMeta(u); return `<div style="display:flex;justify-content:space-between;gap:8px;font-size:12px;padding:5px 0;border-bottom:.5px solid var(--line)"><a href="${u}" target="_blank" rel="noopener">${m.dom} ↗</a><span style="font-size:10px;font-weight:700;padding:1px 6px;border-radius:10px;background:${TRUSTCOLOR(m.trust)}22;color:${TRUSTCOLOR(m.trust)}">${m.type} · ${m.trust.toFixed(2)}</span></div>`; }).join("") || '<span class="muted">no sources</span>'}</div>`;
    if (isDC) {
      const es = REDGES.filter((e) => e.project === id);
      if (es.length) {
        const order = ["develops", "operates", "leases_to", "provides_compute", "serves", "powers"]; const byRel = {}; es.forEach((e) => { (byRel[e.relation] = byRel[e.relation] || []).push(e); });
        const chain = order.filter((r) => byRel[r]).map((r) => `<div class="frow"><span class="muted">${RELLABEL[r]}</span><span>${byRel[r].map((e) => { const en = RENT[e.org] || { name: e.org, category: "other" }; return `<span class="pill" style="background:${(CATCOLOR[en.category] || "#8e8e93")}22;color:${CATCOLOR[en.category] || "#8e8e93"}">${en.name}</span>`; }).join(" ")}</span></div>`).join("");
        h += `<div class="dw-sec"><h4>Value chain <span class="muted" style="text-transform:none;font-weight:400">(real edges)</span></h4>${chain}<div style="margin-top:6px"><a href="#" data-goproj="${id}">open the site dossier ↗</a></div></div>`;
      } else h += `<div class="dw-sec"><h4>Value chain</h4><div class="frow"><span class="muted">Developer</span><span>${d.developer || "—"}</span></div><span class="muted" style="font-style:italic;font-size:11.5px">operator/tenant/compute chain pending extraction.</span></div>`;
    }
    const sh = d.status_history || [];
    h += `<div class="dw-sec"><h4>Status timeline</h4>${sh.length
      ? sh.map((h2) => `<div class="frow"><span class="muted">${h2.status || "—"}</span><span>${h2.as_of || ""}${h2.source ? ` · <span class="muted">${h2.source}</span>` : ""}</span></div>`).join("")
      : '<span class="muted" style="font-style:italic;font-size:11.5px">no recorded transitions.</span>'}</div>`;
    if (DISPUTED.has(id)) h += `<div class="dz-msg dz-err" style="margin-top:14px">⚑ An open dispute is already filed on this record — it has been re-opened for cross-vendor re-verification.</div>`;
    h += `<div class="dispute" id="dw-dispute" style="margin-top:16px;background:var(--accent-soft);color:var(--accent);border-radius:10px;padding:9px 12px;font-size:12.5px;font-weight:600;cursor:pointer;text-align:center">⚑ Flag / dispute this record</div><div id="dw-dzwrap"></div>`;
    $id("drawer-body").innerHTML = h;
    const gp = root.querySelector("[data-goproj]"); if (gp) gp.onclick = (e) => { e.preventDefault(); closeDrawer(); goProjectFromDrawer(id); };
    const dz = $id("dw-dispute"); if (dz) dz.onclick = () => openDisputeForm(d);
    $id("drawer").classList.add("on"); $id("scrim").classList.add("on");
  }

  /* ---------- U2 dispute (Band-1 #3) — a real POST into the review loop, not a relabel ----------
     The button used to only change its own text; the signal went nowhere. It now files the
     dispute to /api/review, which appends to the pipeline inbox that `dcv review-drain` ingests
     into review_log + RE-OPENS the record for L2 re-verification. A failed POST reports the
     failure — never a green message for a write that didn't happen. */
  const DISPUTED = new Set(((D.meta?.rollups?.review_queue || {}).disputed_ids) || []);
  function openDisputeForm(d) {
    const wrap = $id("dw-dzwrap"); if (!wrap || wrap.dataset.open) return;
    wrap.dataset.open = "1";
    const isDC = d.dataset !== "power";
    const fields = isDC ? ["capacity_mw", "status", "location", "developer", "operator", "tenant", "cap_ex", "operating_year", "other"]
                        : ["capacity_mw", "status", "technology", "location", "developer", "other"];
    wrap.innerHTML = `<div class="dz-form">
      <select id="dz-field" aria-label="Which field is wrong">${fields.map((f) => `<option value="${f}">${f}</option>`).join("")}</select>
      <input id="dz-reason" maxlength="500" placeholder="What's wrong, and what's the right value? (a source URL helps)" />
      <button id="dz-send">File dispute → re-verify</button>
      <div class="dz-msg muted">Files a <code>review_log</code> entry and re-opens this record for cross-vendor re-verification. It cannot reject a value — only a human reviewer can.</div>
      <div class="dz-msg" id="dz-msg"></div></div>`;
    $id("dz-send").onclick = () => sendDispute(d, isDC);
  }
  async function sendDispute(d, isDC) {
    const btn = $id("dz-send"), msg = $id("dz-msg"); if (!btn || !msg) return;
    btn.disabled = true; msg.className = "dz-msg muted"; msg.textContent = "filing…";
    try {
      const r = await fetch("/api/review", {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ record_type: isDC ? "data_center" : "power_project", record_id: d.id,
                               field: $id("dz-field").value, reason: $id("dz-reason").value }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || `HTTP ${r.status}`);
      msg.className = "dz-msg dz-ok";
      msg.textContent = `⚑ Filed. ${j.pending} dispute(s) queued — run \`dcv review-drain\` to write review_log and re-open this record, then \`dcv emit\`.`;
      $id("rv-pending") && ($id("rv-pending").textContent = j.pending);
    } catch (e) {
      // honest failure: the record was NOT queued
      msg.className = "dz-msg dz-err";
      msg.textContent = `Could not file the dispute — ${String(e.message || e)}. Nothing was queued.`;
      btn.disabled = false;
    }
  }

  /* ---------- HITL review queue (Band-1 #3) ----------
     The queue the retro found had no drain: 363/428 records sat in needs_review with no way to
     work them. Ranked by the SAME active-learning formula the CLI uses (uncertainty × value,
     log1p-damped) so the panel and `dcv review` agree on what to look at first. Disputed records
     jump the queue — a human already told us that one is wrong. */
  const rvPriority = (conf, cap) => (1 - (conf == null ? 0 : conf)) * Math.log1p(cap || 0);
  function reviewQueue(limit) {
    return [...DC, ...PWR].filter((d) => d.review_status === "needs_review")
      .map((d) => ({ d, disputed: DISPUTED.has(d.id), pri: rvPriority(d.confidence, d.capacity_mw) }))
      .sort((a, b) => (b.disputed - a.disputed) || (b.pri - a.pri)).slice(0, limit);
  }
  function renderReview() {
    const rq = (D.meta?.rollups?.review_queue) || {};
    const rows = reviewQueue(120), total = [...DC, ...PWR].filter((d) => d.review_status === "needs_review").length;
    const rev = rq.reviewed || {}, decided = rq.reviewed_total || 0;
    let h = `<div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em">Human review queue · U2 → L2</div>
      <h3 style="margin:2px 0 4px">${fmt(total)} records need review</h3>
      <div class="rv-meta">Ranked by <b>uncertainty × value</b> — the least-certain, biggest thing first (the same active-learning order as <code>dcv review</code>). Reviewing top-down reduces the most error per unit of effort.</div>
      <div class="dw-sec"><h4>Loop state</h4>
        <div class="frow"><span class="muted">Open disputes</span><span><b>${rq.open_disputes ?? 0}</b> ${rq.open_disputes ? '<span class="rv-flag">⚑ jump the queue</span>' : ""}</span></div>
        <div class="frow"><span class="muted">Undrained inbox</span><span><b id="rv-pending">${rq.inbox_pending ?? 0}</b> awaiting <code>dcv review-drain</code></span></div>
        <div class="frow"><span class="muted">Decisions logged</span><span><b>${decided}</b>${decided ? ` · ${esc(Object.entries(rev).map(([k, v]) => `${k} ${v}`).join(", "))}` : ' <span class="muted" style="font-style:italic">— nothing drained yet</span>'}</span></div>
        <div class="frow"><span class="muted">Oldest in queue</span><span>${rq.oldest_needs_review_days != null ? rq.oldest_needs_review_days + "d since last verify" : "—"}</span></div>
      </div>
      <div class="dw-sec"><h4>Queue — top ${Math.min(rows.length, 120)}${total > rows.length ? ` of ${fmt(total)}` : ""}</h4>`;
    h += rows.map(({ d, disputed, pri }) => `<div class="rv-row" data-rv="${esc(d.id)}">
        <span class="rv-pri">${pri.toFixed(2)}</span>
        <span>${disputed ? '<span class="rv-flag">⚑ </span>' : ""}${esc(d.project_name)}<div class="rv-meta">${esc(d.state || "—")} · ${d.capacity_mw != null ? fmt(d.capacity_mw) + " MW" : "no capacity"} · ${(d.sources || []).length} source${(d.sources || []).length === 1 ? "" : "s"}${(d.sources || []).length < 2 ? " (needs ≥2)" : ""}</div></span>
        <span class="conf c-lo">${d.confidence != null ? d.confidence.toFixed(2) : "—"}</span></div>`).join("");
    h += `</div><div class="rv-meta" style="margin-top:12px">Click a row to inspect it. Approve or reject from the CLI — <code>dcv review-decide &lt;id&gt; --decision approve</code> — so a verdict always carries a named reviewer into <code>review_log</code>; the browser can only <i>dispute</i>.</div>`;
    $id("rv-body").innerHTML = h;
    root.querySelectorAll("#rv-body [data-rv]").forEach((r) => (r.onclick = () => { closeReview(); openDrawer(r.dataset.rv); }));
  }
  function openReview() { renderReview(); $id("rv-panel").classList.add("on"); $id("rv-scrim").classList.add("on"); }
  function closeReview() { $id("rv-panel").classList.remove("on"); $id("rv-scrim").classList.remove("on"); }
  function goProjectFromDrawer(id) { if (!CHAIN_PROJECTS.includes(id)) return; switchView("chain"); sdSelect(id); $id("projchain").scrollIntoView({ behavior: "smooth" }); }

  /* ==================== PRICE BOARD (seed) ==================== */
  let term = "on_demand";
  function heat(v, med, lo, hi) { if (v <= med) { const t = (med - v) / (med - lo || 1); return t > 0.5 ? "var(--op-soft2)" : t > 0.15 ? "var(--op-soft)" : "var(--panel-2)"; } const t = (v - med) / (hi - med || 1); return t > 0.5 ? "var(--rd-soft2)" : t > 0.15 ? "var(--rd-soft)" : "var(--panel-2)"; }
  function renderBoard() {
    let h = '<thead><tr><th class="sku">GPU SKU</th>' + PROV.map((p) => `<th data-e="${p[0]}" style="cursor:pointer">${p[1]}</th>`).join("") + '<th>Low·Med·High</th><th title="Kalshi market-implied 3-month forward curve">Kalshi fwd · 3mo</th></tr></thead><tbody>';
    SKUS.forEach((s) => { const vals = PROV.map((p) => (PX[p[0]][s[0]] != null ? PX[p[0]][s[0]] * TERMMULT[term] : null)).filter((v) => v != null); if (!vals.length) return; const med = vals.slice().sort((a, b) => a - b)[Math.floor(vals.length / 2)], lo = Math.min(...vals), hi = Math.max(...vals);
      h += `<tr><td class="sku">${s[1]}</td>`;
      PROV.forEach((p) => { const b = PX[p[0]][s[0]]; if (b == null) { h += '<td class="cell na">—</td>'; return; } const v = b * TERMMULT[term]; const raw = series(hash(p[0] + s[0] + term), TREND[s[0]] || 0); const d = (raw[29] - raw[0]) / raw[0];
        h += `<td class="cell" style="background:${heat(v, med, lo, hi)}" data-e="${p[0]}"><div class="px">$${v.toFixed(2)}</div><div class="spk">${sparkline(raw, d < 0)}<span class="dl ${d < 0 ? "dn" : "up"}">${d < 0 ? "▼" : "▲"}${Math.abs(d * 100).toFixed(0)}%</span></div></td>`; });
      const fwd = (FWD[s[0]] || med) * TERMMULT[term], fd = (fwd - med) / med, fdown = fd < 0, cov = FWD_COVERED[s[0]];
      h += `<td class="rowstat">$${lo.toFixed(2)}<br>$${med.toFixed(2)}<br>$${hi.toFixed(2)}</td>` +
        `<td class="rowstat" title="market-implied 3-month forward (Kalshi)"><b style="font-size:12.5px">$${fwd.toFixed(2)}</b> <span class="dl ${fdown ? "dn" : "up"}">${fdown ? "▼" : "▲"}${Math.abs(fd * 100).toFixed(0)}%</span><br><span style="font-size:9px;color:${cov ? "var(--op)" : "var(--muted)"}">${cov ? "● Kalshi curve" : "modeled"}</span></td></tr>`; });
    const t = $id("board"); t.innerHTML = h + "</tbody>";
    t.querySelectorAll("[data-e]").forEach((x) => (x.onclick = () => goChain(x.dataset.e)));
  }

  /* ==================== NEWSFEED RAIL (real pipeline output) ====================
     Was a standalone tab: a global, reverse-chronological list. Two problems killed that shape.
     (1) It had no selection to bind to, so it answered "what happened" but never "what happened
     to THIS". (2) Only 24 of 258 items carry a published_date — a chronological ticker would
     have been mostly fabricated order. So the rail sits beside Chain Analysis, ranks by RELEVANCE
     to the current selection, and states the date gap in its own footer rather than hiding it.
     Scope is an EXPLICIT filter (All / this site / this company), never inferred: a list that
     silently re-scopes itself when you click elsewhere is worse than one that doesn't move. */
  const feedLabel = (id) => FEEDS[id] || id;
  const RAIL_N = 40;
  let RAILF = "all"; // 'all' | 'site' | 'ent'
  function railMatch(n, ctx, mode) {
    const ps = n.projects || [];
    if (mode === "site") return ctx.siteId ? ps.includes(ctx.siteId) : false;
    if (mode === "ent") return ctx.ent ? ps.some((p) => { const d = DCBYID[p]; return d && [d.developer, d.operator, d.tenant, d.end_user].filter(Boolean).some((r) => r.toLowerCase().includes(ctx.ent.toLowerCase())); }) : false;
    return ps.length > 0; // 'all' — every item that links to a tracked site
  }
  // dated first (newest), then by linked-site capacity. An undated item is never ordered as if
  // it had a date — it sorts into its own tier and says "no date" on its face.
  function railRank(a, b) {
    const da = a.n.published_date ? 1 : 0, db = b.n.published_date ? 1 : 0;
    return db - da || String(b.n.published_date || "").localeCompare(String(a.n.published_date || "")) || b.mw - a.mw;
  }
  function railContext() {
    const d = DCBYID[selProject];
    return { siteId: d ? d.id : null, siteName: d ? d.project_name : null, ent: SENT[central] ? SENT[central].name : null };
  }
  function renderRail() {
    const list = $id("rail-list"); if (!list) return;
    const ctx = railContext();
    const withMw = NEWS.map((n) => ({ n, mw: Math.max(0, ...(n.projects || []).map((p) => (DCBYID[p] || {}).capacity_mw || 0)) }));
    const count = (m) => withMw.filter((x) => railMatch(x.n, ctx, m)).length;
    const nAll = count("all"), nSite = count("site"), nEnt = count("ent");
    // a filter the current selection cannot satisfy must not stay silently active
    if ((RAILF === "site" && !ctx.siteId) || (RAILF === "ent" && !ctx.ent)) RAILF = "all";
    const chips = [["all", `All · ${nAll}`, true]];
    if (ctx.siteId) chips.push(["site", `${ctx.siteName} · ${nSite}`, nSite > 0]);
    if (ctx.ent) chips.push(["ent", `${ctx.ent} · ${nEnt}`, nEnt > 0]);
    $id("rail-chips").innerHTML = chips.map(([k, label, on]) =>
      `<button class="railchip ${RAILF === k ? "on" : ""}" data-f="${k}" ${on ? "" : "disabled"} title="${esc(label)}">${esc(label)}</button>`).join("");
    root.querySelectorAll("#rail-chips .railchip").forEach((b) => { if (!b.disabled) b.onclick = () => { RAILF = b.dataset.f; renderRail(); }; });
    const rows = withMw.filter((x) => railMatch(x.n, ctx, RAILF)).sort(railRank);
    $id("rail-ctx").textContent =
      RAILF === "all" ? `Every item linked to a tracked site · ${DC.length} data centers`
      : RAILF === "site" ? "Filtered to this site" : `Filtered to sites where ${ctx.ent} holds a role`;
    const unlinked = NEWS.filter((n) => !(n.projects || []).length).length;
    list.innerHTML = rows.length ? rows.slice(0, RAIL_N).map(({ n }) => {
      const sites = (n.projects || []).map((p) => (DCBYID[p] || {}).project_name).filter(Boolean);
      return `<a class="railitem" href="${esc(n.url)}" target="_blank" rel="noopener">
        <div class="rt">${esc(n.title)}</div>
        <div class="rm"><span>${esc(feedLabel(n.source_feed) || "—")}</span>${n.published_date ? `<span>· ${esc(n.published_date)}</span>` : '<span class="nodate">no date</span>'}</div>
        ${sites.length ? `<div class="rl">${esc(sites[0])}${sites.length > 1 ? ` +${sites.length - 1}` : ""}</div>` : ""}</a>`;
    }).join("")
      : `<div class="railempty">No linked coverage${RAILF === "site" ? ` for ${esc(ctx.siteName || "this site")}` : RAILF === "ent" ? ` naming ${esc(ctx.ent)}` : ""}. Only ${unlinked} of ${NEWS.length} items link to no site at all, so this is a gap in that entity's coverage, not in the feed.</div>`;
    const dated = NEWS.filter((n) => n.published_date).length;
    $id("rail-ft").innerHTML =
      `Showing ${Math.min(rows.length, RAIL_N)} of ${rows.length} · as of ${esc(D.generated_at || "—")}<br>
       <b>${dated} of ${NEWS.length}</b> items carry a publish date; the rest sort after them, by linked-site capacity.`;
    /* Every path that changes main's height (site select, re-centre, tab switch) comes through
       here, and the ResizeObserver only fires a frame later — so re-match the column now. */
    syncRailHeight();
  }
  /* Rail height := the main column's height, so the rail's bottom edge lands exactly on the Site
     dossier's bottom edge. The list scrolls inside when the items overflow. Setting the rail's
     height cannot change main's height (fixed grid columns), so this cannot loop. */
  function syncRailHeight() {
    const main = root.querySelector("main"), rc = root.querySelector(".railcard");
    if (!main || !rc) return;
    if (matchMedia("(max-width:1180px)").matches) { rc.style.height = ""; rc.style.maxHeight = "460px"; return; }
    rc.style.maxHeight = "none";
    rc.style.height = Math.round(main.getBoundingClientRect().height) + "px";
  }
  /* Read visibility off the ACTIVE TAB rather than a passed-in view, so the initial mount (which
     never calls switchView) lands in the same state as a click. In the demo this exact split
     shipped the rail onto Overview on first load; every test called switchView and masked it. */
  function syncRailVisibility() {
    const t = root.querySelector(".tab.active"), shell = root.querySelector(".shell");
    if (shell) shell.classList.toggle("norail", (t ? t.dataset.v : "") !== "chain");
  }

  /* ==================== WIRING ==================== */
  function switchView(v) {
    root.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.v === v));
    root.querySelectorAll(".view").forEach((s) => s.classList.toggle("active", s.id === "v-" + v));
    if (v === "overview") setTimeout(renderSankey, 30);
    if (v === "explorer") { if (!map) initMap(); else setTimeout(() => map.resize(), 50); }
    syncRailVisibility();
    renderRail(); // re-matches the rail to the column height
  }
  function setWeight(w) { WEIGHT = w; root.querySelectorAll("#w-seg button,#w-seg2 button").forEach((b) => b.classList.toggle("on", b.dataset.w === w)); renderSankey(); renderChain(); }
  function closeDrawer() { $id("drawer").classList.remove("on"); $id("scrim").classList.remove("on"); }
  window.goChain = goChain; window.closeDrawer = closeDrawer; window.closeReview = closeReview;

  const onResize = () => { syncRailHeight(); if ($id("v-overview") && $id("v-overview").classList.contains("active")) renderSankey(); };
  let railRO = null;

  function init() {
    root.querySelectorAll(".tab").forEach((t) => (t.onclick = () => switchView(t.dataset.v)));
    root.querySelectorAll("#w-seg button,#w-seg2 button").forEach((b) => (b.onclick = () => setWeight(b.dataset.w)));
    root.querySelectorAll("#g-seg button").forEach((b) => (b.onclick = () => { GROUP = b.dataset.g; root.querySelectorAll("#g-seg button").forEach((x) => x.classList.toggle("on", x === b)); renderSankey(); }));
    // site select (real DCs that carry role edges), ordered by capacity
    const ps = $id("proj-sel");
    ps.innerHTML = SDLIST.map((id) => { const p = DCBYID[id]; return `<option value="${esc(id)}">${esc(p.project_name)}${p.capacity_mw != null ? " — " + fmt(p.capacity_mw) + " MW" : ""}</option>`; }).join("");
    if (SDLIST.length) { selProject = SDLIST[0]; ps.value = selProject; }
    ps.onchange = () => { selProject = ps.value; renderProject(); };
    root.querySelectorAll("#sd-seg button").forEach((b) => (b.onclick = () => { SDMODE = b.dataset.m; root.querySelectorAll("#sd-seg button").forEach((x) => x.classList.toggle("on", x === b)); renderProject(); }));
    // Jump targets are DERIVED, not a hardcoded slug list: the dossier's whole point is that
    // site shapes differ, so the shortcuts must keep pointing at real examples of each shape as
    // the pipeline grows. Claimed greedily in priority order — one site can satisfy several
    // predicates (the largest 3-party site may also be the largest backbone-reaching one), and
    // two buttons landing on the same record teaches nothing. A bucket with no unclaimed member
    // is simply not offered.
    (function () {
      const taken = new Set();
      const claim = (pred) => { const id = SDLIST.find((x) => !taken.has(x) && pred(DCBYID[x])); if (id) taken.add(id); return id; };
      const jumps = [
        [claim((d) => nParties(d) >= 3), "Richest structure (3+ parties)"],
        [claim((d) => (EDGES_BY_PROJ[d.id] || []).some((e) => SENT[e.org])), "Reaches the backbone"],
        [claim((d) => isRetail(d)), "Typical retail colo"],
        [claim((d) => nParties(d) === 1), "Single-party self-build"],
      ].filter(([id]) => id);
      $id("sd-jump").innerHTML = jumps.map(([id, l]) => `<button data-j="${esc(id)}">${esc(l)}</button>`).join("");
      root.querySelectorAll("#sd-jump button").forEach((b) => (b.onclick = () => sdSelect(b.dataset.j)));
      // Land on the richest structure the graph actually has, so the panel opens showing what it
      // does. Not cherry-picking: the very first band states that 3+ party sites are rare and the
      // distribution strip under it shows exactly how rare. Select order stays capacity-ranked.
      const lead = jumps.length ? jumps[0][0] : SDLIST[0];
      if (lead) { selProject = lead; ps.value = lead; }
    })();
    // chain (seed)
    const cs = $id("central-sel"); cs.innerHTML = Object.keys(SENT).map((id) => `<option value="${id}">${SENT[id].name}</option>`).join(""); cs.value = central; cs.onchange = () => { central = cs.value; renderChain(); };
    $id("qonly").onchange = (e) => { qOnly = e.target.checked; renderChain(); };
    // explorer
    // seed the layer set from the data rather than a hardcoded list, so a layer that arrives
    // later (P5 assets) is on by default instead of invisible until someone updates a literal
    layersPresent = new Set(allMapAssets().map((a) => a.layer));
    expLayers = new Set(allLayerIds());
    // rendered HERE, not only from the map's `load` handler — the legend describes the data,
    // not the tiles, and the landing path is the one every user hits first
    renderExpLayers(); renderExpFilters(); renderMapLegend();
    // a filter change alters the per-layer counts on the chips, so they re-render too
    const onFilter = () => { renderExpLayers(); renderExpTable(); refreshMap(); };
    $id("exp-q").oninput = (e) => { expF.q = e.target.value.toLowerCase(); onFilter(); };
    $id("exp-state").onchange = (e) => { expF.state = e.target.value; onFilter(); };
    $id("exp-status").onchange = (e) => { expF.status = e.target.value; onFilter(); };
    $id("exp-type").onchange = (e) => { expF.type = e.target.value; onFilter(); };
    $id("exp-mw").oninput = (e) => { expF.minmw = +e.target.value; $id("exp-mw-v").textContent = e.target.value; onFilter(); };
    $id("exp-btm").onchange = (e) => { expF.btm = e.target.checked; onFilter(); };
    renderExpTable();
    // board
    root.querySelectorAll("#term-seg button").forEach((b) => (b.onclick = () => { term = b.dataset.t; root.querySelectorAll("#term-seg button").forEach((x) => x.classList.toggle("on", x === b)); renderBoard(); }));
    renderBoard();
    // The clearing-price board's provenance badge is MEASURED, not asserted: if a price row ever
    // arrives carrying a source/as_of (P4), the badge must stop saying SEED on its own.
    (function () {
      const rows = D.prices || [], sourced = rows.filter((p) => p.source || p.as_of).length, b = $id("board-prov");
      if (!b) return;
      if (!rows.length) { b.textContent = "no price rows"; return; }
      if (sourced === rows.length) { b.className = "badge b-disc"; b.style.marginLeft = "8px"; b.textContent = `SOURCED — ${sourced}/${rows.length} rows carry a source`; }
      else { b.textContent = `SEED — ${rows.length - sourced} of ${rows.length} price rows carry no source or as_of`; }
    })();
    // newsfeed rail — visibility must be set at mount too, not only on a tab click
    syncRailVisibility(); syncRailHeight(); renderRail();
    /* main's height changes on every tab switch and re-render; observe it rather than
       remembering to call sync from each render path. Rail height never feeds back into main's
       height (fixed grid columns), so this cannot loop. */
    if (window.ResizeObserver) { railRO = new ResizeObserver(syncRailHeight); railRO.observe(root.querySelector("main")); }
    // header
    const dcMW = DC.reduce((s, d) => s + (d.capacity_mw || 0), 0);
    $id("asof").textContent = `data as of ${D.generated_at} · ${fmt(DC.length)} data centers · ${fmt(PWR.length)} power · ${REDGES.length} role edges · ${NEWS.length} news · seed compute-chain · v${D.schema_version || ""}`;
    // demo-flag financials count is LIVE from the read-model (not hardcoded) — loop-design "measured value must be live"
    const roll = (D.meta && D.meta.rollups) || {};
    const finCov = roll.financials_coverage, edgeCov = roll.edge_coverage;
    if (finCov && $id("demo-flag")) {
      const edgeTxt = edgeCov
        ? `${edgeCov.disclosed}/${edgeCov.disclosed + edgeCov.estimated} disclosed from filings, ${edgeCov.named || 0} counterparties named`
        : "%COGS/%rev edges ≈ seed";
      // per-metric coverage: market cap and revenue have different sources, so a single
      // conflated count would mislabel whichever metric the weight toggle is showing.
      const n = finCov.backbone || 0;
      const cov = (m) => (finCov[m] ? `${finCov[m].disclosed}/${n}` : "—");
      $id("demo-flag").innerHTML = `◆ Financials disclosed — revenue ${cov("revenue")} · market cap ${cov("market_cap")} · capex ${cov("capex")} (rest estimated) · edges: ${edgeTxt} · chain topology &amp; Price Board ≈ seed · Explorer, project drill &amp; Newsfeed ≈ live pipeline`;
    }
    // review queue badge (Band-1 #3) — LIVE depth from the read-model, not a hardcoded label
    (function () {
      const rq = (D.meta?.rollups?.review_queue) || {};
      const b = $id("rv-badge"), c = $id("rv-count"); if (!b || !c) return;
      const depth = [...DC, ...PWR].filter((d) => d.review_status === "needs_review").length;
      const open = rq.open_disputes || 0, pending = rq.inbox_pending || 0;
      c.textContent = fmt(depth) + (open ? ` · ⚑${open}` : "") + (pending ? ` · ${pending} undrained` : "");
      if (open || pending) b.classList.add("has-disputes");
      b.title = `${depth} records need human review · ${open} open dispute(s) · ${pending} dispute(s) awaiting \`dcv review-drain\``;
      b.onclick = openReview;
    })();
    // theme
    $id("theme-btn").onclick = () => {
      const r = document.documentElement; const cur = r.getAttribute("data-theme") || (matchMedia("(prefers-color-scheme:dark)").matches ? "dark" : "light"); const nx = cur === "dark" ? "light" : "dark"; r.setAttribute("data-theme", nx);
      try { localStorage.setItem("dcv-theme", nx); } catch (e) {}
      $id("theme-btn").textContent = nx === "dark" ? "☾" : "☀";
      renderSankey(); renderProject(); renderChain(); renderExpLayers(); renderExpTable(); renderBoard();
      if (map) { map.remove(); map = null; if ($id("v-explorer").classList.contains("active")) initMap(); }
    };
    (function () { const dark = (document.documentElement.getAttribute("data-theme") || (matchMedia("(prefers-color-scheme:dark)").matches ? "dark" : "light")) === "dark"; const b = $id("theme-btn"); if (b) b.textContent = dark ? "☾" : "☀"; })();
    window.addEventListener("resize", onResize);
    // initial renders
    renderSankey(); renderProject(); renderChain();
  }
  init();

  return () => {
    try { window.removeEventListener("resize", onResize); } catch (e) {}
    try { if (railRO) railRO.disconnect(); } catch (e) {}
    try { if (map) map.remove(); } catch (e) {}
    try { delete window.goChain; delete window.closeDrawer; delete window.closeReview; } catch (e) {}
  };
}

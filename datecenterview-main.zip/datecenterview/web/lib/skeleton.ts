// The Compute Terminal UI markup (ported from compute-terminal-demo.html's <body>),
// injected once on the client. All dynamic content is populated imperatively by
// lib/runtime against the pipeline-emitted /data.json v1.2 — the page stays a pure
// function of that contract.
//
// IA (three altitudes, two instruments folded in):
//   Overview       — Chain flow (aggregate) + Clearing price (what the chain's output costs)
//   Chain Analysis — SPLC (entity) → Site dossier (project) → Newsfeed rail (what changed)
//   Explorer       — geography
// The old standalone Price Board and Newsfeed TABS are gone: a price grid with nothing to
// compare it to, and a global news list with no selection to bind to, were both instruments
// in search of a question. Each now sits next to the thing it explains.
export const BODY_HTML = `
<div class="topbar">
<header>
  <div class="brand"><div class="dot"></div><div>
    <h1>Compute Terminal</h1>
    <div class="sub">The GPU compute chain as one graph at three altitudes: <b>Overview</b> (aggregate flow + what it clears at) → <b>Chain Analysis</b> (one company, then one site, with the coverage on both) → <b>Explorer</b> (geography), weightable by capacity · revenue · market cap.</div>
    <div class="demo-flag" id="demo-flag">◆ Financials real (FMP) · chain topology, %COGS/%rev edges &amp; Price Board = illustrative seed (→ P3) · Explorer, site dossier &amp; Newsfeed = live pipeline</div>
    <div class="asof" id="asof">loading…</div>
  </div></div>
  <div class="hdr-actions">
    <button class="rv-badge" id="rv-badge" title="Open the human-review queue (needs_review, ranked by uncertainty × value)" aria-label="Open the review queue">⚑ Review <span id="rv-count">—</span></button>
    <button class="theme-btn" id="theme-btn" title="Toggle light / dark" aria-label="Toggle light or dark theme">◐</button>
  </div>
</header>
<nav class="tabs" id="tabs">
  <div class="tab active" data-v="overview">Overview <span class="sec">flow &amp; price</span></div>
  <div class="tab" data-v="chain">Chain Analysis <span class="sec">entity · site · news</span></div>
  <div class="tab" data-v="explorer">Explorer <span class="sec">geography</span></div>
</nav>
</div>

<div class="shell">
<main>
  <!-- OVERVIEW -->
  <section class="view active" id="v-overview">
    <div class="card">
      <h3>Chain flow <span class="muted" style="font-weight:500;font-size:12px">— silicon → systems → facility → operators → end-users</span></h3>
      <p class="hint">The whole chain as a flow. <b>Weight</b> re-scales every flow by capacity, revenue, or market cap — flip to Market cap to see the value-vs-bottleneck mismatch. <b>Group</b> switches the end-to-end supply chain (companies) vs the market flow (categories). Click a company node → its Chain Analysis.</p>
      <div class="ctrls">
        <span class="weightbadge">Weight</span>
        <div class="seg" id="w-seg"><button data-w="cap">Capacity</button><button data-w="rev">Revenue</button><button data-w="mcap" class="on">Market cap</button></div>
        <span class="weightbadge" style="margin-left:8px">Group</span>
        <div class="seg" id="g-seg"><button data-g="company" class="on">Supply chain (companies)</button><button data-g="cat">Market flow (categories)</button></div>
      </div>
      <div id="sankey"></div>
    </div>
    <div class="card">
      <h3>Clearing price <span class="muted" style="font-weight:500;font-size:12px">— what the chain's output costs, $/GPU-hr</span></h3>
      <p class="hint">The flow above is the <b>supply structure</b>; this is what it <b>clears at</b>. $/GPU-hr by SKU × cloud (incl. Blackwell-Ultra <b>B300 / GB300</b>). Cell tint = price vs the SKU-row median; sparkline = 30-day trend. The <b>Kalshi fwd · 3mo</b> column is the market-implied forward curve — ▼ = market expects it cheaper, ▲ = tightening. Click a cell or provider → its Chain Analysis.</p>
      <div class="ctrls"><div class="seg" id="term-seg"><button data-t="on_demand" class="on">On-demand</button><button data-t="reserved_1yr">Reserved 1-yr</button><button data-t="spot">Spot</button></div>
        <span class="badge b-est" id="board-prov" style="margin-left:8px">SEED</span></div>
      <div class="boardwrap"><table class="board" id="board"></table></div>
    </div>
  </section>

  <!-- CHAIN ANALYSIS -->
  <section class="view" id="v-chain">
    <div class="card">
      <h3>Chain Analysis <span class="muted" style="font-weight:500;font-size:12px">— who depends on whom, quantified</span></h3>
      <p class="hint">Suppliers by <b>% of COGS</b>, customers by <b>% of revenue</b>, peers. <span class="badge b-disc">DISCLOSED</span> vs <span class="badge b-est">EST</span>. Node size follows the shared <b>weight</b>. Click any node to re-center.</p>
      <div class="ctrls">
        <label class="fl">Central</label><select id="central-sel"></select>
        <span class="weightbadge" style="margin-left:6px">Weight</span>
        <div class="seg" id="w-seg2"><button data-w="cap">Capacity</button><button data-w="rev">Revenue</button><button data-w="mcap" class="on">Market cap</button></div>
        <label class="fl" style="margin-left:6px"><input type="checkbox" id="qonly"> Quantified only</label>
      </div>
      <div class="splc">
        <div><h4>◀ Suppliers (by % of COGS)</h4><div id="suppliers"></div></div>
        <div><h4>Central</h4><div class="central" id="central"></div><h4 style="margin-top:12px">Peers</h4><div class="peers" id="peers"></div></div>
        <div><h4>Customers (by % of revenue) ▶</h4><div id="customers"></div></div>
      </div>
    </div>
    <div class="card">
      <h3>Site dossier <span class="muted" style="font-weight:500;font-size:12px">— drill into one real site</span></h3>
      <p class="hint">Two bands: <b>deal shape</b> (what kind of structure this is, against the whole tracked base) and <b>chain position</b> (what this site buys, upstream). Runs on the live pipeline read-model — data centers, role edges and the chain backbone — <i>not</i> the illustrative seed the flow/price views use, so the sparsity here is the true sparsity. Click a supplier below → it re-centers the chain map <b>above</b>.</p>
      <div class="ctrls">
        <div class="seg" id="sd-seg"><button data-m="dossier" class="on">Site dossier</button><button data-m="roleflow">Role flow</button></div>
      </div>
      <div class="ctrls"><label class="fl">Site</label><select id="proj-sel"></select><div class="sd-jump" id="sd-jump"></div></div>
      <div id="projchain"></div>
    </div>
  </section>

  <!-- EXPLORER -->
  <section class="view" id="v-explorer">
    <div class="card">
      <h3>Explorer <span class="muted" style="font-weight:500;font-size:12px">— where the chain physically is</span></h3>
      <p class="hint">Map + table of the physical chain: data centers &amp; power (from the pipeline) plus upstream supply-chain asset layers (fabs, HBM, packaging…). <b>Click a layer to show only that layer</b>; click it again for all. ⇧-click to add or remove one. The table follows the layers.</p>
      <div>
        <div class="ctrls" id="expfilters" style="margin-bottom:8px">
          <input type="text" id="exp-q" placeholder="Search project / developer…" style="padding:7px 10px;border:.5px solid var(--line);border-radius:10px;background:var(--panel);color:var(--ink);font-size:13px;width:190px">
          <span><label class="fl">State</label><select id="exp-state"></select></span>
          <span><label class="fl">Status</label><select id="exp-status"></select></span>
          <span><label class="fl" id="exp-type-lbl">Type</label><select id="exp-type"></select></span>
          <span><label class="fl">Min MW</label><input type="range" id="exp-mw" min="0" max="2000" step="50" value="0" style="vertical-align:middle"> <span class="weightbadge" id="exp-mw-v">0</span></span>
          <label class="fl" id="exp-btm-wrap" style="display:none;align-items:center;gap:5px"><input type="checkbox" id="exp-btm"> BTM-linked only</label>
        </div>
        <p class="hint" id="exp-asset-note" style="display:none;margin:0 0 8px">Upstream assets are an <b>illustrative seed</b> with no state/status/capacity fields, so the filters above do not apply to them — they are hidden rather than shown doing nothing. Click a row for that company's Chain Analysis.</p>
        <div class="chips" id="explayers" style="margin-bottom:10px"></div>
        <div id="map"></div>
        <div id="maplegend"></div>
        <div class="ctrls" style="margin:12px 0 0"><label class="fl">Table</label><div class="seg" id="tbl-seg"></div><span class="weightbadge" id="exp-count"></span></div>
        <div class="tablewrap"><table class="tbl" id="exptable"></table></div>
      </div>
    </div>
  </section>
</main>

<aside id="rail">
  <div class="railcard">
    <div class="railhd">
      <h4>Newsfeed</h4>
      <div class="railctx" id="rail-ctx">—</div>
      <div class="railchips" id="rail-chips"></div>
    </div>
    <div class="raillist" id="rail-list"></div>
    <div class="railft" id="rail-ft"></div>
  </div>
</aside>
</div>

<footer>
  Compute Terminal · the chain graph carries real FMP financials (8 mega-caps disclosed, rest estimated) and edge magnitudes quantified from SEC filings (disclosed %s sourced; counterparties named from the buyer's 10-K + first-party/trade press where public, else inferred; the rest estimated); chain topology and the clearing-price board still run on an illustrative mid-2026 seed; Explorer, the site dossier and the Newsfeed are live pipeline output ·
  chain-layer colors from the dataviz validated categorical palette; Apple-glass theme. Pure function of <code>data.json</code> v1.2.
</footer>

<div id="scrim" onclick="closeDrawer()"></div>
<aside id="drawer"><button class="dw-close" onclick="closeDrawer()">✕</button><div id="drawer-body"></div></aside>
<!-- Band-1 #3: the HITL queue — the drain the retro found missing (needs_review had no exit) -->
<div id="rv-scrim" onclick="closeReview()"></div>
<aside id="rv-panel"><button class="dw-close" onclick="closeReview()">✕</button><div id="rv-body"></div></aside>
`;

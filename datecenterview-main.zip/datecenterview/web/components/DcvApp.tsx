"use client";
import { useEffect, useRef, useState } from "react";
import maplibregl from "maplibre-gl";
import * as d3 from "d3";
import { sankey, sankeyLinkHorizontal } from "d3-sankey";
import { BODY_HTML } from "@/lib/skeleton";
import { initApp } from "@/lib/runtime";

// Client-only shell: fetch the pipeline-emitted /data.json, then run the ported
// dataCenterView runtime against it. The UI stays a pure function of that file.
export default function DcvApp() {
  const ref = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let dispose: (() => void) | undefined;
    let cancelled = false;
    fetch("/data.json", { cache: "no-store" })
      .then((r) => {
        if (!r.ok) throw new Error(`data.json ${r.status}`);
        return r.json();
      })
      .then((data) => {
        if (cancelled || !ref.current) return;
        dispose = initApp(data, { d3, sankey, sankeyLinkHorizontal, maplibregl, root: ref.current });
      })
      .catch((e) => !cancelled && setError(String(e)));
    return () => {
      cancelled = true;
      try {
        dispose?.();
      } catch {}
    };
  }, []);

  if (error)
    return (
      <div style={{ padding: 24, fontFamily: "system-ui" }}>
        <b>Could not load data.json.</b>
        <div style={{ color: "#6b7280", marginTop: 6 }}>{error}</div>
        <div style={{ color: "#6b7280", marginTop: 6, fontSize: 13 }}>
          Run <code>python -m dcv emit</code> to regenerate it, or check that it is served at <code>/data.json</code>.
        </div>
      </div>
    );

  return <div ref={ref} dangerouslySetInnerHTML={{ __html: BODY_HTML }} />;
}

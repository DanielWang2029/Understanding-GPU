/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // `npm run build:check` sets NEXT_DIST_DIR=.next-verify so a verification build does NOT
  // overwrite the .next/ that a running `next dev` is serving from. Building into the same
  // directory as a live dev server corrupts its chunk map and every page 500s with
  // "Cannot find module './NNN.js'" — the app is fine, the artifacts are not.
  distDir: process.env.NEXT_DIST_DIR || ".next",
  // data.json is served statically from /public; no rewrites needed for the demo.
  // In production the /api/data route handler can proxy the store instead.
};

export default nextConfig;

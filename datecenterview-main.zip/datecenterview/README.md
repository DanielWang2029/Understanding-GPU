# dataCenterView

Tracks US (then worldwide) **data centers** plus the **power, news, supply chain, and players** around them — comprehensive, up-to-date, and verified. The UI is a **pure function of `data.json`**, which the ingestion pipeline emits from a Postgres system-of-record with field-level provenance.

> **Status (P0–P3 + Band 1 shipped; Band 2 in progress, 2026-08-07).** Postgres SoR live; **Phase A** power ingest running against **live EIA-860M + ISO queues** (3,558 projects); **Phase B** agentic discovery→extract→cross-vendor verify built + run; the **3-tab Compute Terminal** is live at `localhost:3000` as a pure function of `data.json` **v1.2** (490 data centers · 461 news · 217 entities · 647 edges). A **12-gate** publish validator and **370 tests** guard it. Since then: **P2** entity financials, **P3** cross-vendor edge quantification from SEC filings, **Band-1 #1** EDGAR XBRL widening, **#2** real chain topology from buyer filings, **#3** the HITL review queue + user-dispute loop; **Band-2** equipment-tier backbone, role resolution, `dcv bakeoff` (verifier chosen by measurement), source-liveness probing, dedup with a batch-scoped undo, and the review-queue segmentation.
>
> **New here?** Start with **Quickstart Option 0** below — no keys, no spend, real data.
>
> **Documentation:** [`docs/README.md`](docs/README.md) gives the reading order;
> [`CLAUDE.md`](CLAUDE.md) records the current state and constraints; the canonical build order
> is [`docs/data-collection-and-architecture-plan.md`](docs/data-collection-and-architecture-plan.md) §7.

## Architecture

```
pipeline/ (Python 3.12, uv)
  Phase A  EIA + ISO ─→ normalize → geocode → BTM ─────────────────┐
  Phase B  discover (Exa + Grok Agent Tools web+X + GDELT/RSS)     │
           → fetch (Firecrawl) → extract (Grok)                    │
           → verify (Claude, cross-vendor trust gate) → candidates ├─→ Postgres → DuckDB → data.json
  Chain    financials (EDGAR XBRL + FMP)                           │
           topology  (buyer 10-K names its suppliers)              │
           quantify  (customer-concentration %, cross-vendor)      │
  HITL     user dispute → review_log → record re-opened for L2 ────┘
        │                validate_data.py gates every publish — 12 gates (structural ·
        │                referential · financials · edges · review queue · backbone reach ·
        │                DC roles · source policy · capacity provenance · dedup · trust)
        ▼
db/ (Alembic)     Postgres = system of record (field-level Field<T> provenance, 12 tables,
                  incl. review_log / change_log / gold_set as the audit + training trail)
        ▼
web/ (Next.js 15)  Compute Terminal — Overview · Chain Analysis · Explorer (3 tabs; the
                   price grid and news list dock to what they explain), plus a Review
                   queue — a pure function of data.json v1.2
```

### Stack by layer

| Layer | Tools & frameworks | Role |
|---|---|---|
| **Sources** | `gridstatus` · EIA-860M · 7 ISO queues (ERCOT/CAISO/MISO/SPP/PJM/NYISO/ISO-NE) · Census geocoder · Exa · Grok Agent Tools (`web_search`+`x_search`) · GDELT · RSS · Firecrawl · **PeeringDB** | Free power backbone (Phase A) + agentic news discovery (Phase B) + directory enumeration (operating base) |
| **Pipeline** | Python 3.12 · Typer CLI · httpx · tenacity · polars · pydantic-settings · jsonschema | discover → fetch → extract → cross-vendor verify → gate → persist; delta-only, spend-capped ($25/day) |
| **Store** | PostgreSQL 16 · SQLAlchemy 2.0 · Alembic · JSONB `Field<T>` | System of record; field-level provenance + confidence. 12 tables: data_center, power_project, entity, edge, source, feed, news, supply_node, supply_link + **review_log · change_log · gold_set** (audit + training trail) |
| **Read-model** | DuckDB · `data.json` (~3.3 MB) · `validate_data.py` (JSON Schema) | Flatten store → one validated UI contract; a **12-gate** publish validator blocks bad publishes |
| **Serving / UI** | Next.js 15 · React 19 · TypeScript · Tailwind v4 · MapLibre GL · d3 + d3-sankey · zod | The Compute Terminal — **3 tabs**: Overview (flow + clearing price) · Chain Analysis (entity → site dossier → news rail) · Explorer (geography), + a Review queue; a pure function of `data.json` |
| **Ops** | Docker Compose · GitHub Actions · uv · pytest | Build, test, gate, run |

**Models:** discover `grok-4.5` · extract `grok-4.20-0309-non-reasoning` (xAI) · verify **`claude-sonnet-5`** (Anthropic, cross-vendor) — moved off `claude-opus-4-8` on 2026-07-30 **by measurement**, not preference: `dcv bakeoff` over 16 records × 5 backends found it matched opus-4.8 on every axis measurable without ground truth, with the highest verdict agreement of any candidate (0.917), at **0.69× the all-in cost**. See `docs/verifier-selection-findings.md`.

> **Update (2026-07):** xAI **retired Grok Live Search** (HTTP 410 on 2026-01-12). Discovery has been **migrated to xAI's Agent Tools API** (`/responses` with the `web_search` + `x_search` server-side tools, `grok-4.5`), restoring the live-X freshness signal; `x_search` runs on a rolling window (`DISCOVERY_SEARCH_WINDOW_DAYS`, default 90). Extractor stays **`grok-4.20-0309-non-reasoning`** on `/chat/completions` (unaffected by the deprecation).

**Model diversity is the point (decision #4):** Grok *extracts*, Claude *verifies*. A
verifier from a different vendor is what makes an automated "confirmed" flag mean
something — same-vendor agreement is correlated, so it can't reach auto-approve.

## Quickstart

### Option 0 — read-only, no keys, no spend (start here if you are new)

Everything below runs off data that is **already committed**. No API keys, no paid calls, no
ingest. This is the fastest way to understand what the project actually holds.

```bash
cd web && npm install && npm run dev        # → http://localhost:3000
```

`npm run dev` copies the repo-root `data.json` into `web/public/` for you (`predev` →
`scripts/sync-data.mjs`), so a fresh clone serves the real 3-tab terminal — Overview,
Chain Analysis, Explorer — off the last published read-model. The sync never overwrites a
*newer* `public/data.json`, so once you start running the pipeline your own output wins.

To create a local **system of record** without importing raw production data:

```bash
docker compose up -d postgres
export PYTHONPATH=pipeline
python -m dcv db-upgrade
python -m dcv seed                          # loads the committed demo fixture
python -m dcv review --segments             # what the review queue is actually made of
python -m dcv dedup                         # open duplicate groups, nothing written
python -m dcv validate                      # the 12-gate publish gate
```

None of those commands spend money. Local snapshots created by `./scripts/store-dump.sh`
go to the gitignored `pipeline/snapshots/` directory. Share snapshots only through an
approved private data channel.

### Option A — Docker (one command)

```bash
cp .env.example .env          # add your free EIA_API_KEY (eia.gov/opendata/register.php)
docker compose up             # postgres + web  → http://localhost:3000
docker compose run --rm pipeline db-upgrade
docker compose run --rm pipeline seed
docker compose run --rm pipeline phase-a-ingest --states TX
docker compose run --rm pipeline emit
```

> macOS without Docker Desktop: `brew install colima docker-compose && colima start` gives you a daemon.

### Option B — Local dev (native, fastest to iterate)

```bash
docker compose up -d postgres                 # just the DB
uv venv --python 3.12 && uv pip install -e pipeline
export PYTHONPATH=pipeline                     # (avoids editable-install flakiness on iCloud)
python -m dcv db-upgrade
python -m dcv seed                             # loads the demo bridge (data centers, entities, supply chain)
python -m dcv phase-a-ingest --states TX       # live EIA + ISO → 1,700+ TX power projects
python -m dcv emit                             # → data.json (validated) + web/public/data.json
cd web && npm install && npm run dev           # http://localhost:3000
```

## Pipeline CLI (`python -m dcv …`)

| Command | Does |
|---|---|
| `db-upgrade` | apply Alembic migrations (`--revision`, default `head`) |
| `db-revision` | create a migration (`--message`, `--autogenerate/--no-autogenerate`) |
| `seed` | load the demo read-model into the store (idempotent bridge) |
| `phase-a-ingest --states TX` | EIA-860M + 7 ISO queues (gridstatus) → normalize → geocode → BTM → upsert |
| `phase-b-discover --states TX` | discovery only (Exa + Grok Agent Tools web+X + GDELT/RSS) → print candidate queue |
| `phase-b --states TX` | full Phase B: discover → fetch → extract (Grok) → verify (Claude) → persist |
| `phase-b-goldset` | load the TX gold set into the store |
| `phase-b-eval` | score Phase-B rows vs the gold set (recall/precision/field/dup) |
| `enumerate --states TX` | directory enumeration (PeeringDB) → operating install base as `data_center` rows |
| `enrich-capacity --states TX` | recover `capacity_mw` for sizeless rows (Exa + Grok, delta-only, quote-guarded) |
| `wire-edges` | wire value-chain `operates` edges (facility → operator entity) for enumerated rows |
| `wire-news` | wire the newsfeed to facilities — discovered source articles → linked `News` items |
| `backfill` | P1: fill existing-but-empty columns (operator/tenant, status_history, county) from data already held |
| **Compute chain (P2–P3, Band 1)** | |
| `promote-backbone` | put the 37 curated chain companies into `entity` as first-class rows |
| `purge-denied-sources` | withdraw every value sourced from a tier the VALUE may not come from — tier 1 (licensed competitor, decision #1) **or tier 3** (modelled figures). A withdrawal also **surrenders the confidence that value earned** (capped at the review floor, only above the auto-approve line) — otherwise `_gate` re-approves a row holding nothing. `--cap-confidence` repairs rows an earlier purge left behind. Dry run by default, audited to `change_log` |
| `capacity-audit` | reconcile every stored `capacity_mw` against its own quote (unit-aware), its `measure`, and its source tier. `--fix` withdraws the inadmissible ones, `--restore` puts them back exactly |
| `dedup` | propose duplicate data-center groups (identical exact coordinates; normalised name+state). `--apply` marks losers `duplicate_of` so emit drops them and prints a **batch id**; `--undo --batch <id>` reverses exactly that run; `--batches` lists past runs and whether each is still in effect. `--elect <id>` overrides the auto-ranked survivor (scoped to that one group). Groups whose members disagree on capacity — **or where no member has one** — are held for a human |
| `gold-sample` / `gold-status` | stratified verification worksheet · per-field accuracy + signoff verdict |
| `bakeoff` | **phase 1** of the verifier bake-off — compete `settings.verify_model` against a slate over the *same* stratified sample, same prompt, same gate. Measures what needs no ground truth: structured-output validity (`schema_miss`/`malformed`/`truncated`/`refusal`/`error` — production collapses all five into "held as reported"), whether the model can find an **independent** second source at all, what it would do to the queue via the real `phaseb.verify.score`, and **all-in** measured $/record (tokens **+** server-side search). Read-only. Start with `--plan`; `--write-slate` to add a vendor. **`--mode retrieved`** swaps the architecture instead of the model: Exa retrieves, the model judges **closed-book** over the supplied pages (retrieved once per record and shared by every backend, so judges differ and evidence does not). That is what makes a no-search vendor a candidate — and it reports `cited_urls_not_supplied`, the direct read on whether retrieval removes fabrication or merely relocates it |
| `resolve-roles` | resolve DC role names (developer/operator/tenant/end_user) → entity ids; ties, compound values and undisclosed counterparties resolve to NEITHER and are logged |
| `backbone-reach` | **measure** which backbone entities EDGAR can reach an annual report for → `seed/backbone_reach.json` → `meta.rollups.backbone_reach` |
| `load-financials` | load `entity.financials` from the committed fixture — **EDGAR supplies revenue + capex; market cap comes only from the 8 FMP-reachable mega-caps** (EDGAR carries no price) |
| `reverify` | re-run **only** the cross-vendor trust gate on rows the verifier never checked (e.g. after an API outage); persists corroborating sources, dry run by default. `--segment reverifiable\|evidence_blocked\|gate_satisfied\|below_floor` targets one review-queue population using the same classifier `review --segments` counts with, so spend matches what was costed |
| `chain-topology` | **discover** real `supplies` edges — each buyer's 10-K names its own suppliers (Grok voted → Claude confirm → local id resolution) |
| `chain-quant` | quantify edges from disclosed customer-concentration %s (open-ended: infers the counterparty) |
| `chain-quant-named` | quantify an **already-named** topology edge (closed question — no counterparty inference) |
| `chain-identity` | flip an inferred counterparty to `named` using the buyer's 10-K + first-party press |
| **Human review (Band-1 #3)** | |
| `review` | print the HITL queue — `needs_review` in active-learning order (uncertainty × value), disputed first. **`--segments`** classifies it by *what would move each row* (discovery / verify / decision) instead of listing it — depth alone hides that 32% can never be approved by review at all |
| `review-drain` | ingest user disputes → `review_log` + **re-open** each record for re-verification |
| `review-decide <id> --decision approve\|reject\|edit\|dismiss` | record a human verdict (`dismiss` undoes an unfounded dispute) |
| **Publish** | |
| `emit` | DuckDB reads Postgres → assembles `data.json` → **validate_data.py gate** |
| `validate` | run the publish gate on the current `data.json` |
| `build --states TX [--skip-ingest]` | db-upgrade → seed → ingest → emit (all-in-one; optionally reuse the current store) |

## The data contract

`data.json` (contract **`schema_version` 1.2**) is validated by `pipeline/data.schema.json` +
`pipeline/validate_data.py` — the CI publish gate. Two groups of keys:

- **Real pipeline output** — `meta` (incl. `meta.rollups`: `financials_coverage`, `edge_coverage`,
  `review_queue`), `datasets{data_center, power_project, news}`, `entities[]` (with per-metric
  `financials`), `edges[]` (547 DC role edges), `feeds[]`, `supply_chain{nodes,links}`.
- **Compute-chain layer** — `layers[]`, `chain{entities,edges}`, `projects[]`, `power[]`, `assets[]`,
  `skus[]`, `providers[]`, `prices[]`, `price_terms`, `forwards[]`. Financials and 12 topology edges
  are real; **prices/forwards/assets are still an illustrative seed** and are flagged as such in the UI.

The validator runs nine gates: `structural` (JSON Schema) · `referential` · `financials_integrity` ·
`edge_integrity` · `review_queue_integrity` · `semantic` (trust + freshness + acyclic). Errors block
publish; warnings don't. Every gate rule ships with a must-pass **and** a must-fail test.

## Phase B — agentic discovery (Design Y)

Turns the open web into cited, confidence-scored `data_center` records. Cross-vendor
by design: **Grok extracts** (`grok-4.20-0309-non-reasoning`), **Claude verifies** (different vendors).

```bash
# add EXA_API_KEY, XAI_API_KEY, FIRECRAWL_API_KEY, ANTHROPIC_API_KEY to .env
python -m dcv phase-b-discover --states TX      # free smoke: GDELT+RSS work without keys
python -m dcv phase-b --states TX               # full run (paid; spend-capped at $25/day)
python -m dcv phase-b-goldset                   # load the TX gold set
python -m dcv emit && python -m dcv phase-b-eval  # publish + score vs targets
```

Guardrails baked in: **every number needs a supporting quote** (hallucination kill),
`confirmed` requires **≥2 independent sources AND cross-vendor agreement**, spend is
capped and delta-only (already-seen URLs are skipped). Gate: ≥0.90 → approved,
0.60–0.89 → needs_review, <0.60 → reported.

## Directory enumeration — the operating base

News discovery (Phase B) finds *newsworthy new builds* but structurally misses the
existing **operating** install base (colo/interconnection facilities that make no
news). `enumerate` fills that gap from structured facility directories (PeeringDB
first) — no LLM: map facility → `operating` `data_center` row, with a light
name+state cross-source dedup and idempotent re-runs (natural key `peeringdb:{id}`).

```bash
python -m dcv enumerate --states TX,VA,CA   # PeeringDB → operating facilities
python -m dcv emit                          # rebuild data.json
```

Result (TX): operating rows **10 → 123** (CleanView shows 125) — the operating gap
is essentially closed for enumerated states. The two modes are **complementary**:
news → *planned / under-construction* new builds; enumeration → the *operating* base.
Remaining gap is the *planned* long tail (permit/rezoning filings → Phase D) and
hyperscale self-build (operator facility pages). Cross-source entity resolution
(merging a PeeringDB site with a news row for the same facility) is a Phase C refinement.

**Capacity enrichment.** Directory rows arrive without a size, so `enrich-capacity`
back-fills `capacity_mw` for the delta: a targeted Exa search + cheap Grok extraction
pulls each facility's MW **with a supporting quote** (unquoted numbers are dropped;
provenance grounded to the page the quote came from). Delta-only + spend-capped +
per-row commit → resumable. Result: capacity coverage **10% → 76%** (327/428 rows),
**60.6 GW** tracked, at ~**$0.006/facility** (73% hit-rate). Single-source + quoted →
confidence 0.65; cross-vendor verifying the number (Claude) is a future hardening.

**Value chain.** `wire-edges` materializes each facility's operator as the value-chain
graph the Chain view reads: an Entity per operator + an `operates` edge (facility →
operator). Enumerated sites in the Chain view: **6 → 354** projects. Operator→category
comes from an expanded canonical map (CoreSite, Flexential, Cologix, …); the obscure
long-tail stays `other`. It touches only the row's `developer_category` (keeping the
provider-type filter in step) — capacity + sources are left intact. The demand side
(tenant / end-user) needs news/leasing extraction and is a separate effort.

**Newsfeed.** `wire-news` turns the source articles the pipeline already discovered
into `news[]` records linked to the facility they're about — linkage is exact (the
article was the evidence used to extract that facility). Newsfeed: **11 → 272 items,
264 linked**; titles from the trade-press URL slug, dates parsed from the URL, and a
short filter bar (known publishers reuse the seed feed ids; the long tail lumps into
"Independent / other press"). Registries, filings, and the CleanView competitor are
excluded (decision #1). One article that sourced several facilities links to all of them.

## The compute chain (P2–P3 + Band 1)

The chain graph answers *who depends on whom, and how much*. Three separate facts, sourced
and flagged separately — conflating them is how a dashboard starts lying:

| Fact | Source | Where it shows |
|---|---|---|
| **Entity size** (market cap / revenue / capex) | EDGAR XBRL `companyfacts` (free) + FMP for the 8 tickers its plan allows | node size + the weight toggle |
| **Topology** — does A supply B at all? | the **buyer's** own 10-K names its suppliers | `link_basis: named` + `topology_basis` |
| **Magnitude** — how much? | the **supplier's** disclosed customer-concentration % | `pct_revenue` + `rev_basis: disclosed` |

```bash
python -m dcv promote-backbone && python -m dcv load-financials   # entity financials
python -m dcv backbone-reach               # size-reach measured value (network)
python -m dcv chain-topology --limit 12 --budget 4                # discover named supplies edges
python -m dcv chain-quant-named --budget 3                        # size the named edges
python -m dcv emit
```

Coverage is stated honestly in `meta.rollups` and surfaced in the UI banner rather than
smoothed over — currently revenue **22/37**, capex **13/37**, market cap **8/37** (EDGAR carries
no price), topology **12 named / 32 seed**. Known structural limits, all logged rather than
silently capped:

- Only **fabless semiconductor filers** name suppliers concretely; cloud/systems filers (MSFT,
  GOOGL, AMZN, META, ORCL, DELL, EQIX) use generic language → the method goes dark at the cloud tier.
- **Foreign-listed suppliers** (Foxconn, Samsung, SK Hynix) file no US annual report, so buyer
  filings can *find* those edges but supplier filings can never *size* them.
- An edge with no disclosed magnitude carries **no** `pct_*` — the UI renders "not quantified" and
  the flow sankey skips it. A fake `0` would render as "0%".

## Human review + the dispute loop (Band-1 #3)

The reader is a sensor, not a support ticket. Disputing a value in the UI writes to `review_log`
and **re-opens the record** for cross-vendor re-verification.

```bash
python -m dcv review --segments            # WHAT WOULD MOVE each row — read this first
python -m dcv review --limit 25            # the queue: uncertainty x value, disputed first
python -m dcv review-drain                 # user disputes -> review_log + re-open
python -m dcv review-decide <id> --decision approve --reviewer you --note "checked the permit"
python -m dcv emit                         # republish the queue depth
```

**Start with `--segments`, not the depth.** The queue looks like one backlog wanting one scarce
input (human hours). Measured over 401 data centers it is three populations wanting three
different things, and human hours is the answer for about **1%** of it:

| segment | rows | what actually moves it |
|---|---:|---|
| `reverifiable` | 262 (65%) | **verify** spend — ≥2 source domains, below auto-approve. 236 sized (19,579 MW), but only **4 carry a quote**, so it re-checks values, not values-plus-evidence |
| `evidence_blocked` | 129 (32%) | **discovery** spend — <2 distinct domains, so the gate can *never* approve them however many humans look. **Zero carry a capacity value**: a PeeringDB listing with no number and no quote gives a reviewer nothing to decide, and approving it just restates the directory |
| `gate_satisfied` | 5 (1%) | a **decision** — already meets the approve gate, re-opened by a source-policy citation strip rather than a failed verification |
| `below_floor` | 5 (1%) | investigate — verifier failed or conflicted |

Spend against a segment with `dcv reverify --status needs_review --segment reverifiable --apply`;
it uses the same classifier, so the money targets the population the table describes.

Design rules worth knowing before you change it:

- **The web tier holds no DB credentials** and cannot write a verdict — `POST /api/review` only
  appends a fact to `pipeline/inbox/disputes.jsonl`. Approve/reject/dismiss live at the CLI so
  every verdict carries a named reviewer.
- **Hysteresis** — a dispute can only *re-open* a record, never reject it, and a record with an
  already-open dispute is not de-rated again. One bad-faith dispute can't destroy a verified
  value; a persistent one can't grind it to the floor either.
- **`dismiss` is the undo** — it restores the pre-dispute `review_status`/`confidence`/
  `last_verified` from `review_log.before`. Without it an unfounded dispute is permanent.
- The **publish gate blocks** on an undrained inbox, a stale queue depth, or a disputed record
  still reading `approved` (a dispute that routed nowhere).

## Repo layout

- `pipeline/` — the `dcv` package: Phase A (sources · normalize · geocode · btm · ingest), `clients/` (grok · claude · exa · firecrawl · **edgar** · fmp · spend), `phaseb/` (discover · fetch · extract · verify · persist · goldset · eval), the chain layer (`backbone` · `financials` · `chain_topology` · `chain_quant` · `chain_identity` · `compute_seed`), `review.py` (HITL queue + dispute drain), `backfill.py`, emit + validator + tests
- `pipeline/inbox/` — the append-only user-dispute inbox the web tier writes and `review-drain` consumes (gitignored; it is runtime state, not source)
- `pipeline/seed/` — committed, reviewable fixtures: `financials*.json`, `chain_edges*.json`, `chain_topology.json`, and `tx_gold_set.json`; full database snapshots are not source artifacts
- `scripts/` — `store-dump.sh` / `store-restore.sh` for ignored local snapshots under `pipeline/snapshots/`; restore is destructive and refuses a populated DB without `--force`
- `db/` — Alembic migrations (Postgres SoR)
- `web/` — Next.js app (`lib/skeleton.ts` markup + `lib/runtime.ts` logic + `components/DcvApp.tsx`)
- `docs/` — product, architecture, research, handoff, and operational documentation; see `docs/README.md`
- `.github/workflows/ci.yml` — validate-data gate · pipeline pytest · web build

## Known follow-ups

- **Single-source warnings** on gov/ISO rows are expected (the ≥2-source rule is uniform); a trust-weighted confirm rule is a Phase C refinement.
- **Cross-source dedup** is a light name+geo+capacity pass; entity resolution + fuzzy merge is Phase C. 33 groups remain open (774.7 MW double-counted) and **all of them need a human** — the two matchers propose, a person applies (`dcv dedup --apply --elect <id>`), and `--undo --batch` reverses exactly one run.
- ⚠️ **`reverify` commits its whole run in ONE transaction** — `session_scope()` wraps the entire loop, so nothing is written until every row finishes. Combined with `SpendLimitError` subclassing `BaseException` (which sails past `except Exception`), a cap trip at row 250 of 262 **discards all 250 rows of work while the money stays spent**. Same for a crash or Ctrl-C. Batch the commit (every N rows, or a savepoint per row) before the next long paid run.
- **The fail-closed directory guard reads HOSTNAMES, not paths.** `aterio.io` (ruled tier 2 on 2026-08-07) passed every check because the tell is in `/us-data-centers/`. Widening it to match paths is *not* free — trade press and operators' own sites publish under `/data-centers/` too — so it is pinned by a test and left open deliberately, not overlooked.
- **~360 SPP queue rows** classify as "Other" technology because their queue fuel field is **blank** — no data to classify, not a mapping gap.
- Move the repo **out of iCloud** for dev-server performance (node_modules/.venv sync churn).
- **Never run `npm run build` while `next dev` is up** — both write `.next/` and the production
  build corrupts the dev server's chunk map (every page 500s with `Cannot find module './NNN.js'`).
  Use **`npm run build:check`**, which builds into `.next-verify`. Recovery: `rm -rf .next` + restart.
- `market_cap` stays **8/37** until a price source exists (EDGAR has no price); Finnhub or
  price × EDGAR shares-outstanding are the candidates. No `FMP_API_KEY` in `.env` today.
- The **backbone is missing the semiconductor-equipment tier** (ASML, Tokyo Electron, Lam Research,
  Teradyne, Advantest) — surfaced by `chain-topology` as unresolved supplier names and logged in
  `pipeline/seed/chain_topology.json`. Highest-leverage next expansion.

_Fixed this session:_ ERCOT queue now ingests (state-name normalization "Texas" → TX, 1,789 TX rows); ISO fuel abbreviations (CT/CTG/reciprocating) + ERCOT compound labels now classify; negative interconnection capacities are nulled at the source.

## Decisions & open items

**Decided (Phase B — "Design Y"):** discovery = **Exa + Grok Agent Tools (web+X) + GDELT/RSS**
(the Grok live-X freshness edge, originally on Live Search, now runs on xAI's **Agent Tools API**
after xAI retired Live Search — HTTP 410); extract = **Grok 4.20 non-reasoning** (cheap, high-volume);
verify = **Claude Opus 4.8** (cross-vendor trust gate, config-swappable to Sonnet 5 at scale).
Rationale: same-vendor agreement is correlated and can't certify facts, so the verifier must be a
different vendor than the extractor.

**Still open:** orchestrator (GitHub Actions → Prefect) · API host (Next route handlers vs
FastAPI) · national-scale two-tier verify (Grok 4.1 Fast fast-pass → escalate on conflict).
Defaults in `docs/build-handoff-spec.md §8`.

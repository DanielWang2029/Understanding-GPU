#!/usr/bin/env python3
"""build_p0_data.py — produce the v1.2 read-model without running the full pipeline.

P0 (data-collection plan §7): "extend emit.py to v1.2 (arrays present, illustrative
where absent)". emit.py does this from the live store; this standalone builder does the
same merge against the already-emitted real data.json, so the Next app has a v1.2
contract to render even when Postgres/keys aren't up. It:

  1. loads the current (real, v1.0) data.json,
  2. merges the illustrative compute-chain seed (dcv.compute_seed) under NEW top-level
     keys that don't collide with the real arrays,
  3. bumps schema_version -> 1.2 and annotates meta,
  4. writes web/public/data.json (+ root data.json / data.js for parity).

Idempotent: re-running overwrites the seed blocks cleanly.

Usage:  python3 pipeline/build_p0_data.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "pipeline"))

from dcv.compute_seed import build_seed  # noqa: E402

SCHEMA_VERSION = "1.2"
SEED_KEYS = ("layers", "chain", "projects", "power", "assets", "skus",
             "providers", "prices", "price_terms", "forwards")


def build(model: dict) -> dict:
    seed = build_seed()
    # merge seed blocks (new keys only — real arrays untouched)
    for k in SEED_KEYS:
        model[k] = seed[k]
    model["schema_version"] = SCHEMA_VERSION
    meta = model.setdefault("meta", {})
    meta["illustrative_compute_seed"] = (
        "layers/chain/projects/power/assets/skus/providers/prices/forwards are an "
        "ILLUSTRATIVE compute-chain seed (mid-2026 representative figures) for the "
        "Overview/Chain Analysis/Explorer/Price Board views. Newsfeed + datasets are "
        "real pipeline output. P1 derives the chain graph from real entities+edges; "
        "P2 attaches FMP financials."
    )
    return model


def main() -> None:
    src = REPO / "web" / "public" / "data.json"
    if not src.exists():
        src = REPO / "data.json"
    model = json.loads(src.read_text())
    model = build(model)
    text = json.dumps(model, indent=2, ensure_ascii=False)

    (REPO / "web" / "public" / "data.json").write_text(text + "\n")
    (REPO / "data.json").write_text(text + "\n")
    (REPO / "data.js").write_text("window.DCV_DATA = " + text + ";\n")

    seed = build_seed()
    print(f"✓ v1.2 data.json — schema_version {model['schema_version']}")
    print(f"  real:  {len(model['datasets']['data_center'])} data_center · "
          f"{len(model['datasets']['power_project'])} power_project · "
          f"{len(model['datasets']['news'])} news · {len(model.get('entities', []))} entities")
    print(f"  seed:  {len(seed['chain']['entities'])} chain entities · "
          f"{len(seed['chain']['edges'])} supply edges · {len(seed['projects'])} projects · "
          f"{len(seed['power'])} power · {len(seed['assets'])} assets · "
          f"{len(seed['skus'])} skus · {len(seed['prices'])} prices · {len(seed['forwards'])} forwards")


if __name__ == "__main__":
    main()

"""build_financials_fixture — generate pipeline/seed/financials.json (P2.2, L9).

The dcv pipeline runs standalone and cannot reach the FMP MCP tools; the connected
FMP plan also only serves a FIXED SET OF 8 MEGA-CAP TICKERS (income-statement AND
market-cap both denied for every other symbol — probed 2026-07-19). So the real
financials for those 8 were pulled in-session via FMP MCP and are baked in here as
`REAL` (authoritative, disclosed, with filing dates); the other 21 backbone names
carry the illustrative compute_seed figures, flagged `estimated`.

This is the "in-session MCP pull → fixture" realization of the L9 connector; the
keyed REST client in `dcv/clients/fmp.py` is the automation path (needs FMP_API_KEY
+ a higher plan). `dcv financials load` reads this fixture into entity.financials.

Re-run: `python3 pipeline/build_financials_fixture.py`. To widen real coverage
later (EDGAR / Finnhub / FMP upgrade), add entries to REAL (or a second real source
dict) and re-run — estimated names drop out of the seed fallback automatically.

Units: raw USD. market_cap as_of = batch-market-cap date; revenue as_of = filingDate.
TWD figures (TSM) converted at FX below. The `aws` node carries Amazon.com
consolidated (parent) financials — it stands in for Amazon-as-cloud-provider.
"""
from __future__ import annotations

import json
from pathlib import Path

from dcv.backbone import CANONICAL
from dcv.compute_seed import build_seed

HERE = Path(__file__).resolve().parent
FIXTURE = HERE / "seed" / "financials.json"

# TWD→USD (mid-2026, ≈32.5 TWD/USD). Approximate — flagged on converted fields.
TWD_USD = 0.0308

FMP_ALLOWED = ["NVDA", "TSM", "INTC", "AMD", "MSFT", "GOOGL", "AMZN", "META"]

# --- the 8 the FMP plan serves — pulled in-session via FMP MCP (2026-07-19) --------
# id: ticker, market_cap(+date), revenue(+filingDate, period), costOfRevenue, netIncome,
#     weightedAverageShsOut, currency, optional note. All values as reported (USD unless noted).
_MC_DATE = "2026-07-17"  # batch-market-cap date
REAL = {
    "nvidia": dict(ticker="NVDA", mc=4912261010000, rev=215938000000, rev_asof="2026-02-25",
                   period="FY2026", cogs=62475000000, ni=120067000000, shs=24359000000),
    "google": dict(ticker="GOOGL", mc=4194138171504, rev=402963000000, rev_asof="2026-02-05",
                   period="FY2025", cogs=162535000000, ni=132170000000, shs=12116000000),
    "microsoft": dict(ticker="MSFT", mc=2925464302600, rev=281724000000, rev_asof="2025-07-30",
                      period="FY2025", cogs=87831000000, ni=101832000000, shs=7433000000),
    "aws": dict(ticker="AMZN", mc=2659477833000, rev=716924000000, rev_asof="2026-02-06",
                period="FY2025", cogs=356414000000, ni=77670000000, shs=10656000000,
                unit="parent_consolidated",
                note="Amazon.com consolidated (parent) — revenue incl. non-cloud; AWS segment ≈ $0.13T"),
    "tsmc": dict(ticker="TSM", mc=2066138037600, rev=3848510949000, rev_asof="2026-04-16",
                 period="FY2025", cogs=1543585648000, ni=1735678080000, shs=5185652400,
                 fx=TWD_USD, note="revenue/COGS/NI reported in TWD, converted TWD→USD @%.4f" % TWD_USD),
    "meta": dict(ticker="META", mc=1639846785644, rev=200966000000, rev_asof="2026-01-29",
                 period="FY2025", cogs=36175000000, ni=60458000000, shs=2521000000),
    "amd": dict(ticker="AMD", mc=808386256000, rev=34639000000, rev_asof="2026-02-04",
                period="FY2025", cogs=17487000000, ni=4335000000, shs=1624000000),
    "intel": dict(ticker="INTC", mc=477671040000, rev=52853000000, rev_asof="2026-01-23",
                  period="FY2025", cogs=34478000000, ni=-267000000, shs=4856000000),
}

FMP_SRC_IS = ["FMP:statements/income-statement"]
FMP_SRC_MC = ["FMP:company/batch-market-cap"]
SEED_SRC = ["compute_seed"]


def _real_entry(rid: str, r: dict) -> dict:
    fx = r.get("fx", 1.0)
    def usd(x):  # convert reported→USD when fx applies
        return round(x * fx) if fx != 1.0 else x
    rev = {"value": usd(r["rev"]), "as_of": r["rev_asof"], "period": r["period"],
           "basis": "disclosed", "sources": FMP_SRC_IS}
    if fx != 1.0:
        rev["note"] = "TWD→USD @%.4f" % fx
    mc = {"value": r["mc"], "as_of": _MC_DATE, "basis": "disclosed", "sources": FMP_SRC_MC}
    if r.get("unit"):  # unit-of-analysis flag (e.g. parent-consolidated vs segment) — review C9
        mc["unit"] = rev["unit"] = r["unit"]
    e = {
        "ticker": r["ticker"], "currency": "USD",
        "market_cap": mc,
        "revenue": rev,
        # kept for P3 (edge %COGS) + later market-cap derivation; not persisted to entity.financials
        "_cost_of_revenue": usd(r["cogs"]), "_net_income": usd(r["ni"]), "_shares_out": r["shs"],
    }
    if r.get("note"):
        e["note"] = r["note"]
    return e


def _est_entry(seed_ent: dict) -> dict:
    tick = seed_ent.get("ticker")
    tick = tick if tick and tick not in ("private", "—", "-") else None
    return {
        "ticker": tick, "currency": "USD",
        "market_cap": {"value": int(seed_ent["market_cap"] * 1e9), "as_of": "2026-07-19",
                       "basis": "estimated", "sources": SEED_SRC},
        "revenue": {"value": int(seed_ent["revenue"] * 1e9), "as_of": "2026-07-19",
                    "basis": "estimated", "sources": SEED_SRC},
    }


def build() -> dict:
    seed_ents = {CANONICAL.get(e["id"], e["id"]): e for e in build_seed()["chain"]["entities"]}
    out = {"_meta": {
        "generated_at": "2026-07-19",
        "source": "FMP MCP (income-statement + batch-market-cap) for 8 disclosed mega-caps; "
                  "compute_seed illustrative figures for the other 21 (flagged estimated)",
        "fmp_allowed_tickers": FMP_ALLOWED,
        "fx": {"TWD_USD": TWD_USD},
        "units": "raw USD",
        "note": "market_cap as_of = batch date; revenue as_of = filingDate. Widen real "
                "coverage via EDGAR/Finnhub/FMP-upgrade by extending REAL in the generator.",
    }}
    real_n = est_n = 0
    for rid, ent in seed_ents.items():
        if rid in REAL:
            out[rid] = _real_entry(rid, REAL[rid]); real_n += 1
        else:
            out[rid] = _est_entry(ent); est_n += 1
    out["_meta"]["coverage"] = {"disclosed": real_n, "estimated": est_n}
    return out


if __name__ == "__main__":
    fx = build()
    FIXTURE.parent.mkdir(parents=True, exist_ok=True)
    FIXTURE.write_text(json.dumps(fx, indent=2, ensure_ascii=False) + "\n")
    cov = fx["_meta"]["coverage"]
    print(f"✓ wrote {FIXTURE.relative_to(HERE.parent)} — "
          f"{cov['disclosed']} disclosed, {cov['estimated']} estimated")

# dcv — dataCenterView pipeline

Python 3.12 ingestion pipeline. **Phase A** (free power layer) + **Phase B** (agentic
data-center discovery→extract→cross-vendor verify, "Design Y") + the `data.json` emit step.

## CLI

> **The full command reference is the root [`README.md`](../README.md) "Pipeline CLI" table** — 31 commands.
> What follows is only the Phase-A/B path, kept here beside the run-env notes below.

```
python -m dcv db-upgrade                      # apply Alembic migrations (--revision head)
python -m dcv seed                            # load the demo read-model bridge (idempotent)

# Phase A — free structured power layer
python -m dcv phase-a-ingest --states TX      # EIA + ISO → normalize → geocode → BTM → Postgres

# Phase B — agentic data-center discovery (needs API keys; see .env below)
python -m dcv phase-b-discover --states TX    # discovery only → print the candidate queue
python -m dcv phase-b --states TX             # full: discover → fetch → extract → verify → persist
python -m dcv phase-b --states TX --no-verify # skip the paid Claude gate (cheap smoke)
python -m dcv phase-b-goldset                 # load the TX gold set into the store
python -m dcv phase-b-eval                    # score Phase-B rows vs the gold set

python -m dcv emit                            # DuckDB reads Postgres → data.json (--no-validate to skip the gate)
python -m dcv validate                        # run the nine publish gates (--max-stale-days 45)

# Trust / governance (Band 1–2) — all dry-run by default; add --apply to write
python -m dcv reverify --status reported      # re-run ONLY the cross-vendor gate on unverified rows
python -m dcv purge-denied-sources            # withdraw values sourced from a tier-1 competitor
python -m dcv resolve-roles                   # resolve developer/operator/tenant/end_user → entity ids
python -m dcv backbone-reach                  # classify which backbone entities EDGAR can reach
python -m dcv gold-sample && python -m dcv gold-status
python -m dcv review                          # the HITL queue (review-drain · review-decide)
```

## Local dev (native, fast)

```
uv venv --python 3.12 && source .venv/bin/activate
uv pip install --python .venv/bin/python -e pipeline
export PYTHONPATH="$PWD/pipeline"             # see note below
docker compose up -d postgres                 # Postgres = system of record
python -m dcv db-upgrade && python -m dcv seed
python -m dcv phase-a-ingest --states TX && python -m dcv emit
```

> **`PYTHONPATH` note:** the editable-install `.pth` does not always get picked up (e.g. when
> the repo path contains spaces, as under iCloud Drive), so `python -m dcv` can fail with
> `No module named dcv`. Exporting `PYTHONPATH="$PWD/pipeline"` is the reliable workaround.
> Also pass `python -u` when redirecting output to a file — stdout is block-buffered otherwise.

## Phase B keys & cost control

Set in the repo-root `.env` (gitignored):

| Key | Used by | Required? |
|---|---|---|
| `EXA_API_KEY` | discovery (neural search) | yes (main discovery source) |
| `XAI_API_KEY` | Grok extraction + Agent Tools discovery (web+X search) | yes |
| `ANTHROPIC_API_KEY` | Claude cross-vendor verify | optional — without it, records persist as `reported` (no trust gate) |
| `FIRECRAWL_API_KEY` | fetch/scrape thin candidates | optional — Exa candidates already carry text; thin ones are skipped |

Spend is capped (`DAILY_SPEND_LIMIT_USD`, default $25), delta-only (already-seen URLs are
skipped), and state-scoped for the pilot. Confidence gate: ≥0.90 **and** ≥2 independent
sources → `approved`; 0.60–0.89 → `needs_review`; <0.60 → `reported`.

> ⛔ **This gate runs, but its output is a per-path constant — don't build on it downstream.** Measured
> 2026-07-20: all 364 queued DCs carry exactly two confidence values (0.72 news-extracted, 0.75
> PeeringDB), so no *later* threshold can discriminate between them and `(1-conf)×log1p(mw)` ranks by
> capacity alone. See `docs/data-schema-and-validation-spec.md` §4.3.

> **Live-X signal via Agent Tools API:** xAI retired the old Live Search `search_parameters`
> (HTTP 410, 2026-01-12), so discovery's `_grok_agent` mode now calls the **Agent Tools API**
> (`clients/grok.py:search` → `/responses` with `web_search` + `x_search`, `grok-4.5`). `x_search`
> uses a rolling window (`DISCOVERY_SEARCH_WINDOW_DAYS`, default 90) and an optional
> `DISCOVERY_X_HANDLES` scope. Extraction stays on `/chat/completions` (unaffected).

## First live TX pilot (2026-07-15)

- **Full run** (`phase-b --states TX`): 66 new candidates after the delta filter → 7 records
  extracted → cross-vendor verified → **3 approved · 4 needs-review**, ~$1.20 spend.
- **Back-fill re-verify** of 52 legacy `reported` rows (persisted before the Claude key was set):
  **19 upgraded to approved · 11 to needs-review · 22 held at `reported`** (some at 0.20 = the
  verifier actively disagreed), ~$11.63 spend.
- Store now (Phase B `dcb-*` rows + seed): **37 approved · 15 needs-review · 28 reported**.

## Layout

- `dcv/config.py` — env-driven settings (keys, model ids, spend caps, gate thresholds)
- `dcv/models.py` — SQLAlchemy tables (the store schema; Alembic target metadata)
- `dcv/field.py` — the `Field<T>` provenance wrapper
- `dcv/normalize.py` — technology + status normalization maps (phase-a §4)
- `dcv/geocode.py` — US Census county-centroid geocoder
- `dcv/btm.py` — behind-the-meter data-center signal heuristic (phase-a §5)
- `dcv/sources/eia.py` · `dcv/sources/iso.py` — EIA-860M + 7 ISO queues (gridstatus)
- `dcv/clients/` — `exa` · `grok` · `claude` · `firecrawl` · `spend` (the shared cost ledger)
- `dcv/phaseb/` — `discover` · `fetch` · `extract` · `verify` · `persist` · `pipeline` · `goldset` · `eval`
- `dcv/emit.py` — Postgres → DuckDB rollups → `data.json` read-model
- `dcv/backfill.py` · `dcv/enumerate_dc.py` · `dcv/enrich.py` · `dcv/wire_edges.py` · `dcv/wire_news.py` — backfill + coverage
- **Chain layer** — `dcv/backbone.py` (37 entities + the reach classifier) · `dcv/financials.py` + `clients/{edgar,fmp}.py` · `dcv/chain_topology.py` · `dcv/chain_quant.py` · `dcv/chain_identity.py`
- **Trust layer** — `dcv/review.py` (HITL queue · drain · decide) · `dcv/dc_roles.py` (role→entity resolution) · `dcv/goldset.py` (L6 gate) · `dcv/reverify.py` (re-run the cross-vendor gate)
- **Licensing layer** — `dcv/source_policy.py` (decision #1 as code) · `dcv/purge_sources.py` (withdraw denied-source values)
- `dcv/compute_seed.py` — the illustrative compute-chain seed (assets/skus/prices/forwards)
- `validate_data.py` + `data.schema.json` — the CI publish gate, **nine gates** (see `docs/data-schema-and-validation-spec.md` §4.1)


#!/usr/bin/env python3
"""build_edgar_financials.py — widen the financial spine past the 8 FMP mega-caps (Band-1 #1).

The connected FMP plan gates market_cap/revenue to 8 tickers, leaving 21 backbone names on
compute_seed estimates. SEC EDGAR's free XBRL companyfacts API (no key) discloses ANNUAL
REVENUE + CAPEX for every US filer — so this pulls it for the backbone entities whose revenue
is still `estimated` AND that resolve to a US CIK, and writes disclosed revenue/capex to
`pipeline/seed/financials_edgar.json`. `dcv load-financials` merges it OVER seed/financials.json
with disclosed-over-estimated precedence (market_cap is untouched — EDGAR has no price, so it
stays estimated until a price source is added).

Deliberately targets ONLY the currently-estimated names, which excludes the 8 disclosed
mega-caps — critically the `aws` node (=Amazon parent, a SEGMENT-unit mismatch): pulling
Amazon's consolidated revenue onto the AWS-cloud node would be the entity-unit-of-analysis bug,
so it must never be overlaid. Foreign filers with no US ticker (Samsung, SK Hynix, Foxconn,
Schneider) and privates (Crusoe, OpenAI, Anthropic, xAI) resolve to no CIK → stay estimated,
LOGGED explicitly (no silent cap). Non-USD XBRL (foreign IFRS) → None → stays estimated.

Live + regenerable (unlike the disconnected FMP MCP). Usage: python3 pipeline/build_edgar_financials.py
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "pipeline"))

from dcv.chain_quant import _ticker_cik_map  # noqa: E402
from dcv.clients import edgar  # noqa: E402
from dcv.compute_seed import build_seed  # noqa: E402

FMP_FIXTURE = REPO / "pipeline" / "seed" / "financials.json"
OUT = REPO / "pipeline" / "seed" / "financials_edgar.json"


def _field(hit: dict) -> dict:
    return {"value": hit["value"], "as_of": hit["as_of"], "basis": "disclosed",
            "period": f"FY end {hit['period']}", "sources": [hit["source"]]}


def main() -> None:
    fmp = json.loads(FMP_FIXTURE.read_text())
    tick = {e["id"]: e.get("ticker") for e in build_seed()["chain"]["entities"]}
    t2c = _ticker_cik_map()

    out: dict = {}
    got_rev = got_capex = 0
    skipped: list[str] = []
    for eid, fin in fmp.items():
        if eid.startswith("_"):
            continue
        if (fin.get("revenue") or {}).get("basis") != "estimated":
            continue  # already disclosed (the 8 mega-caps incl. the aws segment node) → never overlay
        tk = tick.get(eid) or fin.get("ticker")
        cik = t2c.get(tk) if tk else None
        if not cik:
            skipped.append(f"{eid} (ticker {tk!r} → no US CIK)")
            continue
        try:
            cf = edgar.company_financials(cik)
        except Exception as ex:  # a bad filer must not sink the batch
            skipped.append(f"{eid} ({type(ex).__name__})")
            continue
        entry: dict = {"ticker": tk}
        if cf.get("revenue"):
            entry["revenue"] = _field(cf["revenue"])
            got_rev += 1
        if cf.get("capex"):
            entry["capex"] = _field(cf["capex"])
            got_capex += 1
        if "revenue" in entry or "capex" in entry:
            out[eid] = entry
            # capex-without-revenue is a real shape (a 20-F filer that tags capex in USD but
            # revenue in its home currency), so the revenue cell must tolerate None.
            r = entry.get("revenue", {}).get("value")
            print(f"  [edgar-fin] {eid:<14} {tk:<6} rev={f'{r/1e9:.1f}B' if r else '—':<7} "
                  f"capex={'y' if 'capex' in entry else '—'}")
        elif cf.get("stale"):
            # Distinguish "stopped filing" from "files, but nothing USD-tagged" — only the
            # latter is a fact about the filing. See edgar.company_financials.
            skipped.append(f"{eid} ({tk} — DEREGISTERED, newest XBRL annual "
                           f"{'/'.join(cf['stale'])} is past the freshness horizon)")
        else:
            skipped.append(f"{eid} ({tk} — no USD annual revenue/capex in XBRL)")
        time.sleep(0.4)  # EDGAR politeness

    out["_meta"] = {
        "source": "SEC EDGAR XBRL companyfacts (free, no key) — disclosed annual revenue + capex",
        "method": "latest FY 10-K/20-F us-gaap Revenue* / PaymentsToAcquirePropertyPlantAndEquipment",
        "note": ("Widens the financial spine past the 8 FMP mega-caps. market_cap untouched "
                 "(EDGAR has no price). Merged OVER seed/financials.json by load-financials "
                 "(disclosed>estimated). Skipped (stay estimated, no silent cap): "
                 + "; ".join(skipped)),
        "coverage": {"revenue_disclosed": got_rev, "capex_disclosed": got_capex,
                     "skipped": len(skipped)},
    }
    OUT.write_text(json.dumps(out, indent=2) + "\n")
    print(f"\n✓ wrote {OUT.name} — {got_rev} revenue + {got_capex} capex disclosed; "
          f"{len(skipped)} stayed estimated")
    for s in skipped:
        print(f"    · skipped {s}")


if __name__ == "__main__":
    main()

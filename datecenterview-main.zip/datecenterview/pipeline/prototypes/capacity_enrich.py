"""Prototype — capacity enrichment for facilities missing capacity_mw.

The operating base (PeeringDB) has location + operator but no *size*: 383/428
data centers have no MW. This probes whether a targeted search + cheap extraction
can recover per-facility capacity, reusing the Phase B clients (Exa + Grok). It
measures hit-rate, spot-checkable accuracy (every number needs a supporting
quote), and cost on a small sample before we commit to enriching all 383.

    PYTHONPATH=pipeline python pipeline/prototypes/capacity_enrich.py 8

Not wired into the pipeline — a paid probe (Exa + Grok). Spend-capped.
"""
from __future__ import annotations

import re
import sys

from sqlalchemy import select

from dcv.clients import exa, grok, spend
from dcv.config import settings
from dcv.db import session_scope
from dcv.models import DataCenter

CAP_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "capacity_mw": {"type": ["number", "null"]},
        "quote": {"type": ["string", "null"]},
        "source_hint": {"type": ["string", "null"]},
    },
    "required": ["capacity_mw", "quote", "source_hint"],
}
SYS = (
    "Extract the electrical / IT power capacity in megawatts (MW) of ONE specific "
    "data-center facility from the provided web snippets. Return capacity_mw ONLY if "
    "a snippet explicitly states THIS facility's power/IT capacity in MW or GW "
    "(convert GW->MW). Include the exact supporting quote and the source URL. If not "
    "explicitly stated for this facility, capacity_mw=null. Never guess, and never "
    "infer from a campus or company-portfolio total."
)


def _sample(n: int) -> list[dict]:
    with session_scope() as s:
        rows = s.execute(
            select(DataCenter).where(
                DataCenter.id.like("dce-pdb-%"), DataCenter.capacity_mw.is_(None)
            )
        ).scalars().all()
    facs = []
    for r in rows:
        loc = r.location or {}
        facs.append({
            "id": r.id, "name": r.project_name, "op": r.developer_name,
            "city": loc.get("city"), "state": loc.get("state"),
            "url": (r.sources or [None])[0],
        })
    stride = max(1, len(facs) // n)           # spread the sample across operators/metros
    return facs[::stride][:n]


def enrich(fac: dict) -> dict:
    q = (f'{fac["name"]} {fac["op"] or ""} {fac["city"] or ""} {fac["state"] or ""} '
         f'data center power capacity megawatts')
    try:
        results = exa.search(q, num_results=5, with_text=True)
    except Exception as e:  # noqa: BLE001
        return {"err": f"exa:{type(e).__name__}"}
    snippets = "\n\n".join(f'[{r["url"]}]\n{(r.get("text") or "")[:1200]}' for r in results[:5])
    if not snippets.strip():
        return {"cap": None}
    user = (f'Facility: {fac["name"]} — operator {fac["op"]}, {fac["city"]}, {fac["state"]}\n\n'
            f'SNIPPETS:\n{snippets[:9000]}')
    try:
        content, _ = grok.chat(SYS, user, model=settings.extract_model, response_schema=CAP_SCHEMA)
    except Exception as e:  # noqa: BLE001
        return {"err": f"grok:{type(e).__name__}"}
    cap = content.get("capacity_mw")
    quote = content.get("quote") or ""
    # hallucination guard: the number must appear in the supporting quote
    ok = cap is not None and bool(re.search(r"\d", quote))
    return {"cap": cap if ok else None, "raw": cap, "quote": quote,
            "src": content.get("source_hint")}


def main(n: int) -> None:
    spend.configure(settings.daily_spend_limit_usd)
    facs = _sample(n)
    print(f"probing capacity for {len(facs)} facilities missing capacity_mw\n")
    hits = 0
    for f in facs:
        r = enrich(f)
        cap = r.get("cap")
        hits += bool(cap)
        mark = "HIT " if cap else "miss"
        print(f"  [{mark}] {f['name'][:42]:42} [{f['city']}, {f['state']}] → {cap} MW")
        if cap and r.get("quote"):
            print(f'         "{r["quote"][:130]}"')
        if r.get("raw") and not cap:
            print(f"         (dropped unquoted value {r['raw']})")
        if r.get("err"):
            print(f"         ERR {r['err']}")
    n = max(len(facs), 1)
    per = spend.LEDGER.total_usd / n
    print(f"\nhit-rate: {hits}/{len(facs)} ({100 * hits // n}%)")
    print(f"spend: {spend.LEDGER.summary()}  → ≈ ${per:.3f}/facility")
    print(f"extrapolated to 383 sizeless rows ≈ ${per * 383:.2f}")


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 8)

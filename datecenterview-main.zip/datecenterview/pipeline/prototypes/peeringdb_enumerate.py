"""Prototype — enumerate the operating install base from PeeringDB.

Tests the hypothesis that facility-directory *enumeration* closes the "operating"
coverage gap that news-first Phase B discovery leaves behind (TX: ours ~10
operating vs CleanView ~125). Prints counts + a sample so we can decide whether
to promote this to a real discovery/ingest mode before investing further.

    PYTHONPATH=pipeline python pipeline/prototypes/peeringdb_enumerate.py TX VA CA

Not wired into the pipeline yet — deliberately a throwaway probe.
"""
from __future__ import annotations

import collections
import sys

from dcv.clients import peeringdb


def probe(state: str) -> list[dict]:
    facs = peeringdb.facilities(state=state)
    cands = [peeringdb.to_candidate(f) for f in facs]
    withgeo = sum(1 for c in cands if c["lat"] and c["lng"])
    by_city = collections.Counter(c["city"] for c in cands)
    by_op = collections.Counter(c["operator"] for c in cands if c["operator"])

    print(f"\n=== PeeringDB facilities in {state}: {len(cands)} "
          f"(all 'Operating') ===")
    print(f"  with lat/lng   : {withgeo}/{len(cands)}")
    print(f"  distinct metros: {len(by_city)}  → top: "
          + ", ".join(f"{c}({n})" for c, n in by_city.most_common(6)))
    print(f"  distinct operators: {len(by_op)}  → top: "
          + ", ".join(f"{o}({n})" for o, n in by_op.most_common(5)))
    print("  sample (by networks present, a size proxy):")
    for c in sorted(cands, key=lambda x: -(x.get("net_count") or 0))[:12]:
        print(f"    · {c['project_name']}  —  {c['city']}, {c['state']}"
              f"  ·  op={c['operator']}  ·  nets={c['net_count']}  ·  {c['url']}")
    return cands


def main(states: list[str]) -> None:
    totals = {}
    for st in states:
        try:
            totals[st] = len(probe(st))
        except Exception as e:  # noqa: BLE001 — prototype: report and continue
            print(f"\n=== {st}: FAILED ({type(e).__name__}: {e}) ===")
            totals[st] = None
    print("\n=== summary (PeeringDB 'operating' vs our current + CleanView) ===")
    ref = {"TX": ("ours 10 op / 67 total", "CleanView 125 op / 355 total")}
    for st, n in totals.items():
        extra = f"   [{ref[st][0]} · {ref[st][1]}]" if st in ref else ""
        print(f"  {st}: PeeringDB {n} operating facilities{extra}")


if __name__ == "__main__":
    main([s.upper() for s in (sys.argv[1:] or ["TX"])])

"""dcv CLI — db-upgrade · seed · phase-a-ingest · emit · validate · build."""
from __future__ import annotations

import subprocess
import sys

import typer

from .config import settings

app = typer.Typer(add_completion=False, help="dataCenterView pipeline")


def _alembic_config():
    from alembic.config import Config
    cfg = Config()
    cfg.set_main_option("script_location", str(settings.repo_root / "db"))
    cfg.set_main_option("sqlalchemy.url", settings.database_url)
    return cfg


@app.command("db-upgrade")
def db_upgrade(revision: str = "head"):
    """Apply Alembic migrations."""
    from alembic import command
    command.upgrade(_alembic_config(), revision)
    typer.echo(f"✓ db upgraded to {revision}")


@app.command("db-revision")
def db_revision(message: str = "auto", autogenerate: bool = True):
    """Create a new Alembic revision (autogenerate by default)."""
    from alembic import command
    command.revision(_alembic_config(), message=message, autogenerate=autogenerate)


@app.command()
def seed():
    """Load the demo read-model into the store (idempotent bridge)."""
    from .seed import seed_store
    seed_store()


@app.command("phase-a-ingest")
def phase_a_ingest(states: str = typer.Option(None, help="Comma-separated states, or ALL. Defaults to INGEST_STATES.")):
    """EIA + ISO → normalize → geocode → BTM → upsert to Postgres."""
    from .ingest import phase_a_ingest as run
    state_list = (
        [s.strip().upper() for s in states.split(",") if s.strip() and states.upper() != "ALL"]
        if states else settings.states
    )
    run(state_list, settings.eia_api_key)


@app.command("phase-b-discover")
def phase_b_discover(
    states: str = typer.Option(None, help="Comma-separated states. Defaults to PHASE_B_STATES."),
    max_candidates: int = typer.Option(None, help="Cap on the candidate queue."),
):
    """Discovery only (Exa + Grok Agent Tools web+X search + GDELT/RSS) → print the candidate queue."""
    from .config import settings as _s
    from .phaseb import discover as disc
    state_list = _s._split_states(states) if states else _s.phase_b_state_list
    queue = disc.discover(state_list, max_candidates or _s.discovery_max_candidates)
    for c in queue[:40]:
        typer.echo(f"  [{c['mode']:>10}] {c['url']}")
    typer.echo(f"({len(queue)} candidates)")


@app.command("phase-b")
def phase_b(
    states: str = typer.Option(None, help="Comma-separated states, e.g. TX. Defaults to PHASE_B_STATES."),
    verify: bool = typer.Option(True, help="Run the Claude cross-vendor trust gate."),
    max_candidates: int = typer.Option(None, help="Cap on the candidate queue."),
):
    """Full Phase B: discover → fetch → extract (Grok) → verify (Claude) → persist."""
    from .config import settings as _s
    from .phaseb.pipeline import run
    state_list = _s._split_states(states) if states else _s.phase_b_state_list
    run(state_list, max_candidates=max_candidates, do_verify=verify)


@app.command("enumerate")
def enumerate_cmd(
    states: str = typer.Option(None, help="Comma-separated states. Defaults to PHASE_B_STATES."),
    source: str = typer.Option("peeringdb", help="Directory source (peeringdb)."),
):
    """Enumerate the operating install base from a facility directory (PeeringDB)."""
    from .config import settings as _s
    from . import enumerate_dc
    state_list = _s._split_states(states) if states else _s.phase_b_state_list
    if source == "peeringdb":
        enumerate_dc.enumerate_peeringdb(state_list)
    else:
        raise typer.BadParameter(f"unknown directory source: {source!r}")


@app.command("enrich-capacity")
def enrich_capacity_cmd(
    states: str = typer.Option(None, help="Comma-separated states. Default: all sizeless rows."),
    limit: int = typer.Option(None, help="Cap rows processed (cost control / smoke test)."),
):
    """Recover capacity_mw for sizeless data_center rows (Exa + Grok, delta-only, spend-capped)."""
    from .config import settings as _s
    from . import enrich
    state_list = _s._split_states(states) if states else []
    enrich.enrich_capacity(state_list or None, limit=limit)


@app.command("wire-edges")
def wire_edges_cmd():
    """Wire value-chain edges: `operates` for directory rows, `develops` for news rows."""
    from . import wire_edges
    wire_edges.wire_edges()


@app.command("wire-news")
def wire_news_cmd():
    """Wire the newsfeed to facilities: turn discovered source articles into linked News items."""
    from . import wire_news
    wire_news.wire_news()


@app.command("phase-b-goldset")
def phase_b_goldset():
    """Load the TX gold set (pipeline/seed/tx_gold_set.json) into the store."""
    from .phaseb.goldset import load_gold_set
    load_gold_set()


@app.command("phase-b-eval")
def phase_b_eval():
    """Score Phase-B rows against the gold set (recall/precision/field/dup)."""
    from .phaseb.eval import evaluate
    evaluate()


@app.command()
def backfill(
    skip_county: bool = typer.Option(False, help="Skip the FCC reverse-geocode step (offline / fast)."),
    county_limit: int = typer.Option(None, help="Cap county reverse-geocode rows (smoke test)."),
):
    """P1 Tier-B: populate existing-but-empty columns (operator/tenant, status_history,
    entity category, county) from data already in the store. Idempotent; then run `emit`."""
    from .backfill import run
    run(skip_county=skip_county, county_limit=county_limit)


@app.command("promote-backbone")
def promote_backbone():
    """P2.1 (L9): promote the curated compute-chain companies into `entity` as
    first-class rows (merge existing, insert net-new upstream/private). No financials
    yet — P2.2 attaches those. Idempotent; run before the FMP pull, then `emit`."""
    from .backbone import run
    run()


@app.command("reverify")
def reverify_cmd(
    limit: int = typer.Option(None, help="Cap rows (cost control)."),
    status: str = typer.Option("reported", help="Status to re-verify."),
    max_sources: int = typer.Option(None, help="Only rows with <= this many sources."),
    segment: str = typer.Option(None, help="Only one review-queue segment: reverifiable | "
                                           "evidence_blocked | gate_satisfied | below_floor. "
                                           "Uses the same classifier as `dcv review --segments`, "
                                           "so spend targets the population that was costed."),
    apply: bool = typer.Option(False, "--apply", help="Write (default is a dry run)."),
):
    """Re-run ONLY the cross-vendor trust gate on rows the verifier never checked — e.g. after
    an API outage, where phaseb.verify correctly fails CLOSED and holds candidates as
    `reported`. No discovery, no re-extraction: one Claude call per row.

    Strength depends on the row: since 2026-07-20 the extraction QUOTE is persisted, so rows
    written after that re-verify values-PLUS-evidence (full strength). Older rows carry no
    quote and re-verify values-only — a weaker check. Each run reports the split and tags every
    ChangeLog row `reverify_with_quote` / `reverify_no_quote`. Most of the store still predates
    the change, so expect values-only to dominate until those rows are re-extracted."""
    from .reverify import run
    run(limit=limit, status=status, dry_run=not apply, max_sources=max_sources,
        segment=segment)


@app.command("purge-denied-sources")
def purge_denied_sources(
    apply: bool = typer.Option(False, "--apply", help="Write the changes (default is a dry run)."),
    cap_confidence: bool = typer.Option(
        False, "--cap-confidence",
        help="Repair rows whose confidence outlived a value an EARLIER purge withdrew."),
):
    """Band 2 #3: withdraw every value sourced from a TIER-1 denied competitor (decision #1).
    A Field<T> with a denied source loses its VALUE, not just the url — re-citing an extracted
    figure to a permitted page would launder it. Affected records return to `needs_review` and
    surrender the confidence the withdrawn value earned. Every withdrawal is logged to
    change_log with the complete old value, so it is auditable and restorable. Dry run by
    default."""
    from .purge_sources import cap_withdrawn_confidence, run
    if cap_confidence:
        st = cap_withdrawn_confidence(dry_run=not apply)
        tag = "DRY RUN — nothing written" if not apply else "APPLIED"
        typer.echo(f"=== cap withdrawn-value confidence ({tag}) ===")
        typer.echo(f"  rows still missing a withdrawn value : {st['candidates']}")
        typer.echo(f"  already at/below the cap             : {st['already_low']}")
        typer.echo(f"  re-derived since (skipped)           : {st['refilled_skipped']}")
        typer.echo(f"  capped                               : {st['capped']}")
        for r in st["records"]:
            typer.echo(f"    {r}")
        return
    run(dry_run=not apply)


@app.command("gold-sample")
def gold_sample(n: int = typer.Option(20, help="Approx. sample size."),
                status: str = typer.Option("needs_review", help="Queue status to sample.")):
    """Band 2 #3 (L6): stratified sample of review-queue records to verify against PRIMARY
    sources, written to pipeline/seed/gold_worksheet.json. Stratified by SOURCE CLASS
    (directory vs news), not confidence — confidence has only two distinct values across the
    whole queue, so it cannot discriminate."""
    import json as _json

    from .goldset import WORKSHEET, sample
    rows = sample(n=n, status=status)
    WORKSHEET.write_text(_json.dumps(
        {"_meta": {"note": "Verification worksheet. For each row, open a PRIMARY source and "
                           "copy the value + a verbatim quote into tx_gold_set.json. A gold "
                           "field with no quote is not ground truth.",
                   "status": status, "requested": n, "returned": len(rows)},
         "rows": rows}, indent=2) + "\n")
    import collections
    by = collections.Counter(r["source_class"] for r in rows)
    typer.echo(f"✓ wrote {WORKSHEET.name} — {len(rows)} rows ({dict(by)})")


@app.command("gold-status")
def gold_status():
    """Band 2 #3 (L6): can the gold set certify an auto-approve rule? Prints per-field
    accuracy over EVIDENCE-BACKED gold values and the signoff verdict."""
    from .goldset import certify, field_accuracy
    fa = field_accuracy()
    typer.echo("per-field accuracy (evidence-backed gold only):")
    for f, b in sorted(fa["per_field"].items()):
        typer.echo(f"   {f:16s} {b['correct']}/{b['checked']}  acc={b['accuracy']}")
    if not fa["per_field"]:
        typer.echo("   (none — no gold field carries a source + verbatim quote yet)")
    typer.echo(f"   skipped unevidenced gold fields: {fa['skipped_unevidenced_fields']}; "
               f"gold rows with no matching store record: {fa['unmatched_gold_rows']}")
    c = certify()
    typer.echo(f"\ncertify: {'OK' if c['ok'] else 'REFUSED'} — {c['signed']}/{c['total']} "
               f"signed {c['by_source_class']}")
    for r in c["reasons"]:
        typer.echo(f"   · {r}")


@app.command("bakeoff")
def bakeoff_cmd(
    n: int = typer.Option(24, help="Approx. sample size (stratified by source class)."),
    status: str = typer.Option("needs_review", help="Queue status to sample."),
    budget: float = typer.Option(10.0, help="Spend cap in USD for the run (L5)."),
    only: str = typer.Option(None, help="Comma-separated backend names to run."),
    mode: str = typer.Option("agentic", help="agentic = model searches and judges (today's "
                                             "pipeline) · retrieved = Exa retrieves, model "
                                             "judges CLOSED-BOOK over the pages we pass in."),
    plan_only: bool = typer.Option(False, "--plan", help="Show the slate + projected cost; spend nothing."),
    write_slate: bool = typer.Option(False, "--write-slate",
                                     help="Dump the built-in slate to seed/bakeoff_slate.json for editing."),
):
    """PHASE 1 of the verifier bake-off: compete `settings.verify_model` against a slate of
    candidates over the SAME stratified sample, using the same prompt and the same gate.

    Measures only what needs no ground truth — structured-output validity (split into
    schema_miss / malformed / truncated / refusal / error, which production currently
    collapses into one "held as reported"), whether the model can find an INDEPENDENT second
    source at all (without which it can never promote a row), what it would do to the review
    queue via the real `phaseb.verify.score`, and measured $/record. It does NOT decide who is
    CORRECT: the gold set is 7 demo_seed_bootstrap rows and `goldset.certify()` refuses it.

    Read-only — no write path to the store. Start with `--plan`."""
    from .bakeoff import DEFAULT_SLATE, SLATE_PATH, load_slate, plan, report, run
    names = [x.strip() for x in only.split(",")] if only else None
    if write_slate:
        import json as _json
        SLATE_PATH.write_text(_json.dumps(
            {"_meta": {"note": "Edit and re-run `dcv bakeoff`. Every backend needs a "
                               "[input, output] $/1M price — an unpriced model bills $0 "
                               "through the ledger, so the spend cap stops binding. Set "
                               "\"enabled\": true and supply its api_key_env to add a vendor. "
                               "Do NOT pin \"temperature\" on an anthropic-transport backend: "
                               "it is deprecated on Opus 4.8 / Opus 5 / Sonnet 5 and 400s."},
             "backends": DEFAULT_SLATE}, indent=2) + "\n")
        typer.echo(f"✓ wrote {SLATE_PATH} — edit it, then re-run `dcv bakeoff --plan`")
        return
    if plan_only:
        slate = load_slate()
        if names:
            slate = [b for b in slate if b.name in names]
        p = plan(n, status, slate)
        typer.echo(f"=== bake-off plan — {len(p['records'])} record(s) {p['by_source_class']} ===")
        for b in p["run"]:
            typer.echo(f"  RUN   {b.name:<24} {b.vendor:<11} search={b.search:<7} "
                       f"${b.price[0]}/{b.price[1]} per 1M")
        for b, why in p["skip"]:
            typer.echo(f"  skip  {b.name:<24} {why}")
        from .bakeoff import _EST_IN, _EST_OUT
        typer.echo(f"\nprojected ≈ ${p['projected_usd']:.2f} "
                   f"(estimate at ~{_EST_IN}in/{_EST_OUT}out + 5 searches per call; the run "
                   f"measures the real figure and the spend cap is the actual guardrail)")
        return
    report(run(n=n, status=status, budget_usd=budget, limit_backends=names, mode=mode))


@app.command("resolve-roles")
def resolve_roles_cmd():
    """Band 2 #2 (L2-dcroles): resolve data-center role NAMES (developer/operator/tenant/
    end_user) to `entity` ids — deterministic, local, no LLM. Normalize → exact → alias, with
    ties and compound values ("OpenAI / Oracle") resolving to NEITHER and being logged as
    entity-expansion candidates. Never creates an entity. Idempotent; run after `wire-edges`
    + `backfill`, then `emit`."""
    from .dc_roles import run
    run()


@app.command("backbone-reach")
def backbone_reach():
    """Band 2 #1 (L2-backbone): MEASURE which backbone entities SEC EDGAR can reach an
    annual report for, and write pipeline/seed/backbone_reach.json. `current` is the only
    status a disclosed financial may come from; `stale` (deregistered — e.g. Advantest's
    newest 20-F is from 2015), `no_us_listing` and `private` are facts about our reach and
    are never reportable as coverage. Emitted to meta.rollups.backbone_reach."""
    from .backbone import run_reach
    run_reach()


@app.command("load-financials")
def load_financials():
    """P2.2 (L9): load entity.financials (market_cap/revenue) from the committed
    fixture (pipeline/seed/financials.json — 8 disclosed FMP mega-caps + 21 seed
    estimates). Guardrails: disclosed>estimated + market_cap deadband. Idempotent;
    run after `promote-backbone`, then `emit`. Regenerate the fixture with
    `python3 pipeline/build_financials_fixture.py`."""
    from .financials import run
    run()


@app.command("chain-quant")
def chain_quant(
    limit: int = typer.Option(6, help="Max suppliers to quantify (active-learning order)."),
    budget: float = typer.Option(2.0, help="Spend cap in USD for the run (L5)."),
    rounds: int = typer.Option(3, help="Extraction-voting rounds per supplier (beats non-determinism)."),
):
    """P3 L2: cross-vendor edge quantification — Grok extracts customer-concentration from SEC
    filings (voted over `rounds`), Claude (different vendor) verifies the consensus % + inferred
    counterparty → seed/chain_edges_verified.json (emit merges it OVER seed/chain_edges.json)."""
    from .chain_quant import run, targets_from_seed
    suppliers, candidates = targets_from_seed(limit=limit)
    run(suppliers, candidates, budget_usd=budget, rounds=rounds)


@app.command("chain-quant-named")
def chain_quant_named(
    budget: float = typer.Option(3.0, help="Spend cap in USD for the run (L5)."),
    rounds: int = typer.Option(3, help="Voting rounds per edge."),
):
    """Band-1 #3b (L9): put MAGNITUDES on the edges chain_topology named. Because the
    counterparty is already established by the buyer's own filing, this asks the supplier's
    filing a closed question ("what share of your revenue is this named buyer?") instead of
    inferring who the customer is. A filing that discloses no share leaves the edge
    unquantified — estimating one would draw a fake flow in the sankey."""
    from .chain_quant import named_targets, run_named
    run_named(named_targets(), budget_usd=budget, rounds=rounds)


@app.command("chain-identity")
def chain_identity(
    limit: int = typer.Option(8, help="Max edges to resolve (active-learning order, biggest first)."),
    budget: float = typer.Option(3.0, help="Spend cap in USD for the run (L5)."),
    rounds: int = typer.Option(3, help="Verify-voting rounds per edge (majority)."),
):
    """P3 L2-identity: flip inferred edge LINKS to NAMED. For each disclosed-magnitude edge whose
    counterparty is still inferred, gather identity evidence from the BUYER's 10-K risk factors +
    first-party/trade press, then cross-vendor verify (Grok extract → Claude verify ×rounds) →
    link_basis named (+ confirmed when the %-attribution holds) → seed/chain_edges_identity_auto.json
    (emit merges it OVER the manual identity baseline; magnitude untouched)."""
    from .chain_identity import run, targets
    run(targets(limit=limit), budget_usd=budget, rounds=rounds)


@app.command("chain-topology")
def chain_topology(
    limit: int = typer.Option(12, help="Max buyer filings to sweep (biggest first)."),
    budget: float = typer.Option(4.0, help="Spend cap in USD for the run (L5)."),
    rounds: int = typer.Option(3, help="Extraction-voting rounds per filer."),
):
    """Band-1 #2 (L2): DISCOVER real chain topology. Each buyer's own 10-K/20-F names its
    suppliers ("We utilize foundries, such as TSMC … We purchase memory from SK Hynix,
    Micron …") — extract them (Grok, voted), cross-vendor confirm (Claude), resolve names to
    backbone ids locally → `supplies` edges (supplier→buyer, link_basis=named) in
    seed/chain_topology.json, which emit merges into chain.edges. Topology only: no magnitude."""
    from .chain_topology import run, targets
    run(targets(limit=limit), budget_usd=budget, rounds=rounds)


@app.command("review")
def review_cmd(
    limit: int = typer.Option(25, help="Rows to print."),
    record_type: str = typer.Option(None, help="data_center | power_project (default: both)."),
    segments: bool = typer.Option(
        False, "--segments",
        help="Classify the queue by WHAT WOULD MOVE each row (evidence / verify / decision) "
             "instead of listing it. Depth alone hides that these need different inputs."),
):
    """Band-1 #3 (U2→L2): print the HITL queue — `needs_review` rows in ACTIVE-LEARNING order
    (uncertainty × value), disputed records first. This is the drain the retro found missing."""
    from . import review
    if segments:
        review.print_segments(record_type or "data_center")
        return
    review.print_queue(limit=limit, record_type=record_type)


@app.command("review-drain")
def review_drain(
    max_reopen: int = typer.Option(200, help="Anti-windup cap on re-opens per drain (L5)."),
):
    """Band-1 #3 (U2→L2): ingest pending user disputes from pipeline/inbox/disputes.jsonl →
    write `review_log` rows and RE-OPEN each record (approved→needs_review, confidence de-rated,
    last_verified cleared) so the next verify pass re-checks it. Hysteresis: a dispute can only
    re-open, never reject. Run `emit` afterwards to publish the new queue depth."""
    from . import review
    review.drain(max_reopen=max_reopen)


@app.command("review-decide")
def review_decide(
    record_id: str = typer.Argument(..., help="Record id from `dcv review`."),
    decision: str = typer.Option(..., help="approve | reject | edit | dismiss (undo an unfounded dispute)."),
    record_type: str = typer.Option("data_center", help="data_center | power_project."),
    reviewer: str = typer.Option("operator", help="Who decided (audit trail)."),
    note: str = typer.Option("", help="Why (stored in review_log.after)."),
):
    """Band-1 #3: record a HUMAN verdict on a queued record. Only this path may write
    approved/rejected — a user dispute never can. `--decision dismiss` closes an UNFOUNDED
    dispute and restores the record's pre-dispute review_status/confidence/last_verified from
    the audit trail. Writes `review_log` (the L4 training example)."""
    from . import review
    review.decide(record_type, record_id, decision, reviewer=reviewer, note=note)


@app.command()
def emit(validate: bool = True):
    """Build data.json from the store (DuckDB rollups), gated by the validator."""
    from .emit import emit as run_emit
    run_emit(validate=validate)


@app.command()
def validate(max_stale_days: int = 45):
    """Run validate_data.py on the current data.json."""
    res = subprocess.run(
        [sys.executable, str(settings.validator_path), str(settings.data_json_path),
         "--schema", str(settings.schema_path), "--max-stale-days", str(max_stale_days)],
    )
    raise SystemExit(res.returncode)


@app.command()
def dedup(
    apply_: bool = typer.Option(False, "--apply", help="Mark losers duplicate_of=<survivor>."),
    undo: bool = typer.Option(False, "--undo", help="Clear duplicate_of — the reversal."),
    survivor: str = typer.Option(None, help="Comma-separated survivor id(s) to act on."),
    allow_disagree: bool = typer.Option(
        False, help="Also collapse groups whose members disagree on capacity (destructive)."),
    matcher: str = typer.Option("both", help="both | coord | name"),
    elect: str = typer.Option(None, help="Row id to make the SURVIVOR of its group, "
                                         "overriding the auto-rank (which orders by "
                                         "confidence and can pick the row with no evidence)."),
    batch: str = typer.Option(None, help="With --undo: reverse exactly this apply() run."),
    batches_: bool = typer.Option(False, "--batches", help="List past --apply runs and "
                                                           "whether they are still in effect."),
):
    """Propose / apply / undo data-center duplicate collapsing (default: propose only)."""
    from . import dedup as dd
    ids = [x.strip() for x in survivor.split(",")] if survivor else None
    if batches_:
        rows = dd.batches()
        if not rows:
            typer.echo("no dedup --apply runs in the change log")
            return
        typer.echo("=== dedup apply runs ===")
        for b in rows:
            state = ("in effect" if b["still_marked"] == b["rows"] else
                     "REVERSED" if b["still_marked"] == 0 else
                     f"partial ({b['still_marked']}/{b['rows']} still marked)")
            typer.echo(f"\n{b['batch']}  {b['rows']} row(s), −{b['mw_removed']} MW  [{state}]"
                       + ("  elected-survivor" if b["elected"] else ""))
            typer.echo(f"  survivors: {', '.join(b['survivors'])}")
        typer.echo("\nReverse one:  dcv dedup --undo --batch <id>")
        return
    if undo:
        r = dd.undo(ids, batch=batch)
        typer.echo(f"↩ restored {r['restored']} row(s) to the read-model")
        if r["refused"]:
            typer.echo(f"  refused {r['refused']} row(s): re-marked by a later run — "
                       f"not this batch's to reverse")
        return
    if apply_:
        r = dd.apply(ids, allow_disagree=allow_disagree, elect=elect)
        typer.echo(f"✓ marked {r['marked']} duplicate row(s), −{r['mw_removed']} MW")
        for sid, why in r["skipped"]:
            typer.echo(f"  skipped {sid}: {why}")
        if r["marked"]:
            typer.echo(f"  batch {r['batch']}  —  reverse with: "
                       f"dcv dedup --undo --batch {r['batch']}")
        return
    groups = dd.find_groups(matcher)
    st = dd.stats()
    typer.echo(f"=== dedup — {st['groups_open']} group(s), {st['rows_open']} duplicate row(s), "
               f"{st['mw_double_counted']:,} MW double-counted "
               f"({st['groups_needing_human']} need a human) ===")
    for g in groups:
        # `auto` here must mean what apply() will actually do. Testing only mw_disagree told the
        # operator a sizeless group was collapsible while apply() skipped it — a listing that
        # disagrees with the command it exists to stage.
        flag = ("NEEDS-HUMAN" if g["mw_disagree"] else
                "NEEDS-HUMAN (no size)" if g["mw_uninformative"] else "auto")
        typer.echo(f"\n[{g['matcher']}] {flag}  +{g['mw_double_counted']} MW")
        typer.echo(f"  keep {g['survivor']['id']}  {g['survivor']['name']!r} "
                   f"({g['survivor']['mw']} MW, {g['survivor']['sources']} src)")
        for lo in g["losers"]:
            typer.echo(f"  drop {lo['id']}  {lo['name']!r} ({lo['mw']} MW, {lo['sources']} src)")
    typer.echo("\nApply the safe ones:  dcv dedup --apply"
               "\nApply one group:      dcv dedup --apply --survivor <id>"
               "\nList past runs:       dcv dedup --batches"
               "\nUndo one run:         dcv dedup --undo --batch <id>")


@app.command("capacity-audit")
def capacity_audit(
    fix: bool = typer.Option(False, "--fix", help="Withdraw values that fail the audit."),
    restore_: bool = typer.Option(False, "--restore", help="Undo --fix, exactly."),
):
    """Reconcile every stored capacity_mw against its own quote, measure and source tier."""
    from .capacity_audit import audit, withdraw, restore
    if restore_:
        n, refused = restore()
        typer.echo(f"↩ restored {n} withdrawn capacity value(s)"
                   + (f"; refused {refused} still inadmissible under current tiers" if refused else ""))
        return
    rep = audit()
    typer.echo(f"=== capacity-audit — {rep['values']} value(s) ===")
    for k in ("unquoted", "quote_unreconciled", "measure_unrecorded", "measure_wrong", "source_untiered",
              "source_inadmissible"):
        typer.echo(f"  {k:<22} {len(rep[k]):>4}")
    for k in ("quote_unreconciled", "measure_wrong", "source_inadmissible"):
        for row in rep[k][:10]:
            typer.echo(f"    [{k}] {row['id']}  {row['value']} MW  {row['why']}")
    if fix:
        n = withdraw(rep)
        typer.echo(f"\n✓ withdrew {n} inadmissible value(s) — re-run `dcv enrich-capacity` "
                   f"to recover them from a permitted source")
    else:
        typer.echo("\n(run with --fix to withdraw the inadmissible values)")


@app.command()
def build(states: str = typer.Option(None), skip_ingest: bool = False):
    """Convenience: db-upgrade → seed → phase-a-ingest → emit."""
    db_upgrade("head")
    seed()
    if not skip_ingest:
        phase_a_ingest(states)
    emit(validate=True)


if __name__ == "__main__":
    app()

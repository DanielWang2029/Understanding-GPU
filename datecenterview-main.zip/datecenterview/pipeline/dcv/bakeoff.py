"""bakeoff — measure which model should hold the cross-vendor trust gate (phase 1).

Architecture decision #4 fixes the *shape* of the trust gate: the verifier must be a
DIFFERENT VENDOR than the extractor, because same-vendor agreement is not evidence. It does
not fix the vendor. `settings.verify_model = claude-opus-4-8` is the most expensive line in
the pipeline's cost model and it was never competed — so this module competes it.

PHASE 1 IS DELIBERATELY BLIND TO CORRECTNESS. The gold set holds 7 rows, all
`verified_by="demo_seed_bootstrap"`, which `goldset.certify()` refuses by construction — so
there is no ground truth to score accuracy against, and inventing one from the incumbent's own
verdicts would be the same circularity one level up. What phase 1 measures instead is
everything that does NOT require knowing the right answer, and it turns out to be most of the
decision:

  * **Can it answer at all** — structured-output validity, split into schema_miss / malformed /
    truncated / refusal / error. `phaseb.verify` funnels all five into "held as reported", so
    today a refusal, a truncation and a bad transport are the same event in the store.
  * **Can it corroborate** — the fraction of verdicts that come back with a source on a domain
    the extractor did not already have. This is not a nice-to-have: `_AGREE_CORROBORATED`
    requires an independent domain and the approve gate requires ≥2 sources, so a verifier that
    never finds a second source CANNOT move a row to `approved` no matter how right it is.
  * **What it would do to the queue** — every candidate's verdicts are pushed through the real
    `phaseb.verify.score()`, so the headline is not an abstract score but "swap to this model
    and your 363-deep queue resolves like THIS".
  * **What it actually costs** — measured from each response's own usage block, not projected
    from a price list and an assumed token count.

It also runs the extractor's own vendor as a CONTROL. Decision #4 asserts same-vendor
agreement is meaningless; including Grok-as-verifier against Grok-as-extractor turns that
assertion into a number. If it agrees with the extraction markedly more than every cross-vendor
model does, the decision is confirmed by measurement rather than by argument.

The output feeds phase 2: records where the candidates most disagree are exactly where ground
truth is most informative, so `gold_priority` re-ranks the adjudication worksheet by
disagreement instead of by capacity.

Loop framing (loop-design): setpoint = the trust gate is held by the cheapest verifier that
can still corroborate and answer reliably; measured = the per-backend table below; error =
incumbent dominated on cost at equal reliability; correction = change `verify_model`;
mechanism = controlled same-input comparison (identical records, identical prompt, identical
max_tokens; temperature is pinned only where the vendor still accepts it — it is DEPRECATED on
Opus 4.8 / Opus 5 / Sonnet 5 and 400s the request, so results from those models are ONE SAMPLE
rather than a reproducible point and a narrow gap should be re-run before it is believed);
guardrail = the shared spend ledger caps the run, an unpriced
backend is REFUSED rather than billed invisibly, and this module has NO write path to the
store — it is a measurement, not an ingest path.
"""
from __future__ import annotations

import collections
import json
import statistics
from datetime import date
from pathlib import Path

from sqlalchemy import select

from .clients import spend, verifiers
from .clients.verifiers import Attempt, Backend
from .config import settings
from .db import session_scope
from .models import DataCenter

SLATE_PATH = settings.repo_root / "pipeline" / "seed" / "bakeoff_slate.json"
RESULTS_DIR = settings.repo_root / "pipeline" / "seed"


def results_path(mode: str = "agentic") -> Path:
    """One file PER MODE. A single `bakeoff_results.json` meant the retrieved run silently
    destroyed the agentic run it exists to be compared against — a comparison tool that
    overwrites its own baseline. Stamped by mode so both survive."""
    return RESULTS_DIR / f"bakeoff_results_{mode}.json"

# --------------------------------------------------------------------------- retrieved mode
#
# Two ways to answer "is this value corroborated by an independent source":
#
#   agentic   — hand the model a web-search TOOL and let it search and judge in one call.
#               What the pipeline does today. It is also the expensive one: measured
#               $0.1387/record on sonnet-5, ~33x the extractor, and the dominant line in a
#               full refresh (~$55 per 400 records vs $1.68 for extraction).
#
#   retrieved — WE retrieve with Exa ($0.005/search, already wired into discover.py and
#               enrich.py), then ask the model a CLOSED-BOOK question about the text we pass
#               in. The judge never searches.
#
# Retrieved mode is not only cheaper. The URLs come out of a search INDEX, so they exist by
# construction — which structurally removes the failure the 2026-07-30 run measured, where a
# search-less verifier invented citations and 8 of 10 were hard 404s. `source_liveness` stops
# being the primary defence and becomes a backstop.
#
# It is also what makes a no-search vendor (Fireworks-served open weights) a candidate at all:
# the reason those models are disqualified from `phaseb.verify` is that they cannot retrieve,
# not that they cannot judge. Separate the two and the judge job is open to everyone.
#
# The thing that could go wrong, and the reason this is a MEASUREMENT and not a migration:
# agentic search reformulates across rounds and digs; one Exa call does not. If retrieval is
# weaker, a good judge can only answer `unverifiable` and corroboration will FALL. That is the
# number to read.
RETRIEVED_VERIFY_SYSTEM = (
    "You are a skeptical fact-checker verifying a data-center project record. For each field "
    "you are given the extracted value, the supporting quote, and the source URL it came from. "
    "You are ALSO given the full text of several independently retrieved web pages.\n"
    "Judge each field ONLY against the retrieved pages below. Do not rely on prior knowledge, "
    "and never invent a URL — cite only a url that appears in the RETRIEVED SOURCES block. If "
    "the retrieved pages do not settle a field, answer unverifiable. That is the correct "
    "answer, not a failure.\n"
    "Respond with ONLY a JSON object of this exact shape (no prose):\n"
    "{\n"
    '  "capacity_mw": {"verdict": "agree|disagree|unverifiable", "found_value": <number|null>, "source_url": <url|null>},\n'
    '  "status":      {"verdict": "agree|disagree|unverifiable", "found_value": <string|null>, "source_url": <url|null>},\n'
    '  "location":    {"verdict": "agree|disagree|unverifiable", "found_value": <string|null>, "source_url": <url|null>}\n'
    "}"
)

RETRIEVAL_CHARS = 3_000       # per page, into the prompt
RETRIEVAL_RESULTS = 5

# Token counts used ONLY for the pre-run projection in `plan()`. The run replaces them with
# measured values — an estimate that is never reconciled against a bill is how a cost model
# quietly becomes fiction.
_EST_IN, _EST_OUT = 5_000, 1_200

#: The default slate. Anthropic + xAI run today (both keys are in .env); everything else is
#: declared but disabled pending a key, so `dcv bakeoff --plan` states the ask precisely
#: rather than failing halfway through a paid run.
DEFAULT_SLATE: list[dict] = [
    {"name": "opus-4.8 (incumbent)", "vendor": "anthropic", "model": "claude-opus-4-8",
     "transport": "anthropic", "search": "native", "price": [5.0, 25.0],
     "note": "settings.verify_model — the row every other row is compared against"},
    {"name": "opus-5", "vendor": "anthropic", "model": "claude-opus-5",
     "transport": "anthropic", "search": "native", "price": [5.0, 25.0],
     "note": "same price as the incumbent — a free upgrade if it wins"},
    {"name": "sonnet-5", "vendor": "anthropic", "model": "claude-sonnet-5",
     "transport": "anthropic", "search": "native", "price": [3.0, 15.0],
     "note": "priced at LIST, not the $2/$10 intro rate that expires 2026-08-31 — the "
             "decision is about steady state"},
    {"name": "haiku-4.5", "vendor": "anthropic", "model": "claude-haiku-4-5",
     "transport": "anthropic", "search": "native", "price": [1.0, 5.0],
     "note": "5x cheaper than the incumbent; the question is whether it can corroborate"},
    {"name": "grok-4.5 (CONTROL)", "vendor": "xai", "model": "grok-4.5",
     "transport": "openai_chat", "search": "none", "price": [2.0, 6.0],
     "base_url": settings.xai_base_url, "api_key_env": "XAI_API_KEY",
     "temperature": 0, "extra": {"json_mode": True},
     "note": "SAME VENDOR as the extractor — disqualified as verifier of record by decision "
             "#4. Present to MEASURE that decision, and as the no-web-search baseline."},
    # ---- declared but keyless: enable by adding the key and flipping `enabled` ----
    {"name": "gemini-flash", "vendor": "openrouter", "model": "google/gemini-3-flash",
     "transport": "openai_chat", "search": "none", "price": [0.3, 2.5],
     "base_url": "https://openrouter.ai/api/v1", "api_key_env": "OPENROUTER_API_KEY",
     "enabled": False, "extra": {"json_mode": True},
     "note": "needs OPENROUTER_API_KEY. Add {\"plugins\":[{\"id\":\"web\"}]} under "
             "extra.body and set search=native to give it corroboration ability."},
    {"name": "gpt-5-mini", "vendor": "openrouter", "model": "openai/gpt-5-mini",
     "transport": "openai_chat", "search": "none", "price": [0.25, 2.0],
     "base_url": "https://openrouter.ai/api/v1", "api_key_env": "OPENROUTER_API_KEY",
     "enabled": False, "extra": {"json_mode": True}, "note": "needs OPENROUTER_API_KEY"},
    {"name": "deepseek-v3 (open weights)", "vendor": "openrouter",
     "model": "deepseek/deepseek-chat", "transport": "openai_chat", "search": "none",
     "price": [0.25, 1.0], "base_url": "https://openrouter.ai/api/v1",
     "api_key_env": "OPENROUTER_API_KEY", "enabled": False, "price_confirmed": False,
     "extra": {"json_mode": True},
     "note": "open weights via hosted per-token inference — the economically viable form of "
             "'run open source'; a self-hosted GPU exceeds the whole monthly budget at this "
             "volume"},
    # ---- Fireworks: open-weight models on a hosted per-token OpenAI-compatible endpoint ----
    # The prices below are WORKING FIGURES, not confirmed against Fireworks' current rate
    # card — `price_confirmed: false` makes the plan and the report say so out loud. Check
    # them before believing a $/record row, because that column is computed from exactly
    # these numbers and a guessed rate that reads as measured is the one error that silently
    # changes the ranking.
    {"name": "fw-deepseek-v3", "vendor": "fireworks",
     "model": "accounts/fireworks/models/deepseek-v3", "transport": "openai_chat",
     "search": "none", "price": [0.9, 0.9],
     "base_url": "https://api.fireworks.ai/inference/v1",
     "api_key_env": "FIREWORKS_API_KEY", "enabled": False, "temperature": 0,
     "price_confirmed": False, "extra": {"json_mode": True},
     "note": "needs FIREWORKS_API_KEY. No web search on this endpoint — and a verifier that "
             "cannot search cannot corroborate. The bake-off measured a search-less model "
             "asserting 4 hard-404 URLs out of 16; source_liveness now withholds the bonus "
             "instead of crediting a citation nobody fetched, so this is safe to TEST — but "
             "expect corroboration rate, not agreement rate, to be the disqualifier."},
    {"name": "fw-qwen3-235b", "vendor": "fireworks",
     "model": "accounts/fireworks/models/qwen3-235b-a22b", "transport": "openai_chat",
     "search": "none", "price": [0.22, 0.88],
     "base_url": "https://api.fireworks.ai/inference/v1",
     "api_key_env": "FIREWORKS_API_KEY", "enabled": False, "temperature": 0,
     "price_confirmed": False, "extra": {"json_mode": True},
     "note": "needs FIREWORKS_API_KEY"},
    {"name": "fw-llama-3.3-70b", "vendor": "fireworks",
     "model": "accounts/fireworks/models/llama-v3p3-70b-instruct", "transport": "openai_chat",
     "search": "none", "price": [0.9, 0.9],
     "base_url": "https://api.fireworks.ai/inference/v1",
     "api_key_env": "FIREWORKS_API_KEY", "enabled": False, "temperature": 0,
     "price_confirmed": False, "extra": {"json_mode": True},
     "note": "needs FIREWORKS_API_KEY"},
]

INCUMBENT = "opus-4.8 (incumbent)"


# ------------------------------------------------------------------------------- the slate
def load_slate(path: Path | None = None) -> list[Backend]:
    """Slate from JSON if present, else the default. Every backend must carry a price."""
    p = Path(path or SLATE_PATH)
    specs = json.loads(p.read_text())["backends"] if p.exists() else DEFAULT_SLATE
    return [verifiers.from_spec(s) for s in specs]


def runnable(slate: list[Backend]) -> tuple[list[Backend], list[tuple[Backend, str]]]:
    """(will run, skipped-with-reason). Keyless and disabled backends are reported, not
    silently dropped — a slate that quietly shrinks looks like a completed comparison."""
    go, skip = [], []
    for b in slate:
        if not b.enabled:
            skip.append((b, "disabled in the slate"))
        elif not b.has_key:
            skip.append((b, f"no {b.api_key_env} in the environment"))
        else:
            go.append(b)
    return go, skip


# ------------------------------------------------------------------------------ the sample
def records(n: int, status: str = "needs_review") -> list[dict]:
    """The SAME stratified sample `dcv gold-sample` writes, rebuilt into verifier-input shape.

    Same sample on purpose: phase 2 can only score phase 1's runs if both ran over the same
    records. `goldset.sample` is deterministic (capacity desc, then id) so this holds across
    invocations without pinning ids in a file.
    """
    from .goldset import sample
    from .reverify import _candidate

    picks = sample(n=n, status=status)
    cls = {p["id"]: p["source_class"] for p in picks}
    order = [p["id"] for p in picks]
    with session_scope() as s:
        rows = {d.id: d for d in s.execute(
            select(DataCenter).where(DataCenter.id.in_(order))).scalars()}
        return [{"id": i, "source_class": cls[i], "name": rows[i].project_name,
                 "candidate": _candidate(rows[i])}
                for i in order if i in rows]


# ------------------------------------------------------------------------------ retrieval
def _retrieval_query(cand: dict) -> str:
    loc = cand.get("location") or {}
    where = " ".join(x for x in [loc.get("county"), loc.get("state")] if x)
    return f"{cand.get('project_name', '')} data center {where} capacity MW status".strip()


def retrieve(cand: dict) -> list[dict]:
    """Exa-retrieve independent evidence for one candidate. Returns [{url, title, text}].

    Two filters, both load-bearing:

    * **Source policy.** A retrieved URL becomes value-provenance on a sized row the moment
      the judge cites it, so it goes through the SAME test the publish gate enforces —
      `value_denied_reason` (tier-1 competitor AND tier-3 modelled-figure), not the weaker
      `denied_reason`. Enforcing a constraint on every ingest path and not just the one that
      broke first is the standing rule here; retrieval is a new ingest path.
    * **Independence.** A page on a domain the extractor already cited cannot corroborate
      anything — feeding it back would let the record confirm itself.
    """
    from . import source_policy
    from .clients import exa
    from .phaseb.verify import _domain

    held = {d for s in cand.get("sources", []) if (d := _domain(s.get("url")))}
    out, refused = [], 0
    for r in exa.search(_retrieval_query(cand), num_results=RETRIEVAL_RESULTS, with_text=True):
        u = r.get("url")
        if not u or _domain(u) in held:
            continue
        if source_policy.value_denied_reason(u):
            refused += 1
            continue
        out.append({"url": u, "title": r.get("title"),
                    "text": (r.get("text") or "")[:RETRIEVAL_CHARS]})
    if refused:
        print(f"    [retrieve] {refused} result(s) refused by source policy")
    return out


def _retrieved_prompt(cand: dict, docs: list[dict]) -> str:
    from .phaseb.verify import _user_prompt
    if not docs:
        return _user_prompt(cand) + "\nRETRIEVED SOURCES:\n(none — answer unverifiable)\n"
    block = "\n\n".join(
        f"[{i + 1}] {d['url']}\nTITLE: {d.get('title') or ''}\n{d['text']}"
        for i, d in enumerate(docs))
    return _user_prompt(cand) + f"\nRETRIEVED SOURCES:\n{block}\n"


# ------------------------------------------------------------------------------- the metrics
def _field_verdicts(a: Attempt, cand: dict) -> dict[str, str]:
    """{field: verdict} for fields the candidate actually carries — a verdict on a field the
    record does not have is not a datapoint, it is a hallucination we must not score."""
    from .phaseb.verify import CRITICAL, _field_present
    out = {}
    for f in CRITICAL:
        if not _field_present(cand, f):
            continue
        v = (a.verdicts.get(f) or {}).get("verdict")
        if v:
            out[f] = v
    return out


def _offered_urls(a: Attempt) -> set[str]:
    return {u for v in (a.verdicts or {}).values()
            if isinstance(v, dict) and (u := v.get("source_url"))}


def summarize(attempts: list[Attempt], recs: list[dict],
              backends: list[Backend], mode: str = "agentic") -> list[dict]:
    from .phaseb.verify import score as gate_score

    by_rec = {r["id"]: r for r in recs}
    rows = []
    for b in backends:
        mine = [a for a in attempts if a.backend == b.name]
        if not mine:
            continue
        outcomes = collections.Counter(a.outcome for a in mine)
        ok = [a for a in mine if a.answered]

        verdict_mix: collections.Counter = collections.Counter()
        corrob_hits = corrob_chances = 0
        gate_mix: collections.Counter = collections.Counter()
        live_mix: collections.Counter = collections.Counter()
        off_script = 0
        for a in ok:
            rec = by_rec[a.record_id]
            cand = rec["candidate"]
            verdict_mix.update(_field_verdicts(a, cand).values())
            sc = gate_score(cand, a.verdicts)
            gate_mix[sc["review_status"]] += 1
            live_mix.update(sc["liveness"])
            if mode == "retrieved":
                # Did it cite a url we did NOT hand it? The prompt forbids inventing one, and
                # in closed-book mode there is nowhere legitimate for a new url to come from.
                # This is the direct read on whether retrieval actually removes fabrication or
                # merely relocates it.
                given = set(rec.get("retrieved_urls") or [])
                off_script += len(_offered_urls(a) - given)
            # "chances" counts the fields it rendered a verdict on; "hits" the ones where it
            # produced a source the extractor did not already hold. The gate needs the latter.
            corrob_chances += len(sc["field_conf"])
            corrob_hits += len(sc["new_sources"])

        spent = sum(a.usd for a in mine)
        rows.append({
            "name": b.name, "vendor": b.vendor, "model": b.model, "search": b.search,
            "price_in_out": list(b.price), "price_confirmed": b.price_confirmed,
            "note": b.note, "cited_source_liveness": dict(live_mix),
            "cited_urls_not_supplied": off_script if mode == "retrieved" else None,
            "attempts": len(mine), "outcomes": dict(outcomes),
            "ok_rate": round(len(ok) / len(mine), 3),
            "verdict_mix": dict(verdict_mix),
            "corroboration_rate": round(corrob_hits / corrob_chances, 3) if corrob_chances else None,
            "would_gate_to": dict(gate_mix),
            "usd_total": round(spent, 4),
            "usd_per_record": round(spent / len(mine), 5),
            "usd_per_record_tokens": round(sum(a.usd_tokens for a in mine) / len(mine), 5),
            "usd_per_record_search": round(sum(a.usd_search for a in mine) / len(mine), 5),
            "searches_per_record": round(sum(a.searches for a in mine) / len(mine), 2),
            "median_latency_s": round(statistics.median([a.latency_s for a in mine]), 1),
            "median_out_tokens": int(statistics.median([a.out_tokens for a in mine] or [0])),
        })
    return rows


def agreement(attempts: list[Attempt], recs: list[dict]) -> dict:
    """Pairwise verdict agreement with the incumbent, over records where BOTH answered."""
    by_rec = {r["id"]: r for r in recs}
    by_key = {(a.backend, a.record_id): a for a in attempts if a.answered}
    inc = {rid: a for (bk, rid), a in by_key.items() if bk == INCUMBENT}
    out: dict[str, dict] = {}
    for (bk, rid), a in by_key.items():
        if bk == INCUMBENT or rid not in inc:
            continue
        cand = by_rec[rid]["candidate"]
        mine, theirs = _field_verdicts(a, cand), _field_verdicts(inc[rid], cand)
        shared = set(mine) & set(theirs)
        d = out.setdefault(bk, {"compared": 0, "same": 0, "records": 0})
        d["records"] += 1
        d["compared"] += len(shared)
        d["same"] += sum(1 for f in shared if mine[f] == theirs[f])
    for d in out.values():
        d["agreement"] = round(d["same"] / d["compared"], 3) if d["compared"] else None
    return out


def gold_priority(attempts: list[Attempt], recs: list[dict]) -> list[dict]:
    """Records ranked by how much the candidates DISAGREE — where ground truth pays most.

    This is the phase-1 → phase-2 handoff. `goldset.sample` orders by capacity because with no
    other signal, size is the best proxy for what a wrong value costs. Once several verifiers
    have looked at the same record, spread is a far better one: a record every model calls
    `agree` teaches an adjudicator nothing, and one they split three ways sits exactly on the
    boundary the gate has to get right.
    """
    by_rec = {r["id"]: r for r in recs}
    per: dict[str, dict[str, set]] = collections.defaultdict(lambda: collections.defaultdict(set))
    for a in attempts:
        if not a.answered:
            continue
        for f, v in _field_verdicts(a, by_rec[a.record_id]["candidate"]).items():
            per[a.record_id][f].add(v)
    out = []
    for rid, fields in per.items():
        spread = sum(len(v) - 1 for v in fields.values())
        out.append({"id": rid, "name": by_rec[rid]["name"],
                    "source_class": by_rec[rid]["source_class"], "spread": spread,
                    "split_fields": {f: sorted(v) for f, v in fields.items() if len(v) > 1}})
    out.sort(key=lambda r: (-r["spread"], r["id"]))
    return out


# ---------------------------------------------------------------------------------- the run
def plan(n: int, status: str, slate: list[Backend]) -> dict:
    go, skip = runnable(slate)
    recs = records(n, status)
    per_call = [( (_EST_IN / 1e6) * b.price[0] + (_EST_OUT / 1e6) * b.price[1]
                  + (0.01 * 5 if b.search == "native" else 0.0) ) for b in go]
    return {"records": recs, "run": go, "skip": skip,
            "by_source_class": dict(collections.Counter(r["source_class"] for r in recs)),
            "projected_usd": round(sum(per_call) * len(recs), 2)}


def run(n: int = 24, status: str = "needs_review", budget_usd: float = 10.0,
        slate_path: Path | None = None, limit_backends: list[str] | None = None,
        mode: str = "agentic") -> dict:
    from .phaseb.verify import VERIFY_SYSTEM, _user_prompt

    if mode not in ("agentic", "retrieved"):
        raise ValueError(f"mode must be 'agentic' or 'retrieved', got {mode!r}")
    slate = load_slate(slate_path)
    if limit_backends:
        slate = [b for b in slate if b.name in limit_backends]
    go, skip = runnable(slate)
    recs = records(n, status)
    if not go or not recs:
        raise RuntimeError(f"nothing to run — {len(go)} backend(s), {len(recs)} record(s)")

    if mode == "retrieved":
        # Force every judge CLOSED-BOOK. Leaving `search: native` on the Anthropic backends
        # would let them go find their own evidence, which is precisely the variable this mode
        # exists to remove — and the comparison against a no-search vendor would then be
        # measuring tool access again, the confound the Grok control already fell into.
        import dataclasses
        go = [dataclasses.replace(b, search="none") for b in go]

    # The cap must bind on EVERY model in the slate, including ones TOKEN_PRICES has never
    # seen. register_price is non-clobbering, so a slate quoting list price cannot rewrite
    # the rate production is billed at underneath a live run.
    for b in go:
        spend.register_price(b.model, b.price[0], b.price[1])
    spend.configure(budget_usd)

    attempts: list[Attempt] = []
    truncated_by_budget = False
    retrieval = {"records": 0, "docs": 0, "empty": 0, "usd": 0.0}
    print(f"→ bake-off [{mode}]: {len(recs)} record(s) × {len(go)} backend(s), "
          f"cap ${budget_usd:.2f}")
    for r in recs:
        if mode == "retrieved":
            # Retrieve ONCE per record and share it across every backend. This is what makes
            # the comparison controlled: the judges differ, the evidence does not. Retrieving
            # per backend would confound judge quality with retrieval luck.
            docs = retrieve(r["candidate"])
            retrieval["records"] += 1
            retrieval["docs"] += len(docs)
            retrieval["empty"] += 0 if docs else 1
            retrieval["usd"] += spend.SEARCH_COSTS.get("exa_search", 0.0)
            system, user = RETRIEVED_VERIFY_SYSTEM, _retrieved_prompt(r["candidate"], docs)
            r["retrieved_urls"] = [d["url"] for d in docs]
        else:
            system, user = VERIFY_SYSTEM, _user_prompt(r["candidate"])
        for b in go:
            try:
                a = verifiers.call(b, system, user, r["id"])
            except spend.SpendLimitError as e:
                print(f"  ⚠ {e}")
                truncated_by_budget = True
                break
            attempts.append(a)
            flag = "" if a.answered else f"  ← {a.outcome}: {(a.detail or '')[:70]}"
            print(f"  [{b.name:<22}] {r['id'][:34]:<34} {a.outcome:<10} "
                  f"${a.usd:.4f} {a.latency_s:>5.1f}s{flag}")
        if truncated_by_budget:
            break

    res = {
        "_meta": {
            "generated": date.today().isoformat(), "phase": 1, "mode": mode,
            "note": "PHASE 1 — no ground truth. Measures reliability, corroboration ability, "
                    "queue impact and measured cost. It does NOT measure who is CORRECT: "
                    "the gold set holds 7 demo_seed_bootstrap rows, which goldset.certify() "
                    "refuses. See gold_priority for where adjudication pays most.",
            "retrieval": (retrieval | {"usd": round(retrieval["usd"], 4),
                                       "usd_per_record": round(
                                           retrieval["usd"] / max(retrieval["records"], 1), 5)}
                          ) if mode == "retrieved" else None,
            "sample_status": status, "requested": n, "records": len(recs),
            "by_source_class": dict(collections.Counter(r["source_class"] for r in recs)),
            "prompt": "phaseb.verify.VERIFY_SYSTEM", "max_tokens": verifiers.MAX_TOKENS,
            "incumbent": INCUMBENT, "budget_usd": budget_usd,
            "truncated_by_budget": truncated_by_budget,
            "ledger": spend.LEDGER.summary(),
            "skipped_backends": [{"name": b.name, "reason": why} for b, why in skip],
        },
        "backends": summarize(attempts, recs, go, mode),
        "agreement_with_incumbent": agreement(attempts, recs),
        "gold_priority": gold_priority(attempts, recs),
        "attempts": [vars(a) for a in attempts],
    }
    results_path(mode).write_text(json.dumps(res, indent=2) + "\n")
    return res


# ------------------------------------------------------------------------------- the report
def report(res: dict) -> None:
    m = res["_meta"]
    print(f"\n=== verifier bake-off [{m.get('mode', 'agentic')}] — {m['records']} record(s) × "
          f"{len(res['backends'])} backend(s) {m['by_source_class']} ===")
    print(f"{m['note']}\n")
    rt = m.get("retrieval")
    if rt:
        print(f"retrieval: Exa, {rt['docs']} page(s) over {rt['records']} record(s) "
              f"({rt['empty']} returned nothing), ${rt['usd_per_record']:.4f}/record.")
        print("Retrieved ONCE per record and shared by every backend — the judges differ, the")
        print("evidence does not. Add that figure to each $/rec below for the true per-record")
        print("cost; it is charged once, not once per model.\n")

    hdr = (f"{'backend':<24}{'search':<8}{'$/1M i/o':<11}{'ok':>4}{'miss':>5}{'malf':>5}"
           f"{'trunc':>6}{'refus':>6}{'err':>4}{'corrob':>8}"
           f"{'$/rec':>9}{'tok':>9}{'srch':>8}{'med s':>7}")
    print(hdr)
    print("-" * len(hdr))
    base = next((b["usd_per_record"] for b in res["backends"] if b["name"] == m["incumbent"]), None)
    for b in res["backends"]:
        o = b["outcomes"]
        cr = "—" if b["corroboration_rate"] is None else f"{b['corroboration_rate']:.2f}"
        price = f"{b['price_in_out'][0]}/{b['price_in_out'][1]}"
        if not b.get("price_confirmed", True):
            price += "?"
        print(f"{b['name']:<24}{b['search']:<8}{price:<11}"
              f"{o.get('ok', 0):>4}{o.get('schema_miss', 0):>5}{o.get('malformed', 0):>5}"
              f"{o.get('truncated', 0):>6}{o.get('refusal', 0):>6}{o.get('error', 0):>4}"
              f"{cr:>8}{b['usd_per_record']:>9.4f}{b['usd_per_record_tokens']:>9.4f}"
              f"{b['usd_per_record_search']:>8.4f}{b['median_latency_s']:>7.1f}")

    srch = max((b["searches_per_record"] for b in res["backends"]), default=0.0)
    print("\n$/rec is ALL-IN (tok + srch). The search column is not a rounding error: at "
          f"~{srch:.1f} searches/record it is comparable to a cheap model's\nentire token bill, "
          "so a token-only comparison flatters exactly the models being considered\nas the "
          "cheap alternative.")
    if base:
        print("relative to the incumbent, all-in: " + " · ".join(
            f"{b['name'].split(' ')[0]} {b['usd_per_record'] / base:.2f}×"
            for b in res["backends"] if b["name"] != m["incumbent"]))

    if any(not b.get("price_confirmed", True) for b in res["backends"]):
        print("? = price is a WORKING FIGURE, not confirmed against the vendor's rate card. "
              "The $/rec\n    column is computed from it — confirm before acting on that row.")

    print("\ncorrob = share of verdicts that came back with a source on a domain the extractor")
    print("did not already have AND that resolves when fetched. The approve gate needs an")
    print("INDEPENDENT second source, so a verifier that cannot corroborate cannot promote a")
    print("row however right it is — which is why `search` is shown next to it. Compare within")
    print("a search class, not across.")

    off = {b["name"]: b["cited_urls_not_supplied"] for b in res["backends"]
           if b.get("cited_urls_not_supplied") is not None}
    if off:
        print("\n--- did the judge stay closed-book? (urls cited that we did NOT supply) ---")
        for name, k in off.items():
            print(f"  {name:<24} {k}" + ("   ← INVENTED, off the retrieved set" if k else "   ✓"))

    live = {b["name"]: b["cited_source_liveness"] for b in res["backends"]
            if b.get("cited_source_liveness")}
    if live:
        print("\n--- do the cited URLs exist? (source_liveness probe) ---")
        for name, mix in live.items():
            dead = mix.get("unreachable", 0)
            print(f"  {name:<24} {mix}" + ("   ← FABRICATED CITATIONS" if dead else ""))
        print("  unreachable = a hard 404/410. Those earn no corroboration bonus and are")
        print("  never persisted as provenance. `unverified` (403/timeout) also earns no")
        print("  bonus but IS kept — bot-blocking is not proof a page is absent.")

    print(f"\n--- what each would do to the queue (via phaseb.verify.score) ---")
    for b in res["backends"]:
        print(f"  {b['name']:<24} {b['would_gate_to'] or '—'}   verdicts={b['verdict_mix'] or '—'}")

    ag = res["agreement_with_incumbent"]
    if ag:
        print(f"\n--- verdict agreement with {m['incumbent']} ---")
        for name, d in sorted(ag.items(), key=lambda kv: -(kv[1]["agreement"] or 0)):
            print(f"  {name:<24} {d['agreement']}  ({d['same']}/{d['compared']} field verdicts, "
                  f"{d['records']} shared records)")

    gp = [g for g in res["gold_priority"] if g["spread"]]
    print(f"\n--- where ground truth pays most ({len(gp)} record(s) the candidates split on) ---")
    for g in gp[:10]:
        print(f"  spread {g['spread']}  {g['id'][:38]:<38} {g['split_fields']}")
    if not gp:
        print("  (none — every backend returned the same verdict on every field)")

    if m["skipped_backends"]:
        print("\n--- not run ---")
        for s in m["skipped_backends"]:
            print(f"  {s['name']:<24} {s['reason']}")
    print(f"\nledger: {m['ledger']}")
    if m["truncated_by_budget"]:
        print("⚠ RUN TRUNCATED BY THE SPEND CAP — the table above is partial.")
    print(f"written: {results_path(m.get('mode', 'agentic'))}")

"""Capacity enrichment — recover per-facility capacity_mw for sizeless rows.

The operating base (PeeringDB) has location + operator but no *size* (383/428 rows
have no MW). This enriches the delta: for each row missing capacity_mw, a targeted
Exa search + cheap Grok extraction pulls the facility's MW *with a supporting
quote* (unquoted numbers are dropped — the Phase B hallucination guard). The value
lands as a Field<T> and its source is appended to the row. Delta-only (skips rows
that already have capacity) and spend-capped, and it commits per row, so a run can
be interrupted / resumed cheaply. See phase-b-spec §5-7 and the README.

Single-source + quoted → moderate confidence (0.65); cross-vendor verifying the
capacity (Claude) is a future hardening, deliberately skipped for cost here.
"""
from __future__ import annotations

import re
from datetime import date

from sqlalchemy import select

from .clients import exa, grok, spend
from .clients.spend import SpendLimitError
from .config import settings
from .db import session_scope
from .field import field
from .models import DataCenter, Source
from . import source_policy
from .phaseb.verify import _domain

CAP_CONFIDENCE = 0.65
# The measure the `capacity_mw` COLUMN is defined to hold. Everything else is a different
# quantity that happens to be denominated in MW — see MEASURES below.
WANTED_MEASURE = "facility_power_capacity"
MEASURES = ["facility_power_capacity", "facility_it_load", "campus_total",
            "utility_service", "unclear"]
CAP_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "capacity_mw": {"type": ["number", "null"]},
        # entity-unit-of-analysis: the number is useless without knowing WHAT it measures.
        # Directory pages routinely print "Power Capacity" and "IT Load" side by side, and the
        # 2026-07-21 audit found the extractor silently taking different ones on different rows
        # — CoreSite Reston stored the IT load (426.67), CoreSite San Jose the capacity (2.675).
        # A column that holds two different measures cannot be summed, ranked or compared.
        "measure": {"type": ["string", "null"], "enum": MEASURES + [None]},
        "unit_seen": {"type": ["string", "null"]},
        "quote": {"type": ["string", "null"]},
        "source_hint": {"type": ["string", "null"]},
    },
    "required": ["capacity_mw", "measure", "unit_seen", "quote", "source_hint"],
}
SYS = (
    "Extract the electrical power CAPACITY in megawatts (MW) of ONE specific data-center "
    "facility from the provided web snippets.\n"
    "UNITS: the snippet may state kW, MW or GW. Convert to MW: kW/1000, GW*1000. Report the "
    "unit you actually saw in `unit_seen` (one of: kW, MW, GW). Never assume a bare number is MW.\n"
    "WHICH FIGURE: a page often lists several MW numbers. Set `measure` to what your number is:\n"
    "  facility_power_capacity - this building's total/installed/critical power capacity  <- WANTED\n"
    "  facility_it_load        - IT load / IT power draw (usually capacity divided by PUE)\n"
    "  campus_total            - a multi-building campus or portfolio total\n"
    "  utility_service         - a substation / utility service or interconnection size\n"
    "  unclear                 - the snippet does not say which of these it is\n"
    "Prefer facility_power_capacity. If the page gives BOTH a power capacity and an IT load, "
    "return the power capacity and set measure=facility_power_capacity. Do NOT return an IT "
    "load as if it were capacity.\n"
    "Include the exact supporting quote and the source URL. If this facility's capacity is not "
    "explicitly stated, capacity_mw=null. Never guess, and never infer from a campus or "
    "company-portfolio total."
)


def _norm(s: str | None) -> str:
    return re.sub(r"\s+", " ", (s or "").lower()).strip()


def _source_for_quote(quote: str, results: list[dict], hint: str | None) -> str | None:
    """Ground provenance: the URL whose page text contains the quote (don't trust a
    model-invented URL). Fall back to a valid hint, then the top result."""
    qn = _norm(quote)
    probe = qn[:24]
    for r in results:
        if probe and probe in _norm(r.get("text")):
            return r["url"]
    urls = {r["url"] for r in results}
    if hint in urls:
        return hint
    return results[0]["url"] if results else hint


def _extract_capacity(fac: dict) -> dict | None:
    q = (f'{fac["name"]} {fac["op"] or ""} {fac["city"] or ""} {fac["state"] or ""} '
         f'data center power capacity megawatts')
    results = exa.search(q, num_results=5, with_text=True)
    # SOURCE POLICY (decision #1): drop curated-competitor results BEFORE they reach the
    # model. Filtering only the chosen source afterwards is not enough — their text would
    # still be in the prompt, and a value read out of a competitor's database is what the
    # constraint forbids however it is later cited.
    #
    # `value_denied_reason` covers BOTH objections that forbid taking a number: tier 1
    # (licensed competitor — decision #1) and tier 3 (figures are modelled from a constant PUE,
    # not reported). They are different arguments with the same remedy, so they share one gate.
    kept, denied = [], []
    for r in results:
        (denied if source_policy.value_denied_reason(r.get("url")) else kept).append(r)
    if denied:
        print(f"  [enrich] {len(denied)} inadmissible source(s) refused: "
              + ", ".join(sorted({source_policy._host(r['url']) for r in denied})))
    results = kept
    snippets = "\n\n".join(f'[{r["url"]}]\n{(r.get("text") or "")[:1200]}' for r in results[:5])
    if not snippets.strip():
        return None
    user = (f'Facility: {fac["name"]} — operator {fac["op"]}, {fac["city"]}, {fac["state"]}\n\n'
            f'SNIPPETS:\n{snippets[:9000]}')
    content, _ = grok.chat(SYS, user, model=settings.extract_model, response_schema=CAP_SCHEMA)
    cap = content.get("capacity_mw")
    quote = content.get("quote") or ""
    if cap is None or not re.search(r"\d", quote):   # hallucination guard: number needs a quote
        return None
    if not (0 < float(cap) <= 5000):                 # sanity bound (MW)
        return None
    # Unit-of-analysis gate: the column holds facility power capacity. A campus total, a
    # substation size or an IT load is a DIFFERENT quantity in the same unit — reject rather
    # than store it alongside, which is how the column ended up holding two measures at once.
    # `unclear` is rejected too: "we don't know what this number is" is not a capacity.
    measure = content.get("measure") or "unclear"
    if measure != WANTED_MEASURE:
        print(f"  [enrich] refused {cap} MW for {fac['name'][:40]}: measure={measure}, "
              f"not {WANTED_MEASURE}")
        return None
    # A quoted kW figure must actually contain 'kw' — catches the model reporting unit_seen=kW
    # while having copied a bare number it assumed was MW.
    unit = (content.get("unit_seen") or "").strip().lower()
    if unit and unit not in ("kw", "mw", "gw"):
        return None
    if unit and unit not in quote.lower().replace("kilowatt", "kw").replace(
            "megawatt", "mw").replace("gigawatt", "gw"):
        print(f"  [enrich] refused {cap} MW for {fac['name'][:40]}: claims unit '{unit}' "
              f"but the quote does not contain it")
        return None
    return {"cap": float(cap), "quote": quote, "measure": measure, "unit_seen": unit or None,
            "source": _source_for_quote(quote, results, content.get("source_hint"))}


def _load_sizeless(states: list[str], limit: int | None) -> list[dict]:
    with session_scope() as s:
        rows = [
            {"id": r.id, "name": r.project_name, "op": r.developer_name,
             "state": (r.location or {}).get("state"), "city": (r.location or {}).get("city")}
            for r in s.execute(select(DataCenter).where(DataCenter.capacity_mw.is_(None))).scalars()
        ]
    if states:
        rows = [r for r in rows if r["state"] in states]
    return rows[:limit] if limit else rows


def _write(row_id: str, res: dict, today: str) -> None:
    with session_scope() as s:
        dc = s.get(DataCenter, row_id)
        if dc is None:
            return
        # `res["quote"]` is already required by the hallucination guard above — persist it,
        # rather than proving the number to ourselves and then throwing the proof away.
        dc.capacity_mw = field(res["cap"], unit="MW", sources=[res["source"]],
                               confidence=CAP_CONFIDENCE, method="extracted",
                               last_verified=today, quote=res.get("quote"),
                               measure=res.get("measure"))
        srcs = list(dc.sources or [])
        if res["source"] and res["source"] not in srcs:
            srcs.append(res["source"])
        dc.sources = srcs
        dc.last_verified = today
        if res["source"]:
            s.merge(Source(id=res["source"], url=res["source"], publisher=_domain(res["source"]),
                           type="trade_press", trust_weight=0.7))


def enrich_capacity(states: list[str] | None = None, limit: int | None = None) -> dict:
    states = [s.upper() for s in (states or [])]
    today = date.today().isoformat()
    spend.configure(settings.daily_spend_limit_usd)
    rows = _load_sizeless(states, limit)
    print(f"=== enrich-capacity — {len(rows)} sizeless rows (states={states or 'ALL'}) ===")

    hits = processed = 0
    try:
        for i, fac in enumerate(rows, 1):
            try:
                res = _extract_capacity(fac)
            except SpendLimitError:
                raise
            except Exception as e:  # noqa: BLE001 — one bad facility shouldn't stop the run
                print(f"  [{i}] {fac['name'][:36]}: err {type(e).__name__}")
                res = None
            processed += 1
            if res:
                _write(fac["id"], res, today)
                hits += 1
                print(f"  [{i}/{len(rows)}] HIT {fac['name'][:38]:38} → {res['cap']} MW")
            if i % 25 == 0:
                print(f"  … {i}/{len(rows)} · {hits} filled · {spend.LEDGER.summary()}")
    except SpendLimitError as e:
        print(f"  [enrich] {e} — stopping, keeping what's written")

    print(f"✓ enrich-capacity: filled {hits}/{processed} · spend {spend.LEDGER.summary()}")
    return {"filled": hits, "processed": processed, "spend_usd": round(spend.LEDGER.total_usd, 4)}

"""Phase B — agentic data-center discovery → extraction → cross-vendor verify.

Pipeline (Design Y): discover (Exa + Grok Agent Tools web+X search + RSS/GDELT) →
fetch (Firecrawl) → extract (Grok, structured) → normalize → verify (Claude,
cross-vendor trust gate) → persist candidates into the DataCenter store. `emit`
then projects approved/candidate rows into data.json. See docs/phase-b-spec.md.
"""

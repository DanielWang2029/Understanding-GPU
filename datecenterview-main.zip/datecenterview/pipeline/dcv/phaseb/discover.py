"""Discovery layer (phase-b-spec §2) — high-recall candidate URL queue.

Four complementary modes, each blind to what the others surface:
  - GDELT 2.0 DOC   free global news firehose (US-filtered)
  - curated RSS     trade press (DCD / DCF / DCK / Construction Dive)
  - Exa             neural search on entity/geo/event query patterns
  - Grok Agent Tools  web + X search (live X signal) — our freshness edge over CleanView

Output is deduped on canonical URL + normalized title, then capped (the queue is
the cost valve: it decides how many candidates reach the paid extractor).
"""
from __future__ import annotations

from datetime import date, timedelta
from urllib.parse import urlparse
from xml.etree import ElementTree as ET

import httpx

from ..clients import exa, grok
from ..config import settings
from .. import source_policy
from .normalize_dc import _slug

# --- lexicon + sources -------------------------------------------------------
KEYWORDS = [
    "data center", "hyperscale", "colocation", "campus", "gigawatt",
    "behind-the-meter", "rezoning", "special use permit", "anchor tenant", "AI factory",
]
DEVELOPERS = [
    "Amazon Web Services", "Microsoft", "Google", "Meta", "Oracle", "CoreWeave",
    "Crusoe", "QTS", "Vantage Data Centers", "Digital Realty", "Switch", "Aligned",
    "CyrusOne", "Compass Datacenters", "Stack Infrastructure",
]
# curated trade-press RSS — tunable config; failures degrade gracefully
RSS_FEEDS = [
    ("DCD", "https://www.datacenterdynamics.com/en/rss/"),
    ("DCK", "https://www.datacenterknowledge.com/rss.xml"),
    ("ConstructionDive", "https://www.constructiondive.com/feeds/news/"),
]
GDELT = "https://api.gdeltproject.org/api/v2/doc/doc"


def _canonical(url: str | None) -> str | None:
    if not url:
        return None
    try:
        u = urlparse(url)
        return f"{u.scheme}://{u.netloc.lower()}{u.path.rstrip('/')}"
    except Exception:
        return url


def _cand(url, title, published, mode, *, text="", query=None) -> dict | None:
    curl = _canonical(url)
    if not curl:
        return None
    return {
        "url": curl, "title": (title or "").strip() or None,
        "published_date": published, "mode": mode, "text": text or "", "query": query,
    }


# --- firehose: GDELT + RSS (free) --------------------------------------------
def _gdelt(states: list[str], max_records: int = 60) -> list[dict]:
    # GDELT full-text geo terms are unreliable; keep the query broad + US/English
    # and let the state filter + extraction do the scoping (high recall).
    q = '("data center" OR datacenter OR hyperscale) sourcecountry:US sourcelang:eng'
    try:
        r = httpx.get(GDELT, params={
            "query": q, "mode": "ArtList", "format": "json",
            "maxrecords": str(max_records), "timespan": "3months", "sort": "datedesc",
        }, timeout=45, headers={"User-Agent": "dataCenterView/0.1"})
        r.raise_for_status()
        if not r.text.lstrip().startswith("{"):  # GDELT returns text on a bad query
            print(f"  [discover] GDELT non-JSON response: {r.text[:120].strip()!r}")
            return []
        arts = r.json().get("articles", []) or []
    except Exception as e:
        print(f"  [discover] GDELT failed ({type(e).__name__}: {e})")
        return []
    return [c for a in arts
            if (c := _cand(a.get("url"), a.get("title"), a.get("seendate"), "gdelt"))]


def _rss(max_per_feed: int = 25) -> list[dict]:
    out: list[dict] = []
    for name, url in RSS_FEEDS:
        try:
            r = httpx.get(url, timeout=30, follow_redirects=True,
                          headers={"User-Agent": "dataCenterView/0.1 (+discovery)"})
            r.raise_for_status()
            root = ET.fromstring(r.content)
        except Exception as e:
            print(f"  [discover] RSS {name} failed ({type(e).__name__}: {e})")
            continue
        for item in root.iter("item"):
            link = item.findtext("link")
            title = item.findtext("title")
            pub = item.findtext("pubDate")
            c = _cand(link, title, pub, f"rss:{name}")
            if c:
                out.append(c)
            if sum(1 for x in out if x["mode"] == f"rss:{name}") >= max_per_feed:
                break
    return out


# --- targeted agentic search: Exa + Grok Agent Tools -------------------------
def _queries(states: list[str]) -> list[str]:
    geo = states[0] if states else "United States"
    qs = [
        f'new data center {geo} MW capacity announced',
        f'data center {geo} rezoning OR "special use permit" megawatts',
        f'"data center" {geo} "breaks ground" OR gigawatt OR "anchor tenant"',
    ]
    qs += [f'{dev} data center {geo}' for dev in DEVELOPERS[:6]]
    return qs


def _exa(states: list[str], per_query: int = 6) -> list[dict]:
    out: list[dict] = []
    for q in _queries(states):
        try:
            for r in exa.search(q, num_results=per_query, with_text=True):
                c = _cand(r["url"], r["title"], r["published_date"], "exa",
                          text=r.get("text", ""), query=q)
                if c:
                    out.append(c)
        except Exception as e:
            print(f"  [discover] Exa query failed ({type(e).__name__}: {e})")
    return out


def _grok_agent(states: list[str]) -> list[dict]:
    """xAI Agent Tools (Responses API): Grok agentically runs web_search + x_search
    and returns citations. The x_search date window is the live-X freshness edge."""
    geo = states[0] if states else "the US"
    window = settings.discovery_search_window_days
    to_d = date.today()
    from_d = to_d - timedelta(days=window)
    prompt = (
        f"List recent (last {window} days) news of new or expanding data-center "
        f"projects in {geo}. For each, give the project name and the source URL. "
        f"Search both the web and X."
    )
    tools = [
        grok.web_search_tool(),
        grok.x_search_tool(
            from_date=from_d.isoformat(), to_date=to_d.isoformat(),
            allowed_handles=settings.discovery_x_handle_list or None,
        ),
    ]
    try:
        _text, citations = grok.search(
            prompt, tools,
            system="You are a research assistant surfacing data-center project news.",
        )
    except httpx.HTTPStatusError as e:
        print(f"  [discover] Grok Agent search failed (HTTP {e.response.status_code})")
        return []
    except Exception as e:
        print(f"  [discover] Grok Agent search failed ({type(e).__name__}: {e})")
        return []
    return [c for u in citations if (c := _cand(u, None, None, "grok_x"))]


# --- assemble ----------------------------------------------------------------
def discover(states: list[str], max_candidates: int = 400) -> list[dict]:
    print(f"discover — scope: {states or 'US (national)'}")
    raw: list[dict] = []
    # geo-targeted precision sources first (Exa/Grok) so the cap keeps the most
    # relevant candidates; the broad firehose (GDELT/RSS) fills remaining slots.
    for fn, label in ((_exa, "exa"), (_grok_agent, "grok_x"), (_gdelt, "gdelt"), (_rss, "rss")):
        try:
            batch = fn(states) if fn in (_gdelt, _exa, _grok_agent) else fn()
        except Exception as e:
            print(f"  [discover] {label} mode errored ({type(e).__name__}: {e})")
            batch = []
        print(f"  [discover] {label}: {len(batch)} raw")
        raw.extend(batch)

    seen_url: set[str] = set()
    seen_title: set[str] = set()
    queue: list[dict] = []
    refused = 0
    for c in raw:
        # SOURCE POLICY (decision #1): refuse curated-competitor candidates at the QUEUE, so
        # they are never fetched, extracted or cited. Filtering enrich.py alone was not
        # enough — the 2026-07-20 volume run reintroduced 2 tier-1 URLs through this path and
        # the publish gate caught them. Every ingest path needs the check, not just the one
        # that first broke it.
        if source_policy.denied_reason(c["url"]):
            refused += 1
            continue
        tkey = _slug(c["title"])[:60] if c["title"] else None
        if c["url"] in seen_url or (tkey and tkey in seen_title):
            continue
        seen_url.add(c["url"])
        if tkey:
            seen_title.add(tkey)
        queue.append(c)
        if len(queue) >= max_candidates:
            print(f"  [discover] hit candidate cap ({max_candidates}) — remaining dropped")
            break
    print(f"✓ discovered {len(queue)} unique candidates (from {len(raw)} raw)")
    if refused:
        print(f"  [discover] {refused} competitor candidate(s) refused (decision #1)")
    return queue

"""Data-center normalization — the unglamorous 30% (phase-b-spec §5).

Collapses developer aliases to one canonical entity, maps press phrasing to the
lifecycle enum, parses money/capacity units, and builds the `identity_key` that
Phase C dedupes on. Pure functions — unit-tested, no I/O.
"""
from __future__ import annotations

import re

from ..normalize import LIFECYCLE
from ..sources.iso import STATE_NAME_TO_CODE, US_STATE_CODES

# --- developer / operator canonicalization -----------------------------------
# alias (lowercased) -> (canonical_name, entity_id, category). Category matches
# Entity.category enum: hyperscaler|neocloud|wholesale_colo|retail_colo|developer|
#                       enterprise|utility|ai_lab|other

# Structural default for facility-directory (PeeringDB) rows whose operator we
# can't canonicalize: PeeringDB is a registry of interconnection / colocation
# facilities, so an enumerated row IS a colo — retail/interconnection is the
# dominant type there. This is a source-backed inference, not a catch-all bucket;
# specific operators that are wholesale/hyperscaler are named in _DEV_ROWS below.
DIRECTORY_DEFAULT_CATEGORY = "retail_colo"

_DEV_ROWS: list[tuple[list[str], str, str, str]] = [
    (["amazon", "aws", "amazon web services"], "Amazon Web Services", "aws", "hyperscaler"),
    (["microsoft", "azure", "microsoft azure"], "Microsoft", "microsoft", "hyperscaler"),
    (["google", "alphabet", "google cloud"], "Google", "google", "hyperscaler"),
    (["meta", "facebook"], "Meta", "meta", "hyperscaler"),
    (["oracle", "oci", "oracle cloud"], "Oracle", "oracle", "hyperscaler"),
    (["coreweave"], "CoreWeave", "coreweave", "neocloud"),
    (["crusoe", "crusoe energy"], "Crusoe", "crusoe", "neocloud"),
    (["lambda", "lambda labs"], "Lambda", "lambda", "neocloud"),
    (["nebius"], "Nebius", "nebius", "neocloud"),
    (["nscale"], "Nscale", "nscale", "neocloud"),
    (["xai"], "xAI", "xai", "ai_lab"),
    (["openai"], "OpenAI", "openai", "ai_lab"),
    (["anthropic"], "Anthropic", "anthropic", "ai_lab"),
    (["digital realty", "digitalrealty"], "Digital Realty", "digital-realty", "wholesale_colo"),
    (["equinix"], "Equinix", "equinix", "retail_colo"),
    (["qts", "qts realty"], "QTS", "qts", "wholesale_colo"),
    (["vantage", "vantage data centers"], "Vantage Data Centers", "vantage", "wholesale_colo"),
    (["switch"], "Switch", "switch", "wholesale_colo"),
    (["cyrusone"], "CyrusOne", "cyrusone", "wholesale_colo"),
    (["aligned", "aligned data centers"], "Aligned Data Centers", "aligned", "wholesale_colo"),
    (["edgeconnex"], "EdgeConneX", "edgeconnex", "wholesale_colo"),
    (["compass", "compass datacenters"], "Compass Datacenters", "compass", "wholesale_colo"),
    (["stack", "stack infrastructure"], "Stack Infrastructure", "stack", "wholesale_colo"),
    (["ntt", "ntt global data centers"], "NTT", "ntt", "wholesale_colo"),
    (["cloudhq"], "CloudHQ", "cloudhq", "wholesale_colo"),
    (["prime data centers"], "Prime Data Centers", "prime", "wholesale_colo"),
    (["databank"], "DataBank", "databank", "retail_colo"),
    (["sabey"], "Sabey", "sabey", "wholesale_colo"),
    (["tract"], "Tract", "tract", "developer"),
    # colocation / network operators surfaced by PeeringDB enumeration (2026-07)
    (["coresite"], "CoreSite", "coresite", "retail_colo"),
    (["centersquare"], "Centersquare", "centersquare", "retail_colo"),
    (["h5 data centers"], "H5 Data Centers", "h5", "wholesale_colo"),
    (["data foundry"], "Data Foundry", "data-foundry", "retail_colo"),
    (["flexential"], "Flexential", "flexential", "retail_colo"),
    (["cologix"], "Cologix", "cologix", "retail_colo"),
    (["365 data centers"], "365 Data Centers", "365-datacenters", "retail_colo"),
    (["tierpoint"], "TierPoint", "tierpoint", "retail_colo"),
    (["stream data centers"], "Stream Data Centers", "stream", "wholesale_colo"),
    (["element critical"], "Element Critical", "element-critical", "retail_colo"),
    (["edgecore"], "EdgeCore Digital Infrastructure", "edgecore", "wholesale_colo"),
    (["t5 data centers"], "T5 Data Centers", "t5", "wholesale_colo"),
    (["mdc data centers"], "MDC Data Centers", "mdc", "retail_colo"),
    (["iron mountain"], "Iron Mountain", "iron-mountain", "wholesale_colo"),
    (["telehouse"], "Telehouse", "telehouse", "retail_colo"),
    (["evocative"], "Evocative", "evocative", "retail_colo"),
    (["netrality"], "Netrality Data Centers", "netrality", "wholesale_colo"),
    (["vpls"], "VPLS", "vpls", "retail_colo"),
    (["colocation america"], "Colocation America", "colocation-america", "retail_colo"),
    (["lumen", "centurylink"], "Lumen Technologies", "lumen", "retail_colo"),
    (["cogent"], "Cogent Communications", "cogent", "retail_colo"),
    (["hurricane electric"], "Hurricane Electric", "hurricane-electric", "retail_colo"),
    (["serverfarm"], "ServerFarm", "serverfarm", "wholesale_colo"),
    # AI / energy data-center developers surfaced by Phase-B news discovery (2026-07);
    # categorized from the sourcing article, not the directory default.
    (["iren", "iris energy"], "IREN", "iren", "neocloud"),
    (["intersect power", "intersect"], "Intersect Power", "intersect-power", "developer"),
    (["lancium"], "Lancium", "lancium", "developer"),
    (["kdc"], "KDC", "kdc", "developer"),
    (["new era energy"], "New Era Energy & Digital", "new-era-energy", "developer"),
    (["powerbridge"], "PowerBridge", "powerbridge", "developer"),
    (["big digital"], "Big Digital Energy", "big-digital-energy", "developer"),
    (["copt"], "COPT", "copt", "developer"),
    (["eneus"], "Eneus Energy", "eneus-energy", "developer"),
]
_DEV_ALIAS: dict[str, tuple[str, str, str]] = {}
for _aliases, _canon, _eid, _cat in _DEV_ROWS:
    for _a in _aliases:
        _DEV_ALIAS[_a] = (_canon, _eid, _cat)


def canonical_developer(name: str | None) -> tuple[str | None, str | None, str | None]:
    """(canonical_name, entity_id, category). Unknown names pass through as-is.

    The fallback pass matches an alias on WORD BOUNDARIES and takes the LONGEST match,
    the same rule as `chain_topology._resolve`. A bare `alias in key` substring test that
    returned the FIRST dict hit misattributed whole facilities to the wrong company:
    "Taxair Holdings"→xAI, "Associated Colocation"→Oracle (via "ass-OCI-ated"),
    "Metallurgy Systems"→Meta, "Contract Datacenters"→Tract. Measured against the 156
    developer names in the store today it fired zero times — but names arrive continuously
    from PeeringDB and news discovery, so it was a live landmine, not a hypothetical.
    """
    if not name:
        return None, None, None
    key = re.sub(r"[^a-z0-9 ]", "", name.lower()).strip()
    if key in _DEV_ALIAS:
        return _DEV_ALIAS[key]
    best: tuple[int, tuple[str, str, str]] | None = None
    for alias, hit in _DEV_ALIAS.items():
        if re.search(r"\b" + re.escape(alias) + r"\b", key) and (best is None or len(alias) > best[0]):
            best = (len(alias), hit)
    return best[1] if best else (name.strip(), None, None)


# --- status: press phrasing -> lifecycle (fallback if the model didn't map) ---
_STATUS_HINTS: list[tuple[tuple[str, ...], str]] = [
    (("operational", "online", "in service", "operating", "commissioned", "went live"), "operating"),
    (("under construction", "broke ground", "breaking ground", "underway", "being built", "construction begins"), "under_construction"),
    (("permitted", "approved", "rezoned", "zoning approved", "special use permit", "council approved"), "permitted"),
    (("cancel", "scrapped", "withdrawn", "abandoned", "halted", "shelved"), "cancelled"),
    (("on hold", "paused", "delayed", "suspended"), "on_hold"),
    (("retired", "decommission", "shut down", "closed"), "retired"),
    (("plan", "propos", "announced", "will build", "to build", "intends", "unveiled"), "proposed"),
]


def status_from_press(text: str | None) -> str | None:
    s = (text or "").lower()
    if not s:
        return None
    for needles, life in _STATUS_HINTS:
        if any(n in s for n in needles):
            return life
    return None


def resolve_status(status_field: dict | None) -> str | None:
    """Prefer the model's enum value; else infer from its value/quote phrasing."""
    if not isinstance(status_field, dict):
        return None
    v = status_field.get("value")
    if v in LIFECYCLE:
        return v
    return status_from_press(v) or status_from_press(status_field.get("quote"))


# --- geography ----------------------------------------------------------------
def normalize_state(raw: str | None) -> str | None:
    if not raw:
        return None
    s = str(raw).strip()
    up = s.upper()
    if len(up) == 2 and up in US_STATE_CODES:
        return up
    return STATE_NAME_TO_CODE.get(s.lower())


# --- identity key (Phase C dedupe seed) --------------------------------------
def _slug(s: str | None) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def identity_key(project_name: str | None, county: str | None,
                 state: str | None, developer: str | None) -> str:
    canon_dev, _, _ = canonical_developer(developer)
    return "|".join([
        _slug(project_name),
        _slug(county),
        (state or "").upper(),
        _slug(canon_dev),
    ])


# --- unit parsing (belt-and-suspenders; the model normalizes in-prompt) -------
_MULT = {"thousand": 1e3, "million": 1e6, "billion": 1e9, "trillion": 1e12,
         "k": 1e3, "m": 1e6, "b": 1e9}


def parse_money(text: str | None) -> float | None:
    """'$11.6 billion' -> 11600000000.0 ; '$450M' -> 450000000.0."""
    if text is None:
        return None
    if isinstance(text, (int, float)):
        return float(text)
    m = re.search(r"\$?\s*([\d,]+(?:\.\d+)?)\s*(trillion|billion|million|thousand|[kmb])?", str(text).lower())
    if not m:
        return None
    num = float(m.group(1).replace(",", ""))
    return round(num * _MULT.get(m.group(2), 1.0), 2)


def parse_capacity_mw(text: str | None) -> float | None:
    """'1.2 GW' -> 1200.0 ; '850 MW' -> 850.0 ; 500 -> 500.0."""
    if text is None:
        return None
    if isinstance(text, (int, float)):
        return float(text)
    m = re.search(r"([\d,]+(?:\.\d+)?)\s*(gw|gigawatt|mw|megawatt|kw|kilowatt)?", str(text).lower())
    if not m:
        return None
    num = float(m.group(1).replace(",", ""))
    unit = m.group(2) or "mw"
    if unit.startswith("g"):
        return round(num * 1000, 3)
    if unit.startswith("k"):
        return round(num / 1000, 6)
    return round(num, 3)

"""Post-extraction guardrails (phase-b-spec §4).

The single most important defense against hallucinated specifics is the rule
**every number must carry a supporting quote** — an unquoted capacity/capex/date
is dropped, not trusted. Records with no name or no location are rejected
outright. A `self_consistency` score (0–1) summarizes how complete and internally
supported the single-source extraction is (real confidence comes later, in verify).
"""
from __future__ import annotations

from .schema import NUMERIC_FIELDS, STATUS_ENUM, VALUED_FIELDS


def _val(f):
    return f.get("value") if isinstance(f, dict) else None


def _quote(f):
    q = f.get("quote") if isinstance(f, dict) else None
    return q.strip() if isinstance(q, str) else None


def sanitize_and_validate(project: dict) -> tuple[dict | None, list[str], float]:
    """Return (candidate | None, issues, self_consistency).

    None means the record is rejected (no name / no location). Otherwise the
    returned candidate has unquoted numbers stripped to null and status coerced
    to the enum.
    """
    issues: list[str] = []
    p = dict(project)

    # hard reject: no project name
    name = (p.get("project_name") or "").strip()
    if not name:
        return None, ["reject: no project_name"], 0.0
    p["project_name"] = name

    # hard reject: no location signal at all
    loc = p.get("location") or {}
    if not (loc.get("state") or loc.get("county") or loc.get("address")):
        return None, ["reject: no location"], 0.0

    # coerce every valued field into a {value, quote} shape
    for fld in VALUED_FIELDS:
        f = p.get(fld)
        if not isinstance(f, dict):
            p[fld] = {"value": None, "quote": None}

    # quote guard: any number without a supporting quote is a likely hallucination
    for fld in NUMERIC_FIELDS:
        f = p[fld]
        if _val(f) is not None and not _quote(f):
            issues.append(f"dropped unquoted {fld}={_val(f)!r}")
            p[fld] = {"value": None, "quote": None}

    # status must be in the lifecycle enum; otherwise drop to null
    st = p["status"]
    if _val(st) is not None and _val(st) not in STATUS_ENUM:
        issues.append(f"dropped out-of-enum status={_val(st)!r}")
        p["status"] = {"value": None, "quote": None}
    # a stated status also needs a quote (it drives lifecycle) — else null
    if _val(p["status"]) is not None and not _quote(p["status"]):
        issues.append("dropped unquoted status")
        p["status"] = {"value": None, "quote": None}

    return p, issues, _self_consistency(p)


def _self_consistency(p: dict) -> float:
    """Pre-verify completeness signal in [0,1]. Real confidence is set in verify."""
    score = 0.4
    if _val(p.get("capacity_mw")) is not None:
        score += 0.2
    if _val(p.get("status")) is not None:
        score += 0.2
    if (p.get("location") or {}).get("state"):
        score += 0.1
    if any(_val(p.get(k)) for k in ("developer", "operator", "tenant", "end_user")):
        score += 0.1
    return round(min(score, 1.0), 3)

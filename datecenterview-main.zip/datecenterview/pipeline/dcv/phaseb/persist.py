"""Persist verified candidates into the DataCenter store (phase-b-spec §6-7).

Merges same-project candidates on `identity_key` (union sources, best status,
max confidence, re-gate), builds field-level `Field<T>` provenance, geocodes the
county centroid, and upserts on the natural key. `emit` then projects these rows
into data.json — no UI change needed.
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from sqlalchemy.dialects.postgresql import insert as pg_insert

from .. import geocode
from ..db import session_scope
from ..field import field
from ..models import DataCenter, Source
from .verify import _domain, _gate

LIFECYCLE_RANK = {
    "operating": 5, "under_construction": 4, "permitted": 3,
    "on_hold": 2, "proposed": 1, "cancelled": 0, "retired": 0,
}
# publisher-type trust (registry); primary sources > aggregators
_SOURCE_TYPE = {"x.com": "social", "twitter.com": "social"}


def _fval(f):
    return f.get("value") if isinstance(f, dict) else None


def _fconf(f):
    return f.get("confidence", 0.0) if isinstance(f, dict) else 0.0


def _honest_precision(loc: dict, lat) -> str | None:
    """Never claim `exact` without a coordinate to back it.

    extract._geo_precision returns "exact" whenever the extraction carried an address string.
    An address is not a coordinate: geocoding can fail, and persist stores lat/lng but not the
    address, so the row ends up asserting a precise location with nothing precise in it. Gate
    12 blocks that, correctly. Degrade to what the row actually holds.
    """
    p = loc.get("geo_precision")
    if p != "exact" or lat is not None:
        return p
    return ("county" if loc.get("county") else
            "state" if loc.get("state") else None)


def merge_candidates(cands: list[dict]) -> list[dict]:
    """Collapse candidates sharing an identity_key into one merged record."""
    groups: dict[str, list[dict]] = {}
    for c in cands:
        groups.setdefault(c["identity_key"], []).append(c)

    merged: list[dict] = []
    for key, grp in groups.items():
        if len(grp) == 1:
            merged.append(grp[0])
            continue
        base = dict(max(grp, key=lambda c: c.get("overall_confidence", 0)))
        # union sources by url
        seen, srcs = set(), []
        for c in grp:
            for s in c.get("sources", []):
                if s.get("url") and s["url"] not in seen:
                    seen.add(s["url"])
                    srcs.append(s)
        base["sources"] = srcs
        # aka union
        aka = {a for c in grp for a in (c.get("aka") or [])}
        base["aka"] = sorted(aka)
        # per-field: prefer the highest-confidence non-null variant
        for fld in ("developer", "operator", "tenant", "end_user", "status",
                    "capacity_mw", "capacity_mwh", "building_sqft", "land_acres",
                    "cap_ex_usd", "operating_year", "btm_generation", "announced_date"):
            best = None
            for c in grp:
                f = c.get(fld)
                if _fval(f) is not None and (best is None or _fconf(f) > _fconf(best)):
                    best = f
            if best is not None:
                base[fld] = best
        # most-advanced lifecycle
        lifecycles = [c.get("status_lifecycle") for c in grp if c.get("status_lifecycle")]
        if lifecycles:
            base["status_lifecycle"] = max(lifecycles, key=lambda s: LIFECYCLE_RANK.get(s, 0))
        # re-gate on merged confidence + distinct source domains
        conf = max(c.get("overall_confidence", 0) for c in grp)
        n_dom = len({d for s in srcs if (d := _domain(s.get("url")))})
        base["overall_confidence"] = round(conf, 3)
        base["review_status"] = _gate(conf, n_dom)
        merged.append(base)
    return merged


def _field(cand: dict, key: str, *, unit: str | None = None):
    f = cand.get(key)
    if not isinstance(f, dict) or f.get("value") is None:
        return None
    method = "cross_verified" if f.get("verify") == "agree" else "extracted"
    return field(
        f["value"], unit=unit,
        sources=[s["url"] for s in cand.get("sources", []) if s.get("url")],
        confidence=f.get("confidence", cand.get("overall_confidence", 0.0)),
        method=method, last_verified=cand.get("last_verified"),
        # The extractor requires a supporting quote for every value it returns; keep it.
        quote=f.get("quote"),
    )


def _register_sources(session, cands: list[dict], now: datetime) -> None:
    seen: set[str] = set()
    for c in cands:
        for s in c.get("sources", []):
            url = s.get("url")
            if not url or url in seen:
                continue
            seen.add(url)
            dom = _domain(url)
            session.merge(Source(
                id=url, url=url, publisher=s.get("publisher") or dom,
                type=_SOURCE_TYPE.get(dom, "trade_press"),
                trust_weight=0.6 if _SOURCE_TYPE.get(dom) == "social" else 0.75,
                retrieved_at=now,
            ))


def persist(cands: list[dict]) -> dict:
    """Upsert candidates; return counts by review_status."""
    cands = merge_candidates(cands)
    today = date.today().isoformat()
    now = datetime.now(timezone.utc)
    counts = {"approved": 0, "needs_review": 0, "reported": 0, "candidate": 0}

    with session_scope() as session:
        _register_sources(session, cands, now)
        session.flush()

        for c in cands:
            loc = c.get("location") or {}
            lat = lng = None
            if loc.get("county") and loc.get("state"):
                hit = geocode.county_centroid(loc["county"], loc["state"])
                if hit:
                    lat, lng = hit
            urls = [s["url"] for s in c.get("sources", []) if s.get("url")]
            cid = "dcb-" + c["identity_key"].replace("|", "-")

            values = dict(
                id=cid,
                natural_key=c["identity_key"],
                project_name=c["project_name"],
                aka=c.get("aka") or [],
                developer_name=c.get("developer_canonical") or _fval(c.get("developer")),
                end_user_name=_fval(c.get("end_user")),
                # The extractor has always returned these two; until Band 2 #2 there was no
                # column to write them to, so they were dropped here silently.
                tenant_name=_fval(c.get("tenant")),
                operator_name=_fval(c.get("operator")),
                developer_category=c.get("developer_category"),
                status=c.get("status_lifecycle") or "proposed",
                capacity_mw=_field(c, "capacity_mw", unit="MW"),
                building_sqft=_field(c, "building_sqft", unit="sqft"),
                land_acres=_field(c, "land_acres", unit="acres"),
                cap_ex=_field(c, "cap_ex_usd", unit="USD"),
                btm_generation=_field(c, "btm_generation"),
                power_sources=c.get("power_sources") or [],
                location={
                    "county": loc.get("county"), "state": loc.get("state"),
                    "country": loc.get("country") or "US", "lat": lat, "lng": lng,
                    # `exact` is a claim about a COORDINATE, and extract._geo_precision
                    # derives it from the presence of an address STRING — which geocoding may
                    # then fail to resolve, and which persist does not even store. The
                    # 2026-07-31 sweep wrote 5 rows claiming `exact` with neither lat/lng nor
                    # address, and gate 12 blocked publish. Same defect class as the
                    # enumerate_dc `... or "exact"` default fixed the day before, on a
                    # different ingest path: degrade to the finest granularity the row can
                    # actually support rather than assert one we never had.
                    "geo_precision": _honest_precision(loc, lat),
                    # location is a plain dict rather than a Field<T>, so its quote needs
                    # carrying explicitly — it is the evidence for the siting claim.
                    **({"quote": loc["quote"][:500]} if loc.get("quote") else {}),
                },
                announced_date=_fval(c.get("announced_date")),
                operating_year=_fval(c.get("operating_year")),
                overall_confidence=c.get("overall_confidence"),
                review_status=c.get("review_status", "candidate"),
                last_verified=today,
                sources=urls,
                updated_at=now,
            )
            stmt = pg_insert(DataCenter).values(**values)
            update_cols = {k: stmt.excluded[k] for k in values if k not in ("id", "created_at")}
            stmt = stmt.on_conflict_do_update(index_elements=["id"], set_=update_cols)
            session.execute(stmt)
            counts[c.get("review_status", "candidate")] = counts.get(c.get("review_status", "candidate"), 0) + 1

    total = sum(counts.values())
    print(f"✓ persisted {total} data_center rows "
          f"(approved={counts['approved']}, needs_review={counts['needs_review']}, reported={counts['reported']})")
    return counts

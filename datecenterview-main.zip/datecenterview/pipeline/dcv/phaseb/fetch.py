"""Fetch & clean (phase-b-spec §3) — candidate URL → clean text + metadata.

Cost discipline: discovery via Exa already returns article text, so we reuse it
and skip a Firecrawl scrape when the body is substantial. Only thin candidates
(GDELT/RSS/Grok links) are scraped. Paywalls are flagged, never bypassed.
"""
from __future__ import annotations

from urllib.parse import urlparse

from ..clients import firecrawl

MIN_TEXT = 600  # chars; below this we scrape for a fuller body


def _publisher(url: str) -> str | None:
    try:
        return urlparse(url).netloc.lower().removeprefix("www.") or None
    except Exception:
        return None


def fetch(candidate: dict) -> dict | None:
    """Return a document dict or None if it couldn't be fetched/cleaned."""
    text = candidate.get("text") or ""
    if len(text) >= MIN_TEXT:  # reuse Exa's text — no scrape needed
        return {
            "url": candidate["url"],
            "canonical_url": candidate["url"],
            "title": candidate.get("title"),
            "publisher": _publisher(candidate["url"]),
            "published_date": candidate.get("published_date"),
            "text": text,
            "paywalled": False,
        }

    doc = firecrawl.scrape(candidate["url"])
    if not doc or not doc.get("text"):
        return None
    doc["title"] = doc.get("title") or candidate.get("title")
    doc["published_date"] = doc.get("published_date") or candidate.get("published_date")
    doc["publisher"] = doc.get("publisher") or _publisher(candidate["url"])
    return doc

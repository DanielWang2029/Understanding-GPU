"""Extraction (phase-b-spec §4) — document → cited candidate `data_center` records.

Grok 4.1 Fast (a different vendor than the Claude verifier) reads one article and
returns structured JSON bound to the §11 schema. We attach the article URL as each
field's `source` (the model never invents URLs), run the hallucination guards, and
assemble the candidate record Phase C verify + persist consume.
"""
from __future__ import annotations

from datetime import date

from ..clients import grok
from ..config import settings
from .normalize_dc import canonical_developer, identity_key, normalize_state, resolve_status
from .schema import EXTRACTION_SCHEMA, EXTRACTION_SYSTEM_PROMPT
from .validate_extract import sanitize_and_validate

MAX_ARTICLE_CHARS = 24000  # token guard for the extractor


def _pf(f: dict | None, source: str, today: str) -> dict:
    """Field with provenance, or a bare null field."""
    if not isinstance(f, dict) or f.get("value") is None:
        return {"value": None}
    return {"value": f["value"], "quote": f.get("quote"), "source": source, "extracted_at": today}


def _geo_precision(loc: dict) -> str | None:
    if loc.get("address"):
        return "exact"
    if loc.get("county"):
        return "county"
    return "state" if loc.get("state") else None


def _build_candidate(cand: dict, doc: dict, self_consistency: float) -> dict:
    today = date.today().isoformat()
    src = doc["canonical_url"]
    loc = cand.get("location") or {}
    state = normalize_state(loc.get("state"))
    dev = cand.get("developer") or {}
    canon_dev, dev_id, dev_cat = canonical_developer(dev.get("value"))
    return {
        "identity_key": identity_key(cand["project_name"], loc.get("county"), state, canon_dev),
        "aka": cand.get("aka") or [],
        "project_name": cand["project_name"],
        "developer": _pf(dev, src, today),
        "developer_canonical": canon_dev,
        "developer_id": dev_id,
        "developer_category": dev_cat,
        "operator": _pf(cand.get("operator"), src, today),
        "tenant": _pf(cand.get("tenant"), src, today),
        "end_user": _pf(cand.get("end_user"), src, today),
        "status": _pf(cand.get("status"), src, today),
        "status_lifecycle": resolve_status(cand.get("status")),
        "capacity_mw": _pf(cand.get("capacity_mw"), src, today),
        "capacity_mwh": _pf(cand.get("capacity_mwh"), src, today),
        "building_sqft": _pf(cand.get("building_sqft"), src, today),
        "land_acres": _pf(cand.get("land_acres"), src, today),
        "cap_ex_usd": _pf(cand.get("cap_ex_usd"), src, today),
        "operating_year": _pf(cand.get("operating_year"), src, today),
        "btm_generation": _pf(cand.get("btm_generation"), src, today),
        "announced_date": _pf(cand.get("announced_date"), src, today),
        "power_sources": cand.get("power_sources") or [],
        "location": {
            "county": loc.get("county"), "state": state,
            "country": loc.get("country") or "US", "address": loc.get("address"),
            "quote": loc.get("quote"), "geo_precision": _geo_precision(loc),
        },
        "sources": [{
            "url": src, "publisher": doc.get("publisher"),
            "published": doc.get("published_date"), "paywalled": doc.get("paywalled", False),
        }],
        "extraction_model": settings.extract_model,
        "self_consistency": self_consistency,
        "review_status": "candidate",
    }


def extract(document: dict) -> list[dict]:
    """Return a list of candidate records (one article can hold several projects)."""
    text = (document.get("text") or "")[:MAX_ARTICLE_CHARS]
    if not text.strip():
        return []
    user = (
        f"URL: {document['canonical_url']}\n"
        f"Title: {document.get('title') or ''}\n\n"
        f"ARTICLE:\n{text}"
    )
    try:
        content, _ = grok.chat(
            EXTRACTION_SYSTEM_PROMPT, user,
            model=settings.extract_model, response_schema=EXTRACTION_SCHEMA,
        )
    except Exception as e:
        print(f"  [extract] {document['canonical_url']} failed ({type(e).__name__}: {e})")
        return []

    projects = content.get("projects", []) if isinstance(content, dict) else []
    out: list[dict] = []
    for proj in projects:
        cand, issues, sc = sanitize_and_validate(proj)
        if cand is None:
            continue
        if issues:
            print(f"  [extract] {cand.get('project_name','?')}: {'; '.join(issues)}")
        out.append(_build_candidate(cand, document, sc))
    return out

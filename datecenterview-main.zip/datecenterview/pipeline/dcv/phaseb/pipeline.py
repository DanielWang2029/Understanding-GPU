"""Phase B orchestrator — discover → fetch → extract → verify → persist.

Delta-only (skips URLs already in the store), spend-capped (stops cleanly at the
daily limit and still persists what it has), state-scoped for the pilot. Verify is
optional so a cheap smoke can skip the paid cross-vendor gate.
"""
from __future__ import annotations

from sqlalchemy import select

from ..clients import spend
from ..clients.spend import SpendLimitError
from ..config import settings
from ..db import session_scope
from ..models import DataCenter
from . import discover as discover_mod
from . import extract as extract_mod
from . import fetch as fetch_mod
from . import persist as persist_mod
from . import verify as verify_mod


def _seen_urls() -> set[str]:
    urls: set[str] = set()
    with session_scope() as s:
        for dc in s.execute(select(DataCenter)).scalars():
            for u in dc.sources or []:
                urls.add(u)
    return urls


def run(states: list[str] | None = None, *, max_candidates: int | None = None,
        do_verify: bool = True) -> dict:
    states = [s.upper() for s in (states if states is not None else settings.phase_b_state_list)]
    max_candidates = max_candidates or settings.discovery_max_candidates
    spend.configure(settings.daily_spend_limit_usd)
    print(f"=== Phase B — states={states or 'US'} verify={do_verify} cap=${settings.daily_spend_limit_usd} ===")

    seen = _seen_urls()
    queue = [c for c in discover_mod.discover(states, max_candidates) if c["url"] not in seen]
    queue = queue[: settings.extract_max_records]
    print(f"→ {len(queue)} new candidates after delta filter (skipped {len(seen)} seen)")

    candidates: list[dict] = []
    try:
        for c in queue:
            doc = fetch_mod.fetch(c)
            if not doc:
                continue
            for rec in extract_mod.extract(doc):
                st = (rec.get("location") or {}).get("state")
                if states and st not in states:
                    continue  # keep the pilot scoped
                candidates.append(rec)
    except SpendLimitError as e:
        print(f"  [pipeline] {e} — stopping extraction, persisting what we have")
    print(f"→ extracted {len(candidates)} candidate records")

    verified: list[dict] = []
    try:
        for cand in candidates:
            if do_verify and settings.anthropic_api_key:
                cand = verify_mod.verify(cand)
            else:
                cand["overall_confidence"] = round(min(cand.get("self_consistency", 0.4), 0.55), 3)
                cand["review_status"] = "reported"
                cand["last_verified"] = None
            verified.append(cand)
    except SpendLimitError as e:
        print(f"  [pipeline] {e} — stopping verify, persisting what we have")

    counts = persist_mod.persist(verified) if verified else {"approved": 0, "needs_review": 0, "reported": 0}
    print(f"=== spend: {spend.LEDGER.summary()} ===")
    return {"counts": counts, "spend_usd": round(spend.LEDGER.total_usd, 4),
            "extracted": len(candidates)}

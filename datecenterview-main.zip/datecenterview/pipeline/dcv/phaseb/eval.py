"""Texas pilot eval (phase-b-spec §8) — recall / precision / field accuracy / dup rate.

Compares Phase-B-discovered rows (id prefix `dcb-`) against the loaded gold set.
Precision here is measured *against the gold set*, so it is a lower bound while the
gold set is incomplete — an extracted row absent from a 7-project gold set may still
be real. Targets: recall ≥0.80, precision ≥0.90, field ≥0.85, dup <0.05.
"""
from __future__ import annotations

from sqlalchemy import select

from ..db import session_scope
from ..field import field_value
from ..models import DataCenter, GoldSet
from .normalize_dc import _slug

TARGETS = {"recall": 0.80, "precision": 0.90, "field_accuracy": 0.85, "dup_rate": 0.05}
CAP_TOLERANCE = 0.15  # ±15% counts as a capacity match


def _name_key(name, state):
    return (_slug(name), (state or "").upper())


def evaluate() -> dict:
    with session_scope() as s:
        gold = list(s.execute(select(GoldSet).where(GoldSet.record_type == "data_center")).scalars())
        extracted = [d for d in s.execute(select(DataCenter)).scalars() if str(d.id).startswith("dcb-")]

        by_key = {d.natural_key: d for d in extracted}
        by_name = {_name_key(d.project_name, (d.location or {}).get("state")): d for d in extracted}

        matched: list[tuple[dict, DataCenter]] = []
        for g in gold:
            f = g.fields or {}
            dc = by_key.get(g.natural_key) or by_name.get(_name_key(f.get("project_name"), f.get("state")))
            if dc:
                matched.append((f, dc))

        gold_keys = {g.natural_key for g in gold} | {
            _name_key((g.fields or {}).get("project_name"), (g.fields or {}).get("state")) for g in gold
        }
        extr_hit = sum(
            1 for d in extracted
            if d.natural_key in gold_keys or _name_key(d.project_name, (d.location or {}).get("state")) in gold_keys
        )

        # field accuracy over matched pairs
        checks = correct = 0
        for f, dc in matched:
            if f.get("capacity_mw") is not None:
                checks += 1
                cv = field_value(dc.capacity_mw)
                if cv is not None and abs(cv - f["capacity_mw"]) <= CAP_TOLERANCE * f["capacity_mw"]:
                    correct += 1
            if f.get("status"):
                checks += 1
                if dc.status == f["status"]:
                    correct += 1
            if f.get("county"):
                checks += 1
                if _slug((dc.location or {}).get("county")) == _slug(f["county"]):
                    correct += 1

        n_gold, n_extr = len(gold), len(extracted)
        distinct = len({_name_key(d.project_name, (d.location or {}).get("state")) for d in extracted})

    metrics = {
        "gold_size": n_gold,
        "extracted": n_extr,
        "recall": round(len(matched) / n_gold, 3) if n_gold else 0.0,
        "precision": round(extr_hit / n_extr, 3) if n_extr else 0.0,
        "field_accuracy": round(correct / checks, 3) if checks else None,
        "dup_rate": round((n_extr - distinct) / n_extr, 3) if n_extr else 0.0,
    }
    _report(metrics)
    return metrics


def _report(m: dict) -> None:
    def mark(name, val, hi_good=True):
        if val is None:
            return "  n/a"
        t = TARGETS[name]
        ok = (val >= t) if hi_good else (val <= t)
        return f"{'✓' if ok else '✗'} {val:.2f} (target {'≥' if hi_good else '<'}{t})"

    print("\n=== Phase B — Texas pilot eval ===")
    print(f"  gold set: {m['gold_size']} projects   extracted (dcb-): {m['extracted']} rows")
    if m["extracted"] == 0:
        print("  (no Phase-B rows yet — run `phase-b --states TX` then `emit`, then re-run eval)")
        return
    print(f"  recall         {mark('recall', m['recall'])}")
    print(f"  precision*     {mark('precision', m['precision'])}   *lower bound vs incomplete gold set")
    print(f"  field accuracy {mark('field_accuracy', m['field_accuracy'])}")
    print(f"  dup rate       {mark('dup_rate', m['dup_rate'], hi_good=False)}")

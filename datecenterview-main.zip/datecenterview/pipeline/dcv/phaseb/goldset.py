"""TX gold-set loader (phase-b-spec §8).

Loads the hand-verified fixture into the GoldSet table, computing the same
`identity_key` the extractor uses so eval can match on it. Idempotent: replaces
the existing data_center gold rows on each load.
"""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

from sqlalchemy import delete

from ..config import settings
from ..db import session_scope
from ..models import GoldSet
from .normalize_dc import identity_key

DEFAULT_PATH = settings.repo_root / "pipeline" / "seed" / "tx_gold_set.json"


def load_gold_set(path: Path | None = None) -> int:
    path = path or DEFAULT_PATH
    data = json.loads(Path(path).read_text())
    today = date.today().isoformat()
    projects = data.get("projects", [])

    with session_scope() as s:
        s.execute(delete(GoldSet).where(GoldSet.record_type == "data_center"))
        for p in projects:
            nk = identity_key(p.get("project_name"), p.get("county"), p.get("state"), p.get("developer"))
            s.add(GoldSet(
                record_type="data_center",
                natural_key=nk,
                fields={
                    "project_name": p.get("project_name"),
                    "developer": p.get("developer"),
                    "county": p.get("county"),
                    "state": p.get("state"),
                    "capacity_mw": p.get("capacity_mw"),
                    "status": p.get("status"),
                    "aka": p.get("aka", []),
                },
                notes=data.get("_meta", {}).get("note"),
                verified_by="demo_seed_bootstrap",
                verified_at=today,
            ))
    print(f"✓ loaded {len(projects)} TX gold-set projects "
          f"(target {data.get('_meta', {}).get('target_size', 100)} — expand before eval is authoritative)")
    return len(projects)

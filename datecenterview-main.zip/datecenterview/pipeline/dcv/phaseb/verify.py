"""Cross-vendor verify + confidence gate (phase-b-spec §7, architecture decision #4).

Claude (a *different vendor* than the Grok extractor) independently re-checks the
three critical fields — capacity_mw, status, location — with web search enabled so
it can find a *second* source rather than echo the extractor's page. Agreement +
an independent corroborating source raises confidence; conflict flags it.

Two independences are enforced separately:
  1. source independence — `confirmed` needs ≥2 independent SOURCES (distinct domains)
  2. model independence   — the verifier is a different VENDOR than the extractor
Same-vendor or single-source agreement can never reach auto-approve.
"""
from __future__ import annotations

from urllib.parse import urlparse

from .. import source_liveness, source_policy
from ..clients import claude
from ..config import settings

CRITICAL = ("capacity_mw", "status", "location")

# verdict → base field confidence
_AGREE_CORROBORATED = 0.93   # agrees AND found an independent source
_AGREE_UNCORROBORATED = 0.72  # agrees but only the extractor's source
_UNVERIFIABLE = 0.45
_DISAGREE = 0.20
_SINGLE_SOURCE_CAP = 0.85     # below auto-approve: one source can't be "confirmed"

VERIFY_SYSTEM = (
    "You are a skeptical fact-checker verifying a data-center project record. "
    "For each field you are given the extracted value, the supporting quote, and the "
    "source URL. Use web search to find an INDEPENDENT second source (a different "
    "publisher/domain) that confirms or contradicts each value. Do not simply trust "
    "the given source. Prefer primary sources (company press releases, permits, "
    "utility/ISO filings) over aggregators. Be conservative: if you cannot corroborate "
    "a value, mark it unverifiable rather than agreeing.\n"
    "Respond with ONLY a JSON object of this exact shape (no prose):\n"
    "{\n"
    '  "capacity_mw": {"verdict": "agree|disagree|unverifiable", "found_value": <number|null>, "source_url": <url|null>},\n'
    '  "status":      {"verdict": "agree|disagree|unverifiable", "found_value": <string|null>, "source_url": <url|null>},\n'
    '  "location":    {"verdict": "agree|disagree|unverifiable", "found_value": <string|null>, "source_url": <url|null>}\n'
    "}"
)


def _domain(url: str | None) -> str | None:
    if not url:
        return None
    try:
        return urlparse(url).netloc.lower().removeprefix("www.") or None
    except Exception:
        return None


def _fval(f):
    return f.get("value") if isinstance(f, dict) else None


def _has_location(cand: dict) -> bool:
    loc = cand.get("location") or {}
    return bool(loc.get("state") or loc.get("county") or loc.get("address"))


def _field_present(cand: dict, field: str) -> bool:
    return _has_location(cand) if field == "location" else _fval(cand.get(field)) is not None


def _user_prompt(cand: dict) -> str:
    loc = cand.get("location") or {}
    loc_str = ", ".join(x for x in [loc.get("address"), loc.get("county"), loc.get("state")] if x)
    src = (cand.get("sources") or [{}])[0].get("url")
    return (
        f"Project: {cand['project_name']}\n"
        f"Extraction source: {src}\n\n"
        f"Fields to verify:\n"
        f"- capacity_mw: {_fval(cand.get('capacity_mw'))} "
        f"(quote: {cand.get('capacity_mw', {}).get('quote')!r})\n"
        f"- status: {_fval(cand.get('status'))} "
        f"(quote: {cand.get('status', {}).get('quote')!r})\n"
        f"- location: {loc_str or None} "
        f"(quote: {loc.get('quote')!r})\n"
    )


def _score_field(verdict: dict, extraction_domains: set[str],
                 liveness=None) -> tuple[float, str | None, str | None]:
    """Return (confidence, new_independent_source_url|None, liveness_state|None).

    A source only counts as corroboration when it is independent AND the page EXISTS. Until
    the 2026-07-30 bake-off nothing checked the second half: the bonus was awarded for typing
    a new hostname. A verifier with no web search produced 4 hard 404s out of 16 cited URLs,
    every one of which would have scored 0.93 here. See `source_liveness` for why only 404/410
    disqualify and everything else ambiguous merely fails to earn the bonus.
    """
    v = (verdict or {}).get("verdict", "unverifiable")
    found = (verdict or {}).get("source_url")
    found_dom = _domain(found)
    independent = bool(found_dom and found_dom not in extraction_domains)
    if v == "disagree":
        return _DISAGREE, None, None
    if v == "agree":
        if not independent:
            return _AGREE_UNCORROBORATED, None, None
        state = (liveness or _liveness)(found)
        if state == source_liveness.LIVE:
            return _AGREE_CORROBORATED, found, state
        # Cited but not confirmed. The VALUE may still be right — this is not a `disagree` —
        # but an unconfirmed citation cannot buy the independence bonus. A proven-absent page
        # additionally returns no url, so it is never persisted as provenance.
        return (_AGREE_UNCORROBORATED,
                None if state == source_liveness.UNREACHABLE else found,
                state)
    return _UNVERIFIABLE, None, None


def _liveness(url: str | None) -> str:
    """Indirection so a caller (and the tests) can supply a checker, and so the probe can be
    turned off for an offline run without editing the gate."""
    if not settings.verify_check_source_liveness:
        return source_liveness.LIVE
    return source_liveness.check(url)


def _gate(confidence: float, n_sources: int) -> str:
    if confidence >= settings.confidence_auto_approve and n_sources >= 2:
        return "approved"
    if confidence >= settings.confidence_review_floor:
        return "needs_review"
    return "reported"


def score(cand: dict, result: dict, liveness=None) -> dict:
    """PURE: given a candidate and a verifier's raw verdict object, compute the gate outcome.

    Split out of `verify()` so a candidate verifier can be scored by the SAME code the
    pipeline runs. A bake-off that reimplemented this aggregation would drift from production
    the first time a threshold moved, and would then be comparing models against a gate that
    does not exist. Mutates nothing — `verify()` owns the writes.
    """
    extraction_domains = {d for s in cand.get("sources", []) if (d := _domain(s.get("url")))}
    field_conf: dict[str, float] = {}
    conflicts: list[str] = []
    new_sources: list[dict] = []
    verdicts: dict[str, dict] = {}
    liveness_mix: dict[str, int] = {}

    for f in CRITICAL:
        if not _field_present(cand, f):
            continue
        vd = (result or {}).get(f, {}) or {}
        conf, new_src, state = _score_field(vd, extraction_domains, liveness)
        field_conf[f] = conf
        verdicts[f] = vd
        if state:
            liveness_mix[state] = liveness_mix.get(state, 0) + 1
        if vd.get("verdict") == "disagree":
            conflicts.append(f"{f}: extractor={_fval(cand.get(f))} vs verifier={vd.get('found_value')}")
        if new_src and _domain(new_src) not in extraction_domains:
            # Stamp the probe result onto the source itself: a reader (and the review queue)
            # must be able to tell a confirmed page from one we merely could not reach.
            new_sources.append({"url": new_src, "publisher": _domain(new_src),
                                "method": "cross_verified", "liveness": state})
            extraction_domains.add(_domain(new_src))

    base = min(field_conf.values()) if field_conf else 0.4
    # n_sources counts DOMAINS WE STILL HOLD. A proven-absent citation never entered
    # extraction_domains, so it cannot push a row over the >=2-source approve gate — which is
    # exactly the promotion a fabricated URL used to buy.
    n_sources = len(extraction_domains)
    if n_sources < 2:
        base = min(base, _SINGLE_SOURCE_CAP)

    return {"field_conf": field_conf, "verdicts": verdicts, "conflicts": conflicts,
            "new_sources": new_sources, "n_sources": n_sources, "liveness": liveness_mix,
            "overall_confidence": round(base, 3), "review_status": _gate(base, n_sources)}


def verify(cand: dict) -> dict:
    """Run the cross-vendor check; return the candidate augmented with
    overall_confidence, review_status, per-field confidence, conflicts, and any
    corroborating sources. Falls back to a conservative score if verify errors."""
    try:
        result = claude.verify_json(VERIFY_SYSTEM, _user_prompt(cand))
    except Exception as e:
        print(f"  [verify] {cand.get('project_name','?')} failed ({type(e).__name__}: {e}) — held as reported")
        cand["overall_confidence"] = round(min(cand.get("self_consistency", 0.4), 0.55), 3)
        cand["review_status"] = "reported"
        cand["verify"] = {"error": str(e)}
        return cand

    sc = score(cand, result)
    # stamp field-level confidence back onto the candidate
    for f, conf in sc["field_conf"].items():
        if isinstance(cand.get(f), dict):
            cand[f]["confidence"] = conf
            cand[f]["verify"] = sc["verdicts"][f].get("verdict")

    # SOURCE POLICY on the verifier's OWN findings. `verify` runs Claude with web search, so
    # it surfaces curated competitors and modelled-figure directories like any other search —
    # and whatever it appends becomes value-provenance on a sized row. Filter with the SAME
    # test the publish gate enforces: `value_denied_reason` (tier-1 competitor AND tier-3
    # modelled), not `denied_reason` (tier-1 only).
    #
    # reverify.py was fixed for exactly this on 2026-07-21 and THIS path was not, so the
    # 2026-07-31 sweep let a dgtlinfra.com URL onto a published capacity and gate 10 blocked
    # publish. discover.py refuses tier-1 at the queue, but that only covers URLs WE went
    # looking for — the verifier brings its own. Every ingest path, not the one that broke
    # first.
    kept = []
    for src in sc["new_sources"]:
        why = source_policy.value_denied_reason(src.get("url"))
        if why:
            print(f"  [verify] refused corroborating source {src.get('url')} — {why}")
            continue
        kept.append(src)
    cand["sources"] = (cand.get("sources") or []) + kept
    cand["sources_refused"] = len(sc["new_sources"]) - len(kept)
    cand["overall_confidence"] = sc["overall_confidence"]
    cand["review_status"] = sc["review_status"]
    cand["conflicts"] = sc["conflicts"]
    cand["verify"] = {"model": settings.verify_model, "verdicts": sc["verdicts"],
                      "n_sources": sc["n_sources"], "liveness": sc["liveness"]}
    return cand

"""Extraction target schema (phase-b-spec §11) — the candidate `data_center`.

Bound to Grok's structured-output mode. Every populated field carries a verbatim
`quote` from the source; the `source_url` is attached by the pipeline (all fields
of one extraction share the article URL), so the model never invents URLs. One
article may describe many projects, so the top level is a `projects` array.
"""
from __future__ import annotations

from ..normalize import LIFECYCLE

# lifecycle enum the model must map status into (or null)
STATUS_ENUM = sorted(LIFECYCLE)

# fields that must carry a supporting quote when non-null (hallucination guard)
NUMERIC_FIELDS = ("capacity_mw", "capacity_mwh", "building_sqft", "land_acres",
                  "cap_ex_usd", "operating_year")
VALUED_FIELDS = ("developer", "operator", "tenant", "end_user", "status",
                 "btm_generation", "announced_date", *NUMERIC_FIELDS)


def _valued(json_type: str, *, enum: list | None = None) -> dict:
    """A {value, quote} object; value is `json_type` or null."""
    value: dict = {"type": [json_type, "null"]}
    if enum is not None:
        value = {"type": ["string", "null"], "enum": [*enum, None]}
    return {
        "type": "object",
        "properties": {
            "value": value,
            "quote": {"type": ["string", "null"]},
        },
        "required": ["value", "quote"],
        "additionalProperties": False,
    }


PROJECT_SCHEMA: dict = {
    "type": "object",
    "properties": {
        "project_name": {"type": "string"},
        "aka": {"type": "array", "items": {"type": "string"}},
        "developer": _valued("string"),
        "operator": _valued("string"),
        "tenant": _valued("string"),
        "end_user": _valued("string"),
        "status": _valued("string", enum=STATUS_ENUM),
        "capacity_mw": _valued("number"),
        "capacity_mwh": _valued("number"),
        "building_sqft": _valued("number"),
        "land_acres": _valued("number"),
        "cap_ex_usd": _valued("number"),
        "operating_year": _valued("integer"),
        "btm_generation": _valued("boolean"),
        "announced_date": _valued("string"),
        "power_sources": {"type": "array", "items": {"type": "string"}},
        "location": {
            "type": "object",
            "properties": {
                "county": {"type": ["string", "null"]},
                "state": {"type": ["string", "null"]},
                "country": {"type": ["string", "null"]},
                "address": {"type": ["string", "null"]},
                "quote": {"type": ["string", "null"]},
            },
            "required": ["county", "state", "country", "address", "quote"],
            "additionalProperties": False,
        },
    },
    "required": [
        "project_name", "aka", "developer", "operator", "tenant", "end_user",
        "status", "capacity_mw", "capacity_mwh", "building_sqft", "land_acres",
        "cap_ex_usd", "operating_year", "btm_generation", "announced_date",
        "power_sources", "location",
    ],
    "additionalProperties": False,
}

EXTRACTION_SCHEMA: dict = {
    "type": "object",
    "properties": {"projects": {"type": "array", "items": PROJECT_SCHEMA}},
    "required": ["projects"],
    "additionalProperties": False,
}


EXTRACTION_SYSTEM_PROMPT = (
    "You extract US data-center project facts from the article the user provides. "
    "Return JSON matching the schema. Rules:\n"
    "1. Extract ONLY facts explicitly stated in the text. Never infer, estimate, or "
    "use outside knowledge.\n"
    "2. For every non-null field include a short verbatim `quote` copied from the "
    "article that supports the value. If you cannot quote it, set the field to null.\n"
    "3. If a field is not stated, return null for its value and quote — null is the "
    "expected, correct answer for unstated fields.\n"
    "4. If the article covers multiple distinct projects, return one object per "
    "project in `projects`. A multi-building 'campus' is ONE project.\n"
    "5. Normalize units in the value (but keep the original wording in the quote): "
    "gigawatts→MW (1.2 GW → 1200), '$11.6 billion'→11600000000, parse sqft and acres "
    "as plain numbers.\n"
    "6. Map status to one of: " + ", ".join(STATUS_ENUM) + " (proposed=plans/announced, "
    "under_construction=broke ground/building, operating=online/operational, "
    "cancelled=scrapped/withdrawn). If unclear, null.\n"
    "7. Only US projects. If the article is about a non-US project, return an empty "
    "projects array.\n"
    "8. The four ROLE fields are distinct parties and are the point of the record — read "
    "for them deliberately, and keep them apart:\n"
    "   · `developer` — who is building/financing the site (often a colo or REIT).\n"
    "   · `operator` — who runs the facility day to day.\n"
    "   · `tenant` — who LEASES the space or has contracted the capacity ('signed a lease "
    "with', 'leased to', 'anchor tenant', 'take-up by', 'pre-leased to').\n"
    "   · `end_user` — whose WORKLOAD ultimately runs there ('to power X's models', 'for "
    "X's AI training'). Often differs from the tenant: a neocloud may lease the hall while "
    "an AI lab is the end user.\n"
    "   One company may hold several roles — a hyperscaler self-build is developer, operator, "
    "tenant and end_user at once. Fill each role you can quote; leave the rest null.\n"
    "Do not invent capacities, dates, tenants, or locations. Rule 8 says where to LOOK for a "
    "tenant, never to guess one: an unstated tenant is still null."
)

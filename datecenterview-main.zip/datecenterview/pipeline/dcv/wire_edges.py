"""Wire value-chain edges from each facility's known counterparty.

One pass materializes the graph the Chain view reads, both sides of it.

Supply side — relation chosen by row type (the two are semantically different and
must not be conflated):
  * directory rows (dce-pdb-*) -> `operates` edge (facility -> operator). PeeringDB's
    `developer_name` is unambiguously the *operator*.
  * news rows (everything else) -> `develops` edge (facility -> developer). Phase-B's
    `developer_name` is the *developer/owner* stated in the sourcing article.

Demand side:
  * `serves` edge (facility -> end-user) from `end_user_name` (Phase-B extraction) for
    every row that has a named end-user.
  * `leases_to` edge (facility -> tenant) ONLY where a space-lease is implied: a colo
    developer (wholesale/retail) with a named customer distinct from itself. There is
    no separately-extracted tenant field, so self-builds (owner-occupied) and neocloud
    compute-contracts get no tenant edge rather than a fabricated one.
  * self-operate / self-consume: an operator-type developer (hyperscaler / neocloud /
    colo) runs the build it develops -> `operates` edge to itself; a hyperscaler also
    consumes it -> `serves` edge to itself (renders as the self-build summary). Land /
    real-estate `developer` and `enterprise` are excluded — they don't operate — so
    their demand side stays empty and the UI collapses it.

Power side — `powers` edge (facility -> power provider):
  * when the developer is a generation/energy company (POWER_PROVIDERS) it powers the
    co-located build it develops — UNLESS `power_sources` is purely grid, in which case
    the utility powers it and no developer->powers edge is made.

Curated seed chains are never touched: a facility that already has a `develops` /
`serves` / `leases_to` / `powers` edge is left exactly as seeded. Existing entities are
reused, never overwritten.

It also reconciles `developer_category` for every row (the ONLY data_center column
it writes; capacity + sources are left intact) so the provider-type filter and the
market-flow Sankey track the value chain: an operator/developer that canonicalizes to
a real category wins; an unmapped *directory* operator falls back to the structural
colo default (PeeringDB = colocation registry). Unmapped *news* developers are left
null (the UI shows them as "Other") rather than mislabeled. Idempotent. See
phase-b-spec / loop-engineering-value-chain-proposal.
"""
from __future__ import annotations

from sqlalchemy import select

from .db import session_scope
from .models import DataCenter, Edge, Entity
from .phaseb.normalize_dc import (
    DIRECTORY_DEFAULT_CATEGORY,
    _slug,
    canonical_developer,
)

OPERATES_CONFIDENCE = 0.8    # the operator relation comes straight from the registry
DEVELOPS_CONFIDENCE = 0.75   # the developer relation comes from the (verified) news source
SERVES_CONFIDENCE = 0.7      # the end-user is extracted from the sourcing article
LEASES_CONFIDENCE = 0.6      # tenant is *inferred*: a colo facility w/ a named customer is leased to it
POWERS_CONFIDENCE = 0.6      # powers is *inferred*: a generation company powers its own co-located build
SELF_OP_CONFIDENCE = 0.65    # operator-type developer runs the build it develops (self-operate)
SELF_USE_CONFIDENCE = 0.65   # a hyperscaler self-build consumes its own facility
COLO_CATS = {"wholesale_colo", "retail_colo"}   # a colo build with a distinct customer implies a lease
# operator-type developers run the facility they develop (they aren't land/real-estate
# developers, who sell pads and don't operate). Hyperscalers additionally consume it.
OPERATOR_SELF_CATS = {"hyperscaler", "neocloud", "wholesale_colo", "retail_colo"}

# entity ids whose business is generation/power — a co-located build they develop is
# powered by them (their model IS the on-site generation). Utilities included for seed.
POWER_PROVIDERS = {"intersect-power", "powerbridge", "new-era-energy", "eneus-energy",
                   "lancium", "crusoe", "iren", "sbenergy", "talen", "entergy"}
# purely-grid power_sources => the *utility* powers it, not the developer (drop the inference)
GRID_ONLY = {"grid", "utility grid", "utility", "grid power", "purchased power"}


def _is_directory(row: DataCenter) -> bool:
    return (row.id or "").startswith("dce-pdb-")


def _resolve(operator: str, *, directory: bool) -> tuple[str, str, str | None]:
    """(entity_id, canonical_name, category). `category` is the mapped category, or
    the structural colo default for a directory operator, or None (unmapped news)."""
    canon, eid, cat = canonical_developer(operator)
    canon = canon or operator
    if not cat and directory:
        cat = DIRECTORY_DEFAULT_CATEGORY      # PeeringDB row IS a colo — source-backed
    eid = eid or ("op-" + _slug(canon)[:40])
    return eid, canon, cat


def wire_edges() -> dict:
    with session_scope() as s:
        all_rows = list(s.execute(select(DataCenter)).scalars())
        known_ents = {e.id for e in s.execute(select(Entity)).scalars()}
        existing_edges = list(s.execute(select(Edge)).scalars())
        known_edges = {e.id for e in existing_edges}
        has_develops = {e.from_id for e in existing_edges if e.relation == "develops"}
        has_operates = {e.from_id for e in existing_edges if e.relation == "operates"}
        has_serves = {e.from_id for e in existing_edges if e.relation == "serves"}
        has_leases = {e.from_id for e in existing_edges if e.relation == "leases_to"}
        has_powers = {e.from_id for e in existing_edges if e.relation == "powers"}

        # 1) reconcile developer_category across ALL rows (structural default for
        #    directory operators; a definite category overwrites a stale/missing one).
        recat = 0
        for r in all_rows:
            if not r.developer_name:
                continue
            _eid, _name, cat = _resolve(r.developer_name, directory=_is_directory(r))
            if cat and r.developer_category != cat:
                r.developer_category = cat
                recat += 1

        # 2) value-chain edges + counterparty entities.
        new_ent = new_op = new_dev = new_srv = new_lease = new_pow = 0

        def _ensure_entity(eid: str, name: str, cat: str | None, sources: list[str]) -> None:
            nonlocal new_ent
            if eid not in known_ents:                 # never overwrite a seed/curated entity
                s.merge(Entity(id=eid, name=name, category=(cat or "other"),
                               category_confidence=0.8, sources=sources or []))
                known_ents.add(eid)
                new_ent += 1

        def _ensure_edge(r: DataCenter, rel: str, eid: str, conf: float) -> bool:
            edge_id = f"e-{r.id}-{rel}-{eid}"
            if edge_id in known_edges:
                return False
            s.merge(Edge(id=edge_id, from_id=r.id, to_id=eid, relation=rel,
                         confidence=conf, sources=r.sources or [], status="active"))
            known_edges.add(edge_id)
            return True

        # supply side — relation chosen by row type.
        for r in all_rows:
            if not r.developer_name:
                continue
            is_dir = _is_directory(r)
            eid, name, cat = _resolve(r.developer_name, directory=is_dir)
            if is_dir:
                _ensure_entity(eid, name, cat, ["https://www.peeringdb.com"])
                new_op += _ensure_edge(r, "operates", eid, OPERATES_CONFIDENCE)
            else:
                if r.id in has_develops:              # keep curated seed chains untouched
                    continue
                _ensure_entity(eid, name, cat, r.sources or [])
                new_dev += _ensure_edge(r, "develops", eid, DEVELOPS_CONFIDENCE)

        # demand side — end-user from `end_user_name`; tenant only where a colo lease is implied.
        for r in all_rows:
            if not r.end_user_name:
                continue
            eu_eid, eu_name, eu_cat = _resolve(r.end_user_name, directory=False)
            _ensure_entity(eu_eid, eu_name, eu_cat, r.sources or [])
            if r.id not in has_serves:
                new_srv += _ensure_edge(r, "serves", eu_eid, SERVES_CONFIDENCE)
            if (r.developer_category in COLO_CATS and r.developer_name and r.id not in has_leases):
                dev_eid, _, _ = _resolve(r.developer_name, directory=False)
                if dev_eid != eu_eid:                 # a colo facility IS leased to its named customer
                    new_lease += _ensure_edge(r, "leases_to", eu_eid, LEASES_CONFIDENCE)

        # self-operate / self-consume — an operator-type developer (hyperscaler / neocloud /
        # colo) runs the build it develops; a hyperscaler self-build also consumes it. This
        # fills the demand side for the vertically-integrated case. Directory rows already
        # carry `operates`; land/real-estate `developer` + `enterprise` are excluded (they
        # don't operate) and their demand side is left empty (the UI collapses it).
        for r in all_rows:
            if not r.developer_name or _is_directory(r):
                continue
            if r.developer_category not in OPERATOR_SELF_CATS:
                continue
            eid, name, cat = _resolve(r.developer_name, directory=False)
            _ensure_entity(eid, name, cat, r.sources or [])
            if r.id not in has_operates:
                new_op += _ensure_edge(r, "operates", eid, SELF_OP_CONFIDENCE)
            if r.developer_category == "hyperscaler" and r.id not in has_serves:
                new_srv += _ensure_edge(r, "serves", eid, SELF_USE_CONFIDENCE)

        # power side — a generation company powers the co-located build it develops,
        # unless the facility is purely grid-powered (then the utility powers it).
        for r in all_rows:
            if not r.developer_name or r.id in has_powers:
                continue
            eid, name, cat = _resolve(r.developer_name, directory=_is_directory(r))
            if eid not in POWER_PROVIDERS:
                continue
            ps = [str(p).lower() for p in (r.power_sources or [])]
            if ps and all(p in GRID_ONLY for p in ps):    # grid-only => utility powers it, not the dev
                continue
            _ensure_entity(eid, name, cat, r.sources or [])
            new_pow += _ensure_edge(r, "powers", eid, POWERS_CONFIDENCE)

    print(f"✓ wire-edges: +{new_ent} entities · +{new_dev} develops +{new_pow} powers "
          f"+{new_op} operates +{new_srv} serves +{new_lease} leases_to · "
          f"{recat} categories reconciled (from {len(all_rows)} rows)")
    return {"entities_added": new_ent, "operates_added": new_op, "develops_added": new_dev,
            "powers_added": new_pow, "serves_added": new_srv, "leases_to_added": new_lease,
            "recategorized": recat, "rows": len(all_rows)}

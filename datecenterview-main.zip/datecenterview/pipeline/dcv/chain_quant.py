"""chain_quant — cross-vendor edge quantification (P3, L9 + L2 maker-checker).

Closes the loop line P3 left DEFERRED. The disclosed magnitude + inferred counterparty
that seed/chain_edges.json carries as a SINGLE-ANALYST fixture are here re-derived by a
DIFFERENT-VENDOR maker-checker: Grok (xAI) extracts the customer-concentration from the
filing and infers the chain counterparty; Claude (Anthropic) — a different vendor —
independently confirms the % is in the filing text and assesses the inference (web-search
allowed). Same-vendor agreement is meaningless; cross-vendor agreement is what makes the
disclosed/inferred flags trustworthy (project principle).

L9+L2 5-line contract:
  1. Setpoint  — each target edge has a magnitude + counterparty confirmed by a 2nd vendor.
  2. Measured  — extractor↔verifier agreement rate; % of targets verified (run() stats).
  3. Error     — verifier can't confirm the % in the filing, or refutes the inferred link.
  4. Correction— disclosed accepted only if the verifier confirms it in the text; link_basis
                 stays inferred with confidence = agreement; refute → drop; low-conf → HITL
                 (review_status="needs_review").
  5. Mechanisms— maker-checker + requisite variety (Grok≠Claude) · disclosed>estimated ·
                 active-learning order (highest-market-cap suppliers first, caller-supplied) ·
                 spend governor (both clients route through clients.spend.LEDGER, L5).

Conformance:
  Setpoint→quantify() gate · Measured→run() agreement stats · Error→verdict.pct_confirmed/
  link_verdict · Correction→drop/needs_review below · Mechanisms→two-vendor call + spend
  ledger. Guardrail asserted at import: settings.extract_model ≠ settings.verify_model.

Output: verified edges → seed/chain_edges_verified.json, which emit merges OVER the manual
seed/chain_edges.json (verified wins). The manual fixture stays the reliable baseline; a
successful automation run supersedes it per (from,to). Run: `dcv chain-quant`.
"""
from __future__ import annotations

import json
from pathlib import Path

from .clients import claude, edgar, grok
from .config import settings

VERIFIED_FIXTURE = Path(__file__).resolve().parent.parent / "seed" / "chain_edges_verified.json"

# requisite variety: the checker MUST be a different vendor than the maker (loop-design)
assert settings.extract_model.split("-")[0] != settings.verify_model.split("-")[0], (
    "chain_quant requires a cross-vendor pair (extract≠verify); same-vendor agreement is "
    f"meaningless — got extract={settings.extract_model}, verify={settings.verify_model}")

EXTRACT_SCHEMA = {
    "type": "object",
    "properties": {
        "customers": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "pct": {"type": "number"},
                "rank": {"type": "string"},
                "verbatim": {"type": "string"},
                "inferred_customer_id": {"type": "string"},
                "inference_reason": {"type": "string"},
            },
            "required": ["pct", "verbatim", "inferred_customer_id", "inference_reason"],
        }},
    },
    "required": ["customers"],
}

_EXTRACT_SYS = (
    "You extract DISCLOSED customer-concentration facts from an SEC filing excerpt. For each "
    "distinct customer stated as a percentage of the filer's revenue, return ONE entry: the pct "
    "for the MOST RECENT fiscal year only (the largest year shown — ignore prior-year "
    "comparatives) and the VERBATIM sentence/row. Filings usually leave the customer unnamed "
    "('Customer A', 'one customer', 'largest customer') — infer which of the CANDIDATE chain "
    "companies it is from segment/industry/magnitude, and return its id from the candidate list "
    "(or 'unknown'). Do NOT emit one customer multiple times for different years. Report ONLY "
    "figures actually present in the excerpt; never invent a number or a name.")

_VERIFY_SYS = (
    "You are a skeptical, independent verifier. A DIFFERENT model extracted the claim below "
    "from an SEC filing excerpt. Do NOT trust it. Independently: (1) pct_confirmed — is that "
    "exact percentage of the filer's revenue actually stated in the excerpt? (2) link_verdict "
    "(agree|refute|uncertain) — is the inferred customer correct? You MAY web-search known "
    "supplier→customer relationships. Give link_alternative if you'd name a different chain "
    "company. (3) confidence 0-1 overall. Reply ONLY with JSON: "
    '{"pct_confirmed":bool,"link_verdict":"agree|refute|uncertain","link_alternative":str,'
    '"confidence":number,"reason":str}.')


def _ticker_cik_map() -> dict[str, str]:
    import httpx
    m = httpx.get("https://www.sec.gov/files/company_tickers.json",
                  headers={"User-Agent": settings.edgar_user_agent}, timeout=40).json()
    return {v["ticker"]: str(v["cik_str"]).zfill(10) for v in m.values()}


def targets_from_seed(limit: int | None = None) -> tuple[list[dict], dict[str, str]]:
    """Build (suppliers, candidates) from the compute-chain backbone. Suppliers = chain
    entities with a US ticker, ordered by market cap DESC (active learning — verify the
    biggest first); candidates = every chain entity {id: name} (the inference target set)."""
    from .compute_seed import build_seed
    ents = build_seed()["chain"]["entities"]
    candidates = {e["id"]: e["name"] for e in ents}
    t2c = _ticker_cik_map()
    supp = []
    for e in sorted(ents, key=lambda e: e.get("market_cap", 0) or 0, reverse=True):
        tk = e.get("ticker")
        if tk and tk not in ("private", "—", "-") and tk in t2c:
            supp.append({"id": e["id"], "name": e["name"], "ticker": tk, "cik": t2c[tk]})
    return (supp[:limit] if limit else supp), candidates


def _src_url(cik: str, rpt: dict) -> str:
    return (f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/"
            f"{rpt['accession'].replace('-', '')}/{rpt['doc']}")


def quantify(supplier: dict, candidates: dict[str, str]) -> list[dict]:
    """Cross-vendor quantify one supplier's disclosed customer edges.
    supplier: {id, name, ticker, cik}; candidates: {entity_id: name}. Returns verified edges."""
    subs = edgar.submissions(supplier["cik"])
    rpt = edgar.latest_report(subs)
    if not rpt:
        return []
    excerpt = edgar.concentration_excerpt(edgar.filing_text(supplier["cik"], rpt["accession"], rpt["doc"]))
    if not excerpt:
        return []
    cand_str = "; ".join(f"{i}: {n}" for i, n in candidates.items())
    user = (f"Filer: {supplier['name']} ({supplier.get('ticker', '?')}). "
            f"Candidate chain customers — {cand_str}\n\nFiling excerpt:\n{excerpt}")
    content, _ = grok.chat(_EXTRACT_SYS, user, response_schema=EXTRACT_SCHEMA)

    edges = []
    for c in content.get("customers", []):
        cid = c.get("inferred_customer_id")
        if cid not in candidates or cid == supplier["id"]:
            continue  # only edges to a known chain entity (drops 'unknown'/Apple/distributors)
        verdict = claude.verify_json(_VERIFY_SYS, (
            f"Filer: {supplier['name']}. Extracted claim: customer '{candidates[cid]}' = "
            f"{c['pct']}% of revenue. Basis: \"{c.get('verbatim', '')}\". Inference reason: "
            f"{c.get('inference_reason', '')}\n\nFiling excerpt:\n{excerpt}"))
        if not verdict.get("pct_confirmed"):
            continue  # the magnitude isn't in the filing → drop (never emit unconfirmed as disclosed)
        if verdict.get("link_verdict") == "refute":
            continue  # cross-vendor refutes the counterparty → drop
        agree = verdict.get("link_verdict") == "agree"
        edges.append({
            "from": supplier["id"], "to": cid, "pct_revenue": c["pct"],
            "rev_basis": "disclosed", "link_basis": "inferred",
            "link_confidence": round(float(verdict.get("confidence", 0.5)), 2),
            "as_of": rpt["filed"], "sources": [_src_url(supplier["cik"], rpt)],
            "review_status": "confirmed" if agree else "needs_review",
            "verify": {"extractor": settings.extract_model, "verifier": settings.verify_model,
                       "link_verdict": verdict.get("link_verdict"),
                       "reason": (verdict.get("reason") or "")[:240]},
            "note": f"{supplier['name']} filing customer-concentration; "
                    f"cross-vendor {verdict.get('link_verdict')} (conf {verdict.get('confidence')})",
        })
    return edges


def _modal(vals: list):
    from collections import Counter
    return Counter(vals).most_common(1)[0][0]


def quantify_voted(supplier: dict, candidates: dict[str, str],
                   rounds: int = 3, min_votes: int = 2) -> list[dict]:
    """Full voting: beats non-determinism in BOTH steps. (1) EXTRACTION voted — run Grok
    `rounds` times (sampling temperature), keep a customer only if proposed in ≥ `min_votes`
    rounds; pct = the modal value (drops prior-year comparatives). (2) VERIFY voted — the
    verdict oscillates for unnamed-customer inferences, so run Claude `rounds` times on the
    consensus candidate and MAJORITY-vote: majority must confirm the %; a majority to refute
    drops it; a strict majority to AGREE → `confirmed`, else `needs_review`. This is the
    "run N times, union confirmed verdicts" the ask names. link_confidence = agree-share ×
    avg stated confidence. Filing is fetched once and reused across all rounds."""
    subs = edgar.submissions(supplier["cik"])
    rpt = edgar.latest_report(subs)
    if not rpt:
        return []
    excerpt = edgar.concentration_excerpt(edgar.filing_text(supplier["cik"], rpt["accession"], rpt["doc"]))
    if not excerpt:
        return []
    cand_str = "; ".join(f"{i}: {n}" for i, n in candidates.items())
    user = (f"Filer: {supplier['name']} ({supplier.get('ticker', '?')}). "
            f"Candidate chain customers — {cand_str}\n\nFiling excerpt:\n{excerpt}")

    proposals: dict[str, list] = {}  # cid -> [(pct, verbatim), ...] across rounds
    for _ in range(rounds):
        try:
            content, _ = grok.chat(_EXTRACT_SYS, user, response_schema=EXTRACT_SCHEMA, temperature=0.4)
        except Exception:
            continue  # a flaky extraction round shouldn't sink the vote
        for c in content.get("customers", []):
            cid = c.get("inferred_customer_id")
            if cid in candidates and cid != supplier["id"]:
                proposals.setdefault(cid, []).append((c["pct"], c.get("verbatim", "")))

    edges = []
    for cid, plist in proposals.items():
        votes = len(plist)
        if votes < min_votes:  # extraction-consensus gate — a one-off proposal isn't enough
            continue
        pct = _modal([p for p, _ in plist])
        verbatim = next((v for p, v in plist if p == pct), plist[0][1])
        vuser = (f"Filer: {supplier['name']}. Extracted claim (consensus of {votes}/{rounds} "
                 f"rounds): customer '{candidates[cid]}' = {pct}% of revenue. Basis: "
                 f"\"{verbatim}\".\n\nFiling excerpt:\n{excerpt}")
        # VERIFY VOTING: the verdict oscillates for unnamed-customer inferences, so run the
        # verifier `rounds` times and majority-vote (the "union confirmed verdicts" the ask
        # names). A confident answer requires a majority to AGREE; a majority to refute drops.
        verdicts = []
        for _ in range(rounds):
            try:
                verdicts.append(claude.verify_json(_VERIFY_SYS, vuser))
            except Exception:
                continue
        if not verdicts:
            continue
        n = len(verdicts)
        if sum(bool(v.get("pct_confirmed")) for v in verdicts) * 2 < n:  # majority must confirm the %
            continue
        vl = [v.get("link_verdict") for v in verdicts]
        agree_n, refute_n = vl.count("agree"), vl.count("refute")
        if refute_n > agree_n:  # majority-ish refute → drop the counterparty
            continue
        confirmed = agree_n * 2 > n  # strict majority AGREE → confirmed link
        avg_conf = sum(float(v.get("confidence", 0.5)) for v in verdicts) / n
        conf = round((agree_n / n) * avg_conf, 2)
        reason = next((v.get("reason") for v in verdicts if v.get("reason")), "")
        edges.append({
            "from": supplier["id"], "to": cid, "pct_revenue": pct,
            "rev_basis": "disclosed", "link_basis": "inferred", "link_confidence": conf,
            "as_of": rpt["filed"], "sources": [_src_url(supplier["cik"], rpt)],
            "review_status": "confirmed" if confirmed else "needs_review",
            "verify": {"extractor": settings.extract_model, "verifier": settings.verify_model,
                       "extraction_votes": f"{votes}/{rounds}", "verify_votes": f"agree {agree_n}/{n}",
                       "reason": (reason or "")[:240]},
            "note": f"{supplier['name']} customer-concentration; extraction {votes}/{rounds}, "
                    f"verify agree {agree_n}/{n} (conf {conf})",
        })
    return edges


# --------------------------------------------------------------------------- targeted mode
# Band-1 #3b: once chain_topology has NAMED a supplier→buyer relationship from the buyer's own
# filing, quantification no longer has to GUESS the counterparty — it can ask the supplier's
# filing a closed question ("what share of your revenue is this named buyer?"). That removes
# the inference step that made most of the open-ended run land in needs_review, and it narrows
# the verifier's job to one thing: is that % actually in the text, attributed to that buyer?
#
# The identity≠attribution split still holds. A filing that says "Customer A — 21%" without
# naming Customer A gives a DISCLOSED magnitude whose attribution is still inferred, so the
# edge stays needs_review. Only a filing that names the buyer next to the number is confirmed.

_TARGETED_SCHEMA = {
    "type": "object",
    "properties": {
        "pct": {"type": ["number", "null"]},
        "named_in_text": {"type": "boolean"},
        "verbatim": {"type": "string"},
        "reason": {"type": "string"},
    },
    "required": ["pct", "named_in_text", "verbatim", "reason"],
}

_TARGETED_EXTRACT_SYS = (
    "You are given a SEC filer's customer-concentration excerpt and the name of ONE specific "
    "customer. Report the percentage of the FILER's revenue attributable to that customer for "
    "the MOST RECENT fiscal year (ignore prior-year comparatives). Filings often withhold the "
    "name ('Customer A', 'one customer'): if the excerpt discloses a percentage you believe is "
    "that customer, return it with named_in_text=false and explain in `reason`. Set "
    "named_in_text=true ONLY if the excerpt literally names the customer beside the figure. "
    "If the excerpt discloses no percentage attributable to this customer, return pct=null. "
    "Never invent or estimate a number — pct must appear verbatim in the excerpt.")

_TARGETED_VERIFY_SYS = (
    "You are a skeptical, independent verifier. A DIFFERENT model read a filer's "
    "customer-concentration excerpt and claims a percentage belongs to a named customer. Do NOT "
    "trust it. Answer: (1) pct_confirmed — does that exact percentage of the filer's revenue "
    "appear in the excerpt? (2) attributed (agree|refute|uncertain) — does the excerpt actually "
    "attribute it to THAT customer (naming it, or unambiguously identifying it)? Be conservative: "
    "an unnamed 'Customer A' is uncertain, not agree, unless the excerpt makes it unambiguous. "
    "(3) confidence 0-1. Reply ONLY with JSON: "
    '{"pct_confirmed":bool,"attributed":"agree|refute|uncertain","confidence":number,"reason":str}.')


def quantify_named(supplier: dict, buyer_id: str, buyer_name: str,
                   rounds: int = 3, min_votes: int = 2, diag: dict | None = None) -> dict | None:
    """Quantify ONE already-named supplier→buyer edge from the supplier's own filing.

    Returns a magnitude edge, or None when no per-customer share for this buyer could be
    established. Never estimates: a topology edge without a disclosed figure keeps no magnitude
    at all (a fabricated number would render as a real flow in the sankey).

    `diag` (if given) is filled with why a miss happened, and with the head of the excerpt the
    models actually read. A miss is a claim about a filing — it must be auditable, because
    "the section says nothing" and "we anchored on the wrong section" look identical from the
    outside, and only the first is a fact about the company (Amkor's 10-K anchors on its
    end-market table, so its miss is a MEASUREMENT gap, not a disclosure fact).
    """
    def _miss(reason: str, **extra):
        if diag is not None:
            diag.update({"reason": reason, **extra})
        return None

    rpt = edgar.latest_report(edgar.submissions(supplier["cik"]))
    if not rpt:
        return _miss("no annual report found")
    excerpt = edgar.concentration_excerpt(
        edgar.filing_text(supplier["cik"], rpt["accession"], rpt["doc"]))
    if diag is not None:
        diag.update({"form": rpt["form"], "filed": rpt["filed"],
                     "excerpt_chars": len(excerpt), "excerpt_head": excerpt[:220]})
    if not excerpt:
        return _miss("no customer-concentration section matched — we did NOT read a "
                     "concentration disclosure, so this is a measurement gap, not a fact "
                     "about what the company discloses")

    user = (f"Filer: {supplier['name']} ({supplier.get('ticker', '?')}). "
            f"Customer of interest: {buyer_name}.\n\nFiling excerpt:\n{excerpt}")
    props = []
    for _ in range(rounds):
        try:
            got, _ = grok.chat(_TARGETED_EXTRACT_SYS, user,
                               response_schema=_TARGETED_SCHEMA, temperature=0.4)
        except Exception:
            continue
        if got.get("pct") is not None:
            props.append(got)
    if len(props) < min_votes:
        return _miss("the concentration section discloses no per-customer share attributable "
                     "to this buyer (extraction consensus below threshold)")

    pct = _modal([p["pct"] for p in props])
    best = next(p for p in props if p["pct"] == pct)

    vuser = (f"Filer: {supplier['name']}. Claim: customer '{buyer_name}' = {pct}% of the filer's "
             f"revenue. Basis: \"{best.get('verbatim', '')}\".\n\nFiling excerpt:\n{excerpt}")
    verdicts = []
    for _ in range(rounds):
        try:
            # CLOSED-BOOK on purpose. Both of `_TARGETED_VERIFY_SYS`'s questions are bound to
            # the excerpt — does the % appear in it, and does IT attribute the % to that
            # customer. The counterparty is already NAMED here (that is what makes this the
            # "targeted" path), so there is no identity question left to search for; the only
            # question is whether the filing discloses the magnitude. A web-confirmed % would
            # be an estimate wearing a `disclosed` label, which is the one thing this module
            # refuses to emit. Contrast `_VERIFY_SYS` above, which DOES grant search because
            # it must infer an unnamed counterparty.
            verdicts.append(claude.verify_json(_TARGETED_VERIFY_SYS, vuser,
                                               allow_web_search=False))
        except Exception:
            continue
    if not verdicts:
        return _miss("verifier unavailable")
    n = len(verdicts)
    if sum(bool(v.get("pct_confirmed")) for v in verdicts) * 2 <= n:
        # the number isn't in the filing → never publish it as disclosed
        return _miss(f"cross-vendor verifier could not confirm {pct}% in the filing text")
    att = [v.get("attributed") for v in verdicts]
    if att.count("refute") > att.count("agree"):
        return _miss(f"cross-vendor verifier refutes attributing {pct}% to {buyer_name}")
    agree_n = att.count("agree")
    avg_conf = sum(float(v.get("confidence", 0.5)) for v in verdicts) / n
    confirmed = agree_n * 2 > n
    return {
        "from": supplier["id"], "to": buyer_id, "pct_revenue": pct,
        "rev_basis": "disclosed",
        # the LINK was already named by the buyer's own filing (chain_topology); this stage only
        # adds the magnitude, so the link half stays what the topology evidence established.
        "link_basis": "named",
        "link_confidence": round((agree_n / n) * avg_conf, 2),
        "as_of": rpt["filed"], "sources": [_src_url(supplier["cik"], rpt)],
        "review_status": "confirmed" if confirmed else "needs_review",
        "verify": {"extractor": settings.extract_model, "verifier": settings.verify_model,
                   "extraction_votes": f"{len(props)}/{rounds}",
                   "attribution_votes": f"agree {agree_n}/{n}",
                   "named_in_text": bool(best.get("named_in_text")),
                   "reason": (next((v.get("reason") for v in verdicts if v.get("reason")), "") or "")[:240]},
        "note": f"{supplier['name']} discloses {pct}% of revenue to {buyer_name} "
                f"(targeted: relationship already named by {buyer_name}'s filing); "
                f"attribution agree {agree_n}/{n}",
    }


def _resolve_unnamed_conflicts(edges: list[dict]) -> tuple[list[dict], list[str]]:
    """Mutual exclusion for UNNAMED concentration figures.

    A filing that says "one customer represented 19% of revenue" states ONE fact about ONE
    customer. Quantifying edges buyer-by-buyer lets that single figure land on several edges —
    TSMC's 19% attached to BOTH nvidia and broadcom on the first run — which would double-count
    the same revenue as two separate flows in the sankey.

    So: group unnamed disclosures by (supplier, pct, as_of). If more than one buyer claims the
    same one, keep only the single best-attributed edge (highest link_confidence) and drop the
    rest; on a tie, drop them ALL, because a coin-flip between two counterparties is not
    evidence. Edges whose filing NAMES the buyer beside the figure are exempt — two named
    customers can legitimately sit at the same percentage.
    """
    groups: dict[tuple, list[dict]] = {}
    keep, dropped = [], []
    for e in edges:
        if (e.get("verify") or {}).get("named_in_text"):
            keep.append(e)
            continue
        groups.setdefault((e["from"], e.get("pct_revenue"), e.get("as_of")), []).append(e)
    for (frm, pct, _), grp in groups.items():
        if len(grp) == 1:
            keep.append(grp[0])
            continue
        grp.sort(key=lambda e: e.get("link_confidence") or 0, reverse=True)
        top = grp[0].get("link_confidence") or 0
        if (grp[1].get("link_confidence") or 0) == top:
            dropped += [f"{frm}→{e['to']} ({pct}%, unnamed, tied attribution)" for e in grp]
            continue
        keep.append(grp[0])
        dropped += [f"{frm}→{e['to']} ({pct}%, unnamed, lost to {grp[0]['to']})" for e in grp[1:]]
    return keep, dropped


def run_named(edges: list[dict], budget_usd: float = 3.0, rounds: int = 3) -> dict:
    """Quantify NAMED topology edges (chain_topology output) whose supplier is an SEC filer.

    `edges`: [{supplier: {id,name,ticker,cik}, buyer_id, buyer_name}]. Merges into the same
    seed/chain_edges_verified.json the open-ended run writes, keyed per (from,to).
    """
    import time

    from .clients import spend
    try:
        existing = {(e["from"], e["to"]): e
                    for e in json.loads(VERIFIED_FIXTURE.read_text()).get("edges", [])}
        meta = json.loads(VERIFIED_FIXTURE.read_text()).get("_meta", {})
    except FileNotFoundError:
        existing, meta = {}, {}

    got_n = missed = 0
    misses: dict[str, dict] = {}
    for t in edges:
        if spend.LEDGER.total_usd >= budget_usd:
            print(f"  [chain_quant/named] spend cap ${budget_usd} reached — stopping")
            break
        tag = f"{t['supplier']['id']}→{t['buyer_id']}"
        diag: dict = {}
        try:
            e = quantify_named(t["supplier"], t["buyer_id"], t["buyer_name"],
                               rounds=rounds, diag=diag)
        except Exception as ex:
            print(f"  [chain_quant/named] {tag}: {type(ex).__name__}: {ex}")
            continue
        if e is None:
            missed += 1
            misses[tag] = diag
            print(f"  [chain_quant/named] {tag}: unquantified — {diag.get('reason', '?')}; "
                  f"spend ${spend.LEDGER.total_usd:.2f}")
        else:
            existing[(e["from"], e["to"])] = e
            got_n += 1
            print(f"  [chain_quant/named] {tag}: {e['pct_revenue']}% ({e['review_status']}); "
                  f"spend ${spend.LEDGER.total_usd:.2f}")
        time.sleep(0.7)

    out, conflicts = _resolve_unnamed_conflicts(list(existing.values()))
    stats = {"targets": len(edges), "quantified": got_n, "unquantified": missed,
             "unnamed_conflicts_dropped": len(conflicts),
             "spend_usd": round(spend.LEDGER.total_usd, 3)}
    for c in conflicts:
        print(f"  [chain_quant/named] mutual-exclusion: dropped {c}")
    VERIFIED_FIXTURE.write_text(json.dumps({
        "_meta": {**meta,
                  "source": "chain_quant — open-ended customer-concentration sweep + TARGETED "
                            "quantification of chain_topology's named edges (cross-vendor)",
                  "extractor": settings.extract_model, "verifier": settings.verify_model,
                  "targeted_stats": stats,
                  "targeted_unquantified": misses,
                  # The disclosure is REAL even when we can't say whose it is. Keeping the
                  # dropped claims here preserves "TSMC discloses one customer at 19%" as a
                  # known-but-unattributed fact instead of silently deleting it.
                  "targeted_unattributed": conflicts,
                  "targeted_note": "A named topology edge with no establishable share keeps NO "
                                   "magnitude — estimating one would draw a fake flow in the "
                                   "sankey. Each miss records WHY plus the head of the excerpt "
                                   "actually read, because 'the filing discloses nothing' and "
                                   "'we anchored on the wrong section' are different claims and "
                                   "only the first is a fact about the company."},
        "edges": out}, indent=2) + "\n")
    print(f"✓ chain_quant/named — {got_n}/{len(edges)} targeted edges quantified "
          f"({missed} filing had no disclosed share); spend ${stats['spend_usd']}")
    return stats


def named_targets() -> list[dict]:
    """Topology edges (link_basis=named) whose SUPPLIER files with the SEC. Foreign-listed
    suppliers (Foxconn, Samsung, SK Hynix) have no EDGAR filing — they are REPORTED as
    structurally out of reach rather than silently skipped."""
    from .chain_topology import FIXTURE as TOPO_FIXTURE
    from .compute_seed import build_seed
    try:
        topo = json.loads(TOPO_FIXTURE.read_text()).get("edges", [])
    except FileNotFoundError:
        return []
    ents = {e["id"]: e for e in build_seed()["chain"]["entities"]}
    t2c = _ticker_cik_map()
    out, unreachable = [], []
    for e in topo:
        sup, buyer = ents.get(e["from"]), ents.get(e["to"])
        if not sup or not buyer:
            continue
        tk = sup.get("ticker")
        if not tk or tk not in t2c:
            unreachable.append(f"{e['from']}→{e['to']}")
            continue
        out.append({"supplier": {"id": sup["id"], "name": sup["name"], "ticker": tk,
                                 "cik": t2c[tk]},
                    "buyer_id": buyer["id"], "buyer_name": buyer["name"]})
    if unreachable:
        print(f"  [chain_quant/named] {len(unreachable)} named edge(s) have a non-SEC-filing "
              f"supplier — unreachable via EDGAR: {', '.join(unreachable)}")
    return out


def run(suppliers: list[dict], candidates: dict[str, str],
        budget_usd: float = 2.0, rounds: int = 3) -> dict:
    """Quantify suppliers (active-learning order = caller's order) under a spend cap, using
    `rounds`-way extraction voting per supplier. Writes seed/chain_edges_verified.json.
    Returns run stats (the L9 measured value)."""
    import time

    from .clients import spend
    all_edges, confirmed, review = [], 0, 0
    for s in suppliers:
        if spend.LEDGER.total_usd >= budget_usd:  # L5 spend governor
            print(f"  [chain_quant] spend cap ${budget_usd} reached — stopping")
            break
        try:
            got = quantify_voted(s, candidates, rounds=rounds)
            for e in got:
                all_edges.append(e)
                confirmed += e["review_status"] == "confirmed"
                review += e["review_status"] == "needs_review"
            print(f"  [chain_quant] {s['id']}: {len(got)} edge(s); spend ${spend.LEDGER.total_usd:.2f}")
        except Exception as ex:  # a bad filing/LLM call must not sink the batch
            print(f"  [chain_quant] {s.get('id')}: {type(ex).__name__}: {ex}")
        time.sleep(0.7)  # EDGAR politeness (≤10 req/s; each supplier is ~2 requests)

    # dedup per (from,to): a filing can still yield multiple rows — keep the best
    # (confirmed over needs_review, then highest link_confidence). Guards against
    # prior-year comparatives slipping through as duplicate edges.
    best: dict = {}
    for e in all_edges:
        k = (e["from"], e["to"])
        cur = best.get(k)
        rank = (e["review_status"] == "confirmed", e.get("link_confidence") or 0)
        if cur is None or rank > (cur["review_status"] == "confirmed", cur.get("link_confidence") or 0):
            best[k] = e
    all_edges = list(best.values())
    confirmed = sum(e["review_status"] == "confirmed" for e in all_edges)
    review = sum(e["review_status"] == "needs_review" for e in all_edges)
    total = confirmed + review
    stats = {"edges": total, "confirmed": confirmed, "needs_review": review,
             "agreement_rate": round(confirmed / total, 2) if total else None,
             "spend_usd": round(spend.LEDGER.total_usd, 3)}
    VERIFIED_FIXTURE.write_text(json.dumps(
        {"_meta": {"source": f"chain_quant cross-vendor, {rounds}-way extraction voting "
                             "(Grok extract ×N → consensus → Claude verify)",
                   "extractor": settings.extract_model, "verifier": settings.verify_model,
                   "rounds": rounds, "stats": stats}, "edges": all_edges}, indent=2) + "\n")
    print(f"✓ chain_quant — {total} edges ({confirmed} confirmed, {review} needs-review); "
          f"agreement {stats['agreement_rate']}; spend ${stats['spend_usd']}")
    return stats

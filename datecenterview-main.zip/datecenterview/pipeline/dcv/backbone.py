"""backbone — promote the curated compute-chain backbone into the store (P2.1).

The real graph is downstream-only (colos / operators / clouds); the upstream
chain (foundry → HBM/packaging → accelerator → systems → power) and a couple of
private labs live only in the illustrative seed (compute_seed.py). P2.1 promotes
the seed's ~29 chain companies into `entity` as first-class rows so the financial
spine (P2.2, L9) and the supply-sankey / SPLC render on real system-of-record
nodes rather than seed constants.

Resolution (merge, never duplicate): a seed entity that already exists in the
store is ENRICHED (layer + ticker set; the pipeline's own name/category left
alone); one that doesn't is INSERTED. Two seed ids differ from the store's ids
and are mapped explicitly (`CANONICAL`).

Loop (L9 setup): this step makes the nodes real; it writes NO financials — P2.2
attaches the freshness-controlled market_cap/revenue. Idempotent: re-running only
re-sets layer/ticker and inserts anything still missing.

L2-backbone 5-line contract (Band 2 #1 — the ACTUATOR for the sensor Band-1 #2 built).
`chain_topology` already measures the error: every filing-named supplier it cannot map to a
backbone id is logged in `unresolved_supplier_names`. That log was read by a human and never
acted on, which made it an open loop — a sensor with no actuator. This closes it:
  1. Setpoint  — every company a swept filing NAMES as a chain participant resolves to a
                 backbone entity (`unresolved_supplier_names` → empty), and every backbone
                 entity's annual-report reach is KNOWN rather than assumed.
  2. Measured  — `len(unresolved_supplier_names)` from the chain_topology run + the
                 `backbone_reach` status counts emitted to `meta.rollups`.
  3. Error     — a named supplier with no backbone id; or an entity whose reach is unknown.
  4. Correction— promote the unresolved name into the backbone (id + layer + category +
                 aliases), then re-sweep so the next run resolves it; classify its reach.
  5. Mechanisms— evidence-gated promotion (only names a filing produced — never a prior) ·
                 requisite variety inherited from the cross-vendor sweep that named it ·
                 freshness guard on the reach classifier (a deregistered filer is `stale`,
                 not `current`) · idempotent upsert.

Guardrail — promotion is EVIDENCE-GATED, and that cuts both ways. Applied Materials and KLA
are conspicuously absent from the equipment tier because no swept filing named them; adding
them from general knowledge would make the backbone a curated list again, and would hide the
extraction gap that their absence is evidence of. If they are real participants the next
sweep names them and they arrive as unresolved. Letting the loop find them is the test.
"""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

from .compute_seed import build_seed
from .db import session_scope
from .models import Entity

REACH_FIXTURE = Path(__file__).resolve().parent.parent / "seed" / "backbone_reach.json"

# seed id → existing store id, where they differ (all others resolve to themselves)
CANONICAL = {"amazon": "aws", "digitalrealty": "digital-realty"}

# seed chain category → store provider_category enum, for NET-NEW inserts only.
# Existing entities keep the category the pipeline already assigned. Upstream
# suppliers aren't "providers" — their chain position is carried by `layer`.
_CHAIN_CAT_TO_PROVIDER = {
    "equipment": "other",
    "foundry": "other", "hbm": "other", "packaging": "other",
    "accelerator": "other", "systems": "other", "power": "other",
    "colo": "wholesale_colo", "hyperscaler": "hyperscaler",
    "neocloud": "neocloud", "ai_lab": "ai_lab",
}


def _ticker(seed_ent: dict) -> str | None:
    t = seed_ent.get("ticker")
    return t if t and t not in ("private", "—", "-") else None


def promote_backbone(session) -> dict:
    """Upsert the seed chain entities into `entity`. Returns {enriched, inserted}."""
    ents = build_seed()["chain"]["entities"]
    src = [{"type": "seed", "ref": "compute_seed.backbone",
            "as_of": date.today().isoformat()}]
    enriched, inserted = [], []
    for se in ents:
        store_id = CANONICAL.get(se["id"], se["id"])
        e = session.get(Entity, store_id)
        tick = _ticker(se)
        if e:  # merge/enrich — do NOT overwrite the pipeline's name/category
            e.layer = se.get("layer")
            if tick:
                ids = dict(e.identifiers or {})
                ids.setdefault("ticker", tick)
                e.identifiers = ids
            enriched.append(store_id)
        else:  # net-new (upstream suppliers + private labs)
            ids = {"ticker": tick} if tick else {}
            session.add(Entity(
                id=store_id, name=se["name"],
                category=_CHAIN_CAT_TO_PROVIDER.get(se.get("category"), "other"),
                layer=se.get("layer"), identifiers=ids, sources=src,
            ))
            inserted.append(store_id)
    return {"enriched": enriched, "inserted": inserted}


REACH_REASONS = {
    "private": "private company — never files",
    "no_us_listing": "no US registration — files with a non-US regulator only",
    "stale": "registered once, then deregistered — newest annual report is past the horizon",
    "no_annual_report": "in EDGAR, but no 10-K/20-F on file",
}


def classify_reach(today=None) -> dict:
    """MEASURE which backbone entities EDGAR can reach an annual report for (Band 2 #1).

    `evidence-extraction` rule 4: the source that can FIND a relationship may be structurally
    unable to SIZE it, and that gap must be emitted as a measured value — a named, counted
    set — never left as an assumption or smoothed into a low-confidence estimate that makes
    the column look full. Adding the equipment tier made this acute: of the 8 filing-named
    equipment suppliers, most are Taiwanese or Japanese and file nothing with the SEC, so
    they can be NAMED as chain participants forever and never carry a disclosed figure.

    Returns {status: [entity ids]} plus per-entity detail. Statuses: `current` (usable) and
    the four out-of-reach reasons in REACH_REASONS. Hits the network (~1 call per ticker).
    """
    import time

    from .chain_quant import _ticker_cik_map
    from .clients import edgar
    from .compute_seed import build_seed

    t2c = _ticker_cik_map()
    detail: dict[str, dict] = {}
    for se in build_seed()["chain"]["entities"]:
        eid, tk = CANONICAL.get(se["id"], se["id"]), se.get("ticker")
        row = {"name": se["name"], "layer": se.get("layer"), "ticker": tk}
        if tk == "private":
            row |= {"status": "private", "detail": None}
        elif not tk or tk in ("—", "-") or tk not in t2c:
            row |= {"status": "no_us_listing", "detail": None}
        else:
            try:
                reach = edgar.annual_report_reach(edgar.submissions(t2c[tk]), today=today)
            except Exception as ex:  # a flaky filer must not sink the report
                row |= {"status": "no_annual_report", "detail": f"{type(ex).__name__}: {ex}"}
            else:
                row |= {"status": {"current": "current", "stale": "stale",
                                   "none": "no_annual_report"}[reach["status"]],
                        "detail": reach["reason"], "age_days": reach["age_days"],
                        "form": (reach["report"] or {}).get("form")}
            time.sleep(0.4)  # EDGAR politeness
        detail[eid] = row

    by_status: dict[str, list[str]] = {}
    for eid, row in detail.items():
        by_status.setdefault(row["status"], []).append(eid)
    return {
        "_meta": {
            "source": "SEC EDGAR submissions index — annual-report reach per backbone entity",
            "note": "The SIZE-reach gap (evidence-extraction rule 4). `current` is the only "
                    "status a disclosed financial can come from; the rest are facts about "
                    "OUR reach, never about the company, and are never reported as coverage.",
            "horizon_days": edgar.STALE_AFTER_DAYS,
            "reasons": REACH_REASONS,
            "counts": {k: len(v) for k, v in sorted(by_status.items())},
            "entities": len(detail),
        },
        "by_status": {k: sorted(v) for k, v in sorted(by_status.items())},
        "detail": detail,
    }


def run_reach() -> None:
    rep = classify_reach()
    REACH_FIXTURE.write_text(json.dumps(rep, indent=2) + "\n")
    c = rep["_meta"]["counts"]
    print(f"✓ backbone reach — {rep['_meta']['entities']} entities: "
          + ", ".join(f"{k}={v}" for k, v in c.items()))
    for st, ids in rep["by_status"].items():
        if st != "current":
            print(f"    · {st:18s} {', '.join(ids)}")


def run() -> None:
    with session_scope() as s:
        res = promote_backbone(s)
    print(f"✓ backbone promoted — {len(res['enriched'])} enriched, "
          f"{len(res['inserted'])} inserted")
    print(f"  enriched: {', '.join(res['enriched'])}")
    print(f"  inserted: {', '.join(res['inserted'])}")

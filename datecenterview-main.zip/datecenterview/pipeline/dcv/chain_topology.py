"""chain_topology — DISCOVER the real compute-chain topology from buyer filings (Band-1 #2, L2).

The P3.5 retro found that the 547 real `edges` are DC-centric (`operates`/`develops`/`serves`/
`powers`) and carry NO supplier→customer relationships — so the chain topology cannot be
"derived from the real graph" as P1 assumed. It has to be BUILT from evidence.

The identity spike showed where that evidence lives: a BUYER's 10-K enumerates its own
suppliers by name. Nvidia's FY2026 filing states verbatim — "We utilize foundries, such as
Taiwan Semiconductor Manufacturing Company Limited, or TSMC, and Samsung … We purchase memory
from SK Hynix Inc., Micron Technology, Inc., and Samsung … We engage with independent
subcontractors and contract manufacturers such as Hon Hai Precision Industry Co., Ltd.,
Wistron Corporation, and Fabrinet." That single paragraph is six sourced topology edges.

So this stage sweeps each SEC-filing chain company, extracts every NAMED supplier, cross-vendor
verifies the list, resolves names to chain ids LOCALLY (alias map — never an LLM's id guess),
and emits `supplies` edges (supplier→buyer) with link_basis=named + link_sources.

Direction: `supplies` ONLY. The SPLC derives both views from one directed edge list
(`to == central` → suppliers, `from == central` → customers), so an inverse `customer_of`
edge would double-count the same relationship in the sankey.

L2-topology 5-line contract:
  1. Setpoint  — every supplier→buyer relationship a filing NAMES exists as a `supplies` edge
                 with link_basis=named + a citable source.
  2. Measured  — discovered/confirmed edge counts (run stats) + `edge_coverage.named` in emit.
  3. Error     — a filing-named relationship absent from chain.edges (or present only as seed).
  4. Correction— extract named suppliers per buyer (Grok, voted) → cross-vendor confirm (Claude)
                 → add the edge, or upgrade a seed edge to named; unresolved names are LOGGED as
                 backbone-expansion candidates, never silently dropped.
  5. Mechanisms— maker-checker + requisite variety (Grok≠Claude) · extraction voting · active
                 learning (biggest buyers first) · spend governor (L5) · local alias resolution.

Guardrails: topology carries NO magnitude — a discovered edge never invents pct_cogs/pct_revenue
(those stay estimated until chain_quant discloses them). Self-edges dropped. Names that don't
resolve to a backbone entity are reported, not silently capped. Cross-vendor asserted at import.

Output: seed/chain_topology.json → emit merges it into `chain.edges`. Run: `dcv chain-topology`.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .chain_identity import _ALIASES
from .chain_quant import _src_url, _ticker_cik_map
from .clients import claude, edgar, grok
from .config import settings

FIXTURE = Path(__file__).resolve().parent.parent / "seed" / "chain_topology.json"

assert settings.extract_model.split("-")[0] != settings.verify_model.split("-")[0], (
    "chain_topology requires a cross-vendor pair (extract≠verify); same-vendor agreement is "
    f"meaningless — got extract={settings.extract_model}, verify={settings.verify_model}")

TOPO_SCHEMA = {
    "type": "object",
    "properties": {
        "suppliers": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "supplies": {"type": "string"},
                "verbatim": {"type": "string"},
            },
            "required": ["name", "supplies", "verbatim"],
        }},
    },
    "required": ["suppliers"],
}

_EXTRACT_SYS = (
    "You extract the companies that a SEC filer NAMES as its own SUPPLIERS. From the filing "
    "excerpt, return every company explicitly named as supplying the filer — foundries, memory/"
    "component vendors, packaging/assembly and contract manufacturers, equipment or power "
    "suppliers. For each: `name` exactly as written in the filing (full legal name if given), "
    "`supplies` (what it provides, e.g. 'semiconductor wafers', 'memory', 'assembly'), and the "
    "VERBATIM sentence. EXCLUDE the filer itself, its customers, its competitors, auditors, "
    "banks and law firms. Report ONLY companies actually named in the excerpt — never infer or "
    "invent a supplier.")

_VERIFY_SYS = (
    "You are a skeptical, independent verifier. A DIFFERENT model extracted the supplier list "
    "below from a filer's own SEC filing excerpt. Do NOT trust it. Read the excerpt and decide, "
    "for each proposed company, whether the excerpt genuinely names it as a SUPPLIER TO the "
    "filer (not a customer, competitor, subsidiary, or unrelated mention). Reply ONLY with JSON: "
    '{"confirmed":["exact names that ARE named as suppliers"],'
    '"refuted":["names that are not"],"reason":str}.')


def _resolve(name: str) -> str | None:
    """Map a filing-written supplier name to a backbone entity id using the alias map, with
    word-boundary matching (so 'Intel' doesn't match inside another word). Longest alias first
    so 'Taiwan Semiconductor' wins over a shorter partial. Returns None when unmapped — the
    caller LOGS those as backbone-expansion candidates rather than dropping them silently."""
    best: tuple[int, str] | None = None
    for eid, aliases in _ALIASES.items():
        for a in aliases:
            if re.search(r"\b" + re.escape(a) + r"\b", name, re.I) and (best is None or len(a) > best[0]):
                best = (len(a), eid)
    return best[1] if best else None


def targets(limit: int | None = None) -> list[dict]:
    """Chain companies that file with the SEC — these are the BUYERS whose filings we mine.
    Ordered by market cap DESC (active learning: the biggest buyers name the most chain)."""
    from .compute_seed import build_seed
    ents = build_seed()["chain"]["entities"]
    t2c = _ticker_cik_map()
    out = []
    for e in sorted(ents, key=lambda x: x.get("market_cap", 0) or 0, reverse=True):
        tk = e.get("ticker")
        if tk and tk in t2c:
            out.append({"id": e["id"], "name": e["name"], "ticker": tk, "cik": t2c[tk]})
    return out[:limit] if limit else out


def discover(buyer: dict, rounds: int = 3, min_votes: int = 2) -> tuple[list[dict], list[str]]:
    """Extract + cross-vendor confirm the suppliers a buyer's own filing names.
    Returns (edges, unresolved_names). Extraction is voted over `rounds`; the consensus list is
    then confirmed in ONE Claude call (a different vendor) against the same excerpt."""
    rpt = edgar.latest_report(edgar.submissions(buyer["cik"]))
    if not rpt:
        return [], []
    excerpt = edgar.supplier_excerpt(
        edgar.filing_text(buyer["cik"], rpt["accession"], rpt["doc"]))
    if not excerpt:
        return [], []

    user = f"Filer: {buyer['name']} ({buyer.get('ticker', '?')}).\n\nFiling excerpt:\n{excerpt}"
    votes: dict[str, dict] = {}   # normalized name -> {name, supplies, verbatim, n}
    for _ in range(rounds):
        try:
            got, _ = grok.chat(_EXTRACT_SYS, user, response_schema=TOPO_SCHEMA, temperature=0.4)
        except Exception:
            continue  # a flaky round must not sink the vote
        for s in got.get("suppliers", []):
            nm = (s.get("name") or "").strip()
            if not nm:
                continue
            k = nm.lower()
            rec = votes.setdefault(k, {**s, "name": nm, "n": 0})
            rec["n"] += 1
    consensus = [v for v in votes.values() if v["n"] >= min_votes]
    if not consensus:
        return [], []

    # cross-vendor confirmation of the consensus list (one call per buyer)
    vuser = (f"Filer: {buyer['name']}. Proposed suppliers: "
             + "; ".join(f"{v['name']} ({v.get('supplies', '')})" for v in consensus)
             + f"\n\nFiling excerpt:\n{excerpt}")
    try:
        # CLOSED-BOOK on purpose. `_VERIFY_SYS` asks one question — does THIS EXCERPT name the
        # company as a supplier to the filer — so a web-sourced confirmation would answer a
        # different question than the one asked. The topology edge's whole claim is "the
        # buyer's own filing names this supplier"; letting the verifier confirm from trade
        # press instead would keep the label while destroying what it means.
        # NOT a blanket rule: the sibling verifiers in chain_quant/_VERIFY_SYS and
        # chain_identity explicitly say "You MAY web-search", because a filing discloses a
        # MAGNITUDE and withholds the IDENTITY — the who-question cannot be answered from the
        # excerpt and must reach outside it. Search is off here only where the prompt is
        # entirely excerpt-bound.
        verdict = claude.verify_json(_VERIFY_SYS, vuser, allow_web_search=False)
    except Exception:
        return [], []
    confirmed = [str(n) for n in (verdict.get("confirmed") or [])]
    if not confirmed:
        return [], []
    # Join extractor→verifier on the RESOLVED ID, not the raw string: the two models return
    # different surface forms of the same company ("TSMC" vs "Taiwan Semiconductor Manufacturing
    # Company Limited"), so an exact string join silently drops every edge. Raw-string match is
    # kept as a fallback for names that don't resolve to a backbone entity.
    confirmed_ids = {cid for cid in (_resolve(n) for n in confirmed) if cid}
    confirmed_raw = {n.strip().lower() for n in confirmed}

    src = _src_url(buyer["cik"], rpt)
    edges, unresolved = [], []
    for v in consensus:
        sid = _resolve(v["name"])
        if not sid:
            if v["name"].strip().lower() in confirmed_raw:
                unresolved.append(v["name"])   # real supplier, just not in the backbone yet
            continue
        if sid not in confirmed_ids and v["name"].strip().lower() not in confirmed_raw:
            continue  # the different-vendor verifier didn't confirm it as a supplier
        if sid == buyer["id"]:
            continue  # never a self-edge
        edges.append({
            "from": sid, "to": buyer["id"], "relation": "supplies",
            "link_basis": "named", "link_confidence": round(min(1.0, v["n"] / rounds), 2),
            "supplies": (v.get("supplies") or "")[:80],
            "link_sources": [{"type": "buyer_filing", "url": src, "as_of": rpt["filed"],
                              "excerpt": (v.get("verbatim") or "")[:300]}],
            "verify": {"extractor": settings.extract_model, "verifier": settings.verify_model,
                       "extraction_votes": f"{v['n']}/{rounds}"},
            "note": f"topology: {buyer['name']}'s {rpt['form']} names {v['name']} as a supplier"
                    f"{(' (' + v['supplies'] + ')') if v.get('supplies') else ''}",
        })
    return edges, unresolved


def run(buyers: list[dict], budget_usd: float = 4.0, rounds: int = 3) -> dict:
    """Sweep buyers (active-learning order) under a spend cap; write seed/chain_topology.json."""
    import time

    from .clients import spend
    all_edges: dict[tuple[str, str], dict] = {}
    unresolved: dict[str, int] = {}
    for b in buyers:
        if spend.LEDGER.total_usd >= budget_usd:  # L5 spend governor
            print(f"  [chain_topology] spend cap ${budget_usd} reached — stopping")
            break
        try:
            edges, unres = discover(b, rounds=rounds)
            for e in edges:
                all_edges[(e["from"], e["to"])] = e   # dedup per (supplier, buyer)
            for u in unres:
                unresolved[u] = unresolved.get(u, 0) + 1
            named = ", ".join(e["from"] for e in edges) or "—"
            print(f"  [chain_topology] {b['id']:<14} {len(edges)} edge(s): {named}; "
                  f"spend ${spend.LEDGER.total_usd:.2f}")
        except Exception as ex:
            print(f"  [chain_topology] {b.get('id')}: {type(ex).__name__}: {ex}")
        time.sleep(0.7)  # EDGAR politeness

    edges = list(all_edges.values())
    stats = {"buyers_swept": len(buyers), "edges": len(edges),
             "unresolved_names": len(unresolved), "spend_usd": round(spend.LEDGER.total_usd, 3)}
    FIXTURE.write_text(json.dumps({
        "_meta": {
            "source": "SEC filings — each buyer's own 10-K/20-F naming its suppliers "
                      f"(Grok extract ×{rounds} voted → Claude confirm, cross-vendor)",
            "extractor": settings.extract_model, "verifier": settings.verify_model,
            "direction": "`supplies` = supplier→buyer. No inverse customer_of edge: the SPLC "
                         "derives both views from one directed edge list, so an inverse would "
                         "double-count in the sankey.",
            "note": "Topology only — these edges carry NO magnitude; pct_cogs/pct_revenue stay "
                    "estimated until chain_quant discloses them.",
            "unresolved_supplier_names": dict(sorted(unresolved.items(), key=lambda kv: -kv[1])),
            "stats": stats,
        }, "edges": edges}, indent=2) + "\n")
    print(f"✓ chain_topology — {len(edges)} named supplier edges from {len(buyers)} filers; "
          f"{len(unresolved)} unresolved names; spend ${stats['spend_usd']}")
    return stats

"""The reusable field-level provenance wrapper, `Field<T>` (schema spec §2.1).

Stored as JSONB in Postgres; flattened to `value` (+ top-level confidence/sources/
last_verified) by the emit step for the read-model.
"""
from __future__ import annotations

from datetime import date
from typing import Any

# method: how the value was established
METHODS = {"gov_api", "iso", "extracted", "cross_verified", "human", "geocoded"}


def field(
    value: Any,
    *,
    sources: list[str] | None = None,
    confidence: float = 0.0,
    method: str = "gov_api",
    unit: str | None = None,
    last_verified: str | None = None,
    as_of: str | None = None,
    quote: str | None = None,
    measure: str | None = None,
) -> dict[str, Any]:
    """Build a Field<T> dict. `sources` are source-registry ids.

    `quote` is the verbatim sentence from the source that supports this value. Phase B's
    extractor has always produced one — an unquoted number is dropped as a hallucination —
    but nothing persisted it, so the evidence died at the store boundary. That cost real
    trust: re-verification after the 2026-07-20 outage had to check our VALUES rather than
    values-plus-evidence, a materially weaker cross-vendor check, and a human reviewing the
    queue could see a number but not what the source actually said.

    Omitted from the dict when absent, so a gov_api/ISO field (which has no quote, only a
    feed) is not padded with a null.
    """
    today = date.today().isoformat()
    out = {
        "value": value,
        "unit": unit,
        "sources": sources or [],
        "confidence": round(float(confidence), 4),
        "method": method if method in METHODS else "gov_api",
        "last_verified": last_verified or today,
        "as_of": as_of or today,
    }
    if quote:
        out["quote"] = quote.strip()[:500]
    # `unit` says the number is in MW; `measure` says WHAT is in MW. A facility's power
    # capacity, its IT load, its campus total and its utility service are four different
    # quantities in the same unit, and the 2026-07-21 audit found `capacity_mw` holding at
    # least two of them. Omitted when absent so pre-existing fields aren't padded with a null
    # that would read as "we checked and it has none".
    if measure:
        out["measure"] = measure
    return out


def field_quote(f: Any) -> str | None:
    """Read the supporting quote out of a Field<T>, if it carries one."""
    return f.get("quote") if isinstance(f, dict) else None


def field_measure(f: Any) -> str | None:
    """Read what the value MEASURES, if the field says. None = unknown, not 'capacity'."""
    return f.get("measure") if isinstance(f, dict) else None


def field_value(f: Any) -> Any:
    """Read the scalar out of a Field<T> (or pass through a plain scalar)."""
    if isinstance(f, dict) and "value" in f:
        return f["value"]
    return f

"""capacity_audit — is every stored `capacity_mw` traceable, admissible, and the right quantity?

The 2026-07-21 audit of the MW column found the unit correct everywhere (EIA/ISO read columns
whose NAMES carry the unit; `parse_capacity_mw` converts GW/kW properly) but the VALUES carrying
four defects the pipeline had no sensor for:

  1. 334 of 337 values had no quote — written before quote persistence — so the column could
     not be checked against its own evidence at all.
  2. 50 values came from datacenter.fyi, whose power figures are modelled from a constant PUE
     of 5/3, not reported (tier 3, `source_policy`).
  3. 34 more came from seven directory domains in no tier — the enumeration-only policy could
     not catch a directory nobody had thought of.
  4. The column mixed measures: CoreSite Reston stored the page's IT LOAD (426.67 MW), CoreSite
     San Jose its POWER CAPACITY (2.675 MW). Two different quantities in one column.

    Setpoint       every published capacity_mw: quoted, quote reconciles, measure ==
                   facility_power_capacity, source admissible
    Measured value the five counts below (live: `meta.rollups.capacity_provenance`)
    Error signal   any non-zero count in the three ENFORCED buckets (quote_unreconciled,
                   measure_wrong, source_inadmissible); the two `unrecorded` buckets are
                   legacy debt and are reported, not enforced
    Correction     `withdraw()` clears the value (keeps the row and its sources) so
                   `dcv enrich-capacity` re-derives it from a permitted source under the new
                   prompt; publish gate 10 blocks on the enforced buckets
    Mechanism      balancing gate (L6) + the source-admissibility filter at ingest

WHY WITHDRAW RATHER THAN REWRITE. `purge_sources.py` established the rule in the competitor
case: a figure taken from an inadmissible source does not become ours by being re-cited to a
permitted page. Same here — a modelled number is not rescued by finding a real URL for it. The
value goes; the row stays; re-derivation is a separate, evidenced act. That is also what makes
this reversible: nothing is deleted but the number, and the number is recoverable.
"""
from __future__ import annotations

import re

from sqlalchemy import select

from . import source_policy
from .db import session_scope
from .field import field_measure
from .models import DataCenter

WANTED_MEASURE = "facility_power_capacity"
_NUM_UNIT = re.compile(r"([\d,]+(?:\.\d+)?)\s*-?\s*(gw|gigawatt|mw|megawatt|kw|kilowatt)", re.I)


def quote_supports(quote: str | None, value: float) -> bool:
    """Does a number+unit in the quote reduce to `value` MW?

    Unit-aware on purpose: a kW figure stored as if it were MW must FAIL here, which digit
    matching alone would not catch. A quote with no unit at all also fails — "90-megawatt"
    passes (the hyphen is handled), a bare "90" does not, because a bare number is exactly the
    ambiguity that produced this audit.
    """
    if not quote:
        return False
    for num, unit in _NUM_UNIT.findall(quote):
        n = float(num.replace(",", ""))
        u = unit.lower()
        mw = n * 1000 if u.startswith("g") else (n / 1000 if u.startswith("k") else n)
        if abs(mw - float(value)) <= max(0.02 * float(value), 0.01):
            return True
    return False


def audit() -> dict:
    """Read-only. Buckets every stored capacity value by what is wrong with it."""
    rep = {"values": 0, "unquoted": [], "quote_unreconciled": [], "measure_unrecorded": [],
           "measure_wrong": [], "source_inadmissible": [], "source_untiered": []}
    with session_scope() as s:
        for r in s.execute(select(DataCenter)).scalars():
            f = r.capacity_mw
            if not isinstance(f, dict) or f.get("value") is None:
                continue
            rep["values"] += 1
            v = f["value"]
            row = {"id": r.id, "name": r.project_name, "value": v}

            for u in (f.get("sources") or []):
                why = source_policy.value_denied_reason(u)
                if why:
                    rep["source_inadmissible"].append({**row, "why": f"{source_policy._host(u)} — {why}"})
                    break
            else:
                # FAIL CLOSED: an unruled directory cannot be the evidence for a published
                # number. Not a verdict that the source is bad — a refusal to assume it is
                # good. `restore()` puts these back for free the moment the owner rules.
                for u in (f.get("sources") or []):
                    if source_policy.unclassified_reason(u):
                        rep["source_untiered"].append(
                            {**row, "why": f"{source_policy._host(u)} — no tier ruling yet"})
                        break

            m = field_measure(f)
            if m is None:
                rep["measure_unrecorded"].append(row)
            elif m != WANTED_MEASURE:
                rep["measure_wrong"].append({**row, "why": f"measure={m}, not {WANTED_MEASURE}"})

            q = f.get("quote")
            if not q:
                rep["unquoted"].append(row)
            elif not quote_supports(q, v):
                rep["quote_unreconciled"].append({**row, "why": f'quote does not yield {v} MW: "{q[:70]}"'})
    return rep


# Buckets that justify withdrawing the value. `unquoted` and `measure_unrecorded` do NOT:
# they mean nobody wrote down the evidence, not that the number is wrong, and withdrawing
# 334 legacy values on that basis would delete most of the column to no one's benefit.
ENFORCED = ("quote_unreconciled", "measure_wrong", "source_inadmissible",
            "source_untiered")


def _backup_path():
    from .config import settings
    p = settings.repo_root / "pipeline" / "state" / "capacity_withdrawn.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def withdraw(rep: dict | None = None, *, backup: bool = True) -> int:
    """Clear capacity_mw on the enforced buckets. The withdrawn Field<T>s are written to
    `pipeline/state/capacity_withdrawn.json` first, so `restore()` is a free, exact reversal.

    Re-running `dcv enrich-capacity` is a RE-DERIVATION, not an undo: it costs API spend and
    may legitimately return a different number (that is the point — `aligned-iad02` read 163 MW
    from a competitor and 120 MW once re-derived). An undo has to give back exactly what was
    there, or a mistaken withdrawal is unrecoverable without paying to guess again.

    Idempotent: a row whose value is already gone is skipped, and the backup APPENDS by id
    without overwriting an earlier entry — so withdrawing twice cannot replace the original
    value with the null the first pass left behind.
    """
    import json
    rep = rep or audit()
    ids = {row["id"] for k in ENFORCED for row in rep[k]}
    if not ids:
        return 0
    path = _backup_path()
    saved = {}
    if backup and path.exists():
        saved = json.loads(path.read_text())
    with session_scope() as s:
        n = 0
        for rid in sorted(ids):
            r = s.get(DataCenter, rid)
            if r is None or r.capacity_mw is None:
                continue               # idempotence: already withdrawn
            saved.setdefault(rid, r.capacity_mw)   # never clobber an earlier backup
            r.capacity_mw = None       # the VALUE goes; the row and its sources stay
            n += 1
    if backup and n:
        path.write_text(json.dumps(saved, indent=1, sort_keys=True))
    return n


def restore(ids: list[str] | None = None) -> tuple[int, int]:
    """Put back exactly what `withdraw()` took — but ONLY what current policy still allows.

    Returns (restored, refused).

    The undo must not resurrect something the policy now forbids. The backup accumulates every
    withdrawal, so after the owner ruled the seven untiered directories into tier 2 on
    2026-07-21 it held 84 entries: 34 newly-admissible ones to give back, and 50 modelled-figure
    values (datacenter.fyi / datacenterindex.ai) that are still tier-3 denied and were separately
    purged. A blind restore would have re-published all 84 and quietly undone `purge-denied-sources`.

    So a reversal is not "put the bytes back" — it is "re-apply the decision to the bytes."
    """
    import json
    path = _backup_path()
    if not path.exists():
        return (0, 0)
    saved = json.loads(path.read_text())
    n = refused = 0
    with session_scope() as s:
        for rid, f in saved.items():
            if ids is not None and rid not in ids:
                continue
            if any(source_policy.value_denied_reason(u) for u in (f.get("sources") or [])):
                refused += 1          # still inadmissible under today's tiers — stays withdrawn
                continue
            r = s.get(DataCenter, rid)
            if r is not None and r.capacity_mw is None:
                r.capacity_mw = f
                n += 1
    return (n, refused)

"""Behind-the-meter data-center signal (phase-a-spec §5).

A cheap v1 rule set that flags new generation likely built to power a data center.
This is a *candidate signal* for the agentic layer (Phase C) to confirm, never truth.
"""
from __future__ import annotations

# generation technologies that co-locate with data-center load
_BTM_TECHS = {"Natural Gas", "Solar", "Battery", "Hybrid", "Nuclear"}


def btm_signal(
    *,
    technology: str,
    capacity_mw: float | None,
    status: str,
    developer_name: str | None = None,
    county: str | None = None,
    state: str | None = None,
    dc_developers: set[str] | None = None,
    dc_counties: set[tuple[str, str]] | None = None,
) -> tuple[bool, list[str]]:
    """Return (flag, reasons). Rules from phase-a §5."""
    reasons: list[str] = []
    cap = capacity_mw or 0

    # (1) large NEW gas/solar+storage
    if cap >= 100 and technology in _BTM_TECHS and status in {"proposed", "permitted", "under_construction"}:
        reasons.append(f">100MW new {technology}")

    # (3) developer matches a known data-center campus developer
    dev = (developer_name or "").lower().strip()
    if dc_developers and dev:
        for known in dc_developers:
            if known and (known in dev or dev in known):
                reasons.append(f"developer matches DC campus ({developer_name})")
                break

    # (4) same county as an active DC permit / known campus
    if dc_counties and county and state and (state.upper(), (county or "").lower()) in dc_counties:
        reasons.append(f"co-located county with known DC ({county}, {state})")

    flag = len(reasons) > 0 and cap >= 100
    return flag, reasons

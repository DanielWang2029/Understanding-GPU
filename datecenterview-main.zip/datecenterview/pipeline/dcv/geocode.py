"""County-centroid geocoding via the free US Census Gazetteer.

ISO queue rows rarely carry lat/lng (phase-a §4) -> geocode from the county
centroid and mark geo_precision="county". EIA-860M rows already carry exact
coords, so this is mainly for the ISO layer. Downloads the national county
gazetteer once and caches it to pipeline/out/.
"""
from __future__ import annotations

import io
import zipfile
from pathlib import Path

import httpx

from .config import settings

GAZ_URL = (
    "https://www2.census.gov/geo/docs/maps-data/data/gazetteer/"
    "2023_Gazetteer/2023_Gaz_counties_national.zip"
)
CACHE = settings.repo_root / "pipeline" / "out" / "county_centroids.tsv"

_TABLE: dict[tuple[str, str], tuple[float, float]] | None = None


def _norm(county: str) -> str:
    s = (county or "").lower().strip()
    for suffix in (" county", " parish", " borough", " census area", " municipality"):
        if s.endswith(suffix):
            s = s[: -len(suffix)]
    return s.strip()


def _download() -> str | None:
    try:
        r = httpx.get(GAZ_URL, timeout=60, follow_redirects=True)
        r.raise_for_status()
        zf = zipfile.ZipFile(io.BytesIO(r.content))
        name = next(n for n in zf.namelist() if n.endswith(".txt"))
        text = zf.read(name).decode("latin-1")
        CACHE.parent.mkdir(parents=True, exist_ok=True)
        CACHE.write_text(text, encoding="utf-8")
        return text
    except Exception as e:  # graceful degrade: geocoding is best-effort
        print(f"  [geocode] gazetteer download failed ({e}); ISO rows keep null coords")
        return None


def _load() -> dict[tuple[str, str], tuple[float, float]]:
    global _TABLE
    if _TABLE is not None:
        return _TABLE
    text = CACHE.read_text(encoding="utf-8") if CACHE.exists() else _download()
    table: dict[tuple[str, str], tuple[float, float]] = {}
    if text:
        lines = text.splitlines()
        header = [h.strip() for h in lines[0].split("\t")]
        idx = {h: i for i, h in enumerate(header)}
        try:
            i_usps, i_name = idx["USPS"], idx["NAME"]
            i_lat, i_lng = idx["INTPTLAT"], idx["INTPTLONG"]
        except KeyError:
            i_usps, i_name, i_lat, i_lng = 0, 3, len(header) - 2, len(header) - 1
        for ln in lines[1:]:
            parts = ln.split("\t")
            if len(parts) <= max(i_usps, i_name, i_lat, i_lng):
                continue
            try:
                table[(parts[i_usps].strip(), _norm(parts[i_name]))] = (
                    float(parts[i_lat]),
                    float(parts[i_lng]),
                )
            except (ValueError, IndexError):
                continue
    _TABLE = table
    return table


def county_centroid(county: str | None, state: str | None) -> tuple[float, float] | None:
    if not county or not state:
        return None
    return _load().get((state.upper().strip(), _norm(county)))

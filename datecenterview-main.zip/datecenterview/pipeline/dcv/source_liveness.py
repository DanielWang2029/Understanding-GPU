"""source_liveness — does the corroborating URL the verifier cited actually EXIST?

The gap this closes, found by the 2026-07-30 verifier bake-off: `phaseb.verify._score_field`
awarded `_AGREE_CORROBORATED` (0.93) whenever the verifier returned a source URL on a domain
the extractor did not already hold, and **nothing ever fetched that URL**. "Independent
corroboration" meant "the model typed a different hostname".

That held up only because the verifier of record runs with a server-side web-search tool, so
its URLs come from real search results — measured: of 138 verifier-contributed URLs already in
the store, 124 return 200 and exactly ONE is dead. The gate was not doing the work; the tool
was. The bake-off showed what happens without it: grok-4.5 with **zero** searches still
produced a source URL on 31% of its verdicts, and of the 16 distinct URLs it asserted, **4
were hard 404s** — pages that do not exist. Every one would have scored as independent
corroboration at 0.93, and `reverify` would have persisted it as provenance on an approved row.

So the guarantee has to live in the gate, not in the tool — otherwise "switch to a cheaper
verifier" silently converts corroboration into fabrication.

THREE STATES, because two would lie (same rule as `backbone_reach` and the three absence
states in `provenance-rendering`):

  live        — 2xx/3xx. The page is there. Earns the corroboration bonus.
  unreachable — 404/410 ONLY. Absence is PROVEN. Earns nothing and is never persisted.
  unverified  — 401/403/429/5xx, timeout, DNS failure. We could not tell. Earns nothing,
                but IS persisted, flagged, because the value may be real.

`unverified` is a deliberately large bucket. Bot-blocking is ubiquitous — 7 of the 138 live
store URLs answer 403 to a scripted GET, and a 403 says nothing about whether the path exists.
Treating those as fabricated would withdraw real evidence, which is the failure mode the
capacity audit already paid for once. Treating them as corroborated would let a fabricator
hide behind Cloudflare. Neither: they agree, they just do not get the independence bonus.

This costs coverage and that is the honest price, not a bug: on the current store 124/138
verifier sources keep full credit and 14 drop to uncorroborated.

Loop framing (loop-design): setpoint = every corroborating source is a page that exists;
measured = the live/unreachable/unverified split per run; error = a cited URL that 404s;
correction = withhold the bonus and refuse to persist it; mechanism = HEAD-then-GET probe with
an in-process cache; guardrail = fail-safe on ambiguity (a network outage degrades to
`unverified`, never to `unreachable`, so losing connectivity cannot mass-withdraw evidence).
"""
from __future__ import annotations

import httpx

LIVE, UNREACHABLE, UNVERIFIED = "live", "unreachable", "unverified"

#: Only these prove ABSENCE. Everything else that is not success is ambiguous.
_ABSENT = {404, 410}

_UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# Per-process cache. A verify pass re-checks the same publisher repeatedly, and a bake-off
# runs N verifiers over the same records — without this the probe cost scales with the slate.
_CACHE: dict[str, str] = {}


def check(url: str | None, *, timeout: float = 8.0) -> str:
    """Probe `url`. Returns LIVE / UNREACHABLE / UNVERIFIED. Never raises."""
    if not url or not isinstance(url, str) or not url.lower().startswith(("http://", "https://")):
        return UNVERIFIED
    if url in _CACHE:
        return _CACHE[url]
    state = UNVERIFIED
    try:
        with httpx.Client(timeout=timeout, follow_redirects=True,
                          headers={"User-Agent": _UA}) as c:
            try:
                r = c.head(url)
                # Plenty of servers do not implement HEAD; fall back rather than call a
                # 405 "unreachable" and withdraw a page that is plainly there.
                if r.status_code in (405, 501) or r.status_code in _ABSENT:
                    r = c.get(url)
            except httpx.HTTPError:
                r = c.get(url)
        if r.status_code < 400:
            state = LIVE
        elif r.status_code in _ABSENT:
            state = UNREACHABLE
    except Exception:
        state = UNVERIFIED     # timeout / DNS / TLS — ambiguity, never proof of absence
    _CACHE[url] = state
    return state


def reset_cache() -> None:
    _CACHE.clear()

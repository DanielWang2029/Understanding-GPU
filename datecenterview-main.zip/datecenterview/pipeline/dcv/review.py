"""review — the HITL queue and the U2 dispute drain (Band-1 #3, U2 → L2 + L4).

The P3.5 retro found the trust loop had no drain: 363/428 data centers sat in
`needs_review`, `review_log` had ZERO rows, and the UI's dispute control only relabelled
itself (`runtime.ts::disputeRecord`). A dispute that routes nowhere is open-loop — the
reader is a sensor whose signal was being thrown away.

This module closes it. The web UI POSTs a dispute to an append-only inbox
(pipeline/inbox/disputes.jsonl); `dcv review-drain` ingests it, writes a `review_log` row
(the audit trail + L4 training example) and RE-OPENS the record so the next L2 verify pass
re-checks it. `dcv review` prints the queue in active-learning order; `dcv review-decide`
records a human approve/reject.

U2/L2-HITL 5-line contract:
  1. Setpoint  — no user dispute is dropped (every one reaches `review_log` AND re-opens the
                 record), and the `needs_review` backlog is drainable in priority order.
  2. Measured  — stats(): needs_review depth per dataset, inbox_pending, review_log counts by
                 decision, open disputes, oldest-in-queue age. Emitted live into
                 meta.rollups.review_queue (loop-design: the measured value must be live).
  3. Error     — inbox_pending > 0 (a dispute filed but not routed), or a disputed record still
                 reading `approved` (the dispute did not re-open it), or depth flat while
                 reviewed == 0 (a queue with no drain).
  4. Correction— drain(): review_log row + approved→needs_review + confidence de-rated +
                 last_verified cleared, so the freshness/verify loop re-queues it.
                 decide(): a human approve/reject writes the terminal status + review_log.
  5. Mechanisms— human-in-the-loop negative feedback (the reader is a sensor into L2) ·
                 HYSTERESIS (a dispute can only re-open, never reject — one bad-faith dispute
                 cannot destroy a verified value) · ANTI-WINDUP (coalesce repeats per
                 (record, field); cap re-opens per drain so a burst can't flood L2) ·
                 ACTIVE LEARNING (queue ranked by uncertainty × value).

Guardrails: caps are LOGGED, never silent. An unmatched record_id is reported, not dropped.
A dispute never writes a terminal verdict — only a human `decide()` does. Only the pipeline
touches the store; the web tier appends to the inbox and holds no DB credentials.

Validator (L6) enforces the contract in validate_data.py::review_queue_integrity — the emitted
depth must equal the real row count, and every disputed id must have been re-opened.
"""
from __future__ import annotations

import json
import math
import os
from datetime import date, datetime, timezone
from pathlib import Path

from sqlalchemy import func, select

from .config import settings
from .db import session_scope
from .field import field_quote, field_value
from .models import DataCenter, PowerProject, ReviewLog

INBOX = settings.repo_root / "pipeline" / "inbox" / "disputes.jsonl"
PROCESSED = settings.repo_root / "pipeline" / "inbox" / "disputes.processed.jsonl"

RECORD_TYPES = {"data_center": DataCenter, "power_project": PowerProject}
# `dismiss` closes an UNFOUNDED dispute and restores the record's pre-dispute state. Without
# it a mistaken or bad-faith dispute is irreversible: `reject` rejects the RECORD, and
# `approve` asserts a verification that never happened.
DECISIONS = {"approve", "reject", "edit", "dispute", "dismiss"}

# hysteresis: a dispute de-rates confidence by one step and re-opens; it never rejects.
DISPUTE_DERATE = 0.85
DISPUTE_FLOOR = 0.20
# anti-windup: a burst of disputes can't re-open more than this many records per drain.
MAX_REOPEN_PER_DRAIN = 200


def _conf_attr(r) -> str:
    """DataCenter stores `overall_confidence`, PowerProject stores `confidence`. Dispatch on the
    attribute, not the class: isinstance-dispatch silently reads the wrong column on anything
    that isn't the exact ORM type (a test double, a future record kind) instead of failing."""
    return "overall_confidence" if hasattr(r, "overall_confidence") else "confidence"


def _conf(r) -> float | None:
    return getattr(r, _conf_attr(r), None)


def _set_conf(r, v: float) -> None:
    setattr(r, _conf_attr(r), v)


def priority(confidence: float | None, capacity_mw: float | None) -> float:
    """Active-learning rank: uncertainty × value. Verify the least-certain, biggest thing
    first — uniform review spends the same budget for less error reduction. log1p damps the
    capacity tail so one 2 GW campus can't monopolise the queue.
    (The UI recomputes this same formula client-side for its queue panel.)"""
    u = 1.0 - float(confidence if confidence is not None else 0.0)
    return round(u * math.log1p(float(capacity_mw or 0.0)), 4)


# --------------------------------------------------------------------------- queue
def queue(limit: int = 50, record_type: str | None = None) -> list[dict]:
    """The HITL worklist: `needs_review` rows in active-learning order (highest priority
    first). `record_type` narrows to one dataset."""
    out: list[dict] = []
    with session_scope() as s:
        disputed = _open_dispute_ids(s)
        for rt, model in RECORD_TYPES.items():
            if record_type and rt != record_type:
                continue
            rows = s.execute(select(model).where(model.review_status == "needs_review")).scalars()
            for r in rows:
                cap = field_value(r.capacity_mw)
                conf = _conf(r)
                out.append({
                    "record_type": rt,
                    "id": r.id,
                    "project_name": r.project_name,
                    "state": (r.location or {}).get("state"),
                    "capacity_mw": cap,
                    "confidence": conf,
                    "n_sources": len(r.sources or []),
                    "last_verified": r.last_verified,
                    "disputed": r.id in disputed,
                    # The quote is the whole point of reviewing: "400MW" and "earnings results
                    # SUGGEST the site COULD host up to 400MW" are the same number carrying
                    # very different weight, and only the quote shows the difference.
                    "quote": field_quote(r.capacity_mw),
                    "priority": priority(conf, cap),
                })
    # a disputed record jumps the queue: a human already told us this one is wrong
    out.sort(key=lambda x: (x["disputed"], x["priority"]), reverse=True)
    return out[:limit]


# Only these RESOLVE a dispute. `edit` records that a human changed the record — it is not a
# verdict on the dispute, so it must not clear the flag or close the run (otherwise an edit
# silently strands the de-rate with no way to undo it).
TERMINAL_DECISIONS = {"approve", "reject", "dismiss"}


def _open_dispute_ids(s) -> set[str]:
    """Records with a logged dispute not yet resolved by a human verdict. Computed from
    review_log — no extra column, no migration."""
    open_ids: set[str] = set()
    for rt, rid, dec in s.execute(
            select(ReviewLog.record_type, ReviewLog.record_id, ReviewLog.decision)
            .order_by(ReviewLog.id)):
        if dec == "dispute":
            open_ids.add(rid)
        elif dec in TERMINAL_DECISIONS:
            open_ids.discard(rid)
    return open_ids


# --------------------------------------------------------------------------- segments
# WHAT WOULD ACTUALLY MOVE THIS ROW — the question the queue depth cannot answer.
#
# "363 needs_review vs 37 approved, what's missing is throughput" framed this as one backlog
# needing one scarce input: human hours. Measured 2026-08-07 over 401 rows, it is three
# populations wanting three different things, and human hours is the answer for the smallest
# of them. Same shape as the `tenant 0.5%` finding — check the denominator before staffing the
# problem.
#
#   evidence_blocked  <2 distinct source domains, so `_gate` can NEVER approve it no matter
#                     who reviews it. 129 rows, and ZERO of them carry a capacity value: a
#                     PeeringDB facility listing with no number and no quote gives a reviewer
#                     nothing to decide. Approving it would just restate the directory.
#                     Needs DISCOVERY SPEND, not review.
#   reverifiable      >=2 domains but confidence below the auto-approve line. A cross-vendor
#                     pass can legitimately move these. Needs VERIFY SPEND.
#   gate_satisfied    already meets the approve gate but still reads needs_review — re-opened
#                     by a citation strip or a withdrawal. Needs a DECISION, not evidence.
#   below_floor       under the review floor; the verifier failed or conflicted.
#
# Deliberately NOT a confidence ranking: confidence is a per-ingest-path constant (0.75
# PeeringDB / 0.72 news), so no threshold discriminates — the standing finding this segmenter
# exists to route around.
SEGMENT_NAMES = ("evidence_blocked", "reverifiable", "gate_satisfied", "below_floor")


def classify_row(r) -> str:
    """Which segment one queued row belongs to.

    Shared by `segments()` (which counts) and `reverify --segment` (which spends against the
    count). Two implementations would drift the first time a threshold moved, and the spend
    would then target a population the report does not describe.
    """
    from .phaseb.verify import _domain, _gate

    n_dom = len({d for u in (r.sources or []) if (d := _domain(u))})
    verdict = _gate(_conf(r) or 0.0, n_dom)
    if verdict == "approved":
        return "gate_satisfied"
    if n_dom < 2:
        return "evidence_blocked"
    if verdict == "reported":
        return "below_floor"
    return "reverifiable"


def segments(record_type: str = "data_center") -> dict:
    """Classify the queue by what would actually move each row. Read-only."""
    model = RECORD_TYPES[record_type]
    out: dict[str, dict] = {k: {"rows": 0, "with_capacity": 0, "with_quote": 0, "mw": 0.0}
                            for k in SEGMENT_NAMES}
    with session_scope() as s:
        rows = [r for r in s.execute(
            select(model).where(model.review_status == "needs_review")).scalars()
            if getattr(r, "duplicate_of", None) is None]
        for r in rows:
            key = classify_row(r)
            cap = field_value(r.capacity_mw)
            b = out[key]
            b["rows"] += 1
            b["with_capacity"] += cap is not None
            b["with_quote"] += bool(field_quote(r.capacity_mw))
            b["mw"] += float(cap or 0)
    for b in out.values():
        b["mw"] = round(b["mw"], 1)
    out["total"] = sum(b["rows"] for k, b in out.items() if k != "total")
    return out


_SEGMENT_ACTION = {
    "evidence_blocked": "DISCOVERY spend — <2 source domains, the gate can never approve it",
    "reverifiable":     "VERIFY spend — a cross-vendor pass can move these",
    "gate_satisfied":   "a DECISION — already meets the approve gate, re-opened by a strip",
    "below_floor":      "investigate — under the review floor (verifier failed or conflicted)",
}


def print_segments(record_type: str = "data_center") -> None:
    seg = segments(record_type)
    total = seg.pop("total")
    print(f"=== review queue — {total} {record_type} row(s), by WHAT WOULD MOVE THEM ===")
    for k, b in sorted(seg.items(), key=lambda kv: -kv[1]["rows"]):
        if not b["rows"]:
            continue
        pct = 100.0 * b["rows"] / total if total else 0.0
        print(f"\n  {k:<17} {b['rows']:>4} ({pct:4.1f}%)   {_SEGMENT_ACTION[k]}")
        print(f"  {'':<17} {b['with_capacity']:>4} carry a capacity value "
              f"({b['mw']:,.0f} MW), {b['with_quote']} carry a quote")
    print("\nNOTE: confidence is a per-ingest-path constant (0.75 PeeringDB / 0.72 news), so a "
          "\nthreshold cannot rank this queue — segment by what each row is missing instead.")


# --------------------------------------------------------------------------- drain
def _read_inbox() -> tuple[list[dict], int]:
    """Rotate the inbox out from under the web tier, then parse it. Returns (rows, malformed).
    Rotating (rename → parse) rather than truncating means a POST landing mid-drain appends to
    a fresh file instead of being lost."""
    if not INBOX.exists():
        return [], 0
    tmp = INBOX.with_suffix(".processing.jsonl")
    os.replace(INBOX, tmp)
    rows, bad = [], 0
    for line in tmp.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            bad += 1
    with PROCESSED.open("a") as fh:  # keep the raw inbox as an audit trail
        fh.write(tmp.read_text())
    tmp.unlink()
    return rows, bad


def drain(max_reopen: int = MAX_REOPEN_PER_DRAIN) -> dict:
    """Ingest pending disputes → review_log + re-open the record (the U2→L2 wire).

    Hysteresis: `approved`/`reported` → `needs_review` with a de-rated confidence. A dispute
    NEVER writes `rejected` — only a human decide() does. Anti-windup: repeats on the same
    (record, field) coalesce to one, and at most `max_reopen` records are re-opened per drain;
    whatever is deferred is REPORTED (never a silent cap) and stays in the inbox audit trail.
    """
    rows, malformed = _read_inbox()
    stats = {"received": len(rows), "malformed": malformed, "logged": 0, "reopened": 0,
             "coalesced": 0, "repeat_signal": 0, "unmatched": [], "deferred": 0}
    if not rows:
        return stats

    seen: set[tuple[str, str, str]] = set()
    with session_scope() as s:
        # Records already carrying an OPEN dispute. Coalescing (`seen`) only dedupes within a
        # single drain, so without this a repeat disputer compounds the de-rate across drains
        # (0.95 → 0.81 → 0.69 → … → the 0.2 floor) and pins the record out of `approved`
        # forever. Proper hysteresis: the first dispute moves the state; more of the same input
        # does not move it further. The extra signal is still LOGGED — only the effect is capped.
        already_open = _open_dispute_ids(s)
        for row in rows:
            rt = row.get("record_type")
            rid = str(row.get("record_id") or "")
            model = RECORD_TYPES.get(rt)
            if not model or not rid:
                stats["unmatched"].append(f"{rt}:{rid}")
                continue
            key = (rt, rid, str(row.get("field") or ""))
            if key in seen:               # anti-windup: coalesce repeats within one drain
                stats["coalesced"] += 1
                continue
            seen.add(key)
            rec = s.get(model, rid)
            if rec is None:
                stats["unmatched"].append(f"{rt}:{rid}")
                continue
            if stats["reopened"] >= max_reopen:
                stats["deferred"] += 1
                continue

            before = {"review_status": rec.review_status, "confidence": _conf(rec),
                      "last_verified": rec.last_verified}
            repeat = rid in already_open
            if not repeat:
                if rec.review_status in ("approved", "reported"):
                    rec.review_status = "needs_review"  # hysteresis: re-open, never reject
                conf = _conf(rec)
                if conf is not None:
                    _set_conf(rec, round(max(DISPUTE_FLOOR, conf * DISPUTE_DERATE), 4))
                rec.last_verified = None                # force the freshness loop to re-queue
                stats["reopened"] += 1
            else:
                stats["repeat_signal"] += 1             # logged, but the state does not move again
            s.add(ReviewLog(
                record_type=rt, record_id=rid,
                reviewer=str(row.get("reporter") or "web-ui")[:120],
                decision="dispute",
                before=before,
                after={"review_status": rec.review_status, "confidence": _conf(rec),
                       "field": row.get("field"), "reason": str(row.get("reason") or "")[:500],
                       "filed_at": row.get("ts")},
            ))
            stats["logged"] += 1

    if stats["deferred"]:
        print(f"  [review] anti-windup: {stats['deferred']} dispute(s) deferred past the "
              f"{max_reopen}-per-drain cap — re-run `dcv review-drain` to continue")
    if stats["unmatched"]:
        print(f"  [review] {len(stats['unmatched'])} dispute(s) referenced unknown records: "
              f"{', '.join(stats['unmatched'][:5])}")
    print(f"✓ review-drain — {stats['received']} received, {stats['logged']} logged, "
          f"{stats['reopened']} re-opened, {stats['coalesced']} coalesced, "
          f"{stats['repeat_signal']} repeat (already open — logged, not re-de-rated), "
          f"{stats['malformed']} malformed")
    return stats


# --------------------------------------------------------------------------- decide
def _first_dispute_before(s, record_type: str, record_id: str) -> dict | None:
    """The record's state before the dispute that re-opened it — i.e. the `before` of the
    EARLIEST dispute in the currently-open run, so dismissing restores the pre-dispute value
    rather than an intermediate one."""
    rows = list(s.execute(
        select(ReviewLog.decision, ReviewLog.before)
        .where(ReviewLog.record_type == record_type, ReviewLog.record_id == record_id)
        .order_by(ReviewLog.id)))
    before = None
    for dec, bef in rows:
        if dec == "dispute":
            if before is None:      # first dispute of this open run
                before = bef
        elif dec in TERMINAL_DECISIONS:
            before = None           # a human verdict closed the run; start over
        # `edit` is NOT terminal — it doesn't resolve the dispute, so the run stays open
    return before


def decide(record_type: str, record_id: str, decision: str,
           reviewer: str = "operator", note: str = "") -> dict:
    """Record a HUMAN verdict on a queued record (the drain's terminal step).

    Only this path may write `approved`/`rejected` — a user dispute cannot (hysteresis).
    Approving also re-stamps `last_verified` so the freshness loop stops re-queueing it.

    `dismiss` closes an UNFOUNDED dispute: it restores the record's pre-dispute
    review_status/confidence/last_verified from the audit trail. Without it, a mistaken or
    bad-faith dispute is irreversible — `reject` rejects the record and `approve` asserts a
    verification nobody performed, so the only exits from a bad dispute were both lies.
    """
    if decision not in DECISIONS:
        raise ValueError(f"decision must be one of {sorted(DECISIONS)} — got {decision!r}")
    model = RECORD_TYPES.get(record_type)
    if model is None:
        raise ValueError(f"unknown record_type {record_type!r}")
    with session_scope() as s:
        rec = s.get(model, record_id)
        if rec is None:
            raise ValueError(f"no {record_type} with id {record_id!r}")
        before = {"review_status": rec.review_status, "confidence": _conf(rec),
                  "last_verified": rec.last_verified}
        restored = None
        if decision == "approve":
            rec.review_status = "approved"
            rec.last_verified = date.today().isoformat()
        elif decision == "reject":
            rec.review_status = "rejected"
        elif decision == "dismiss":
            restored = _first_dispute_before(s, record_type, record_id)
            if restored is None:
                raise ValueError(f"{record_id!r} has no open dispute to dismiss")
            rec.review_status = restored.get("review_status", rec.review_status)
            if restored.get("confidence") is not None:
                _set_conf(rec, restored["confidence"])
            rec.last_verified = restored.get("last_verified")
        s.add(ReviewLog(record_type=record_type, record_id=record_id, reviewer=reviewer,
                        decision=decision, before=before,
                        after={"review_status": rec.review_status, "confidence": _conf(rec),
                               **({"restored_from_audit": restored} if restored else {}),
                               "note": note[:500]}))
        after = {"review_status": rec.review_status, "last_verified": rec.last_verified}
    print(f"✓ review-decide — {record_type} {record_id}: {before['review_status']} → "
          f"{after['review_status']} ({decision} by {reviewer})")
    return {"before": before, "after": after}


# --------------------------------------------------------------------------- measured value
def _inbox_pending() -> int:
    if not INBOX.exists():
        return 0
    return sum(1 for ln in INBOX.read_text().splitlines() if ln.strip())


def stats(max_ids: int = 200) -> dict:
    """The live U2/L2-HITL measured value, emitted into meta.rollups.review_queue.

    `disputed_ids` lets the UI badge the records a reader has flagged, and lets the validator
    assert the hysteresis rule (a disputed record must no longer read `approved`).
    """
    today = date.today()
    with session_scope() as s:
        depth = {rt: s.execute(select(func.count()).select_from(model)
                               .where(model.review_status == "needs_review")).scalar() or 0
                 for rt, model in RECORD_TYPES.items()}
        by_decision: dict[str, int] = {}
        for (dec,) in s.execute(select(ReviewLog.decision)):
            by_decision[dec] = by_decision.get(dec, 0) + 1
        disputed = sorted(_open_dispute_ids(s))
        oldest = None
        for rt, model in RECORD_TYPES.items():
            for (lv,) in s.execute(select(model.last_verified)
                                   .where(model.review_status == "needs_review")
                                   .where(model.last_verified.isnot(None))):
                try:
                    age = (today - date.fromisoformat(str(lv)[:10])).days
                except ValueError:
                    continue
                oldest = age if oldest is None else max(oldest, age)
    out = {
        "needs_review": depth,
        "inbox_pending": _inbox_pending(),
        "reviewed": by_decision,
        "reviewed_total": sum(by_decision.values()),
        "open_disputes": len(disputed),
        "disputed_ids": disputed[:max_ids],
        "oldest_needs_review_days": oldest,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    if len(disputed) > max_ids:  # never a silent cap
        out["disputed_ids_truncated"] = len(disputed) - max_ids
    return out


def print_queue(limit: int = 25, record_type: str | None = None) -> None:
    rows = queue(limit=limit, record_type=record_type)
    if not rows:
        print("✓ review queue empty")
        return
    print(f"{'pri':>6}  {'conf':>5}  {'MW':>7}  {'src':>3}  id / project")
    for r in rows:
        flag = "⚑ " if r["disputed"] else "  "
        cap = f"{r['capacity_mw']:.0f}" if r["capacity_mw"] is not None else "—"
        conf = f"{r['confidence']:.2f}" if r["confidence"] is not None else "—"
        print(f"{r['priority']:>6}  {conf:>5}  {cap:>7}  {r['n_sources']:>3}  "
              f"{flag}{r['id']}  {r['project_name'][:52]} [{r['state'] or '—'}]")
        if r.get("quote"):
            print(f"{'':>26}  ↳ {r['quote'][:96]!r}")
    st = stats()
    print(f"\n{sum(st['needs_review'].values())} in queue "
          f"({', '.join(f'{k} {v}' for k, v in st['needs_review'].items())}) · "
          f"{st['open_disputes']} open dispute(s) · {st['inbox_pending']} undrained · "
          f"{st['reviewed_total']} decision(s) logged")

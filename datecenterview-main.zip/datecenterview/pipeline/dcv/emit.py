"""emit — build the data.json read-model from the Postgres store.

Uses DuckDB as the in-pipeline analytics engine (spec §3b): it attaches Postgres
and computes the rollups block. Row projection flattens each store row's Field<T>
provenance to the flat read-model the UI + validate_data.py expect. The write is
gated by validate_data.py (exit 1 blocks publish).
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from datetime import date
from pathlib import Path
from urllib.parse import urlparse

from sqlalchemy import select

from .backbone import CANONICAL
from .compute_seed import build_seed
from .config import settings
from .db import session_scope
from .field import field_quote, field_value
from .models import (
    DataCenter, Edge, Entity, Feed, News, PowerProject, SupplyLink, SupplyNode,
)
from .normalize import display_status

SCHEMA_VERSION = "1.2"
STATE_RE = re.compile(r"^[A-Z]{2}$")


def _libpq_dsn() -> str:
    u = urlparse(settings.database_url.replace("postgresql+psycopg", "postgresql"))
    return (
        f"host={u.hostname or 'localhost'} port={u.port or 5432} "
        f"user={u.username or 'dcv'} password={u.password or ''} "
        f"dbname={(u.path or '/datacenterview').lstrip('/')}"
    )


def _duckdb_rollups() -> dict:
    """DuckDB attaches Postgres and computes summary rollups (best-effort)."""
    try:
        import duckdb
        con = duckdb.connect()
        con.execute("INSTALL postgres; LOAD postgres;")
        con.execute(f"ATTACH '{_libpq_dsn()}' AS pg (TYPE postgres, READ_ONLY);")
        power_by_tech = con.execute(
            "SELECT technology, count(*) n, "
            "coalesce(sum((capacity_mw->>'value')::double), 0) mw "
            "FROM pg.power_project GROUP BY technology ORDER BY mw DESC"
        ).fetchall()
        dc_by_cat = con.execute(
            "SELECT coalesce(developer_category,'other') cat, count(*) n, "
            "coalesce(sum((capacity_mw->>'value')::double),0) mw "
            "FROM pg.data_center GROUP BY 1 ORDER BY mw DESC"
        ).fetchall()
        btm_ct = con.execute(
            "SELECT count(*) FROM pg.power_project WHERE btm_datacenter_signal IS NOT NULL"
        ).fetchone()[0]
        con.close()
        return {
            "engine": "duckdb",
            "power_by_technology": [{"technology": t, "n": n, "mw": round(mw, 1)} for t, n, mw in power_by_tech],
            "data_center_by_category": [{"category": c, "n": n, "mw": round(mw, 1)} for c, n, mw in dc_by_cat],
            "btm_flagged_power": btm_ct,
        }
    except Exception as e:
        print(f"  [emit] DuckDB rollups skipped ({type(e).__name__}: {e})")
        return {"engine": "unavailable"}


ROLE_FIELDS = ("developer", "operator", "tenant", "end_user")


def _role_value(r: DataCenter, role: str, ent_name: dict[str, str]) -> str | None:
    """Resolved entity name if the FK is set, else the raw name the source wrote, else None.
    Preferring the id keeps 'AWS' / 'Amazon Web Services' / 'AMAZON DATA SERVICES, INC' from
    rendering as three different companies once they resolve to one entity."""
    from .dc_roles import is_named_company
    eid = getattr(r, f"{role}_id", None)
    if eid and ent_name.get(eid):
        return ent_name[eid]          # resolved: already known to be a company
    raw = getattr(r, f"{role}_name", None)
    # Unresolved: a raw value that DESCRIBES a party instead of naming one ("a high-
    # investment-grade company") is kept in the store for audit but never rendered as the
    # role — see dc_roles.is_named_company.
    return raw if is_named_company(raw) else None


def _dc_row(r: DataCenter, ent_name: dict[str, str]) -> dict:
    loc = r.location or {}
    return {
        "id": r.id,
        "project_name": r.project_name,
        # All four ROLE fields resolve the same way (Band 2 #2): the resolved entity's name
        # when we have an id, else the raw name the source wrote. They previously used THREE
        # different strategies — developer raw-only, operator/tenant FK-only, end_user
        # raw-first — so the same underlying state rendered differently per column and a
        # resolved end_user was masked by its own raw string.
        **{role: _role_value(r, role, ent_name) for role in ROLE_FIELDS},
        "capacity_mw": field_value(r.capacity_mw),
        "status": display_status(r.status),
        "status_history": r.status_history or [],
        "county": loc.get("county"),
        "state": loc.get("state"),
        "lat": loc.get("lat"),
        "lng": loc.get("lng"),
        # A coordinate without its precision is a lie by omission: `dedup.py` already refuses
        # to treat a non-`exact` point as a location, but the read-model used to drop the flag,
        # so the map drew a county centroid with the same authority as a surveyed site.
        "geo_precision": loc.get("geo_precision"),
        "operating_year": r.operating_year,
        "cap_ex": field_value(r.cap_ex),
        "confidence": r.overall_confidence,
        "review_status": r.review_status,
        "last_verified": r.last_verified,
        "sources": r.sources or [],
        **({"developer_category": r.developer_category} if r.developer_category else {}),
    }


def _deep_canon(obj):
    """Rewrite every string value that is a seed chain-entity id needing remap to its
    canonical store id (amazon→aws, digitalrealty→digital-realty). Only exact id
    matches are affected — names ('Amazon'), tickers ('AMZN'), URLs never collide."""
    if isinstance(obj, dict):
        return {k: _deep_canon(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_deep_canon(v) for v in obj]
    if isinstance(obj, str):
        return CANONICAL.get(obj, obj)
    return obj


def _canonicalize_and_enrich(seed: dict, entities: list[Entity]) -> dict:
    """P2.5 (L9): flip the seed financial graph from illustrative to real.

    (a) Canonicalize every id reference across the whole seed (chain + projects +
    prices + providers + assets) so it shares the real entities[] id space; (b)
    override each chain node's market_cap/revenue with the real store financials
    (raw USD → $B, matching seed units) plus an honest `estimated` flag (True unless
    BOTH metrics are disclosed). Topology (edges, peers, cap_index) stays from the
    seed — %COGS/%revenue edges become real in P3. No-op for nodes lacking financials.
    """
    seed = _deep_canon(seed)
    fin_by_id = {e.id: (e.financials or {}) for e in entities}
    for e in seed.get("chain", {}).get("entities", []):
        f = fin_by_id.get(e["id"], {})
        mc, rv = (f.get("market_cap") or {}), (f.get("revenue") or {})
        if mc.get("value") is not None:
            e["market_cap"] = round(mc["value"] / 1e9, 1)  # raw USD → $B
        if rv.get("value") is not None:
            e["revenue"] = round(rv["value"] / 1e9, 1)
        # PER-METRIC estimated flags (review C3): a node can be disclosed on market
        # cap but estimated on revenue; a single flag mislabels one. The UI badge picks
        # the flag matching the displayed weight (see provenance-rendering skill).
        e["mc_estimated"] = mc.get("basis") != "disclosed"
        e["rev_estimated"] = rv.get("basis") != "disclosed"
        e["estimated"] = e["mc_estimated"] or e["rev_estimated"]
        # unit-of-analysis flag (review C9): a metric reported at a different unit than
        # the node (e.g. Amazon parent vs the AWS cloud segment) must be visible, not silent.
        unit = rv.get("unit") or mc.get("unit")
        if unit == "parent_consolidated":
            e["unit_note"] = "consolidated · incl. non-cloud"
        elif unit:
            e["unit_note"] = unit
    _quantify_edges(seed.get("chain", {}))
    _merge_topology(seed.get("chain", {}))  # Band-1 #2 — after quantify, so magnitude-less
    return seed                             # discovered edges don't pick up basis defaults


_SEED_DIR = Path(__file__).resolve().parent.parent / "seed"
_CHAIN_EDGES_FIXTURE = _SEED_DIR / "chain_edges.json"
_CHAIN_EDGES_VERIFIED = _SEED_DIR / "chain_edges_verified.json"
_CHAIN_EDGES_IDENTITY = _SEED_DIR / "chain_edges_identity.json"
_CHAIN_EDGES_IDENTITY_AUTO = _SEED_DIR / "chain_edges_identity_auto.json"
_CHAIN_TOPOLOGY = _SEED_DIR / "chain_topology.json"


def _load_chain_edges() -> dict:
    """Edge facts keyed by (from,to), FIELD-MERGED across fixtures so each contributes only
    the half it owns: the MAGNITUDE fixtures (manual chain_edges.json, then chain_quant's
    chain_edges_verified.json) carry pct_revenue/rev_basis/as_of/sources; the IDENTITY
    fixtures (manual chain_edges_identity.json, then chain_identity's *_auto.json) carry only
    the link half (link_basis=named/link_sources/review_status). Loaded in precedence order,
    each later fixture updates (overrides) fields of the earlier — so a named/confirmed link
    lands on the disclosed magnitude without either clobbering the other. Missing files skip."""
    out: dict = {}
    for f in (_CHAIN_EDGES_FIXTURE, _CHAIN_EDGES_VERIFIED,
              _CHAIN_EDGES_IDENTITY, _CHAIN_EDGES_IDENTITY_AUTO):
        try:
            data = json.loads(f.read_text())
        except FileNotFoundError:
            continue
        for e in data.get("edges", []):
            out.setdefault((e["from"], e["to"]), {}).update(e)
    return out


def _quantify_edges(chain: dict) -> None:
    """P3 (L9+L2): every seed chain edge is a guess → default it to estimated bases +
    inferred link, then override `pct_revenue` with the disclosed magnitude from the EDGAR
    fixture where we have it (rev_basis=disclosed + as_of + sources). %COGS stays estimated
    (supplier concentration isn't disclosed). The legacy `disclosed` bool is recomputed."""
    real = _load_chain_edges()
    for ed in chain.get("edges", []):
        v = ed.setdefault("value", {})
        v.setdefault("cogs_basis", "estimated")
        v.setdefault("rev_basis", "estimated")
        v.setdefault("link_basis", "inferred")
        r = real.get((ed.get("from"), ed.get("to")))
        if r:
            v["pct_revenue"] = r["pct_revenue"]
            v["rev_basis"] = r.get("rev_basis", "disclosed")
            v["link_basis"] = r.get("link_basis", "inferred")
            v["as_of"] = r["as_of"]
            v["sources"] = r["sources"]
            if r.get("note"):
                v["note"] = r["note"]
            # cross-vendor verdict (chain_quant L2) — surface it so the UI shows verified vs review
            if r.get("review_status"):
                v["review_status"] = r["review_status"]
            if r.get("link_confidence") is not None:
                v["link_confidence"] = r["link_confidence"]
            # L2-identity: the named counterparty's evidence (buyer 10-K / press) — the UI
            # renders "named link" + a who↗ link only when this is present (provenance-rendering).
            if r.get("link_sources"):
                v["link_sources"] = r["link_sources"]
        v["disclosed"] = v["cogs_basis"] == "disclosed" or v["rev_basis"] == "disclosed"


def _merge_topology(chain: dict) -> None:
    """Band-1 #2: merge DISCOVERED supplier→buyer edges (chain_topology) into the chain graph.

    The retro established that chain topology is not derivable from the DC-centric real edges —
    it has to be built from buyer filings that name their suppliers. So an existing seed edge for
    the same pair is UPGRADED in place (topology_basis=named + link_sources) rather than
    duplicated, a pair the seed never had is APPENDED, and every remaining edge is marked
    topology_basis="seed" so the read-model states plainly which topology is evidenced.

    A discovered edge carries NO magnitude — emitting a fake 0 would be dishonest, so pct_* is
    simply absent (schema allows it; the UI renders "—" and the flow sankey skips it).
    Runs AFTER _quantify_edges so appended edges don't pick up magnitude-basis defaults.
    """
    try:
        data = json.loads(_CHAIN_TOPOLOGY.read_text())
    except FileNotFoundError:
        return
    disc = {(e["from"], e["to"]): e for e in data.get("edges", [])}
    edges = chain.setdefault("edges", [])
    known = {(e.get("from"), e.get("to")) for e in edges}
    ids = {e["id"] for e in chain.get("entities", [])}

    def _link(d: dict) -> dict:
        out = {"topology_basis": "named", "link_basis": "named",
               "link_sources": d.get("link_sources", [])}
        if d.get("link_confidence") is not None:
            out["link_confidence"] = d["link_confidence"]
        if d.get("note"):
            out["note"] = d["note"]
        return out

    for e in edges:  # upgrade seed edges the filings confirm; label the rest honestly
        v = e.setdefault("value", {})
        d = disc.get((e.get("from"), e.get("to")))
        v.update(_link(d)) if d else v.setdefault("topology_basis", "seed")

    for (frm, to), d in disc.items():  # genuinely new relationships the seed never drew
        if (frm, to) in known or frm not in ids or to not in ids:
            continue
        edges.append({"from": frm, "to": to, "relation": d.get("relation", "supplies"),
                      "value": {"disclosed": False, **_link(d)}})


def _edge_coverage(chain: dict) -> dict:
    """Live measured value for edges — disclosed vs estimated MAGNITUDE (L9) plus named vs
    confirmed LINK (L2-identity). `named` = counterparty named by a buyer filing / press;
    `confirmed` = named AND the %-attribution held up under cross-vendor verify."""
    disc = est = named = confirmed = topo_named = topo_seed = 0
    for ed in chain.get("edges", []):
        v = ed.get("value") or {}
        if v.get("rev_basis") == "disclosed" or v.get("cogs_basis") == "disclosed":
            disc += 1
        else:
            est += 1
        if v.get("link_basis") == "named":
            named += 1
        if v.get("review_status") == "confirmed":
            confirmed += 1
        if v.get("topology_basis") == "named":
            topo_named += 1
        else:
            topo_seed += 1
    return {"disclosed": disc, "estimated": est, "named": named, "confirmed": confirmed,
            # topology (Band-1 #2): is the RELATIONSHIP itself evidenced by a filing, or drawn?
            "topology_named": topo_named, "topology_seed": topo_seed}


def _fin_coverage(entities: list[Entity]) -> dict:
    """Live financials-coverage metric (the L9 'measured value') — emitted so the UI reads a
    real count, not a hardcoded string (loop-design: measured value must be live).

    Reported PER METRIC: market_cap, revenue and capex have different sources and therefore
    different coverage (EDGAR discloses revenue/capex for any US filer but carries no price, so
    market_cap stays estimated outside the FMP set). A single conflated count would hide the
    revenue widening and mislabel a node the weight toggle is currently showing — the
    provenance-rendering rule: a coverage figure must bind to the metric it describes.
    `disclosed`/`estimated` are kept as the legacy fully-disclosed-entity count.
    """
    n = 0
    per = {k: 0 for k in ("market_cap", "revenue", "capex")}
    both = 0
    for e in entities:
        f = e.financials
        if not f:
            continue
        n += 1
        for k in per:
            if (f.get(k) or {}).get("basis") == "disclosed":
                per[k] += 1
        if (f.get("market_cap") or {}).get("basis") == "disclosed" \
                and (f.get("revenue") or {}).get("basis") == "disclosed":
            both += 1
    return {
        "backbone": n,
        **{k: {"disclosed": v, "estimated": n - v} for k, v in per.items()},
        "disclosed": both, "estimated": n - both,  # legacy: entities disclosed on BOTH metrics
    }


def _review_stats(emitted: dict[str, list[dict]] | None = None) -> dict:
    """Band-1 #3: the live HITL/dispute measured value. Best-effort — a store hiccup must not
    block publish, but it emits an explicit `unavailable` marker rather than a plausible zero
    (a fake 0 would read as 'queue empty', which is the opposite of the truth)."""
    try:
        from .review import stats
        out = stats()
    except Exception as e:
        print(f"  [emit] review_queue stats skipped ({type(e).__name__}: {e})")
        return {"unavailable": True}
    if emitted is not None:
        # The rollup lives INSIDE data.json, so it must describe data.json — not the store.
        # emit drops rows with no state or no sources, so the two diverge the moment anything
        # is dropped. That stayed invisible until the tier-1 purge stripped 8 records down to
        # zero sources; the store then said 380 needs_review while the file held 372, and the
        # L6 gate correctly refused to publish a count that described a different population.
        out["needs_review"] = {rt: sum(1 for r in rows
                                       if r.get("review_status") == "needs_review")
                               for rt, rows in emitted.items()}
    return out


def _backbone_reach() -> dict:
    """Band 2 #1 (L2-backbone): the live SIZE-REACH measured value — of the backbone entities,
    how many can EDGAR reach an annual report for, and why not for the rest.

    `evidence-extraction` rule 4: a source that can FIND a relationship may be structurally
    unable to SIZE it, and that gap is emitted as a named, counted set. This is what stops the
    equipment tier reading as "8 new companies, coverage pending" when 5 of them will never
    carry a disclosed figure from this source. Reads the fixture written by `dcv backbone-reach`
    (network-bound, so it is NOT recomputed on every emit); `unavailable` when absent, never a
    plausible zero.
    """
    try:
        from .backbone import REACH_FIXTURE
        rep = json.loads(REACH_FIXTURE.read_text())
        m = rep["_meta"]
        return {"entities": m["entities"], "horizon_days": m["horizon_days"],
                "counts": m["counts"], "by_status": rep["by_status"]}
    except Exception as e:
        print(f"  [emit] backbone_reach skipped ({type(e).__name__}: {e})")
        return {"unavailable": True}


def _source_policy_exposure(payload: dict) -> dict:
    """Band 2 #3 (L6): the live LICENSING measured value — what the published read-model
    actually depends on, by admissibility tier.

    Tier 1 is a hard deny and gate 8 blocks publish on it, so this should read 0 forever; it is
    emitted anyway because a constraint you cannot *see* holding is indistinguishable from one
    that quietly stopped. Tier 2 is the interesting number: free operator-submitted directories,
    ruled ALLOWED by the owner on 2026-07-20 and therefore "allowed **but tracked**" — and
    "tracked" with nothing tracking it is just "allowed" (`source-admissibility` rule 3). This
    is the sensor that makes the tier real: if that dependency drifts, it drifts visibly.
    """
    try:
        from . import source_policy
        t1 = source_policy.scan(payload, tier="deny")
        t2 = source_policy.scan(payload, tier="review")
        by_domain: dict[str, int] = {}
        for _path, url, _reason in t2:
            dom = url.split("//")[-1].split("/")[0].lower().removeprefix("www.")
            by_domain[dom] = by_domain.get(dom, 0) + 1
        return {"denied_tier1": len(t1),
                "tracked_tier2": len(t2),
                "tracked_by_domain": dict(sorted(by_domain.items(), key=lambda kv: -kv[1])),
                "ruling": "tier 2 (free operator-submitted directories) allowed by the owner "
                          "2026-07-20; tier 1 (paid curated competitors) denied — decision #1"}
    except Exception as e:
        print(f"  [emit] source_policy exposure skipped ({type(e).__name__}: {e})")
        return {"unavailable": True}


def _evidence_coverage() -> dict:
    """The live EVIDENCE measured value — of the values we publish, how many carry the verbatim
    quote that supports them.

    Quotes are store-side only, so this reads the store rather than the emitted rows. It exists
    because the fix shipped and the coverage did not follow: only rows extracted AFTER
    2026-07-20 carry a quote, so the honest number is small and stays small until those rows are
    re-extracted. Publishing it stops "we persist the quote now" from being heard as "our values
    are evidenced" — and it is the denominator behind `reverify`'s with_quote/no_quote split.
    """
    try:
        from sqlalchemy import select

        from .db import session_scope
        from .models import DataCenter
        with session_scope() as s:
            rows = list(s.execute(select(DataCenter)).scalars())
            with_cap = [r for r in rows if r.capacity_mw]
            return {
                "records": len(rows),
                "capacity_values": len(with_cap),
                "capacity_with_quote": sum(1 for r in with_cap if field_quote(r.capacity_mw)),
                "location_with_quote": sum(1 for r in rows if (r.location or {}).get("quote")),
                "note": "quotes are persisted from 2026-07-20 (19673ac); rows written earlier "
                        "carry none and re-verify values-only",
            }
    except Exception as e:
        print(f"  [emit] evidence coverage skipped ({type(e).__name__}: {e})")
        return {"unavailable": True}


def _geo_precision_coverage(dc_rows: list[dict], power_rows: list[dict]) -> dict:
    """The live GEO-PRECISION measured value — of the points we put on the map, how many are
    an actual site and how many are a centroid standing in for one?

    Written after the 2026-07-30 map review, which found the Explorer drawing 2,239 county
    centroids as if they were sites. The tell was visual: the Texas panhandle rendered as a
    regular lattice, because panhandle counties are a survey grid and every project in a
    county lands on that county's centre. 203 projects sat on 23 points; one Brazoria County
    point carried 58 projects totalling 12,280 MW.

    Measured over the EMITTED rows, not the store, so this reports what the map is actually
    standing on. `unlabelled` is the error signal the gate blocks on: a coordinate whose
    precision nobody recorded cannot be rendered honestly, because we do not know which of
    the two things it is.
    """
    out = {}
    for name, rows in (("data_center", dc_rows), ("power_project", power_rows)):
        mapped = [r for r in rows if r.get("lat") is not None and r.get("lng") is not None]
        by = {}
        for r in mapped:
            by[r.get("geo_precision") or "unlabelled"] = by.get(r.get("geo_precision") or "unlabelled", 0) + 1
        # `exact` is the only precision that denotes a site; everything else is a stand-in.
        exact = by.get("exact", 0)
        out[name] = {
            "rows": len(rows),
            "mapped": len(mapped),
            "unmapped": len(rows) - len(mapped),
            "exact": exact,
            "centroid": len(mapped) - exact - by.get("unlabelled", 0),
            "unlabelled": by.get("unlabelled", 0),
            "by_precision": by,
            # how many distinct points the mapped rows collapse onto — the stacking the
            # centroid count implies, stated rather than left for the eye to infer
            "distinct_points": len({(r["lat"], r["lng"]) for r in mapped}),
        }
    return out


def _capacity_provenance() -> dict:
    """The live CAPACITY-PROVENANCE measured value — can each published MW be traced to
    evidence, and does it measure what the column claims?

    Written after the 2026-07-21 audit, which could not answer either question: 334 of 337
    sized rows carried no quote (they predate quote persistence), so the column could not be
    checked against its own evidence at all; and where evidence did exist, the extractor had
    taken *different quantities* on different rows (CoreSite Reston stored the page's IT load,
    CoreSite San Jose its power capacity). Three sensors, all read from the store:

      quoted / unquoted      - is there evidence at all
      quote_reconciles       - does a number in the quote actually reduce to the stored MW
      measure_*              - does the value measure facility capacity, or something else
      source_class           - admissibility tier of the domain the value came from
    """
    try:
        from sqlalchemy import select

        from .db import session_scope
        from .models import DataCenter
        from . import source_policy
        from .field import field_measure
        out = {"values": 0, "quoted": 0, "unquoted": 0, "quote_reconciles": 0,
               "quote_unreconciled": 0, "by_measure": {}, "by_source_class": {}}
        with session_scope() as s:
            for r in s.execute(select(DataCenter)).scalars():
                if getattr(r, "duplicate_of", None) is not None:
                    continue
                f = r.capacity_mw
                if not isinstance(f, dict) or f.get("value") is None:
                    continue
                out["values"] += 1
                m = field_measure(f) or "unrecorded"
                out["by_measure"][m] = out["by_measure"].get(m, 0) + 1
                for u in (f.get("sources") or []):
                    k = source_policy.classify(u)
                    out["by_source_class"][k] = out["by_source_class"].get(k, 0) + 1
                q = f.get("quote")
                if not q:
                    out["unquoted"] += 1
                    continue
                out["quoted"] += 1
                out["quote_reconciles" if _quote_supports(q, f["value"])
                    else "quote_unreconciled"] += 1
        out["note"] = ("`unrecorded` measure and `unquoted` are pre-2026-07-21 rows: the "
                       "extractor did not yet record which quantity it took, nor persist the "
                       "quote. They are not assertions that the value is capacity — only that "
                       "nobody wrote down what it is. Re-run `dcv enrich-capacity` to close.")
        return out
    except Exception as e:
        print(f"  [emit] capacity provenance skipped ({type(e).__name__}: {e})")
        return {"unavailable": True}


def _quote_supports(quote: str, value: float) -> bool:
    """Does some number+unit in the quote reduce to `value` MW? Unit-aware, so a kW figure
    stored as MW fails here rather than passing on the digits matching."""
    import re as _re
    for num, unit in _re.findall(
            r"([\d,]+(?:\.\d+)?)\s*-?\s*(gw|gigawatt|mw|megawatt|kw|kilowatt)", quote, _re.I):
        n = float(num.replace(",", ""))
        u = unit.lower()
        mw = n * 1000 if u.startswith("g") else (n / 1000 if u.startswith("k") else n)
        if abs(mw - float(value)) <= max(0.02 * float(value), 0.01):
            return True
    return False


def _entity_row(e: Entity) -> dict:
    row = {"id": e.id, "name": e.name, "category": e.category}
    if e.layer:
        row["layer"] = e.layer
    tick = (e.identifiers or {}).get("ticker")
    if tick:
        row["ticker"] = tick
    if e.financials:  # P2/L9 — market_cap/revenue with per-metric as_of/basis/sources
        row["financials"] = e.financials
    return row


def _power_row(r: PowerProject) -> dict:
    loc = r.location or {}
    btm = field_value(r.btm_datacenter_signal)
    row = {
        "id": r.id,
        "project_name": r.project_name,
        "developer": r.developer_name,
        "technology": r.technology,
        "capacity_mw": field_value(r.capacity_mw),
        "status": display_status(r.status),
        "county": loc.get("county"),
        "state": loc.get("state"),
        "lat": loc.get("lat"),
        "lng": loc.get("lng"),
        "geo_precision": loc.get("geo_precision"),   # see `_dc_row` — 99.3% of these are centroids
        "operating_year": r.operating_year,
        "source": r.source,
        "btm": bool(btm),
        "confidence": r.confidence,
        "review_status": r.review_status,
        "last_verified": r.last_verified,
        "sources": r.sources or [],
    }
    # the demo's narrative BTM linkage was stashed in source_ref for seed rows
    if r.source == "seed" or (r.source_ref and not r.source_ref.startswith(("plant_id", "queue_id"))):
        row["linked"] = r.source_ref
    return row


def build_read_model() -> dict:
    with session_scope() as s:
        # dedup: a row marked `duplicate_of` is a duplicate of a survivor already in the set.
        # Dropped here rather than deleted in the store, so `dcv dedup --undo` restores it.
        dcs_all = list(s.execute(select(DataCenter)).scalars())
        dcs = [r for r in dcs_all if getattr(r, "duplicate_of", None) is None]
        dc_dropped_duplicate = len(dcs_all) - len(dcs)
        powers = list(s.execute(select(PowerProject)).scalars())
        entities = list(s.execute(select(Entity)).scalars())
        edges = list(s.execute(select(Edge)).scalars())
        feeds = list(s.execute(select(Feed)).scalars())
        news = list(s.execute(select(News)).scalars())
        snodes = list(s.execute(select(SupplyNode)).scalars())
        slinks = list(s.execute(select(SupplyLink)).scalars())

        ent_name = {e.id: e.name for e in entities}
        dc_rows, dropped_dc = [], 0
        # Resolution counts must be read from the ORM (the FKs) while the session is open —
        # the read-model row carries only a display name, so it cannot tell a RESOLVED role
        # from a raw string that happens to look like one. That distinction IS this loop's
        # error signal, so it is measured here rather than inferred later.
        role_resolved = dict.fromkeys(ROLE_FIELDS, 0)
        # Role CONFLICTS (raw name resolves elsewhere than the stored id) are surfaced, not
        # settled: the emitter displays the resolved id, so an unsurfaced disagreement would
        # simply disappear. See dc_roles.detect_conflicts.
        from .dc_roles import build_index, detect_conflicts
        _ex, _al = build_index(s)
        role_conflicts = detect_conflicts(s, _ex, _al)
        for r in dcs:
            row = _dc_row(r, ent_name)
            if not (row["state"] and STATE_RE.match(row["state"])) or not row["sources"]:
                dropped_dc += 1
                continue
            for role in ROLE_FIELDS:
                if getattr(r, f"{role}_id", None):
                    role_resolved[role] += 1
            dc_rows.append(row)

        power_rows, dropped_pw = [], 0
        for r in powers:
            row = _power_row(r)
            if not (row["state"] and STATE_RE.match(row["state"])) or not row["sources"]:
                dropped_pw += 1
                continue
            power_rows.append(row)

        dc_ids = {r["id"] for r in dc_rows}
        pw_ids = {r["id"] for r in power_rows}
        proj_ids = dc_ids | pw_ids
        ent_ids = {e.id for e in entities}

        edge_rows = [
            {"project": e.from_id, "org": e.to_id, "relation": e.relation,
             "confidence": e.confidence, "sources": e.sources or []}
            for e in edges if e.from_id in dc_ids and e.to_id in ent_ids
        ]
        news_rows = [
            {"id": n.id, "type": n.type, "title": n.title, "publisher": n.publisher,
             "published_date": n.published_date, "url": n.url,
             **({"tag": n.tag} if n.tag else {}), "source_feed": n.source_feed,
             "projects": [p for p in (n.project_refs or []) if p in proj_ids]}
            for n in news
        ]
        supply_nodes = [
            {"id": n.id, "label": n.label, "category": n.category,
             **({"rev": n.rev} if n.rev is not None else {}),
             **({"note": n.note} if n.note else {})}
            for n in snodes
        ]
        snode_ids = {n.id for n in snodes}
        supply_links = [
            {"source": lk.source_id, "target": lk.target_id, "value": lk.value,
             **({"title": lk.title} if lk.title else {})}
            for lk in slinks if lk.source_id in snode_ids and lk.target_id in snode_ids
        ]

    if dropped_dc or dropped_pw:
        print(f"  [emit] dropped {dropped_dc} DC + {dropped_pw} power rows (no valid state/source)")

    seed = _canonicalize_and_enrich(build_seed(), entities)  # P2.5 — real financials on the chain graph
    rollups = _duckdb_rollups()
    rollups["financials_coverage"] = _fin_coverage(entities)  # live L9 measured value
    rollups["edge_coverage"] = _edge_coverage(seed.get("chain", {}))  # live P3 measured value
    rollups["review_queue"] = _review_stats(  # live U2/L2-HITL measured value (Band-1 #3)
        {"data_center": dc_rows, "power_project": power_rows})
    rollups["backbone_reach"] = _backbone_reach()  # live L2-backbone measured value (Band 2 #1)
    from .dc_roles import coverage as _dc_role_coverage
    rollups["dc_role_coverage"] = _dc_role_coverage(  # live L2-dcroles (Band 2 #2)
        dc_rows, role_resolved, role_conflicts)
    # Scan the URL-bearing payload, not the finished doc — the rollups block holds no URLs, and
    # scanning the doc that contains this value would mean building it twice.
    rollups["source_policy"] = _source_policy_exposure({  # live licensing measured value
        "data_center": dc_rows, "power_project": power_rows, "news": news_rows,
        "entities": [_entity_row(e) for e in entities], "edges": edge_rows, **seed})
    rollups["evidence_coverage"] = _evidence_coverage()  # live quote-persistence measured value
    rollups["capacity_provenance"] = _capacity_provenance()  # live capacity-audit measured value
    rollups["geo_precision"] = _geo_precision_coverage(dc_rows, power_rows)  # live map-honesty value
    from .dedup import stats as _dedup_stats
    try:
        rollups["dedup"] = dict(_dedup_stats(), rows_dropped_from_read_model=dc_dropped_duplicate)
    except Exception as e:                       # pragma: no cover - store-shape drift
        print(f"  [emit] dedup stats skipped ({type(e).__name__}: {e})")
        rollups["dedup"] = {"unavailable": True}

    return {
        "generated_at": date.today().isoformat(),
        "schema_version": SCHEMA_VERSION,
        "meta": {
            "us_data_center_total": 2950,
            "us_power_project_total": 14000,
            "note": "Emitted by the dataCenterView pipeline from the Postgres store. "
                    "Phase A power layer (EIA-860M + ISO queues) over the seeded demo bridge. "
                    "Migrated from read-model v0.1 to v1.2 (field-level provenance in the store).",
            "illustrative_compute_seed": (
                "layers/chain/projects/power/assets/skus/providers/prices/forwards are an "
                "ILLUSTRATIVE compute-chain seed (mid-2026 representative figures) for the "
                "Overview/Chain Analysis/Explorer/Price Board views. Newsfeed + datasets are "
                "real pipeline output. P1 derives the chain graph from real entities+edges; "
                "P2 attaches FMP financials."
            ),
            "phases": [
                {"id": "A", "label": "Free power layer (EIA + 7 ISO queues)", "status": "live"},
                {"id": "B", "label": "Agentic discovery → extract → cross-vendor verify", "status": "live"},
                {"id": "C", "label": "Verify · confidence · dedup · refresh", "status": "designed"},
                {"id": "D", "label": "Permits · satellite · X-signal", "status": "outlined"},
                {"id": "E", "label": "International", "status": "outlined"},
            ],
            "targets": {"precision": 0.9, "freshness_hours": 48, "confirmed_pct": 0.75},
            "rollups": rollups,
        },
        "datasets": {
            "data_center": dc_rows,
            "power_project": power_rows,
            "news": news_rows,
        },
        "entities": [_entity_row(e) for e in entities],
        "edges": edge_rows,
        "feeds": [{"id": f.id, "name": f.name, "type": f.type} for f in feeds],
        "supply_chain": {"nodes": supply_nodes, "links": supply_links},
        **seed,
    }


def emit(validate: bool = True) -> dict:
    model = build_read_model()
    text = json.dumps(model, indent=2, ensure_ascii=False)
    settings.data_json_path.write_text(text + "\n")
    settings.data_js_path.write_text("window.DCV_DATA = " + text + ";\n")
    settings.web_public_data.parent.mkdir(parents=True, exist_ok=True)
    settings.web_public_data.write_text(text + "\n")

    nd, npw, nn = (len(model["datasets"]["data_center"]),
                   len(model["datasets"]["power_project"]),
                   len(model["datasets"]["news"]))
    print(f"✓ wrote data.json — {nd} data_center, {npw} power_project, {nn} news "
          f"({len(model['entities'])} entities, {len(model['edges'])} edges)")

    if validate:
        print("→ validating (publish gate) …")
        res = subprocess.run(
            [sys.executable, str(settings.validator_path), str(settings.data_json_path),
             "--schema", str(settings.schema_path), "--max-stale-days", "45"],
            capture_output=True, text=True,
        )
        print(res.stdout.rstrip())
        if res.returncode != 0:
            print(res.stderr.rstrip())
            raise SystemExit(f"validate_data.py FAILED (exit {res.returncode}) — publish blocked")
    return model

"""compute_seed — the illustrative compute-chain seed for the v1.2 read-model (P0).

This is the ONE source of truth for the compute-terminal's illustrative data. It is
the demo's inline data (`compute-terminal-demo.html`) promoted into the `data.json`
contract under NEW top-level keys that do not collide with the real pipeline arrays:

    layers · chain{entities,edges} · projects · power · assets · skus · providers
    · prices · forwards · price_terms

The four compute-chain views (Overview flow, Chain Analysis, Explorer, Price Board)
render from this seed in P0 — "arrays present, illustrative where absent" (plan §7,
P0). P1/P2 replace it by *deriving* the graph from the real `entities`+`edges` and
attaching FMP financials; the Newsfeed already runs on the real `datasets.news`.

Pure data, zero imports — safe to load from both `emit.py` (the pipeline emitter)
and the standalone P0 builder without pulling in the DB layer.
"""
from __future__ import annotations

# entity: id → (name, layer, category, ticker, market_cap $B, revenue $B, cap_index, peers, estimated)
#
# Band 2 #1 — the `equipment` tier is EVIDENCE-PROMOTED, not curated. Every entry below came
# from `chain_topology`'s own `unresolved_supplier_names` log: a filing NAMED it as a supplier
# and the resolver had no backbone id to map it to. That log is the error signal; this block is
# the correction. Applied Materials and KLA are deliberately ABSENT — no swept filing named
# them, so adding them would be a prior, not evidence. If they are real chain participants the
# next sweep will name them and they will show up as unresolved. Letting the loop find them is
# the test of whether the loop works.
_ENT = [
    ("asml", "ASML", "equipment", "equipment", "ASML", 300, 32, 85, ["lamresearch", "tokyoelectron"], True),
    ("tokyoelectron", "Tokyo Electron", "equipment", "equipment", "—", 120, 15, 60, ["lamresearch", "asml"], True),
    ("lamresearch", "Lam Research", "equipment", "equipment", "LRCX", 130, 18, 55, ["tokyoelectron", "asml"], True),
    ("teradyne", "Teradyne", "equipment", "equipment", "TER", 25, 3, 25, ["advantest"], True),
    # ATEYY is a real ADR and EDGAR has a CIK for it — but Advantest DEREGISTERED, so its
    # newest 20-F is from 2015. Recording the true ticker (rather than "—") makes the reach
    # report state the true reason, `stale`, instead of the false one, "no ticker".
    ("advantest", "Advantest", "equipment", "equipment", "ATEYY", 60, 6, 30, ["teradyne"], True),
    ("allring", "All Ring Tech", "equipment", "equipment", "—", 1, 0.2, 8, ["marketech"], True),
    ("marketech", "Marketech International", "equipment", "equipment", "—", 2, 1, 10, ["allring"], True),
    ("grandprocess", "Grand Process Technology", "equipment", "equipment", "—", 1, 0.2, 8, ["allring"], True),
    ("tsmc", "TSMC", "foundry", "foundry", "TSM", 1050, 110, 100, ["samsung", "intel"], False),
    ("intel", "Intel Foundry", "foundry", "foundry", "INTC", 110, 55, 40, ["tsmc", "samsung"], False),
    ("samsung", "Samsung", "hbm", "hbm", "—", 380, 200, 70, ["skhynix", "micron"], False),
    ("ase", "ASE Technology", "packaging", "packaging", "ASX", 28, 20, 35, ["amkor"], False),
    ("amkor", "Amkor", "packaging", "packaging", "AMKR", 9, 7, 18, ["ase"], False),
    ("skhynix", "SK Hynix", "hbm", "hbm", "—", 120, 50, 55, ["micron", "samsung"], False),
    ("micron", "Micron", "hbm", "hbm", "MU", 135, 35, 45, ["skhynix", "samsung"], False),
    ("nvidia", "Nvidia", "accelerator", "accelerator", "NVDA", 3600, 170, 95, ["amd", "broadcom"], False),
    ("amd", "AMD", "accelerator", "accelerator", "AMD", 260, 32, 30, ["nvidia", "broadcom"], False),
    ("broadcom", "Broadcom", "accelerator", "accelerator", "AVGO", 820, 60, 50, ["nvidia", "amd"], False),
    ("dell", "Dell", "systems", "systems", "DELL", 95, 95, 60, ["smci", "foxconn"], False),
    ("smci", "Supermicro", "systems", "systems", "SMCI", 28, 25, 35, ["dell"], False),
    ("foxconn", "Foxconn", "systems", "systems", "—", 90, 210, 80, ["dell", "smci"], False),
    ("vertiv", "Vertiv", "power", "power", "VRT", 48, 9, 40, ["eaton", "schneider"], False),
    ("eaton", "Eaton", "power", "power", "ETN", 145, 26, 55, ["vertiv", "schneider"], False),
    ("schneider", "Schneider", "power", "power", "—", 135, 40, 50, ["vertiv", "eaton"], False),
    ("digitalrealty", "Digital Realty", "datacenter", "colo", "DLR", 58, 6, 70, ["equinix"], False),
    ("equinix", "Equinix", "datacenter", "colo", "EQIX", 92, 9, 65, ["digitalrealty"], False),
    ("microsoft", "Microsoft", "cloud", "hyperscaler", "MSFT", 3400, 270, 95, ["google", "amazon", "oracle"], False),
    ("google", "Alphabet", "cloud", "hyperscaler", "GOOGL", 2300, 350, 90, ["microsoft", "amazon"], False),
    ("amazon", "Amazon", "cloud", "hyperscaler", "AMZN", 2200, 640, 92, ["microsoft", "google"], False),
    ("oracle", "Oracle", "cloud", "hyperscaler", "ORCL", 460, 55, 60, ["microsoft", "coreweave"], False),
    ("coreweave", "CoreWeave", "cloud", "neocloud", "CRWV", 42, 5, 45, ["crusoe", "nebius"], False),
    ("crusoe", "Crusoe", "cloud", "neocloud", "private", 12, 1, 30, ["coreweave", "nebius"], True),
    ("nebius", "Nebius", "cloud", "neocloud", "NBIS", 22, 1, 28, ["coreweave", "crusoe"], False),
    ("openai", "OpenAI", "enduser", "ai_lab", "private", 500, 13, 60, ["anthropic", "xai"], True),
    ("anthropic", "Anthropic", "enduser", "ai_lab", "private", 180, 5, 40, ["openai", "xai"], True),
    ("xai", "xAI", "enduser", "ai_lab", "private", 200, 1, 35, ["openai", "anthropic"], True),
    ("meta", "Meta", "enduser", "ai_lab", "META", 1600, 170, 70, ["microsoft", "google"], False),
]

# supply edge: (supplier, buyer, %of buyer's COGS, %of supplier's revenue, disclosed)
_SUP = [
    ("tsmc", "nvidia", 39, 22, True), ("tsmc", "amd", 45, 5, False), ("tsmc", "broadcom", 40, 9, False),
    ("skhynix", "nvidia", 14, 45, False), ("micron", "nvidia", 9, 30, False), ("samsung", "nvidia", 6, 8, False),
    ("ase", "nvidia", 4, 15, False), ("amkor", "nvidia", 3, 25, False),
    ("nvidia", "microsoft", 9, 19, True), ("nvidia", "meta", 11, 14, True), ("nvidia", "amazon", 7, 11, True),
    ("nvidia", "google", 5, 8, False), ("nvidia", "oracle", 13, 7, False), ("nvidia", "coreweave", 62, 6, False),
    ("nvidia", "crusoe", 55, 2, False),
    ("broadcom", "google", 16, 13, False), ("broadcom", "meta", 9, 8, False),
    ("nvidia", "dell", 35, 4, False), ("nvidia", "smci", 40, 3, False), ("nvidia", "foxconn", 45, 5, False),
    ("nvidia", "nebius", 52, 3, False),
    ("dell", "coreweave", 20, 4, False), ("smci", "coreweave", 15, 12, False), ("foxconn", "microsoft", 6, 10, False),
    ("nebius", "anthropic", 28, 40, False),
    ("vertiv", "microsoft", 1, 15, False), ("eaton", "digitalrealty", 6, 3, False), ("schneider", "equinix", 5, 3, False),
    ("eaton", "amazon", 1, 8, False), ("schneider", "google", 1, 7, False),
    ("digitalrealty", "microsoft", 3, 12, False), ("equinix", "oracle", 3, 8, False),
    ("coreweave", "microsoft", 4, 62, True), ("coreweave", "openai", 30, 22, False), ("oracle", "openai", 18, 9, False),
    ("microsoft", "openai", 40, 35, True), ("amazon", "anthropic", 35, 60, True), ("google", "anthropic", 30, 30, True),
    ("microsoft", "meta", 0, 0, False),
]

# project role chain: id, name, developer, operator, tenant, end_user, power, category, state, lat, lng, mw, status, conf, sources
_PROJECTS = [
    ("stargate1", "Stargate I (Abilene TX)", "crusoe", "oracle", "oracle", "openai", "On-site gas (BTM)", "neocloud", "TX", 32.45, -99.73, 1200, "Under construction", 0.82, ["datacenterdynamics.com", "sec.gov"]),
    ("cw_plano", "CoreWeave Plano (TX)", "digitalrealty", "coreweave", "coreweave", "microsoft", "ERCOT", "neocloud", "TX", 33.02, -96.70, 220, "Operating", 0.78, ["peeringdb.com", "crusoe.ai"]),
    ("msft_va", "Microsoft Boydton (VA)", "microsoft", "microsoft", "microsoft", "openai", "PJM", "hyperscaler", "VA", 36.66, -78.38, 450, "Operating", 0.85, ["microsoft.com"]),
    ("meta_id", "Meta Kuna (ID)", "meta", "meta", "meta", "meta", "Idaho Power", "hyperscaler", "ID", 43.49, -116.42, 600, "Under construction", 0.8, ["datacenterfrontier.com"]),
    ("cw_va", "CoreWeave Ashburn (VA)", "digitalrealty", "coreweave", "coreweave", "microsoft", "PJM", "neocloud", "VA", 39.02, -77.46, 180, "Operating", 0.76, ["peeringdb.com"]),
    ("crusoe_az", "Crusoe Abilene expansion", "crusoe", "crusoe", "oracle", "openai", "On-site gas (BTM)", "neocloud", "TX", 32.38, -99.80, 900, "Planned", 0.7, ["crusoe.ai"]),
    ("oracle_tx", "Oracle Cloud (San Antonio TX)", "digitalrealty", "oracle", "oracle", "openai", "ERCOT", "hyperscaler", "TX", 29.42, -98.49, 300, "Operating", 0.77, ["oracle.com"]),
    ("nebius_ny", "Nebius (Kansas City)", "nebius", "nebius", "nebius", "anthropic", "SPP", "neocloud", "MO", 39.10, -94.58, 120, "Under construction", 0.72, ["nebius.com"]),
    ("aws_az", "AWS Goodyear (AZ)", "amazon", "amazon", "amazon", "anthropic", "APS", "hyperscaler", "AZ", 33.44, -112.36, 400, "Operating", 0.83, ["aboutamazon.com"]),
    ("xai_tn", "xAI Colossus (Memphis TN)", "xai", "xai", "xai", "xai", "On-site gas + TVA", "neocloud", "TN", 35.06, -90.03, 250, "Operating", 0.79, ["datacenterdynamics.com"]),
]

# power: id, name, technology, mw, state, lat, lng, status, btm, linked, conf, sources
_POWER = [
    ("p1", "Sweetwater Gas (Fisher Co TX)", "Natural Gas", 2000, "TX", 32.47, -100.40, "Under construction", True, "stargate1", 0.74, ["eia.gov"]),
    ("p2", "PJM Solar+Storage (Loudoun VA)", "Battery", 300, "VA", 39.05, -77.60, "Queue", False, None, 0.7, ["pjm.com"]),
    ("p3", "Goodyear Substation (AZ)", "Grid", 500, "AZ", 33.43, -112.38, "Operating", False, "aws_az", 0.8, ["eia.gov"]),
    ("p4", "TVA supply (Memphis TN)", "Natural Gas", 400, "TN", 35.10, -90.05, "Operating", True, "xai_tn", 0.72, ["tva.com"]),
    ("p5", "SPP Wind (KS)", "Wind", 250, "KS", 38.5, -98.0, "Operating", False, "nebius_ny", 0.68, ["spp.org"]),
    ("p6", "Idaho Power (Kuna ID)", "Grid", 600, "ID", 43.50, -116.40, "Queue", False, "meta_id", 0.7, ["idahopower.com"]),
]

# upstream physical asset: id, entity, layer, name, region, lat, lng, cap
_UP = [
    ("tsmc_tw", "tsmc", "foundry", "TSMC Fab (Taiwan)", "Asia", 24.78, 120.99, 100),
    ("tsmc_az", "tsmc", "foundry", "TSMC Arizona", "US-AZ", 33.72, -112.10, 30),
    ("samsung_kr", "samsung", "foundry", "Samsung (Korea)", "Asia", 37.0, 127.11, 60),
    ("intel_az", "intel", "foundry", "Intel (Chandler AZ)", "US-AZ", 33.30, -111.84, 25),
    ("tsmc_cowos", "tsmc", "packaging", "TSMC CoWoS (Taiwan)", "Asia", 24.47, 120.96, 55),
    ("ase_tw", "ase", "packaging", "ASE (Taiwan)", "Asia", 22.63, 120.30, 25),
    ("amkor_az", "amkor", "packaging", "Amkor (Peoria AZ)", "US-AZ", 33.58, -112.24, 12),
    ("skhynix_kr", "skhynix", "hbm", "SK Hynix (Korea)", "Asia", 37.28, 127.44, 48),
    ("micron_id", "micron", "hbm", "Micron (Boise ID)", "US-ID", 43.62, -116.20, 20),
    ("nvidia_hq", "nvidia", "accelerator", "Nvidia (Santa Clara)", "US-CA", 37.35, -121.97, 90),
    ("foxconn_mx", "foxconn", "systems", "Foxconn (Mexico)", "Americas", 20.67, -103.35, 30),
    ("dell_tx", "dell", "systems", "Dell (Round Rock TX)", "US-TX", 30.51, -97.68, 22),
]

_LAYERS = [
    ("equipment", "Semi equipment"),
    ("foundry", "Foundry"), ("packaging", "Packaging / CoWoS"), ("hbm", "HBM memory"),
    ("accelerator", "Accelerator (GPU/ASIC)"), ("systems", "Systems / networking"),
    ("datacenter", "Data center"), ("power", "Power"), ("cloud", "Cloud / operator"),
    ("enduser", "End-user (AI lab)"),
]

# sku: id, name, trend (30-day drift)
_SKUS = [
    ("h100", "H100", -0.006), ("h200", "H200", -0.004), ("b200", "B200", -0.0015),
    ("b300", "B300", 0.001), ("gb200", "GB200", 0.0012), ("gb300", "GB300", 0.0018),
]
_PROV = [("coreweave", "CoreWeave"), ("crusoe", "Crusoe"), ("nebius", "Nebius"),
         ("oracle", "Oracle"), ("microsoft", "Azure"), ("amazon", "AWS")]
# provider → sku → on-demand $/GPU-hr (None = no offering)
_PX = {
    "coreweave": {"h100": 2.79, "h200": 3.79, "b200": 5.5, "b300": 6.5, "gb200": 7.2, "gb300": 8.6},
    "crusoe": {"h100": 2.45, "h200": 3.35, "b200": 4.9, "b300": 6.0, "gb200": 6.8, "gb300": 8.1},
    "nebius": {"h100": 2.30, "h200": 3.20, "b200": 4.7, "b300": 5.8, "gb200": 6.5, "gb300": None},
    "oracle": {"h100": 3.20, "h200": 4.10, "b200": 6.2, "b300": 7.6, "gb200": 8.0, "gb300": 9.6},
    "microsoft": {"h100": 6.98, "h200": 9.8, "b200": 12.5, "b300": 15.0, "gb200": 14.0, "gb300": 16.5},
    "amazon": {"h100": 5.20, "h200": 6.88, "b200": 9.5, "b300": None, "gb200": 11.0, "gb300": 13.0},
}
_TERM_MULT = {"on_demand": 1.0, "reserved_1yr": 0.62, "spot": 0.48}
# Kalshi market-implied 3-month forward on-demand median; covered = live curve today
_FWD = {"h100": 2.75, "h200": 3.55, "b200": 5.10, "b300": 7.30, "gb200": 8.30, "gb300": 10.10}
_FWD_COVERED = {"h100", "h200", "b200"}


def build_seed() -> dict:
    """Assemble the illustrative compute-chain seed as the v1.2 read-model blocks."""
    entities = [
        {"id": i, "name": nm, "layer": ly, "category": cat, "ticker": tk,
         "market_cap": mc, "revenue": rev, "cap_index": cap, "peers": peers,
         **({"estimated": True} if est else {})}
        for (i, nm, ly, cat, tk, mc, rev, cap, peers, est) in _ENT
    ]
    edges = [
        {"from": s, "to": b, "relation": "supplies",
         "value": {"pct_cogs": cogs, "pct_revenue": rev, "disclosed": disc}}
        for (s, b, cogs, rev, disc) in _SUP
    ]
    projects = [
        {"id": i, "name": nm, "developer": dev, "operator": op, "tenant": ten,
         "end_user": eu, "power": pw, "category": cat, "state": st, "lat": lat,
         "lng": lng, "capacity_mw": mw, "status": stat, "confidence": conf, "sources": srcs}
        for (i, nm, dev, op, ten, eu, pw, cat, st, lat, lng, mw, stat, conf, srcs) in _PROJECTS
    ]
    power = [
        {"id": i, "name": nm, "technology": tech, "capacity_mw": mw, "state": st,
         "lat": lat, "lng": lng, "status": stat, "btm": btm, "linked": lk,
         "confidence": conf, "sources": srcs}
        for (i, nm, tech, mw, st, lat, lng, stat, btm, lk, conf, srcs) in _POWER
    ]
    assets = [
        {"id": i, "entity": ent, "layer": ly, "name": nm, "region": rg,
         "lat": lat, "lng": lng, "cap": cap}
        for (i, ent, ly, nm, rg, lat, lng, cap) in _UP
    ]
    layers = [{"id": i, "label": lbl} for (i, lbl) in _LAYERS]
    skus = [{"id": i, "name": nm, "trend": tr} for (i, nm, tr) in _SKUS]
    providers = [{"id": i, "name": nm} for (i, nm) in _PROV]
    prices = [
        {"provider": p, "sku": sku, "usd_per_gpu_hr": px}
        for p, row in _PX.items() for sku, px in row.items() if px is not None
    ]
    forwards = [
        {"sku": sku, "horizon_mo": 3, "usd_per_gpu_hr": px, "covered": sku in _FWD_COVERED}
        for sku, px in _FWD.items()
    ]
    return {
        "layers": layers,
        "chain": {"entities": entities, "edges": edges},
        "projects": projects,
        "power": power,
        "assets": assets,
        "skus": skus,
        "providers": providers,
        "prices": prices,
        "price_terms": _TERM_MULT,
        "forwards": forwards,
    }

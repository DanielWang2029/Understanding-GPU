"""Exa client — neural web search for discovery (Design Y).

Exa returns clean per-result URLs with publish dates, which makes field-level
provenance straightforward. We use `/search` with inline contents so one call
yields both the candidate URL and enough text to seed extraction.
"""
from __future__ import annotations

from typing import Any

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from ..config import settings
from . import spend


class ExaError(RuntimeError):
    pass


def _headers() -> dict[str, str]:
    if not settings.exa_api_key:
        raise ExaError("EXA_API_KEY not set — cannot call Exa")
    return {"x-api-key": settings.exa_api_key, "Content-Type": "application/json"}


@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=15))
def _post(path: str, payload: dict) -> dict:
    with httpx.Client(timeout=60) as client:
        r = client.post(f"{settings.exa_base_url}{path}", headers=_headers(), json=payload)
        r.raise_for_status()
        return r.json()


def search(
    query: str,
    *,
    num_results: int = 10,
    start_published_date: str | None = None,
    include_domains: list[str] | None = None,
    with_text: bool = True,
) -> list[dict[str, Any]]:
    """Return a list of {url, title, published_date, author, text}."""
    payload: dict[str, Any] = {
        "query": query,
        "type": "auto",
        "numResults": num_results,
    }
    if start_published_date:
        payload["startPublishedDate"] = start_published_date
    if include_domains:
        payload["includeDomains"] = include_domains
    if with_text:
        payload["contents"] = {"text": {"maxCharacters": 8000}}

    spend.LEDGER.check("exa search")
    data = _post("/search", payload)
    spend.LEDGER.record_call("exa_search")

    out: list[dict[str, Any]] = []
    for r in data.get("results", []) or []:
        out.append({
            "url": r.get("url"),
            "title": r.get("title"),
            "published_date": r.get("publishedDate"),
            "author": r.get("author"),
            "text": r.get("text") or "",
        })
    return out

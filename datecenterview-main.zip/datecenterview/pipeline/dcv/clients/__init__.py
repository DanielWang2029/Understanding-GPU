"""External API clients for Phase B (Design Y).

- grok:      xAI — discovery Agent Tools search + cheap extraction (different vendor from verifier)
- claude:    Anthropic — cross-vendor verify / trust gate
- exa:       neural web search — discovery
- firecrawl: fetch & clean URL -> text + metadata
- spend:     shared cost ledger enforcing the daily spend cap (spec §9)

Each client is a thin HTTP wrapper (httpx + tenacity), degrades gracefully, and
routes token usage through `spend` so cost scales with the delta, not DB size.
"""

"""FMP client — the financial spine (L9), automation path.

Two shapes, like the other clients:
  - `income_statement(symbol)` → /stable/income-statement  (revenue, costOfRevenue, netIncome, filingDate)
  - `batch_market_cap(symbols)` → /stable/market-capitalization-batch

PLAN CONSTRAINT (probed 2026-07-19): the FMP subscription reachable in this
project serves a FIXED SET OF 8 MEGA-CAP TICKERS (`ALLOWED`). income-statement
AND market-cap are both access-denied for every other symbol. So this REST client
only yields real data for `ALLOWED`; the rest of the backbone is covered by the
committed fixture (compute_seed estimates) until coverage is widened via EDGAR /
Finnhub / an FMP upgrade. See `build_financials_fixture.py` + `dcv load-financials`.

L9 — Financial / market-graph loop (5-line contract; see loop-design skill):
  1. Setpoint  — every backbone entity carries revenue ≤1-quarter fresh (disclosed);
                 market_cap where the source allows.
  2. Measured  — revenue coverage %, staleness vs filingDate, market_cap availability %.
  3. Error     — missing / stale / an estimate that diverges from a new disclosure.
  4. Correction— re-pull income-statement; reconcile vs the filing anchor; on a new
                 disclosure replace the estimate and log the delta (L4).
  5. Mechanisms— deadband on tiny market_cap moves (material_move) · circuit breaker on
                 repeated FMP errors (CircuitBreaker) · separate horizons (validator).
                 Guardrail: disclosed > estimated (financials.py). Reconciliation vs a
                 re-fetched filing anchor is DEFERRED (open-loop) — tracked as review C2;
                 needs a live re-pull + a filing source we don't wire yet.

Conformance (loop-design gate) — each L9 line → code, honest about what's deferred:
  Setpoint      → validator freshness horizons (validate_data.FIN_HORIZON)
  Measured      → meta.rollups.financials_coverage (emit._fin_coverage) [LIVE]
  Error         → freshness warns + financials_integrity (validate_data)
  Correction    → fixture reload + ChangeLog delta-log (financials.load_financials);
                  live re-pull + filing reconciliation DEFERRED (C2)
  Mechanisms    → material_move (deadband) + CircuitBreaker (this file) + disclosed>estimated

The deadband + circuit-breaker helpers live here so both the REST path and the
fixture loader (`dcv/financials.py`) share one guardrail implementation.
"""
from __future__ import annotations

from typing import Any

import httpx

from ..config import settings

# the exact tickers the connected FMP plan serves (income-statement + market-cap)
ALLOWED = {"NVDA", "TSM", "INTC", "AMD", "MSFT", "GOOGL", "AMZN", "META"}

BASE = "https://financialmodelingprep.com/stable"

# market_cap moves below this fraction are noise — don't rewrite the stored value (L9 deadband)
MARKET_CAP_DEADBAND = 0.02


class FMPError(RuntimeError):
    pass


class FMPAccessDenied(FMPError):
    """Symbol/endpoint gated by the current plan tier (expected for non-ALLOWED tickers)."""


def material_move(old: float | None, new: float | None,
                  deadband: float = MARKET_CAP_DEADBAND) -> bool:
    """L9 deadband: True if `new` differs from `old` by more than `deadband` (fractional).
    A None old (first observation) is always material; a None new never is."""
    if new is None:
        return False
    if old in (None, 0):
        return True
    return abs(new - old) / abs(old) > deadband


class CircuitBreaker:
    """Trips OPEN after `threshold` consecutive failures and then blocks calls, so a
    failing (or newly-gated) FMP isn't hammered. A success resets it. Access-denial is
    NOT a failure (it's an expected per-ticker plan-gate), only transient/HTTP errors are."""

    def __init__(self, threshold: int = 5):
        self.threshold = threshold
        self.failures = 0
        self.open = False

    def before(self) -> None:
        if self.open:
            raise FMPError(f"FMP circuit breaker OPEN ({self.failures} consecutive failures) — not calling")

    def record_success(self) -> None:
        self.failures = 0
        self.open = False

    def record_failure(self) -> None:
        self.failures += 1
        if self.failures >= self.threshold:
            self.open = True


_BREAKER = CircuitBreaker()


def _is_error_body(body: Any) -> bool:
    """FMP frequently returns HTTP 200 with an error envelope for gated/invalid requests;
    detecting it prevents `rows[0]` from silently reading a stray key off the error dict."""
    return isinstance(body, dict) and ("Error Message" in body or "error" in body)


def _params(extra: dict[str, Any]) -> dict[str, Any]:
    if not settings.fmp_api_key:
        raise FMPError("FMP_API_KEY not set — REST path unavailable; use the fixture "
                       "(build_financials_fixture.py → `dcv financials load`)")
    return {**extra, "apikey": settings.fmp_api_key}


def _get(path: str, params: dict[str, Any]) -> Any:
    _BREAKER.before()
    try:
        r = httpx.get(f"{BASE}/{path}", params=_params(params), timeout=30)
    except httpx.HTTPError as e:
        _BREAKER.record_failure()
        raise FMPError(f"FMP request failed: {e}") from e
    if r.status_code in (401, 402, 403):  # plan-gate: expected, not a transient failure
        raise FMPAccessDenied(f"{path} {params.get('symbol','')} — plan-gated ({r.status_code})")
    if r.status_code != 200:
        _BREAKER.record_failure()
        raise FMPError(f"FMP {path} → HTTP {r.status_code}: {r.text[:200]}")
    body = r.json()
    if _is_error_body(body):  # HTTP 200 + error envelope → don't let it corrupt rows[0]
        raise FMPAccessDenied(f"{path} {params.get('symbol','')} — error body: {str(body)[:120]}")
    _BREAKER.record_success()
    return body


def income_statement(symbol: str, period: str = "annual", limit: int = 1) -> dict[str, Any]:
    """Latest income statement. Raises FMPAccessDenied for tickers outside the plan."""
    rows = _get("income-statement", {"symbol": symbol, "period": period, "limit": limit})
    if not rows:
        raise FMPError(f"income-statement {symbol} — empty")
    return rows[0]


def batch_market_cap(symbols: list[str]) -> dict[str, float]:
    """{symbol: marketCap} for whatever the plan returns (a subset — silently drops the rest)."""
    rows = _get("market-capitalization-batch", {"symbols": ",".join(symbols)})
    return {r["symbol"]: r["marketCap"] for r in rows if r.get("marketCap") is not None}

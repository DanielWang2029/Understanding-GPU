"""Anthropic Claude client — the cross-vendor verify / trust gate (Design Y).

Claude is a *different vendor* than the Grok extractor, so its agreement is real
signal (architecture decision #4). It runs with the server-side web_search tool
enabled so it can *independently re-search* a claim rather than just re-reading
the extractor's page. Returns a structured verdict (parsed JSON).
"""
from __future__ import annotations

import json
from typing import Any

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from ..config import settings
from . import spend

API = "https://api.anthropic.com/v1/messages"
WEB_SEARCH_TOOL = {"type": "web_search_20250305", "name": "web_search", "max_uses": 5}


class ClaudeError(RuntimeError):
    pass


def _headers() -> dict[str, str]:
    if not settings.anthropic_api_key:
        raise ClaudeError("ANTHROPIC_API_KEY not set — cannot call Claude verifier")
    return {
        "x-api-key": settings.anthropic_api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }


@retry(stop=stop_after_attempt(4), wait=wait_exponential(multiplier=1, min=2, max=20))
def _post(payload: dict) -> dict:
    with httpx.Client(timeout=180) as client:
        r = client.post(API, headers=_headers(), json=payload)
        r.raise_for_status()
        return r.json()


def _extract_json(text: str) -> dict:
    """Pull the JSON object out of a possibly prose-wrapped response."""
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        text = text[text.find("{"):]
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ClaudeError(f"no JSON object in verifier response: {text[:300]}")
    return json.loads(text[start : end + 1])


def verify_json(
    system: str,
    user: str,
    *,
    model: str | None = None,
    allow_web_search: bool = True,
    max_tokens: int = 2000,
) -> dict:
    """Ask Claude to verify and return a parsed JSON verdict object."""
    model = model or settings.verify_model
    payload: dict[str, Any] = {
        "model": model,
        "max_tokens": max_tokens,
        "system": system,
        "messages": [{"role": "user", "content": user}],
    }
    if allow_web_search:
        payload["tools"] = [WEB_SEARCH_TOOL]

    # Refuse BEFORE spending. `record_tokens` can only raise after the response arrives, so
    # without this the call that trips the cap is billed and then thrown away.
    spend.LEDGER.check(f"claude {model}")
    data = _post(payload)

    usage = data.get("usage", {}) or {}
    spend.LEDGER.record_tokens(
        model,
        int(usage.get("input_tokens", 0) or 0),
        int(usage.get("output_tokens", 0) or 0),
    )
    n_search = int((usage.get("server_tool_use", {}) or {}).get("web_search_requests", 0) or 0)
    for _ in range(n_search):
        spend.LEDGER.record_call("claude_web_search")

    # concatenate the text blocks (web_search_tool_result blocks are skipped)
    parts = [b.get("text", "") for b in data.get("content", []) if b.get("type") == "text"]
    text = "\n".join(p for p in parts if p).strip()
    if not text:
        raise ClaudeError(f"verifier returned no text content: {data}")
    return _extract_json(text)

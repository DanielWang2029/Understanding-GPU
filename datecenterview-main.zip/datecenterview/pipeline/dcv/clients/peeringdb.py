"""PeeringDB client — facility-directory *enumeration* of the operating install base.

PeeringDB (https://www.peeringdb.com) is a free, community-maintained registry of
interconnection / colocation facilities, exposed through an official public REST
API. It is a different ingestion shape than Phase B news discovery: news finds
*newsworthy new builds* (and so structurally misses the existing operating base),
while this *enumerates* live facilities directly from structured records — the
colo slice behind our TX "operating" coverage gap (ours ~10 vs CleanView ~125).

Anonymous GETs are allowed (rate-limited); set PEERINGDB_API_KEY in .env for
higher limits. This is the sanctioned API path — not scraping.
"""
from __future__ import annotations

from typing import Any

import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from ..config import settings

API = "https://www.peeringdb.com/api"


class PeeringDBError(RuntimeError):
    pass


def _headers() -> dict[str, str]:
    h = {"Accept": "application/json", "User-Agent": "dataCenterView/0.1 (+enumeration)"}
    key = getattr(settings, "peeringdb_api_key", "") or ""
    if key:
        h["Authorization"] = f"Api-Key {key}"
    return h


@retry(retry=retry_if_exception_type(httpx.HTTPError),
       stop=stop_after_attempt(4), wait=wait_exponential(multiplier=1, min=2, max=20))
def _get(path: str, params: dict) -> dict:
    with httpx.Client(timeout=45) as c:
        r = c.get(f"{API}/{path}", params=params, headers=_headers())
        r.raise_for_status()
        return r.json()


def facilities(state: str | None = None, country: str = "US",
               city: str | None = None, limit: int = 0) -> list[dict]:
    """Return raw PeeringDB facility objects, filtered server-side.

    `limit=0` asks for all matches; PeeringDB paginates with limit/skip, so we
    page until a short read to avoid silent truncation."""
    base: dict[str, Any] = {"country": country}
    if state:
        base["state"] = state
    if city:
        base["city"] = city

    out: list[dict] = []
    page = 250
    skip = 0
    while True:
        params = dict(base, limit=page, skip=skip)
        rows = _get("fac", params).get("data", []) or []
        out.extend(rows)
        if len(rows) < page or (limit and len(out) >= limit):
            break
        skip += page
    return out[:limit] if limit else out


def to_candidate(fac: dict) -> dict:
    """Map a PeeringDB facility to a structured data-center candidate shell
    (no LLM extraction). Operating by definition — PeeringDB lists live sites."""
    fid = fac.get("id")
    lat, lng = fac.get("latitude"), fac.get("longitude")
    addr = ", ".join(p for p in (fac.get("address1"), fac.get("address2")) if p) or None
    return {
        "source_id": f"peeringdb:{fid}",
        "url": f"https://www.peeringdb.com/fac/{fid}" if fid is not None else None,
        "project_name": (fac.get("name") or "").strip() or None,
        "operator": (fac.get("org_name") or "").strip() or None,
        "operator_id": fac.get("org_id"),
        "address": addr,
        "city": fac.get("city"),
        "state": fac.get("state"),
        "zipcode": fac.get("zipcode"),
        "country": fac.get("country"),
        "lat": lat, "lng": lng,
        "geo_precision": "exact" if (lat and lng) else ("city" if fac.get("city") else "state"),
        "status": "Operating",
        "net_count": fac.get("net_count"),   # networks present — proxy for size/importance
        "ix_count": fac.get("ix_count"),     # internet exchanges present
        "website": fac.get("website"),
        "mode": "peeringdb",
    }

"""xAI Grok client — Agent Tools search (discovery) + cheap structured extraction.

Two endpoints, both OpenAI-shaped:

  - `chat()`   → `/chat/completions`. JSON-schema structured output
                 (`response_format`) for the high-volume extractor. No search.
  - `search()` → `/responses` (Agent Tools API). Server-side `web_search` +
                 `x_search` tools; Grok agentically searches and returns
                 citations — the live-X signal that is our freshness edge over
                 CleanView. Replaces the deprecated Live Search `search_parameters`
                 (retired by xAI 2026-01-12 → 410 Gone).

Token + tool usage is routed through the shared spend ledger.
"""
from __future__ import annotations

import json
from typing import Any

import httpx
from tenacity import retry, retry_if_exception, stop_after_attempt, wait_exponential

from ..config import settings
from . import spend


class GrokError(RuntimeError):
    pass


def _headers() -> dict[str, str]:
    if not settings.xai_api_key:
        raise GrokError("XAI_API_KEY not set — cannot call Grok")
    return {
        "Authorization": f"Bearer {settings.xai_api_key}",
        "Content-Type": "application/json",
    }


def _is_retryable(exc: Exception) -> bool:
    """Retry transient failures only. A permanent 4xx (e.g. 400 bad request, 410
    gone) fails identically on every attempt — retrying it just burns the backoff
    budget, so fail fast and let the caller handle it."""
    if isinstance(exc, httpx.HTTPStatusError):
        code = exc.response.status_code
        return code == 429 or code >= 500
    return isinstance(exc, httpx.RequestError)


@retry(retry=retry_if_exception(_is_retryable),
       stop=stop_after_attempt(4), wait=wait_exponential(multiplier=1, min=2, max=20))
def _post(path: str, payload: dict) -> dict:
    with httpx.Client(timeout=120) as client:
        r = client.post(
            f"{settings.xai_base_url}/{path}",
            headers=_headers(),
            json=payload,
        )
        r.raise_for_status()
        return r.json()


# --- extraction: /chat/completions with structured output --------------------
def chat(
    system: str,
    user: str,
    *,
    model: str | None = None,
    response_schema: dict | None = None,
    temperature: float = 0.0,
) -> tuple[Any, list[str]]:
    """Return (content, citations). content is a parsed dict when response_schema
    is given, else the raw text. citations is always [] here (this endpoint does
    no search) — kept in the return for a stable call site."""
    model = model or settings.extract_model
    payload: dict[str, Any] = {
        "model": model,
        "temperature": temperature,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    }
    if response_schema is not None:
        payload["response_format"] = {
            "type": "json_schema",
            "json_schema": {"name": "extraction", "schema": response_schema, "strict": True},
        }

    spend.LEDGER.check(f"grok {model}")
    data = _post("chat/completions", payload)

    usage = data.get("usage", {}) or {}
    spend.LEDGER.record_tokens(
        model,
        int(usage.get("prompt_tokens", 0) or 0),
        int(usage.get("completion_tokens", 0) or 0),
    )

    choices = data.get("choices") or []
    if not choices:
        raise GrokError(f"Grok returned no choices: {data}")
    content = choices[0].get("message", {}).get("content", "")

    if response_schema is not None:
        try:
            content = json.loads(content) if isinstance(content, str) else content
        except json.JSONDecodeError as e:
            raise GrokError(f"Grok structured output was not valid JSON: {e}\n{content[:500]}")
    return content, []


# --- discovery: /responses Agent Tools (web_search + x_search) ---------------
def web_search_tool(
    *,
    allowed_domains: list[str] | None = None,
    excluded_domains: list[str] | None = None,
) -> dict:
    """web_search tool object. allowed/excluded domains are mutually exclusive
    (xAI rejects both together) and capped at 5; they nest under `filters`."""
    tool: dict[str, Any] = {"type": "web_search"}
    if allowed_domains:
        tool["filters"] = {"allowed_domains": allowed_domains[:5]}
    elif excluded_domains:
        tool["filters"] = {"excluded_domains": excluded_domains[:5]}
    return tool


def x_search_tool(
    *,
    from_date: str | None = None,
    to_date: str | None = None,
    allowed_handles: list[str] | None = None,
) -> dict:
    """x_search tool object. Params sit at the top level of the tool (not under
    `filters`). Dates are ISO8601 'YYYY-MM-DD'; handles capped at 20."""
    tool: dict[str, Any] = {"type": "x_search"}
    if from_date:
        tool["from_date"] = from_date
    if to_date:
        tool["to_date"] = to_date
    if allowed_handles:
        tool["allowed_x_handles"] = allowed_handles[:20]
    return tool


def _responses_text(data: dict) -> str:
    """Concatenate the output_text blocks of a /responses payload."""
    parts: list[str] = []
    for item in data.get("output") or []:
        if item.get("type") != "message":
            continue
        for block in item.get("content") or []:
            if block.get("type") == "output_text" and block.get("text"):
                parts.append(block["text"])
    return "\n".join(parts)


def _responses_citations(data: dict) -> list[str]:
    """Collect source URLs: the top-level `citations` array (returned by default),
    unioned with any url_citation annotations, deduped in first-seen order."""
    urls: list[str] = []
    seen: set[str] = set()

    def _add(u: Any) -> None:
        u = u if isinstance(u, str) else (u.get("url") if isinstance(u, dict) else None)
        if u and u not in seen:
            seen.add(u)
            urls.append(u)

    for c in data.get("citations") or []:
        _add(c)
    for item in data.get("output") or []:
        for block in item.get("content") or []:
            for ann in block.get("annotations") or []:
                if isinstance(ann, dict):
                    _add(ann.get("url"))
    return urls


def search(
    prompt: str,
    tools: list[dict],
    *,
    model: str | None = None,
    system: str | None = None,
) -> tuple[str, list[str]]:
    """Agent Tools search on `/responses`. Returns (text, citation_urls).

    `input` is sent as a plain string (the Responses API accepts that); an
    optional `system` framing is prepended. The tools require grok-4.5."""
    model = model or settings.discovery_model
    text_in = f"{system.strip()}\n\n{prompt}" if system else prompt
    payload: dict[str, Any] = {"model": model, "input": text_in, "tools": tools}

    spend.LEDGER.check(f"grok search {model}")
    data = _post("responses", payload)

    usage = data.get("usage", {}) or {}
    # The Responses API reports input_tokens/output_tokens; chat/completions uses
    # prompt_/completion_. Read the new names, fall back to the old.
    spend.LEDGER.record_tokens(
        model,
        int(usage.get("input_tokens", usage.get("prompt_tokens", 0)) or 0),
        int(usage.get("output_tokens", usage.get("completion_tokens", 0)) or 0),
    )
    spend.LEDGER.record_call("grok_agent_search")

    return _responses_text(data), _responses_citations(data)

"""verifiers — a vendor-NEUTRAL verifier interface, so "which model should hold the trust
gate" can be measured instead of assumed.

`clients/claude.py` is Anthropic-shaped by construction: it hardcodes the Messages API, the
Anthropic web-search tool, and Anthropic's usage block. That is correct for the pipeline's
verifier of record, but it means the incumbent cannot be *compared* to anything — there is no
seam to put a second vendor behind. This module is that seam.

Two things it deliberately does that `claude.py` does not:

1. **It distinguishes the ways a verifier can fail to answer.** `claude.py` funnels every
   non-answer into one `ClaudeError` ("verifier returned no text content"), which
   `phaseb.verify` catches and turns into "held as reported". So a model that REFUSED, a model
   that ran out of `max_tokens` mid-JSON, and a model that returned prose instead of an object
   are all recorded as the same event — and the first two are configuration problems wearing a
   quality problem's clothes. Here they are separate outcomes:
       ok · schema_miss · malformed · truncated · refusal · error
   A bake-off that could not tell `truncated` from `malformed` would rank a verbose model as
   unreliable when the real fix is a bigger `max_tokens`.

2. **It measures rather than derives cost.** Every call returns its own token counts, search
   count and wall-clock latency, priced at the slate's declared rate. A $/record figure
   computed from a price list and an assumed token count is a projection; this is a bill.

Search capability is declared per backend and REPORTED, never inferred. A verifier with no web
search cannot find the independent second source that `phaseb.verify` requires to reach
`approved` — so comparing a searching model against a non-searching one on "corroboration
rate" measures the tool, not the model. The report groups by this field for that reason.

Loop framing (loop-design): setpoint = the trust gate is held by the best cost-adjusted
verifier that can actually corroborate; measured = per-backend outcome mix, corroboration rate
and measured $/record; error = incumbent is dominated on cost at equal reliability; correction
= swap `settings.verify_model`; mechanism = controlled same-input comparison (identical
records, identical prompt, temperature 0 where supported); guardrail = the shared spend ledger
caps the run, an unpriced model is REFUSED rather than run for free (see spend.register_price),
and this module holds no write path to the store.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field as dc_field
from typing import Any

import httpx

from ..config import settings
from . import spend

# The three fields the trust gate renders a verdict on (mirrors phaseb.verify.CRITICAL).
_VERDICT_KEYS = ("capacity_mw", "status", "location")
_VERDICT_VALUES = {"agree", "disagree", "unverifiable"}

# Match the production verifier's budget exactly — the bake-off measures behaviour under the
# conditions the pipeline actually runs, not under a friendlier one.
MAX_TOKENS = 2000


@dataclass(frozen=True)
class Backend:
    """One candidate verifier. `price` is ($/1M in, $/1M out) and is REQUIRED — a model with
    no declared price would bill silently past the spend cap (see spend.SpendLedger)."""
    name: str                       # display id in the report
    vendor: str                     # anthropic · xai · openrouter · openai · …
    model: str                      # wire model id
    price: tuple[float, float]
    transport: str = "anthropic"    # anthropic | openai_chat
    search: str = "none"            # native | none — DECLARED, never inferred
    base_url: str = ""
    api_key_env: str = "ANTHROPIC_API_KEY"
    enabled: bool = True
    note: str = ""
    #: False when the price above is a working figure I have not checked against the
    #: vendor's current published rate. The whole comparison is a $/record ranking, so a
    #: guessed rate that reads as measured is the one error that silently changes the answer.
    #: `plan()` and `report()` mark these; confirm before acting on the row.
    price_confirmed: bool = True
    #: Sent only when set. `None` is the right default for Anthropic: `temperature` is
    #: DEPRECATED on Opus 4.8 / Opus 5 / Sonnet 5 and 400s the request, while Haiku 4.5 still
    #: accepts it — so pinning it for determinism silently disqualifies three of the four
    #: candidates and leaves the cheapest one looking like the only model that works. It also
    #: matches production: clients/claude.py sends no temperature either, and the bake-off
    #: must measure the configuration the pipeline actually runs.
    temperature: float | None = None
    extra: dict = dc_field(default_factory=dict)

    @property
    def api_key(self) -> str:
        # settings loads .env into os.environ, so both paths see the same values.
        return os.environ.get(self.api_key_env, "") or (
            settings.anthropic_api_key if self.api_key_env == "ANTHROPIC_API_KEY"
            else settings.xai_api_key if self.api_key_env == "XAI_API_KEY" else "")

    @property
    def has_key(self) -> bool:
        return bool(self.api_key)


@dataclass
class Attempt:
    """One backend's answer for one record. `outcome` is the taxonomy above."""
    backend: str
    record_id: str
    outcome: str
    verdicts: dict[str, Any] = dc_field(default_factory=dict)
    detail: str | None = None
    in_tokens: int = 0
    out_tokens: int = 0
    searches: int = 0
    #: ALL-IN: tokens + server-side search calls. Tokens alone would understate every
    #: searching model — at ~5 searches/record the search line is comparable to Haiku's
    #: entire token bill, so a token-only "$/record" makes the cheap model look cheaper than
    #: it is and the comparison decides on a number nobody is billed.
    usd: float = 0.0
    usd_tokens: float = 0.0
    usd_search: float = 0.0
    latency_s: float = 0.0

    @property
    def answered(self) -> bool:
        """Did we get a usable verdict object? `schema_miss` is not usable."""
        return self.outcome == "ok"


def from_spec(spec: dict) -> Backend:
    """Build a Backend from a JSON slate entry, failing loudly on a missing price."""
    price = spec.get("price")
    if not (isinstance(price, (list, tuple)) and len(price) == 2):
        raise ValueError(
            f"backend {spec.get('name', '?')!r} has no [input, output] price — refusing to "
            f"run it. An unpriced model bills $0.00 through the ledger, so the spend cap "
            f"silently stops binding (spend.SpendLedger.record_tokens)."
        )
    known = {f for f in Backend.__dataclass_fields__}
    return Backend(**{k: (tuple(v) if k == "price" else v)
                      for k, v in spec.items() if k in known})


# --------------------------------------------------------------------- parsing / classifying
def parse_verdicts(text: str) -> tuple[dict | None, str, str | None]:
    """(verdicts, outcome, detail). Splits "the model did not return our object" into the
    three cases that have different fixes: not JSON at all, JSON of the wrong shape, and JSON
    whose verdict strings are outside the enum."""
    if not text or not text.strip():
        return None, "malformed", "empty response body"
    t = text.strip()
    if t.startswith("```"):
        t = t.strip("`")
        t = t[t.find("{"):] if "{" in t else t
    start, end = t.find("{"), t.rfind("}")
    if start == -1 or end == -1 or end < start:
        return None, "malformed", f"no JSON object: {text[:160]!r}"
    try:
        obj = json.loads(t[start:end + 1])
    except json.JSONDecodeError as e:
        return None, "malformed", f"invalid JSON: {e}"
    if not isinstance(obj, dict):
        return None, "schema_miss", f"top level is {type(obj).__name__}, not an object"
    present = [k for k in _VERDICT_KEYS if isinstance(obj.get(k), dict)]
    if not present:
        return None, "schema_miss", f"no verdict key of {_VERDICT_KEYS}; got {list(obj)[:6]}"
    bad = [f"{k}={obj[k].get('verdict')!r}" for k in present
           if obj[k].get("verdict") not in _VERDICT_VALUES]
    if bad:
        return obj, "schema_miss", f"verdict outside the enum: {', '.join(bad)}"
    return obj, "ok", None


# ------------------------------------------------------------------------------- transports
@dataclass
class _Raw:
    text: str = ""
    in_tokens: int = 0
    out_tokens: int = 0
    searches: int = 0
    stop: str | None = None


def _anthropic(b: Backend, system: str, user: str, timeout: float) -> _Raw:
    payload: dict[str, Any] = {
        "model": b.model,
        "max_tokens": MAX_TOKENS,
        "system": system,
        "messages": [{"role": "user", "content": user}],
    }
    if b.temperature is not None:
        payload["temperature"] = b.temperature
    if b.search == "native":
        payload["tools"] = [{"type": b.extra.get("web_search_tool", "web_search_20250305"),
                             "name": "web_search",
                             "max_uses": b.extra.get("max_uses", 5)}]
    payload.update(b.extra.get("body") or {})
    with httpx.Client(timeout=timeout) as c:
        r = c.post(f"{b.base_url or 'https://api.anthropic.com'}/v1/messages",
                   headers={"x-api-key": b.api_key, "anthropic-version": "2023-06-01",
                            "content-type": "application/json"}, json=payload)
        r.raise_for_status()
        data = r.json()
    usage = data.get("usage") or {}
    parts = [blk.get("text", "") for blk in data.get("content") or []
             if blk.get("type") == "text"]
    return _Raw(
        text="\n".join(p for p in parts if p).strip(),
        in_tokens=int(usage.get("input_tokens") or 0),
        out_tokens=int(usage.get("output_tokens") or 0),
        searches=int((usage.get("server_tool_use") or {}).get("web_search_requests") or 0),
        # The signal claude.py drops on the floor: a refusal and a truncation both arrive as
        # HTTP 200 with unusable content, and only stop_reason tells them apart.
        stop=data.get("stop_reason"),
    )


def _openai_chat(b: Backend, system: str, user: str, timeout: float) -> _Raw:
    """OpenAI-shaped /chat/completions — covers xAI, OpenRouter, OpenAI, Gemini's compat
    endpoint and most hosted open-weight providers behind one adapter, which is why a single
    aggregator key is enough to widen the slate."""
    payload: dict[str, Any] = {
        "model": b.model,
        "max_tokens": MAX_TOKENS,
        "messages": [{"role": "system", "content": system},
                     {"role": "user", "content": user}],
    }
    if b.temperature is not None:
        payload["temperature"] = b.temperature
    if b.extra.get("json_mode"):
        payload["response_format"] = {"type": "json_object"}
    payload.update(b.extra.get("body") or {})
    with httpx.Client(timeout=timeout) as c:
        r = c.post(f"{b.base_url.rstrip('/')}/chat/completions",
                   headers={"Authorization": f"Bearer {b.api_key}",
                            "Content-Type": "application/json"}, json=payload)
        r.raise_for_status()
        data = r.json()
    usage = data.get("usage") or {}
    choices = data.get("choices") or []
    msg = (choices[0].get("message") or {}) if choices else {}
    finish = choices[0].get("finish_reason") if choices else None
    return _Raw(
        text=(msg.get("content") or "").strip(),
        in_tokens=int(usage.get("prompt_tokens") or usage.get("input_tokens") or 0),
        out_tokens=int(usage.get("completion_tokens") or usage.get("output_tokens") or 0),
        searches=int((b.extra.get("assumed_searches") or 0) if b.search == "native" else 0),
        # normalize onto the Anthropic vocabulary so the taxonomy is one taxonomy
        stop={"length": "max_tokens", "content_filter": "refusal"}.get(finish, finish),
    )


_TRANSPORTS = {"anthropic": _anthropic, "openai_chat": _openai_chat}


# ------------------------------------------------------------------------------------ call
def call(b: Backend, system: str, user: str, record_id: str,
         timeout: float = 180.0) -> Attempt:
    """Run one backend over one record. Never raises: a transport failure is an `error`
    outcome, because a bake-off that aborts on the first flaky vendor measures nothing."""
    t0 = time.monotonic()
    try:
        raw = _TRANSPORTS[b.transport](b, system, user, timeout)
    except Exception as e:  # transport / HTTP / auth — all measurable, none fatal
        detail = f"{type(e).__name__}: {e}"
        if isinstance(e, httpx.HTTPStatusError):
            detail = f"HTTP {e.response.status_code}: {e.response.text[:200]}"
        return Attempt(b.name, record_id, "error", detail=detail,
                       latency_s=round(time.monotonic() - t0, 2))

    latency = round(time.monotonic() - t0, 2)
    pin, pout = b.price
    usd_tokens = (raw.in_tokens / 1e6) * pin + (raw.out_tokens / 1e6) * pout
    search_kind = "claude_web_search" if b.vendor == "anthropic" else "grok_agent_search"
    usd_search = raw.searches * spend.SEARCH_COSTS.get(search_kind, 0.0)
    # Route through the shared ledger so the run-level spend cap (L5) genuinely binds. The
    # $/record we REPORT is computed above from the slate's declared price, so the report
    # cannot silently disagree with the rate the reader was shown.
    spend.LEDGER.record_tokens(b.model, raw.in_tokens, raw.out_tokens)
    for _ in range(raw.searches):
        spend.LEDGER.record_call(search_kind)

    def _a(outcome: str, verdicts: dict | None = None, detail: str | None = None) -> Attempt:
        return Attempt(b.name, record_id, outcome, verdicts or {}, detail,
                       raw.in_tokens, raw.out_tokens, raw.searches,
                       round(usd_tokens + usd_search, 6), round(usd_tokens, 6),
                       round(usd_search, 6), latency)

    if raw.stop == "refusal":
        return _a("refusal", detail="stop_reason=refusal")
    verdicts, outcome, detail = parse_verdicts(raw.text)
    # Truncation outranks the parse result: JSON cut off at max_tokens is unparseable for a
    # reason that has nothing to do with the model's instruction-following.
    if outcome != "ok" and raw.stop == "max_tokens":
        return _a("truncated", verdicts, f"hit max_tokens={MAX_TOKENS}; {detail}")
    return _a(outcome, verdicts, detail)

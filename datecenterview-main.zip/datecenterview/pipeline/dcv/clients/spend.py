"""Shared spend ledger — the cost-control valve (architecture proposal §7, phase-b §9).

Every paid call routes its usage through `record_*`; the ledger accumulates an
estimated USD cost and raises `SpendLimitError` once the run crosses the cap.
Prices are per 1M tokens (input/output), verified July 2026 — keep them here so a
price change is a one-line edit, not a hunt through the clients.
"""
from __future__ import annotations

from dataclasses import dataclass, field

# per 1M tokens: (input, output). Source: pricing sweep July 2026.
# grok-4.20 non-reasoning / 4.3 are estimates pending exact SKU pricing.
TOKEN_PRICES: dict[str, tuple[float, float]] = {
    "grok-4.20-0309-non-reasoning": (0.50, 1.50),
    "grok-4.20-0309-reasoning": (2.00, 6.00),
    "grok-4.3": (1.00, 3.00),
    "grok-4.5": (2.00, 6.00),
    "claude-opus-4-8": (5.00, 25.00),
    "claude-opus-5": (5.00, 25.00),
    # LIST price, not the $2/$10 introductory rate that expires 2026-08-31. Sonnet 5 became
    # the verifier of record on 2026-07-30, so it is now the pipeline's highest-volume paid
    # call — and a cap that under-prices the dominant call stops binding on the day the intro
    # rate lapses. Erring high trips the cap early (safe); erring low overspends (not).
    "claude-sonnet-5": (3.00, 15.00),
    "claude-haiku-4-5": (1.00, 5.00),
}

# per-call tool costs (USD each)
SEARCH_COSTS: dict[str, float] = {
    "exa_search": 0.005,         # ~$5 / 1k searches (neural)
    "grok_agent_search": 0.020,  # xAI Agent Tools: agentic multi-round web+X search / call (est.)
    "grok_live_search": 0.005,   # deprecated xAI Live Search (410) — kept for legacy ledgers
    "claude_web_search": 0.010,  # Anthropic web search: ~$10 / 1k calls
    "firecrawl_scrape": 0.001,   # Firecrawl Hobby-tier effective per-page
}


class SpendLimitError(BaseException):
    """Raised when the estimated run cost exceeds the configured daily cap.

    Inherits **BaseException**, not Exception, and that is the whole point.

    Every paid call site in this codebase wraps its call in `except Exception` so that one bad
    filing or one flaky vendor cannot sink a batch — which is correct. But a RuntimeError-based
    spend cap is caught by exactly those handlers, and the caller then CONTINUES ITS LOOP. The
    next iteration makes another real, billed API call, trips the cap again, gets swallowed
    again. Measured consequence on a 400-record Phase B sweep with a $25 cap: it would trip at
    ~180 records and then bill ~220 further calls (~$30) while marking every one of them
    `reported` — the cap converted "stop spending" into "keep spending and discard the results".

    So this is control flow, not an error condition, and it belongs in the same class as
    KeyboardInterrupt and SystemExit: never caught by accident, only on purpose. The
    orchestrators that are SUPPOSED to handle it (`phaseb.pipeline`, `bakeoff.run`,
    `chain_*.run`) name it explicitly and still work.
    """


@dataclass
class SpendLedger:
    limit_usd: float = 25.0
    total_usd: float = 0.0
    calls: int = 0
    by_model: dict[str, float] = field(default_factory=dict)
    #: models billed at $0 because TOKEN_PRICES has no entry. Tracked because an unpriced
    #: model is INVISIBLE to the cap — it accumulates real spend that this ledger scores as
    #: zero, so the run never trips the limit. Harmless while the model set was fixed and
    #: fully priced; load-bearing the moment a new model id can be introduced from a config
    #: file (see bakeoff / verifiers.Backend, which refuses to run an unpriced backend).
    unpriced: set[str] = field(default_factory=set)

    def check(self, what: str = "call") -> None:
        """Raise if the cap is ALREADY exceeded — call this BEFORE a paid request.

        `_add` can only raise after the fact, because the cost is not known until the response
        comes back. That means the call that trips the cap has already been billed and its
        result is then discarded. Checking first makes the stop clean: once the ledger is over,
        zero further requests leave the process.
        """
        if self.limit_usd and self.total_usd > self.limit_usd:
            raise SpendLimitError(
                f"spend cap reached before {what}: ${self.total_usd:.2f} > "
                f"${self.limit_usd:.2f} after {self.calls} calls ({self.summary()})")

    def _add(self, label: str, usd: float) -> None:
        self.total_usd += usd
        self.calls += 1
        self.by_model[label] = self.by_model.get(label, 0.0) + usd
        if self.limit_usd and self.total_usd > self.limit_usd:
            raise SpendLimitError(
                f"spend cap hit: ${self.total_usd:.2f} > ${self.limit_usd:.2f} "
                f"after {self.calls} calls ({self.summary()})"
            )

    def record_tokens(self, model: str, in_tokens: int, out_tokens: int) -> float:
        prices = TOKEN_PRICES.get(model)
        if prices is None:
            self.unpriced.add(model)
            prices = (0.0, 0.0)
        pin, pout = prices
        usd = (in_tokens / 1_000_000) * pin + (out_tokens / 1_000_000) * pout
        self._add(model, usd)
        return usd

    def record_call(self, kind: str, n: int = 1) -> float:
        usd = SEARCH_COSTS.get(kind, 0.0) * n
        self._add(kind, usd)
        return usd

    def summary(self) -> str:
        parts = ", ".join(f"{k}=${v:.3f}" for k, v in sorted(self.by_model.items()))
        warn = (f" ⚠ UNPRICED (billed $0, invisible to the cap): "
                f"{', '.join(sorted(self.unpriced))}") if self.unpriced else ""
        return f"${self.total_usd:.3f} over {self.calls} calls [{parts}]{warn}"


def register_price(model: str, in_usd_per_m: float, out_usd_per_m: float) -> bool:
    """Teach the ledger a model's price so the cap binds on it. Returns True if it was added.

    Non-clobbering ON PURPOSE: the committed TOKEN_PRICES entries are the rates the pipeline
    is actually billed at, and a bake-off slate quoting a go-forward list price must not
    silently rewrite production cost accounting underneath a live run.
    """
    if model in TOKEN_PRICES:
        return False
    TOKEN_PRICES[model] = (in_usd_per_m, out_usd_per_m)
    return True


# process-wide ledger; the orchestrator sets the limit from settings at run start.
LEDGER = SpendLedger()


def configure(limit_usd: float) -> None:
    LEDGER.limit_usd = limit_usd

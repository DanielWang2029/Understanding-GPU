"""SEC EDGAR client — free filings source for P3 edge quantification (L9 + L2).

No API key: EDGAR is public, but requires a descriptive User-Agent (compliance,
settings.edgar_user_agent). Endpoints:
  - submissions(cik)    → data.sec.gov/submissions/CIK##########.json (recent filings index)
  - annual_report_reach(subs) → can we reach an annual report at all? current|stale|none
  - latest_report(cik)  → newest 10-K / 20-F accession + primary doc (freshness-guarded)
  - filing_text(...)    → the filing HTML, tag-stripped to plain text
  - customer_concentration(text) → disclosed "customer … N% of total revenue" magnitudes (verbatim)

P3 reality (probed 2026-07-19): customer-concentration %s ARE disclosed (e.g. Nvidia
FY26 "one direct customer 22% of revenue") but counterparties are UNNAMED, and supplier
%COGS is essentially never disclosed as a number. So this client fetches the filing and
reads the disclosed magnitude; the counterparty linkage is inferred downstream and
flagged (`link_basis:"inferred"`). Cross-vendor verification of that inference (L2) is
the chain_quant automation path — DEFERRED (tracked P3/C2); the committed fixture is the
active path today, same pattern as clients/fmp.py.

Guardrail: shares the CircuitBreaker from clients.fmp so a failing SEC endpoint isn't
hammered. EDGAR asks for ≤10 req/s — batch politely.
"""
from __future__ import annotations

import re
from datetime import date

import httpx

from ..config import settings
from .fmp import CircuitBreaker

SUB_BASE = "https://data.sec.gov/submissions"
ARCH_BASE = "https://www.sec.gov/Archives/edgar/data"
FACTS_BASE = "https://data.sec.gov/api/xbrl/companyfacts"
_BREAKER = CircuitBreaker()

# XBRL concepts in priority order — filers tag revenue/capex differently across eras.
_REV_CONCEPTS = ("RevenueFromContractWithCustomerExcludingAssessedTax",
                 "RevenueFromContractWithCustomerIncludingAssessedTax",
                 "Revenues", "SalesRevenueNet")
_CAPEX_CONCEPTS = ("PaymentsToAcquirePropertyPlantAndEquipment",
                   "PaymentsToAcquireProductiveAssets")
_ANNUAL_FORMS = ("10-K", "20-F")

# Freshness horizon for an annual report. An annual filer's newest 10-K/20-F is at most ~12
# months old plus filing lag; 550d leaves ~6 months of slack. Anything past it means the
# filer STOPPED filing, not that it files slowly. See annual_report_reach().
STALE_AFTER_DAYS = 550


class EdgarError(RuntimeError):
    pass


def _headers() -> dict[str, str]:
    return {"User-Agent": settings.edgar_user_agent, "Accept-Encoding": "gzip, deflate"}


def _get(url: str) -> httpx.Response:
    _BREAKER.before()
    try:
        r = httpx.get(url, headers=_headers(), timeout=40, follow_redirects=True)
    except httpx.HTTPError as e:
        _BREAKER.record_failure()
        raise EdgarError(f"EDGAR request failed: {e}") from e
    if r.status_code != 200:
        _BREAKER.record_failure()
        raise EdgarError(f"EDGAR {url} → HTTP {r.status_code}")
    _BREAKER.record_success()
    return r


def _cik10(cik: str) -> str:
    return str(cik).upper().lstrip("CIK").zfill(10)


def submissions(cik: str) -> dict:
    return _get(f"{SUB_BASE}/CIK{_cik10(cik)}.json").json()


def annual_report_reach(subs: dict, forms: tuple[str, ...] = _ANNUAL_FORMS,
                        max_age_days: int = STALE_AFTER_DAYS,
                        today: date | None = None) -> dict:
    """Classify whether this filer's annual report can be REACHED, and say why if not.

    Reach is not binary. A company can be in EDGAR's ticker file, return a real 10-K/20-F,
    and still be useless: Advantest (CIK 1158838, ADR ATEYY) deregistered from the NYSE, so
    its newest 20-F is dated 2015 — 4,043 days stale as of 2026-07-20. Taking "a report came
    back" as reach stamps decade-old figures `disclosed`.

    Returns {status, report, age_days, reason} where status is:
      `current` — an annual report inside the freshness horizon; the only usable state.
      `stale`   — the filer once registered but has stopped filing (deregistered / delisted).
      `none`    — no 10-K/20-F at all (foreign issuers with no US registration).
    `stale` and `none` are both `source_out_of_reach` in the `evidence-extraction` miss
    taxonomy: facts about our REACH, never about the company, and never reportable as
    coverage. Measured across the 29-node backbone before this guard existed: all 21 SEC
    filers were ≤355 days, so the 550-day horizon has ~6 months of slack over a normal
    annual cycle and flags nothing that was previously working.
    """
    today = today or date.today()
    f = subs["filings"]["recent"]
    for i, form in enumerate(f["form"]):
        if form in forms:
            rpt = {"form": form, "accession": f["accessionNumber"][i],
                   "doc": f["primaryDocument"][i], "filed": f["filingDate"][i]}
            age = (today - date.fromisoformat(rpt["filed"])).days
            rpt["age_days"] = age
            if age > max_age_days:
                return {"status": "stale", "report": rpt, "age_days": age,
                        "reason": f"newest {form} filed {rpt['filed']} is {age}d old "
                                  f"(>{max_age_days}d) — filer appears deregistered"}
            return {"status": "current", "report": rpt, "age_days": age, "reason": None}
    return {"status": "none", "report": None, "age_days": None,
            "reason": f"no {'/'.join(forms)} in EDGAR submissions"}


def latest_report(subs: dict, forms: tuple[str, ...] = _ANNUAL_FORMS,
                  max_age_days: int = STALE_AFTER_DAYS,
                  today: date | None = None) -> dict | None:
    """Newest *current* filing among `forms`. Returns {form, accession, doc, filed, age_days}.

    Returns None when the newest such filing is staler than `max_age_days` — see
    `annual_report_reach` for why "a report came back" is not reach. Callers that need to
    distinguish stale-from-absent (the reach report) should call that instead; callers that
    just want a usable filing get the guard for free. `max_age_days=None` disables it.
    """
    reach = annual_report_reach(subs, forms, max_age_days or 10**9, today)
    return reach["report"] if reach["status"] == "current" else None


def strip_html(html: str) -> str:
    t = re.sub(r"<[^>]+>", " ", html)
    t = re.sub(r"&#[0-9]+;", " ", t)
    t = re.sub(r"&[a-z]+;", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def filing_text(cik: str, accession: str, doc: str) -> str:
    acc = accession.replace("-", "")
    cik_n = str(cik).upper().lstrip("CIK").lstrip("0") or "0"
    return strip_html(_get(f"{ARCH_BASE}/{cik_n}/{acc}/{doc}").text)


# Anchor on "customer"/"represented"/"accounted for" then the % — non-overlapping, so two
# figures in ONE sentence (e.g. "one customer 22% … another customer 14%") are both caught.
_CUST_RE = re.compile(
    r"(?:customer|represented|accounted for)[^.]{0,80}?(\d{1,2})\s*%\s*of\s*(?:our\s*)?(?:total|net|consolidated)?\s*revenue",
    re.I)


def customer_concentration(text: str) -> list[dict]:
    """Disclosed 'customer … N% of revenue' magnitudes (verbatim). The counterparty stays
    UNNAMED here — this is the disclosed magnitude only; inference is downstream."""
    out, seen = [], set()
    for m in _CUST_RE.finditer(text):
        pct = int(m.group(1))
        s = m.group(0).strip()[:300]
        if s in seen:
            continue
        seen.add(s)
        out.append({"pct": pct, "sentence": s})
    return out


# Priority-ordered anchors for the CUSTOMER-concentration disclosure (NOT geographic
# concentration, which also says "% of revenue"). Specific per-customer % patterns first.
_CONC_PATTERNS = [
    re.compile(r"(?:revenue from|sales to)[^.]{0,70}?customer[^.]{0,70}?\d{1,2}\s*%", re.I),
    re.compile(r"(?:largest|significant|single|one|direct)\s+customer[^.]{0,90}?\d{1,2}\s*%", re.I),
    re.compile(r"customer[^.]{0,50}?(?:accounted for|represented)[^.]{0,50}?\d{1,2}\s*%", re.I),
    re.compile(r"Customer\s+[A-D]\b", re.I),  # concentration table ("Customer A 67%")
    re.compile(r"customer concentration|concentration of (?:credit )?risk", re.I),
]


# A window that really holds the customer-concentration disclosure is DENSE in per-customer
# percentage language. Scoring on that separates it from a same-shaped but wrong section
# (Amkor's 10-K matched an end-market distribution table before its concentration note).
_CONC_SIGNAL = re.compile(
    r"(?:customer|customers)[^.]{0,90}?\d{1,2}(?:\.\d+)?\s*%"
    r"|\d{1,2}(?:\.\d+)?\s*%[^.]{0,90}?(?:customer|customers)"
    r"|Customer\s+[A-D]\b", re.I)


def concentration_excerpt(text: str, window: int = 1800, max_scan: int = 6) -> str:
    """A text window around the CUSTOMER-concentration disclosure, for LLM extraction
    (richer than a single sentence — captures the 'Customer A 67%' table + segment hints).

    Candidates come from every anchor pattern, then win on the DENSITY of per-customer
    percentage language, with the pattern's priority as the tie-break. Taking the first match
    of the first matching pattern (the previous behaviour) anchors on whichever same-shaped
    section happens to appear earliest in the filing — the exact failure that made Amkor look
    like it disclosed nothing when the real note sits further down. Empty means we genuinely
    found no concentration section: callers must not report that as "discloses no share".
    """
    best = None  # (score, -priority, start)
    for prio, pat in enumerate(_CONC_PATTERNS):
        for m in list(pat.finditer(text))[:max_scan]:
            # Clamp so a match near the end of the filing still gets a FULL window. Without
            # this, an anchor at the tail (TSMC's "Major customers representing at least 10%"
            # table) returns a few hundred chars that stop before the figures it introduces.
            i = min(max(0, m.start() - 220), max(0, len(text) - window))
            score = len(_CONC_SIGNAL.findall(text[i:i + window]))
            key = (score, -prio, -i)
            if best is None or key > best[0]:
                best = (key, i)
    return text[best[1]:best[1] + window] if best else ""


# supplier-dependency language that a buyer's risk factors use when NAMING a supplier —
# the identity the supplier's own concentration table withholds (spike 2026-07-20).
_DEP_KW = ("supplier", "foundry", "manufactur", "fabricat", "depend", "sourc", "supply",
           "purchase", "wafer", "contract manufactur", "third party", "third-party")


# Where a BUYER's filing enumerates its own suppliers by name — the topology source
# (chain_topology). Priority-ordered: the explicit "we purchase/utilize X from Y" language
# first, then generic supplier headers. Distinct from _CONC_PATTERNS (customer concentration).
_SUPPLIER_PATTERNS = [
    re.compile(r"we\s+(?:utilize|use|purchase|source|obtain|buy|procure)\s+[^.]{0,120}?"
               r"(?:foundr|wafer|memory|component|manufactur|supplier|packaging)", re.I),
    re.compile(r"we\s+(?:rely|depend)\s+(?:on|upon)\s+[^.]{0,120}?"
               r"(?:third[- ]part|supplier|foundr|manufactur|vendor)", re.I),
    re.compile(r"(?:our|the)\s+(?:principal|primary|key|main|significant)\s+suppliers", re.I),
    re.compile(r"contract manufactur|independent subcontractor|sole[- ]source|single[- ]source", re.I),
    re.compile(r"suppliers?\s+and\s+(?:manufactur|vendor)|supply\s+chain", re.I),
]


# A supplier roll-call is DENSE in legal-entity suffixes ("… Taiwan Semiconductor Manufacturing
# Company Limited, or TSMC, and Samsung Electronics Co., Ltd. …"); incidental supplier language
# ("we purchase certain components") is not. Used to rank candidate windows.
_COMPANY_SIGNAL = re.compile(
    r"\b(?:Inc\.|Ltd\.?|Limited|Corporation|Corp\.|Co\.,|N\.V\.|PLC|S\.A\.|GmbH|LLC|"
    r"Technologies|Technology|Semiconductor|Electronics|Industries|Manufacturing)\b")


def supplier_excerpt(text: str, window: int = 2600, max_windows: int = 3) -> str:
    """Text windows around where a filing NAMES its suppliers — the discovery source for chain
    topology. Wide because the roll-call often spans several sentences ('We utilize foundries …
    We purchase memory from … We engage contract manufacturers such as …').

    Candidate windows are gathered from every pattern, then RANKED by company-name density and
    the best `max_windows` non-overlapping ones are returned in document order. Position-based
    selection is not enough: the roll-call sits in "Manufacturing" for some filers and deep in
    Risk Factors for others, and an incidental early "we purchase certain components" otherwise
    wins the slot and silently drops the real list (a regression caught by re-checking a filer
    that previously worked). Density separates the two reliably.
    """
    cands: list[tuple[int, int, int]] = []  # (score, start, end)
    seen: set[int] = set()
    for pat in _SUPPLIER_PATTERNS:
        for m in list(pat.finditer(text))[:8]:
            s = max(0, m.start() - 200)
            if s in seen:
                continue
            seen.add(s)
            e = min(len(text), s + window)
            cands.append((len(_COMPANY_SIGNAL.findall(text[s:e])), s, e))
    if not cands:
        return ""
    picked: list[tuple[int, int]] = []
    for _, s, e in sorted(cands, key=lambda c: -c[0]):
        if len(picked) >= max_windows:
            break
        if any(s < pe and ps < e for ps, pe in picked):
            continue  # overlaps a window already picked
        picked.append((s, e))
    return "\n…\n".join(text[s:e] for s, e in sorted(picked))


def _latest_annual(ns_facts: dict, concepts: tuple[str, ...], *, currency: str = "USD") -> dict | None:
    """From a companyfacts namespace block, return the latest ANNUAL value across `concepts`:
    {val, end, filed, form, accn}. Annual = 10-K/20-F, fiscal-period 'FY'. `currency` guards
    against non-USD filers (skip → None).

    Selection order: newest period-END first, then CONCEPT PRIORITY as the tie-break within
    the same fiscal year, then most-recently-filed (so a restatement beats the original).

    Recency must dominate priority, not the other way round. Filers MIGRATE XBRL tags, and the
    old tag keeps its historical rows forever: Teradyne's priority-1 concept
    (RevenueFromContractWithCustomerExcludingAssessedTax) last carried an annual value for
    FY2020 while `Revenues` carries FY2025. First-concept-wins therefore pinned four backbone
    entities to a stale tag — teradyne (2020 vs 2025), nvidia (2022 vs 2026), google (2024 vs
    2025) and nebius (2022 vs 2025) — and shipped Nebius's FY2022 revenue to the live terminal
    labelled `disclosed`. Priority still decides WHICH tag to trust for a given year; it must
    never decide WHICH YEAR to report.
    """
    best_key, best_row = None, None
    for prio, concept in enumerate(concepts):
        node = ns_facts.get(concept)
        if not node:
            continue
        units = node.get("units", {})
        rows = units.get(currency) if currency else next(iter(units.values()), [])
        if not rows:
            continue
        for r in rows:
            if (r.get("fp") != "FY" or r.get("val") is None
                    or not str(r.get("form", "")).startswith(_ANNUAL_FORMS)):
                continue
            key = (r.get("end", ""), -prio, r.get("filed", ""))
            if best_key is None or key > best_key:
                best_key, best_row = key, r
    if best_row is None:
        return None
    return {"val": best_row["val"], "end": best_row.get("end"), "filed": best_row.get("filed"),
            "form": best_row.get("form"), "accn": best_row.get("accn")}


def _filing_url(cik: str, accn: str | None) -> str | None:
    if not accn:
        return None
    return f"{ARCH_BASE}/{int(cik)}/{accn.replace('-', '')}/"


def company_financials(cik: str, max_age_days: int = STALE_AFTER_DAYS,
                       today: date | None = None) -> dict:
    """Free structured financials from the SEC XBRL companyfacts API (no key). Returns the
    latest disclosed ANNUAL revenue + capex (+ shares outstanding) for a US filer:
      {revenue|capex: {value, as_of(filed), period(end), form, source} | None, shares: int|None,
       stale: [metric names dropped as stale]}
    Non-USD filers (foreign IFRS) yield None for USD-tagged metrics → caller keeps the estimate.
    `as_of` is the FILING date (when it was disclosed), which the freshness gate keys on.

    Freshness guard: this path does NOT go through latest_report, so it needs its own. XBRL
    keeps a deregistered filer's last facts forever — Advantest's newest annual revenue was
    filed in 2015 and would otherwise be written as a `disclosed` value with an 11-year-old
    as_of. A metric past the horizon is dropped and NAMED in `stale`, so the caller reports
    "stopped filing" rather than the wrong reason "no USD annual revenue in XBRL".
    """
    today = today or date.today()
    facts = _get(f"{FACTS_BASE}/CIK{_cik10(cik)}.json").json().get("facts", {})
    gaap, dei = facts.get("us-gaap", {}), facts.get("dei", {})
    stale: list[str] = []

    def _field(hit: dict | None, metric: str) -> dict | None:
        if not hit:
            return None
        filed = hit.get("filed")
        if filed and (today - date.fromisoformat(filed)).days > max_age_days:
            stale.append(metric)
            return None
        return {"value": hit["val"], "as_of": filed, "period": hit.get("end"),
                "form": hit.get("form"), "source": _filing_url(cik, hit.get("accn"))}

    shares = _latest_annual(dei, ("EntityCommonStockSharesOutstanding",), currency="shares")
    return {
        "revenue": _field(_latest_annual(gaap, _REV_CONCEPTS), "revenue"),
        "capex": _field(_latest_annual(gaap, _CAPEX_CONCEPTS), "capex"),
        "shares": shares["val"] if shares else None,
        "stale": stale,
    }


def entity_mention(text: str, aliases: list[str], window: int = 700) -> dict | None:
    """Find where a filing NAMES one of `aliases` (a supplier's name/aliases) and return an
    excerpt window around the best hit. Used on a BUYER's 10-K/20-F to confirm it names its
    SUPPLIER in dependency/supply language (the L2-identity source). Case-insensitive; when a
    name occurs several times, prefers the occurrence nearest supplier-dependency wording so
    a passing mention in an exhibit list doesn't outrank the risk-factor naming."""
    low = text.lower()
    best = None  # (score, alias, excerpt)
    for a in aliases:
        al = a.lower().strip()
        if not al:
            continue
        start = 0
        while True:
            i = low.find(al, start)
            if i == -1:
                break
            ctx = low[max(0, i - 180): i + 180]
            score = sum(kw in ctx for kw in _DEP_KW)
            if best is None or score > best[0]:
                j = max(0, i - 220)
                best = (score, a, text[j:j + window])
            start = i + len(al)
    if best is None:
        return None
    return {"alias": best[1], "score": best[0], "excerpt": best[2]}

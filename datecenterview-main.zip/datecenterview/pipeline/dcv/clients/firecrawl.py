"""Firecrawl client — URL → clean markdown + metadata (spec §3).

Rules from the spec: strip nav/boilerplate (onlyMainContent), keep spec tables,
never bypass paywalls (flag them and keep the visible snippet as a lead),
respect robots/ToS. Returns a normalized dict the extractor consumes.
"""
from __future__ import annotations

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from ..config import settings
from . import spend

_PAYWALL_HINTS = (
    "subscribe to continue", "subscribe to read", "sign in to read",
    "this content is for subscribers", "already a subscriber", "become a member",
)


class FirecrawlError(RuntimeError):
    pass


def _headers() -> dict[str, str]:
    if not settings.firecrawl_api_key:
        raise FirecrawlError("FIRECRAWL_API_KEY not set — cannot fetch")
    return {
        "Authorization": f"Bearer {settings.firecrawl_api_key}",
        "Content-Type": "application/json",
    }


@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=15))
def _post(payload: dict) -> dict:
    with httpx.Client(timeout=90) as client:
        r = client.post(f"{settings.firecrawl_base_url}/v1/scrape", headers=_headers(), json=payload)
        r.raise_for_status()
        return r.json()


def scrape(url: str) -> dict | None:
    """Return {url, canonical_url, title, publisher, published_date, text, paywalled}
    or None if the fetch failed. Never bypasses paywalls — flags them instead."""
    if not settings.firecrawl_api_key:
        return None  # no key → scraping can't work; skip immediately (no wasted retries)
    try:
        data = _post({"url": url, "formats": ["markdown"], "onlyMainContent": True})
    except Exception as e:
        print(f"  [fetch] {url} failed ({type(e).__name__}: {e}) — skipped")
        return None
    spend.LEDGER.record_call("firecrawl_scrape")

    payload = data.get("data", data) or {}
    md = payload.get("markdown") or ""
    meta = payload.get("metadata", {}) or {}
    status = meta.get("statusCode") or meta.get("status")

    lowered = md.lower()
    paywalled = (
        (isinstance(status, int) and status in (401, 402, 403))
        or any(h in lowered for h in _PAYWALL_HINTS)
        or (0 < len(md) < 400)  # suspiciously short = likely gated
    )
    return {
        "url": url,
        "canonical_url": meta.get("sourceURL") or meta.get("canonical") or url,
        "title": meta.get("title") or meta.get("ogTitle"),
        "publisher": meta.get("ogSiteName") or meta.get("publisher"),
        "published_date": (
            meta.get("publishedTime") or meta.get("articlePublishedTime")
            or meta.get("modifiedTime")
        ),
        "text": md,
        "paywalled": bool(paywalled),
    }

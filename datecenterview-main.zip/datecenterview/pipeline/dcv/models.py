"""SQLAlchemy store schema — the system of record (schema spec §2.2).

Field-level provenance is stored as JSONB `Field<T>` columns (the spec's POC
choice; a normalized field_provenance table is the documented future option).
Enums are enforced in the Python layer + the read-model validator rather than as
Postgres enum types, to keep migrations flexible during the POC.

This module's `Base.metadata` is Alembic's autogenerate target (see db/env.py).
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import (
    JSON,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

# JSONB on Postgres; plain JSON elsewhere (tests/sqlite) via variant.
JSONB_ = JSONB(none_as_null=True).with_variant(JSON(), "sqlite")


class Base(DeclarativeBase):
    pass


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )


# --- source registry + feeds -------------------------------------------------
class Source(Base):
    __tablename__ = "source"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    url: Mapped[str | None] = mapped_column(Text)
    publisher: Mapped[str | None] = mapped_column(String)
    # gov_api|iso|trade_press|permit|earnings|company|satellite|social|research
    type: Mapped[str] = mapped_column(String, default="gov_api")
    trust_weight: Mapped[float] = mapped_column(Float, default=0.8)
    license: Mapped[str | None] = mapped_column(String)
    retrieved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class Feed(Base):
    __tablename__ = "feed"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String)
    # firehose|rss|web|reports|research|api
    type: Mapped[str] = mapped_column(String, default="rss")
    trust_weight: Mapped[float] = mapped_column(Float, default=0.8)
    active: Mapped[bool] = mapped_column(default=True)


# --- value-chain graph -------------------------------------------------------
class Entity(Base):
    __tablename__ = "entity"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String)
    aka: Mapped[list] = mapped_column(JSONB_, default=list)
    # hyperscaler|neocloud|wholesale_colo|retail_colo|developer|enterprise|utility|ai_lab|other
    category: Mapped[str] = mapped_column(String, default="other")
    category_confidence: Mapped[float | None] = mapped_column(Float)
    identifiers: Mapped[dict] = mapped_column(JSONB_, default=dict)  # {ticker,LEI,domain}
    # chain layer (foundry|packaging|hbm|accelerator|systems|datacenter|power|cloud|enduser) — L9/P2
    layer: Mapped[str | None] = mapped_column(String)
    # financials — per-metric Field<T>, each carrying its own as_of/basis/sources (L9/P2):
    #   {"market_cap": {"value":float,"as_of":"YYYY-MM-DD","basis":"disclosed|estimated|n/a","sources":[...]},
    #    "revenue": {...,"period":"FY2026"}, "capex": {...}, "currency":"USD"}
    # basis "n/a" = the connected FMP plan can't source it (market cap); revenue is disclosed.
    financials: Mapped[dict | None] = mapped_column(JSONB_)
    sources: Mapped[list] = mapped_column(JSONB_, default=list)


# --- records -----------------------------------------------------------------
class DataCenter(Base, TimestampMixin):
    __tablename__ = "data_center"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    natural_key: Mapped[str] = mapped_column(String, unique=True, index=True)
    project_name: Mapped[str] = mapped_column(String)
    aka: Mapped[list] = mapped_column(JSONB_, default=list)

    developer_id: Mapped[str | None] = mapped_column(ForeignKey("entity.id"))
    operator_id: Mapped[str | None] = mapped_column(ForeignKey("entity.id"))
    tenant_id: Mapped[str | None] = mapped_column(ForeignKey("entity.id"))
    end_user_id: Mapped[str | None] = mapped_column(ForeignKey("entity.id"))
    # Raw names as written by the source, kept alongside the resolved FK above. All FOUR role
    # fields carry the pair: the raw name is what a document said, the id is what we resolved
    # it to, and a miss must stay visible as a name rather than vanish (Band 2 #2 — `tenant`
    # and `operator` had no *_name column, so every extracted tenant was dropped on write).
    developer_name: Mapped[str | None] = mapped_column(String)
    end_user_name: Mapped[str | None] = mapped_column(String)
    tenant_name: Mapped[str | None] = mapped_column(String)
    operator_name: Mapped[str | None] = mapped_column(String)
    developer_category: Mapped[str | None] = mapped_column(String)

    status: Mapped[str] = mapped_column(String, default="proposed")
    status_history: Mapped[list] = mapped_column(JSONB_, default=list)

    # Field<T> provenance columns
    capacity_mw: Mapped[dict | None] = mapped_column(JSONB_)
    building_sqft: Mapped[dict | None] = mapped_column(JSONB_)
    land_acres: Mapped[dict | None] = mapped_column(JSONB_)
    cap_ex: Mapped[dict | None] = mapped_column(JSONB_)
    btm_generation: Mapped[dict | None] = mapped_column(JSONB_)
    power_sources: Mapped[list] = mapped_column(JSONB_, default=list)

    location: Mapped[dict] = mapped_column(JSONB_, default=dict)  # county,state,country,lat,lng,geo_precision
    announced_date: Mapped[str | None] = mapped_column(String)
    operating_year: Mapped[int | None] = mapped_column(Integer)

    overall_confidence: Mapped[float | None] = mapped_column(Float)
    review_status: Mapped[str] = mapped_column(String, default="candidate")
    last_verified: Mapped[str | None] = mapped_column(String)
    sources: Mapped[list] = mapped_column(JSONB_, default=list)  # denormalized source urls for read-model
    # dedup: set to the SURVIVOR's id when this row is a duplicate of another. A mark, never a
    # delete — emit drops marked rows from the read-model and `dcv dedup --undo` restores them.
    duplicate_of: Mapped[str | None] = mapped_column(String, index=True)


class PowerProject(Base, TimestampMixin):
    __tablename__ = "power_project"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    natural_key: Mapped[str] = mapped_column(String, unique=True, index=True)
    project_name: Mapped[str] = mapped_column(String)

    developer_id: Mapped[str | None] = mapped_column(ForeignKey("entity.id"))
    developer_name: Mapped[str | None] = mapped_column(String)  # raw entity_name / queue sponsor

    # Solar|Wind|Battery|Natural Gas|Nuclear|Coal|Hydro|Geothermal|Hybrid|Other
    technology: Mapped[str] = mapped_column(String, default="Other")
    energy_source_code: Mapped[str | None] = mapped_column(String)  # raw EIA code, traceability

    capacity_mw: Mapped[dict | None] = mapped_column(JSONB_)
    capacity_mwh: Mapped[dict | None] = mapped_column(JSONB_)

    status: Mapped[str] = mapped_column(String, default="proposed")
    status_raw: Mapped[str | None] = mapped_column(String)
    balancing_authority: Mapped[str | None] = mapped_column(String)

    location: Mapped[dict] = mapped_column(JSONB_, default=dict)
    btm_datacenter_signal: Mapped[dict | None] = mapped_column(JSONB_)  # Field<bool>
    operating_year: Mapped[int | None] = mapped_column(Integer)
    operating_date: Mapped[str | None] = mapped_column(String)

    source: Mapped[str | None] = mapped_column(String)  # EIA-860M | ERCOT | CAISO | ...
    source_ref: Mapped[str | None] = mapped_column(String)
    source_id: Mapped[str | None] = mapped_column(ForeignKey("source.id"))
    confidence: Mapped[float | None] = mapped_column(Float, default=1.0)
    review_status: Mapped[str] = mapped_column(String, default="approved")
    last_verified: Mapped[str | None] = mapped_column(String)
    sources: Mapped[list] = mapped_column(JSONB_, default=list)


class Edge(Base):
    __tablename__ = "edge"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    from_id: Mapped[str] = mapped_column(String)  # project id (read-model: edge.project)
    to_id: Mapped[str] = mapped_column(String)    # entity id (read-model: edge.org)
    # develops|operates|leases_to|serves|powers|provides_compute|supplies
    relation: Mapped[str] = mapped_column(String)
    value: Mapped[dict | None] = mapped_column(JSONB_)  # Field<MW|GPUs|$>
    confidence: Mapped[float] = mapped_column(Float, default=0.7)
    sources: Mapped[list] = mapped_column(JSONB_, default=list)
    valid_from: Mapped[str | None] = mapped_column(String)
    valid_to: Mapped[str | None] = mapped_column(String)
    status: Mapped[str] = mapped_column(String, default="active")


class SupplyNode(Base):
    __tablename__ = "supply_node"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    entity_id: Mapped[str | None] = mapped_column(ForeignKey("entity.id"))
    label: Mapped[str] = mapped_column(String)
    # foundry|memory|gpu|asic|server|networking|power|cooling|hyperscaler|neocloud|...|enduser
    category: Mapped[str] = mapped_column(String)
    rev: Mapped[float | None] = mapped_column(Float)
    note: Mapped[str | None] = mapped_column(Text)


class SupplyLink(Base):
    __tablename__ = "supply_link"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    source_id: Mapped[str] = mapped_column(ForeignKey("supply_node.id"))
    target_id: Mapped[str] = mapped_column(ForeignKey("supply_node.id"))
    value: Mapped[float] = mapped_column(Float)
    title: Mapped[str | None] = mapped_column(String)
    meta: Mapped[dict] = mapped_column(JSONB_, default=dict)  # {as_of, $}


class News(Base):
    __tablename__ = "news"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    type: Mapped[str] = mapped_column(String, default="news")  # news|report
    title: Mapped[str] = mapped_column(Text)
    publisher: Mapped[str | None] = mapped_column(String)
    published_date: Mapped[str | None] = mapped_column(String)
    url: Mapped[str | None] = mapped_column(Text)
    tag: Mapped[str | None] = mapped_column(String)
    source_feed: Mapped[str | None] = mapped_column(ForeignKey("feed.id"))
    summary: Mapped[str | None] = mapped_column(Text)
    entity_refs: Mapped[list] = mapped_column(JSONB_, default=list)
    project_refs: Mapped[list] = mapped_column(JSONB_, default=list)
    provenance: Mapped[dict] = mapped_column(JSONB_, default=dict)


# --- audit / validation trail ------------------------------------------------
class ReviewLog(Base):
    __tablename__ = "review_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    record_type: Mapped[str] = mapped_column(String)
    record_id: Mapped[str] = mapped_column(String)
    reviewer: Mapped[str | None] = mapped_column(String)
    # approve|reject|edit|dispute|dismiss. Only approve/reject/dismiss are TERMINAL (they resolve
    # an open dispute); `edit` deliberately is not. `dismiss` closes an unfounded dispute and
    # restores the pre-dispute state from this table. See dcv/review.py.
    decision: Mapped[str] = mapped_column(String)
    before: Mapped[dict | None] = mapped_column(JSONB_)
    after: Mapped[dict | None] = mapped_column(JSONB_)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class ChangeLog(Base):
    __tablename__ = "change_log"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    record_type: Mapped[str] = mapped_column(String)
    record_id: Mapped[str] = mapped_column(String)
    field: Mapped[str] = mapped_column(String)
    old: Mapped[dict | None] = mapped_column(JSONB_)
    new: Mapped[dict | None] = mapped_column(JSONB_)
    source_id: Mapped[str | None] = mapped_column(String)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class GoldSet(Base):
    __tablename__ = "gold_set"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    record_type: Mapped[str] = mapped_column(String)
    natural_key: Mapped[str] = mapped_column(String, index=True)
    fields: Mapped[dict] = mapped_column(JSONB_, default=dict)
    notes: Mapped[str | None] = mapped_column(Text)
    verified_by: Mapped[str | None] = mapped_column(String)
    verified_at: Mapped[str | None] = mapped_column(String)


ALL_TABLES = [
    Source, Feed, Entity, DataCenter, PowerProject, Edge,
    SupplyNode, SupplyLink, News, ReviewLog, ChangeLog, GoldSet,
]

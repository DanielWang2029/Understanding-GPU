"""Environment-driven settings. Loads the repo-root .env for local dev."""
from __future__ import annotations

from pathlib import Path

from dotenv import load_dotenv
from pydantic_settings import BaseSettings, SettingsConfigDict

# repo root = two levels up from this file (pipeline/dcv/config.py -> repo/)
REPO_ROOT = Path(__file__).resolve().parents[2]
ENV_PATH = REPO_ROOT / ".env"

# load .env so plain os.environ + libraries (alembic, gridstatus) see it too
if ENV_PATH.exists():
    load_dotenv(ENV_PATH)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=str(ENV_PATH), extra="ignore")

    database_url: str = "postgresql+psycopg://dcv:dcv_local_dev@localhost:5432/datacenterview"
    eia_api_key: str = ""
    ingest_states: str = "TX"

    # --- Phase B: agentic discovery→extract→verify (Design Y) -----------------
    # keys (kept out of git; set in .env)
    exa_api_key: str = ""          # discovery search
    xai_api_key: str = ""          # Grok — discovery (Agent Tools API) + extraction
    firecrawl_api_key: str = ""    # fetch & clean
    anthropic_api_key: str = ""    # Claude — cross-vendor verify
    fmp_api_key: str = ""          # P2/L9 — financial spine (market_cap/revenue); automation path
    # Override with a monitored team mailbox before making SEC requests.
    edgar_user_agent: str = "dataCenterView/0.1 contact@example.com"

    # model ids (swappable without code changes; see `xai list-models`)
    extract_model: str = "grok-4.20-0309-non-reasoning"   # cheap, high-volume extractor
    discovery_model: str = "grok-4.5"  # Agent Tools API web+X search (needs grok-4.5)
    # Trust gate. Switched from claude-opus-4-8 on 2026-07-30 by the verifier bake-off
    # (`dcv bakeoff`, pipeline/seed/bakeoff_results.json — 16 records x 5 backends):
    # sonnet-5 matched the incumbent on every axis that was measurable without ground truth —
    # 16/16 structured-output validity, identical 0.50 corroboration rate, an IDENTICAL queue
    # distribution (needs_review 12 / reported 3 / approved 1) — with the HIGHEST verdict
    # agreement of any candidate (0.917) at 0.69x the all-in cost. Still a different vendor
    # than the Grok extractor, so decision #4 holds.
    # CAVEAT, on the record: that is agreement, not accuracy. Phase 1 could not measure who is
    # CORRECT because the gold set is 7 `demo_seed_bootstrap` rows that goldset.certify()
    # refuses. Revisit once phase 2 has human-signed ground truth.
    verify_model: str = "claude-sonnet-5"

    # api bases
    xai_base_url: str = "https://api.x.ai/v1"
    exa_base_url: str = "https://api.exa.ai"
    firecrawl_base_url: str = "https://api.firecrawl.dev"

    # cost-control valves (spec §9): the candidate queue is where spend is gated
    phase_b_states: str = "TX"            # pilot scope
    discovery_max_candidates: int = 400   # per run — hard cap on the queue
    extract_max_records: int = 400        # per run — hard cap into the paid extractor
    daily_spend_limit_usd: float = 25.0   # alert/abort threshold

    # Grok Agent Tools discovery (x_search freshness window + optional handle scope)
    discovery_search_window_days: int = 90   # x_search from_date = today − N days
    discovery_x_handles: str = ""            # optional CSV of X handles to scope x_search

    # confidence gate thresholds (spec §7)
    confidence_auto_approve: float = 0.90
    confidence_review_floor: float = 0.60

    # Probe every corroborating URL the verifier cites before it earns the independence bonus
    # (see source_liveness). Off = trust the citation, which is what the gate did until the
    # 2026-07-30 bake-off caught a search-less verifier asserting 4 hard-404 URLs out of 16.
    # Only turn this off for a deliberately offline run.
    verify_check_source_liveness: bool = True

    # paths
    repo_root: Path = REPO_ROOT
    data_json_path: Path = REPO_ROOT / "data.json"
    data_js_path: Path = REPO_ROOT / "data.js"
    web_public_data: Path = REPO_ROOT / "web" / "public" / "data.json"
    schema_path: Path = REPO_ROOT / "pipeline" / "data.schema.json"
    validator_path: Path = REPO_ROOT / "pipeline" / "validate_data.py"

    @property
    def states(self) -> list[str]:
        return self._split_states(self.ingest_states)

    @property
    def phase_b_state_list(self) -> list[str]:
        return self._split_states(self.phase_b_states)

    @property
    def discovery_x_handle_list(self) -> list[str]:
        raw = (self.discovery_x_handles or "").strip()
        return [h.strip().lstrip("@") for h in raw.split(",") if h.strip()] if raw else []

    @staticmethod
    def _split_states(raw: str) -> list[str]:
        raw = (raw or "").strip()
        if not raw or raw.upper() == "ALL":
            return []  # empty = national
        return [s.strip().upper() for s in raw.split(",") if s.strip()]


settings = Settings()

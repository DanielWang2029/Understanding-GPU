"""Wire the newsfeed to facilities.

Phase B discovered news articles but kept only their URLs as data_center.sources,
so the newsfeed stayed seed-only (11 items, 0 linked). This turns those source
articles into News records linked to the facility they're about — linkage is
guaranteed-correct because the article was the evidence used to extract that
facility. One article that sourced several facilities becomes one News item that
links to all of them. Titles come from the URL slug (trade-press slugs are the
headline); publisher/feed from the domain; date parsed from the URL when present.
Registries, filings and directories (PeeringDB, SEC, permit portals, capacity
directories) are excluded — they aren't editorial news. Idempotent.
"""
from __future__ import annotations

import re
from urllib.parse import urlparse

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert

from .db import session_scope
from .models import DataCenter, Feed, News
from .phaseb.verify import _domain

# domains that are registries / filings / directories / static company pages — not news
NON_NEWS = {
    "peeringdb.com", "baxtel.com", "datacenter.fyi", "datacenters.com",
    "inferencebench.io", "sec.gov", "en.wikipedia.org", "wikipedia.org",
    "datacentermap.com", "datacenters.google", "local.microsoft.com",
    "datacenters.atmeta.com",
    "cleanview.co",   # competitor — decision #1: we don't surface their content
}
# domain -> (feed_id, display_name). Trade-press domains REUSE the seed feed ids
# (dcd/dck/dcf/condive) so we never create a second chip with the same name.
DOMAIN_FEED = {
    "datacenterdynamics.com": ("dcd", "Data Center Dynamics"),
    "datacenterknowledge.com": ("dck", "Data Center Knowledge"),
    "datacenterfrontier.com": ("dcf", "Data Center Frontier"),
    "constructiondive.com": ("condive", "Construction Dive"),
    "utilitydive.com": ("feed-utilitydive", "Utility Dive"),
    "reuters.com": ("feed-reuters", "Reuters"),
    "bloomberg.com": ("feed-bloomberg", "Bloomberg"),
    "cnbc.com": ("feed-cnbc", "CNBC"),
    "wsj.com": ("feed-wsj", "Wall Street Journal"),
    "theregister.com": ("feed-theregister", "The Register"),
    "techcrunch.com": ("feed-techcrunch", "TechCrunch"),
    "theverge.com": ("feed-theverge", "The Verge"),
    "tomshardware.com": ("feed-tomshardware", "Tom's Hardware"),
    "prnewswire.com": ("feed-prnewswire", "PR Newswire"),
    "businesswire.com": ("feed-businesswire", "Business Wire"),
    "globenewswire.com": ("feed-globenewswire", "GlobeNewswire"),
    "powermag.com": ("feed-powermag", "POWER Magazine"),
}
OTHER_FEED = ("feed-other-press", "Independent / other press")
_DATE_RE = re.compile(r"/(20\d\d)[/-](\d{1,2})[/-](\d{1,2})(?:/|$)")
_KEEP_UPPER = {"ai", "us", "uk", "llc", "dc", "hpc", "gpu", "hbm", "reit", "esg", "sec"}


def _is_news(url: str | None) -> bool:
    d = _domain(url)
    return bool(d) and d not in NON_NEWS and not d.endswith(".gov")


def _date_from_url(url: str) -> str | None:
    m = _DATE_RE.search(url)
    if not m:
        return None
    y, mo, da = m.groups()
    return f"{y}-{int(mo):02d}-{int(da):02d}"


def _title_from_url(url: str) -> str:
    slug = urlparse(url).path.rstrip("/").split("/")[-1]
    slug = re.sub(r"\.(html?|php|aspx)$", "", slug)
    slug = re.sub(r"[-_]+", " ", slug).strip()
    if len(slug) < 8:
        return f"{_domain(url) or 'web'} — article"
    words = []
    for w in slug.split():
        lw = w.lower()
        if re.fullmatch(r"\d+(gw|mw|kw)", lw):
            words.append(w.upper())
        elif lw in _KEEP_UPPER:
            words.append(w.upper())
        else:
            words.append(w[:1].upper() + w[1:])
    return " ".join(words)


def _feed_for(url: str) -> tuple[str, str]:
    """Known publishers get their own feed (reusing seed ids); the long tail lumps
    into one 'other' feed so the newsfeed filter bar stays a short, usable set."""
    return DOMAIN_FEED.get(_domain(url), OTHER_FEED)


def _publisher(url: str) -> str | None:
    hit = DOMAIN_FEED.get(_domain(url))
    return hit[1] if hit else _domain(url)


def _news_id(url: str) -> str:
    return "news-" + re.sub(r"[^a-z0-9]+", "-", url.split("//")[-1].lower()).strip("-")[:90]


def wire_news() -> dict:
    with session_scope() as s:
        url_projects: dict[str, set[str]] = {}
        for r in s.execute(select(DataCenter)).scalars():
            for u in (r.sources or []):
                if _is_news(u):
                    url_projects.setdefault(u, set()).add(r.id)

        # dedupe by news id + feed id first (avoid in-batch duplicate PKs); union
        # the facility links of any URLs that collapse to the same id.
        feeds: dict[str, str] = {}
        news: dict[str, dict] = {}
        for url, projs in url_projects.items():
            fid, fname = _feed_for(url)
            feeds.setdefault(fid, fname)
            nid = _news_id(url)
            if nid in news:
                news[nid]["projs"].update(projs)
            else:
                news[nid] = {"url": url, "projs": set(projs), "fid": fid,
                             "title": _title_from_url(url),
                             "publisher": _publisher(url),
                             "date": _date_from_url(url)}

        existing_feeds = {f.id for f in s.execute(select(Feed)).scalars()}
        existing_news = {n.id for n in s.execute(select(News)).scalars()}

        for fid, fname in feeds.items():
            s.execute(pg_insert(Feed).values(
                id=fid, name=fname, type="web", trust_weight=0.75, active=True
            ).on_conflict_do_nothing(index_elements=["id"]))

        for nid, rec in news.items():
            vals = dict(id=nid, type="news", title=rec["title"], publisher=rec["publisher"],
                        published_date=rec["date"], url=rec["url"], tag="news",
                        source_feed=rec["fid"], project_refs=sorted(rec["projs"]))
            stmt = pg_insert(News).values(**vals)
            s.execute(stmt.on_conflict_do_update(
                index_elements=["id"], set_={k: stmt.excluded[k] for k in vals if k != "id"}))

    links = sum(len(r["projs"]) for r in news.values())
    print(f"✓ wire-news: {len(news)} articles → {links} facility links · "
          f"+{len(set(news) - existing_news)} news items, +{len(set(feeds) - existing_feeds)} feeds")
    return {"articles": len(news), "links": links,
            "news_added": len(set(news) - existing_news), "feeds_added": len(set(feeds) - existing_feeds)}

"""chain_identity — flip inferred edge LINKS to NAMED, cross-vendor verified (P3, L2-identity).

The spike (2026-07-20) found the supplier's own 10-K AND its own earnings call name NO
customer — Micron and TSMC both name zero. The identity the concentration table withholds is
disclosed by the OTHER end of the edge: the BUYER's 10-K risk factors name the supplier
("NVIDIA utilizes foundries such as TSMC … to produce its semiconductor wafers"), and the
supplier's first-party / trade press names the customer ("Micron … HBM4 designed for NVIDIA
Vera Rubin"). So this resolver gathers identity evidence from those two DECORRELATED sources
and, with a different-vendor maker-checker, lifts link_basis inferred→named and (when the
attribution is unambiguous) review_status needs_review→confirmed.

The disclosed MAGNITUDE is never touched here — pct_revenue/rev_basis stay pinned to the
supplier's filing (chain_edges.json / _verified). Each source carries only the half it
actually discloses; that IS the requisite-variety split (loop-design).

L2-identity 5-line contract:
  1. Setpoint  — each disclosed-magnitude edge reaches a NAMED counterparty where a public
                 naming exists (link_basis=named; confirmed when the %-attribution is clean).
  2. Measured  — named-link share + confirmed count (run() stats; emit `edge_coverage`).
  3. Error     — magnitude disclosed but the link is still inferred / needs_review.
  4. Correction— gather buyer-filing + press namings → cross-vendor verify (voted); majority
                 confirms a real naming → named; majority also confident on attribution →
                 confirmed; else stay needs_review (honest — a named link we can't pin to the %).
  5. Mechanisms— maker-checker + requisite variety (buyer-filing ⟂ press; Grok extract ≠
                 Claude verify) · active-learning order (biggest edges first) · spend cap (L5).

Conformance: Setpoint→resolve gate · Measured→run() stats · Error→verdict.named_confirmed/
attribution_confident · Correction→named/confirmed/needs_review below · Mechanisms→two-source
gather + two-vendor call + spend ledger. Guardrails: link_basis=named REQUIRES typed
link_sources[] with a url (validate_data.edge_integrity, L6); magnitude untouched; named≠
confirmed. Cross-vendor asserted at import (extract≠verify vendor).

Output: seed/chain_edges_identity_auto.json → emit merges it LAST over the manual identity
baseline seed/chain_edges_identity.json (auto wins per field), both winning the LINK half
over the magnitude fixtures. Run: `dcv chain-identity`.
"""
from __future__ import annotations

import json
from pathlib import Path

from .chain_quant import _src_url, _ticker_cik_map
from .clients import claude, edgar, grok
from .config import settings

_SEED = Path(__file__).resolve().parent.parent / "seed"
AUTO_FIXTURE = _SEED / "chain_edges_identity_auto.json"
_MAG_FIXTURES = (_SEED / "chain_edges.json", _SEED / "chain_edges_verified.json")

# requisite variety: the checker MUST be a different vendor than the maker (loop-design).
# (Importing chain_quant already asserts this; re-assert for locality/self-documentation.)
assert settings.extract_model.split("-")[0] != settings.verify_model.split("-")[0], (
    "chain_identity requires a cross-vendor pair (extract≠verify); same-vendor agreement is "
    f"meaningless — got extract={settings.extract_model}, verify={settings.verify_model}")

# Name variants a buyer filing / press uses for a chain company. Filing-style legal names are
# included deliberately: chain_topology resolves discovered supplier names LOCALLY against this
# map rather than trusting an LLM's id mapping, so the roll-call in a 10-K ("Hon Hai Precision
# Industry Co., Ltd.", "SK Hynix Inc.") must match. Covers all 29 backbone nodes.
_ALIASES: dict[str, list[str]] = {
    "tsmc": ["TSMC", "Taiwan Semiconductor"],
    "nvidia": ["NVIDIA", "Nvidia"],
    "micron": ["Micron"],
    "skhynix": ["SK hynix", "SK Hynix", "Hynix"],
    "samsung": ["Samsung"],
    "broadcom": ["Broadcom"],
    "amd": ["AMD", "Advanced Micro Devices"],
    "intel": ["Intel Corporation", "Intel"],
    "ase": ["ASE Technology", "Advanced Semiconductor Engineering", "ASE Group"],
    "amkor": ["Amkor"],
    "foxconn": ["Hon Hai", "Foxconn"],
    "microsoft": ["Microsoft"],
    "aws": ["Amazon Web Services", "AWS", "Amazon.com", "Amazon"],
    "google": ["Alphabet", "Google Cloud", "Google"],
    "meta": ["Meta Platforms", "Meta"],
    "oracle": ["Oracle"],
    "coreweave": ["CoreWeave"],
    "nebius": ["Nebius"],
    "crusoe": ["Crusoe"],
    "openai": ["OpenAI"],
    "anthropic": ["Anthropic"],
    "xai": ["xAI"],
    "dell": ["Dell Technologies", "Dell"],
    "smci": ["Super Micro Computer", "Supermicro", "Super Micro"],
    "equinix": ["Equinix"],
    "digital-realty": ["Digital Realty"],
    "vertiv": ["Vertiv"],
    "eaton": ["Eaton"],
    "schneider": ["Schneider Electric", "Schneider"],
    # Band 2 #1 — semiconductor-equipment tier. Every alias here was written by a filing and
    # logged as unresolved by chain_topology; the long legal forms are listed FIRST-class (not
    # just the short name) because `_resolve` takes the LONGEST matching alias.
    "asml": ["ASML Holding", "ASML"],
    "tokyoelectron": ["Tokyo Electron Limited", "Tokyo Electron"],
    "lamresearch": ["Lam Research Corporation", "Lam Research"],
    "teradyne": ["Teradyne"],
    "advantest": ["Advantest Corporation", "Advantest"],
    "allring": ["All Ring Tech Co., Ltd.", "All Ring Tech", "All Ring"],
    "marketech": ["Marketech International Corp.", "Marketech International", "Marketech"],
    "grandprocess": ["Grand Process Technology Corporation", "Grand Process Technology",
                     "Grand Process"],
}


def _aliases(entity_id: str, name: str) -> list[str]:
    return _ALIASES.get(entity_id, [name])


ID_EXTRACT_SCHEMA = {
    "type": "object",
    "properties": {
        "namings": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "source_type": {"type": "string"},   # buyer_filing | press_first_party | press_trade
                "url": {"type": "string"},
                "verbatim": {"type": "string"},
                "names_relationship": {"type": "boolean"},
            },
            "required": ["source_type", "verbatim", "names_relationship"],
        }},
    },
    "required": ["namings"],
}

_EXTRACT_SYS = (
    "You extract EXPLICIT public namings of a supplier→customer relationship from evidence "
    "excerpts. You are given a SUPPLIER, a candidate CUSTOMER, and excerpts from (a) the "
    "CUSTOMER's SEC filing and (b) press/web results. For each excerpt that EXPLICITLY connects "
    "the two — the customer depends on / buys from / is manufactured by / sources from the "
    "supplier, or the supplier ships/sells/supplies to the customer — return one entry: "
    "source_type ('buyer_filing' if it is the customer's SEC filing; 'press_first_party' if the "
    "url is the supplier's or customer's own newsroom/investor site; else 'press_trade'), the "
    "url if present, the VERBATIM naming sentence, and names_relationship=true. Set "
    "names_relationship=false for excerpts that mention only one party or are generic. Never "
    "invent a naming, a url, or a company — report ONLY what the excerpts actually state.")

_VERIFY_SYS = (
    "You are a skeptical, independent verifier. A DIFFERENT model claims the supplier→customer "
    "relationship below is publicly NAMED. Do NOT trust it. You MAY web-search. Decide: "
    "(1) named_confirmed — is the supplier→customer relationship explicitly named by at least "
    "one CREDIBLE source (the customer's SEC filing, or first-party / reputable trade press)? "
    "(2) attribution_confident — the supplier discloses that ONE customer is the stated % of its "
    "revenue; is THIS customer plausibly that one (e.g. it is the supplier's dominant or only "
    "major named customer at that scale / segment)? Be conservative: false if the supplier has "
    "several comparable named customers so the % could be another. (3) confidence 0-1 overall. "
    'Reply ONLY with JSON: {"named_confirmed":bool,"attribution_confident":bool,'
    '"confidence":number,"reason":str}.')


def _load_magnitude_edges() -> dict[tuple[str, str], dict]:
    """The disclosed-magnitude edges (manual + chain_quant-verified), field-merged — the same
    view emit builds. These are the edges the identity pass enriches (never overwrites)."""
    out: dict[tuple[str, str], dict] = {}
    for f in _MAG_FIXTURES:
        try:
            data = json.loads(f.read_text())
        except FileNotFoundError:
            continue
        for e in data.get("edges", []):
            out.setdefault((e["from"], e["to"]), {}).update(e)
    return out


def targets(limit: int | None = None) -> list[dict]:
    """Edges whose MAGNITUDE is disclosed but whose LINK is still inferred (or needs_review),
    ordered by pct_revenue DESC (active learning — resolve the biggest edges first). Each target
    carries supplier/buyer display names + the buyer's CIK (for the buyer-filing evidence)."""
    from .compute_seed import build_seed
    ents = {e["id"]: e for e in build_seed()["chain"]["entities"]}
    t2c = _ticker_cik_map()
    out = []
    for (frm, to), e in _load_magnitude_edges().items():
        if e.get("rev_basis") != "disclosed":
            continue
        if e.get("link_basis") == "named":  # already resolved
            continue
        sup, buy = ents.get(frm), ents.get(to)
        if not sup or not buy:
            continue
        buy_tk = buy.get("ticker")
        out.append({
            "from": frm, "to": to, "pct_revenue": e.get("pct_revenue"),
            "supplier_name": sup["name"], "buyer_name": buy["name"],
            "buyer_cik": t2c.get(buy_tk) if buy_tk in t2c else None,
        })
    out.sort(key=lambda t: t.get("pct_revenue") or 0, reverse=True)
    return out[:limit] if limit else out


def _buyer_filing_evidence(target: dict) -> dict | None:
    """Fetch the BUYER's latest 10-K/20-F and return a {type:buyer_filing, url, as_of, excerpt}
    window where it NAMES the supplier in dependency language, else None."""
    cik = target.get("buyer_cik")
    if not cik:
        return None
    rpt = edgar.latest_report(edgar.submissions(cik))
    if not rpt:
        return None
    text = edgar.filing_text(cik, rpt["accession"], rpt["doc"])
    hit = edgar.entity_mention(text, _aliases(target["from"], target["supplier_name"]))
    if not hit or hit["score"] == 0:   # named, but not near supplier-dependency language → weak
        return None
    return {"type": "buyer_filing", "url": _src_url(cik, rpt), "as_of": rpt["filed"],
            "excerpt": hit["excerpt"][:600]}


def _press_evidence(target: dict) -> tuple[str, list[str]]:
    """Grok Agent-Tools web search for first-party / trade-press naming of the relationship.
    Returns (text, citation_urls). Best-effort — an empty result just means no press evidence."""
    q = (f"Does {target['supplier_name']} publicly supply / sell to {target['buyer_name']}? "
         f"Find the supplier's own press releases or reputable trade press that explicitly name "
         f"{target['buyer_name']} as a customer of {target['supplier_name']} "
         f"(e.g. chips/memory/wafers/components supplied). Quote the naming sentence and give URLs.")
    try:
        return grok.search(q, [grok.web_search_tool()])
    except Exception:
        return "", []


def resolve(target: dict, rounds: int = 3) -> dict | None:
    """Gather buyer-filing + press identity evidence and cross-vendor verify (verify voted over
    `rounds`, majority) → an identity edge upgrading the link, or None if no naming survives.
    Returns only the LINK half (link_basis/link_sources/review_status/…); emit merges it onto
    the magnitude edge. The magnitude is never emitted here."""
    link_sources: list[dict] = []
    bf = _buyer_filing_evidence(target)
    if bf:
        link_sources.append(bf)

    ptext, purls = _press_evidence(target)
    ev_parts = []
    if bf:
        ev_parts.append(f"[{target['buyer_name']} SEC filing — {bf['url']}]\n{bf['excerpt']}")
    if ptext:
        ev_parts.append(f"[press/web results — urls: {', '.join(purls[:8])}]\n{ptext[:2500]}")
    if not ev_parts:
        return None  # nothing to extract from

    euser = (f"SUPPLIER: {target['supplier_name']} (id {target['from']}). "
             f"Candidate CUSTOMER: {target['buyer_name']} (id {target['to']}).\n\n"
             + "\n\n".join(ev_parts))
    try:
        got, _ = grok.chat(_EXTRACT_SYS, euser, response_schema=ID_EXTRACT_SCHEMA)
    except Exception:
        got = {"namings": []}
    have = {s["url"] for s in link_sources}
    for n in got.get("namings", []):
        if not n.get("names_relationship"):
            continue
        st = n.get("source_type") or "press_trade"
        if st == "buyer_filing":
            continue  # the filing evidence is already attached with its real url + as_of
        url = (n.get("url") or "").strip()
        if not url or url in have:
            continue
        have.add(url)
        ls = {"type": st if st in ("press_first_party", "press_trade") else "press_trade",
              "url": url, "excerpt": (n.get("verbatim") or "")[:300]}
        link_sources.append(ls)

    if not link_sources:
        return None  # no credible naming with a citable url → leave the link inferred (honest)

    vuser = (f"Supplier {target['supplier_name']} discloses ONE customer = "
             f"{target.get('pct_revenue')}% of its revenue (customer unnamed in the filing). "
             f"Claim: that customer is {target['buyer_name']}. Named-relationship evidence:\n"
             + "\n".join(f"- ({s['type']}) {s['url']}: {s.get('excerpt', '')}" for s in link_sources))
    verdicts = []
    for _ in range(rounds):
        try:
            verdicts.append(claude.verify_json(_VERIFY_SYS, vuser))
        except Exception:
            continue
    if not verdicts:
        return None
    n = len(verdicts)
    named_n = sum(bool(v.get("named_confirmed")) for v in verdicts)
    if named_n * 2 <= n:  # majority must confirm a REAL naming, else it's still just inferred
        return None
    attr_n = sum(bool(v.get("attribution_confident")) for v in verdicts)
    confirmed = attr_n * 2 > n  # named AND a majority confident on the %-attribution → confirmed
    avg_conf = sum(float(v.get("confidence", 0.5)) for v in verdicts) / n
    conf = round((named_n / n) * avg_conf, 2)
    reason = next((v.get("reason") for v in verdicts if v.get("reason")), "")
    types = sorted({s["type"] for s in link_sources})
    return {
        "from": target["from"], "to": target["to"],
        "link_basis": "named",
        "review_status": "confirmed" if confirmed else "needs_review",
        "link_confidence": conf,
        "link_sources": link_sources,
        "identity_verify": {
            "extractor": settings.extract_model, "verifier": settings.verify_model,
            "named_by": types, "named_votes": f"{named_n}/{n}",
            "attribution_votes": f"{attr_n}/{n}", "reason": (reason or "")[:240],
        },
        "note": f"identity: {target['supplier_name']}→{target['buyer_name']} named by "
                f"{', '.join(types)}; named {named_n}/{n}, attribution {attr_n}/{n} (conf {conf})",
    }


def run(target_list: list[dict], budget_usd: float = 3.0, rounds: int = 3) -> dict:
    """Resolve the identity of each target edge under a spend cap (active-learning order = the
    caller's order). Writes seed/chain_edges_identity_auto.json. Returns run stats."""
    import time

    from .clients import spend
    edges, named, confirmed = [], 0, 0
    for t in target_list:
        if spend.LEDGER.total_usd >= budget_usd:  # L5 spend governor
            print(f"  [chain_identity] spend cap ${budget_usd} reached — stopping")
            break
        try:
            e = resolve(t, rounds=rounds)
            if e:
                edges.append(e)
                named += 1
                confirmed += e["review_status"] == "confirmed"
                tag = f"{t['from']}→{t['to']}"
                print(f"  [chain_identity] {tag}: {e['review_status']} "
                      f"({e['identity_verify']['named_votes']} named); spend ${spend.LEDGER.total_usd:.2f}")
            else:
                print(f"  [chain_identity] {t['from']}→{t['to']}: no naming survived; "
                      f"spend ${spend.LEDGER.total_usd:.2f}")
        except Exception as ex:  # a bad filing/LLM call must not sink the batch
            print(f"  [chain_identity] {t.get('from')}→{t.get('to')}: {type(ex).__name__}: {ex}")
        time.sleep(0.7)  # EDGAR politeness

    stats = {"targets": len(target_list), "named": named, "confirmed": confirmed,
             "needs_review": named - confirmed, "spend_usd": round(spend.LEDGER.total_usd, 3)}
    AUTO_FIXTURE.write_text(json.dumps(
        {"_meta": {"source": "chain_identity cross-vendor (buyer 10-K + press → Grok extract → "
                             f"Claude verify ×{rounds}, majority)",
                   "extractor": settings.extract_model, "verifier": settings.verify_model,
                   "rounds": rounds, "stats": stats}, "edges": edges}, indent=2) + "\n")
    print(f"✓ chain_identity — {named} named ({confirmed} confirmed, {named - confirmed} "
          f"needs-review) of {len(target_list)} targets; spend ${stats['spend_usd']}")
    return stats

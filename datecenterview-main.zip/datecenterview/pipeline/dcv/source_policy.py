"""source_policy — which sources this project is ALLOWED to take data from.

CLAUDE.md names this as decision #1 and a non-negotiable constraint:

    "Source from primary/free data, never scrape CleanView. Their DB is licensed (legal
     risk) and copying it keeps us permanently behind."
    "Constraints that are non-negotiable: don't scrape CleanView or other paid
     competitors' curated data."

Until Band 2 #3 that constraint existed only as prose. No ingest path enforced it, and the
capacity-recovery pass (`enrich.py`) accepts whatever URL a web search hands back — so it
extracted facility capacities straight out of competitor databases. Measured on the live
store: 42 data_center records and 151 URLs in the published `data.json`, including 58 from
cleanview.co and 58 from datacenterhawk.

That is the failure mode `loop-design` calls a docstring-only mechanism: a rule everyone
believes is in force because it is written down. This module makes it code, enforced in two
places — REJECTED at ingest, and BLOCKING at the publish gate.

Note what is and is not prohibited. Reading a competitor's site to see what they cover is
research. Copying a curated VALUE out of it into our store and publishing that value as ours
is the thing decision #1 forbids, and it is exactly what `method: "extracted"` records.
"""
from __future__ import annotations

import re
from urllib.parse import urlparse

# TIER 1 — DENY. Paid/licensed competitor databases whose curated figures are the product
# they sell. Decision #1 names CleanView explicitly and generalises to "other PAID
# competitors' curated data". Taking a value out of these is the prohibited act.
DENY_CURATED_COMPETITOR = {
    "cleanview.co": "CleanView — the licensed competitor decision #1 names explicitly",
    "datacenterhawk.com": "DatacenterHawk — paid/gated curated DC database",
    "dgtlinfra.com": "Dgtl Infra — paywalled curated DC research",
}

# TIER 2 — ALLOWED, tracked. Free-to-browse directories, closer in kind to PeeringDB (which
# this project uses deliberately and by design) than to CleanView: no paywall, listings
# largely operator-submitted.
#
# RULED ON 2026-07-20 by the project owner: tier 2 is acceptable to keep. Do not re-litigate
# this, and do not promote these to tier 1 without a new decision. They stay enumerated so
# their footprint is reportable (167 URLs at the time of the ruling) — if the licensing view
# ever changes, the blast radius is already measurable.
REVIEW_DIRECTORY = {
    "datacenters.com": "Datacenters.com — free commercial directory (operator-submitted)",
    "cloudscene.com": "Cloudscene — free DC/network directory",
    "baxtel.com": "Baxtel — free DC directory",
    "datacentermap.com": "Data Center Map — free DC directory",
    # RULED ON 2026-07-21 by the project owner — the seven domains the new fail-closed check
    # surfaced. They had been supplying values since before any tier existed (210 URLs, 34
    # capacity values) purely because tiers 1 and 2 were enumerations and nothing enumerated
    # them. Same class as the four above: free to browse, listings operator-submitted, no
    # paywall. Not tier 3 — unlike datacenter.fyi these publish figures as given, not derived
    # from a constant PUE. Do not re-litigate; do not promote without a new decision.
    "ocolo.io": "oColo — free colocation directory",
    "gotcolo.com": "GotColo — free colocation directory",
    "datacentercatalog.com": "Data Center Catalog — free DC directory",
    "usdatamap.com": "US Data Map — free DC directory",
    "cloudandcolocation.com": "Cloud & Colocation — free DC directory",
    "colocationm.com": "Colocation M — free DC directory",
    "colomap.com": "ColoMap — free DC directory",
    # RULED ON 2026-08-07 by the project owner. Surfaced while draining the review queue: it
    # was one of only two source domains behind an `approved`-eligible row (ALE61), and it
    # passed EVERY check — tier 1, tier 3, review, and the fail-closed `unclassified_reason`
    # guard — so it had been supplying corroboration silently. Same class as the eleven above:
    # free to browse, no paywall, figures published as given rather than derived.
    #
    # It got through because the fail-closed guard matches directory-shaped HOSTNAMES and
    # "aterio" contains no directory token; the giveaway is in the PATH (/us-data-centers/).
    # That is the enumeration-blindness finding recurring on the guard built to fix it. The
    # guard is deliberately NOT widened to read paths here: trade press and operators' own
    # sites publish under paths like /data-centers/ too, and this ruling does not carry a
    # mandate to start refusing them. Left open and measured rather than patched blind.
    "aterio.io": "Aterio — free DC directory (path-shaped, hostname carries no tell)",
}

# TIER 3 — MODELED. A separate axis from licensing: these are free to use, but their numeric
# figures are DERIVED, not reported, and the site publishes no methodology. Using one is not a
# licensing problem — it is passing off a model's output as a measurement.
#
# datacenter.fyi was caught on 2026-07-21 supplying 49 capacity values. The tell is arithmetic,
# not editorial: three pages for three unrelated operators (CoreSite Reston, CoreSite San Jose,
# unWired Fresno) publish PUE = 1.666667447910563 / 1.6666666666666665 / 1.663716814159292 —
# all 5/3, to fifteen decimals — and on every page IT Load == Power Capacity / 1.6667 exactly.
# Real PUE varies 1.1–1.8 per facility and is never identical across operators. The magnitudes
# fail a sanity check too: CoreSite Reston VA1 is listed at 426.67 MW IT load, which would make
# one colo building a fifth of this project's entire OPERATING population (8,548 MW / 277 sites).
# The site self-describes as a "database" of "permits & public records" and states no method.
#
# DENIED for value extraction; still fine to READ for coverage research (same distinction
# decision #1 draws — looking is research, copying the curated value in is the prohibited act).
MODELED_FIGURES = {
    "datacenter.fyi": "datacenter.fyi — power/IT-load figures are modelled from a constant "
                      "PUE of 5/3, not reported; no published methodology",
    "datacenterindex.ai": "datacenterindex.ai — generated DC index, no published methodology",
}

# Domains whose NAME is directory-shaped. This is a tripwire, not a verdict: a match only means
# "this must be explicitly classified below before its numbers may be published". Trade press
# and operators' own sites match it too and are classified as such.
_DIRECTORY_SHAPE = re.compile(
    r"(datacent(?:er|re)|data-cent(?:er|re)|colocation|colocross|cologix|colomap|"
    r"(?:^|\.)ocolo\.|gotcolo|dcmap|dc-map|datamap)", re.I)

# Directory-shaped domains that are NOT directories. Enumerated because the tripwire above
# cannot tell "datacenterdynamics.com reports on the industry" from "datacenter.fyi sells a
# database of it", nor "datacenters.google is Google's own site" from a third-party listing.
TRADE_PRESS = {
    "datacenterdynamics.com", "datacenterknowledge.com", "datacenterfrontier.com",
    "datacenterpost.com", "datacenterhawk.com",   # hawk stays tier-1 denied; listed for shape only
}
FIRST_PARTY_OPERATOR = {
    "datacenters.google", "datacenters.atmeta.com", "cologix.com", "colocrossing.com",
    "streamdatacenters.com", "h5datacenters.com", "t5datacenters.com", "mdcdatacenters.com",
    "365datacenters.com", "dpdatacenters.com", "trgdatacenters.com", "sabeydatacenters.com",
    "info.sabeydatacenters.com", "coresite.com", "aligneddc.com", "vantage-dc.com",
}

_DENY_RE = re.compile(
    r"(?:^|\.)(" + "|".join(re.escape(d) for d in DENY_CURATED_COMPETITOR) + r")$", re.I)
_REVIEW_RE = re.compile(
    r"(?:^|\.)(" + "|".join(re.escape(d) for d in REVIEW_DIRECTORY) + r")$", re.I)
_MODELED_RE = re.compile(
    r"(?:^|\.)(" + "|".join(re.escape(d) for d in MODELED_FIGURES) + r")$", re.I)


def _host(url: str) -> str:
    try:
        h = (urlparse(url if "//" in url else "//" + url).hostname or "").lower()
    except ValueError:
        return ""
    return h[4:] if h.startswith("www.") else h


def denied_reason(url: str | None) -> str | None:
    """Why this URL may not be used as a source, or None if it is allowed."""
    if not url or not isinstance(url, str):
        return None
    host = _host(url)
    if not host:
        return None
    m = _DENY_RE.search(host)
    if m:
        return DENY_CURATED_COMPETITOR[m.group(1).lower()]
    return None


def is_allowed(url: str | None) -> bool:
    return denied_reason(url) is None


def filter_allowed(urls) -> tuple[list[str], list[tuple[str, str]]]:
    """(allowed, [(denied_url, reason)]). Denials are RETURNED, never silently dropped — an
    ingest path that quietly discards a source looks identical to one that found nothing."""
    ok, bad = [], []
    for u in urls or []:
        r = denied_reason(u)
        (bad.append((u, r)) if r else ok.append(u))
    return ok, bad


def review_reason(url: str | None) -> str | None:
    """Tier-2: a free directory whose use is a licensing judgement for the owner (warn only)."""
    if not url or not isinstance(url, str):
        return None
    m = _REVIEW_RE.search(_host(url))
    return REVIEW_DIRECTORY[m.group(1).lower()] if m else None


def modeled_reason(url: str | None) -> str | None:
    """Tier-3: figures are derived from a model, not reported. Refused for VALUE extraction."""
    if not url or not isinstance(url, str):
        return None
    m = _MODELED_RE.search(_host(url))
    return MODELED_FIGURES[m.group(1).lower()] if m else None


def unclassified_reason(url: str | None) -> str | None:
    """FAIL CLOSED. A directory-shaped domain that nobody has ruled on.

    The hole this closes: tiers 1 and 2 were both *enumerations*, so a domain in neither was
    silently allowed. Measured on the live store 2026-07-21, eight directory domains had entered
    that way and supplied 210 URLs — datacenter.fyi (123), ocolo.io (59, and now 403-ing us),
    gotcolo.com, datacentercatalog.com, datacenterindex.ai, cloudandcolocation.com,
    colocationm.com, colomap.com — none of which any ruling covers. An enumeration that only
    lists what you thought of cannot catch what you didn't.

    Deliberately narrow: it fires only on the directory SHAPE, so trade press and operators'
    own sites (which match the same regex) are classified out rather than blocking the pipeline.
    A non-directory domain we've never seen is not an admissibility question.
    """
    if not url or not isinstance(url, str):
        return None
    # Unlike the tier-1/2 checks — whose regexes are anchored to a full domain — the shape
    # tripwire is a SUBSTRING search, so it happily matches strings that are not URLs at all:
    # the record id `dcb-abilenedatacentercampus--tx-crusoe`, the entity name
    # "Anexio Datacenters, LLC", "Colocation America". `scan()` walks every string in the
    # payload, so without this guard the gate reported 641 "untiered directories", nearly all
    # of them our own ids. Require a real URL.
    if not re.match(r"https?://", url.strip(), re.I):
        return None
    host = _host(url)
    if not host or not _DIRECTORY_SHAPE.search(host):
        return None
    for known in (DENY_CURATED_COMPETITOR, REVIEW_DIRECTORY, MODELED_FIGURES):
        if any(host == d or host.endswith("." + d) for d in known):
            return None
    for d in TRADE_PRESS | FIRST_PARTY_OPERATOR:
        if host == d or host.endswith("." + d):
            return None
    return (f"'{host}' is directory-shaped but is in no tier — rule on it in source_policy "
            f"(DENY_CURATED_COMPETITOR / REVIEW_DIRECTORY / MODELED_FIGURES) or classify it "
            f"(TRADE_PRESS / FIRST_PARTY_OPERATOR) before its values are published")


def classify(url: str | None) -> str:
    """One label per URL: denied_tier1 | modeled_tier3 | tracked_tier2 | unclassified_directory
    | press | first_party | other."""
    if denied_reason(url):
        return "denied_tier1"
    if modeled_reason(url):
        return "modeled_tier3"
    if review_reason(url):
        return "tracked_tier2"
    if unclassified_reason(url):
        return "unclassified_directory"
    host = _host(url or "")
    if any(host == d or host.endswith("." + d) for d in TRADE_PRESS):
        return "press"
    if any(host == d or host.endswith("." + d) for d in FIRST_PARTY_OPERATOR):
        return "first_party"
    return "other"


# Tiers a VALUE may never be extracted from. Licensing (t1) and modelled-figures (t3) are
# different objections with the same remedy: do not take the number.
def value_denied_reason(url: str | None) -> str | None:
    return denied_reason(url) or modeled_reason(url)


_TIER_CHECK = {"deny": denied_reason, "review": review_reason,
               "modeled": modeled_reason, "unclassified": unclassified_reason}


def scan(obj, _path="", tier: str = "deny") -> list[tuple[str, str, str]]:
    """Walk any nested structure and return [(json_path, url, reason)] for denied sources.
    Used by the publish gate, which must catch a competitor URL wherever it hides — a
    Field<T>'s `sources`, an edge, a news row — not only where we thought to look."""
    out: list[tuple[str, str, str]] = []
    check = _TIER_CHECK.get(tier, denied_reason)
    if isinstance(obj, dict):
        for k, v in obj.items():
            out += scan(v, f"{_path}/{k}", tier)
    elif isinstance(obj, list):
        for v in obj:
            out += scan(v, _path, tier)
    elif isinstance(obj, str):
        r = check(obj)
        if r:
            out.append((_path or "/", obj, r))
    return out

"""Directory enumeration — build the operating install base from facility registries.

Phase B *news* discovery finds newsworthy new builds and so structurally misses
the existing operating base (TX: ~10 found vs ~125 real). This *enumerates* live
facilities from structured directories (PeeringDB first) — structured in,
structured out, no LLM. Each facility becomes an `operating` data_center row with
exact geo; a light cross-source dedup drops obvious name+state collisions with
existing rows; upserts key on a source-native natural key so re-runs are
idempotent. `emit` then projects these rows into data.json — no UI change needed.

Cross-source entity resolution (merging a PeeringDB facility with a news-sourced
row for the *same physical site*) is a Phase C refinement — v1 keeps them distinct
and only guards against the cheap name+state duplicate.
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert

from .clients import peeringdb
from .db import session_scope
from .models import DataCenter, Source
from .phaseb.normalize_dc import (
    DIRECTORY_DEFAULT_CATEGORY,
    _slug,
    canonical_developer,
    normalize_state,
)
from .phaseb.verify import _gate

DIRECTORY_CONFIDENCE = 0.75   # trusted registry, single-source, thin details → needs_review
PEERINGDB_TRUST = 0.8         # community-maintained registry with stable facility IDs


def _existing_site_keys(session) -> set[tuple[str, str]]:
    """(slug(name), state) for NON-directory rows only — the cross-source dedup guard.

    Directory rows (dce-pdb-*) are excluded on purpose: their idempotency comes from
    the natural key (upsert-on-id), so re-running enumerate must not treat prior
    directory rows as 'duplicates' of themselves. Full slug (not truncated) so we
    only drop a genuine same-name collision with a news/seed row, never a distinct
    facility that merely shares a name prefix."""
    keys: set[tuple[str, str]] = set()
    for dc in session.execute(select(DataCenter)).scalars():
        if (dc.id or "").startswith("dce-pdb-"):
            continue
        loc = dc.location or {}
        st = loc.get("state")
        if dc.project_name and st:
            keys.add((_slug(dc.project_name), st))
    return keys


def _row_from_facility(fac_cand: dict, today: str, now: datetime) -> dict | None:
    """Map a PeeringDB candidate → DataCenter upsert values (store-ready)."""
    name = (fac_cand.get("project_name") or "").strip()
    state = normalize_state(fac_cand.get("state"))
    url = fac_cand.get("url")
    if not name or not state or not url:
        return None
    operator = (fac_cand.get("operator") or "").strip() or name  # 'developer' is required downstream
    canon_op, _eid, category = canonical_developer(operator)
    category = category or DIRECTORY_DEFAULT_CATEGORY  # PeeringDB row = colo facility (source-backed)
    fid = fac_cand["source_id"].split(":", 1)[-1]
    return dict(
        id=f"dce-pdb-{fid}",
        natural_key=fac_cand["source_id"],            # peeringdb:{id} — idempotent re-runs
        project_name=name,
        aka=[],
        developer_name=canon_op or operator,
        developer_category=category,
        status="operating",                           # PeeringDB lists live facilities
        location={
            "county": None, "state": state, "country": fac_cand.get("country") or "US",
            "city": fac_cand.get("city"), "address": fac_cand.get("address"),
            "lat": fac_cand.get("lat"), "lng": fac_cand.get("lng"),
            # `or "exact"` alone fabricated a precise location for every facility PeeringDB
            # returned without coordinates (19 rows, caught by gate 12 on 2026-07-30). The
            # label has to describe what we actually got back, so it degrades to the finest
            # granularity we DO have rather than defaulting to the strongest claim.
            "geo_precision": (fac_cand.get("geo_precision")
                              or ("exact" if fac_cand.get("lat") is not None else
                                  "city" if fac_cand.get("city") else "state")),
        },
        overall_confidence=DIRECTORY_CONFIDENCE,
        review_status=_gate(DIRECTORY_CONFIDENCE, 1),  # single source → needs_review
        last_verified=today,
        sources=[url],
        updated_at=now,
    )


def enumerate_peeringdb(states: list[str]) -> dict:
    """Enumerate PeeringDB facilities for `states` (empty = US-national) → upsert."""
    states = [s.upper() for s in states]
    today = date.today().isoformat()
    now = datetime.now(timezone.utc)
    print(f"=== enumerate (PeeringDB) — states={states or 'US (national)'} ===")

    inserted = skipped_dup = 0
    with session_scope() as session:
        existing = _existing_site_keys(session)  # non-directory sites (news/seed)
        for st in (states or [None]):
            facs = peeringdb.facilities(state=st)
            print(f"  [{st or 'US'}] {len(facs)} PeeringDB facilities")
            for fac in facs:
                row = _row_from_facility(peeringdb.to_candidate(fac), today, now)
                if row is None:
                    continue
                # skip only genuine cross-source collisions with a news/seed row;
                # re-runs & campus siblings stay correct via upsert-on-id.
                if (_slug(row["project_name"]), row["location"]["state"]) in existing:
                    skipped_dup += 1
                    continue
                session.merge(Source(
                    id=row["sources"][0], url=row["sources"][0], publisher="PeeringDB",
                    type="directory", trust_weight=PEERINGDB_TRUST, retrieved_at=now,
                ))
                stmt = pg_insert(DataCenter).values(**row)
                update_cols = {k: stmt.excluded[k] for k in row if k not in ("id", "created_at")}
                stmt = stmt.on_conflict_do_update(index_elements=["id"], set_=update_cols)
                session.execute(stmt)
                inserted += 1

    print(f"✓ enumerate: upserted {inserted} operating data_center rows "
          f"(skipped {skipped_dup} name+state dupes vs existing)")
    return {"inserted": inserted, "skipped_dup": skipped_dup}

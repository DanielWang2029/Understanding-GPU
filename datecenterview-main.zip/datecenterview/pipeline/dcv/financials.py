"""financials — load the FMP financial spine into entity.financials (P2.2, L9).

Reads the committed fixture (pipeline/seed/financials.json — 8 disclosed mega-caps
pulled from FMP MCP + 21 compute_seed estimates; see build_financials_fixture.py)
and writes each backbone entity's market_cap/revenue into entity.financials,
honoring the L9 guardrails:
  - disclosed > estimated — never overwrite a stored disclosed value with an estimate;
  - market_cap deadband — skip sub-threshold wiggle (clients.fmp.material_move).
Idempotent. Only schema fields (market_cap, revenue, currency) are persisted; the
fixture's _cost_of_revenue/_net_income/_shares_out are kept for P3 and ignored here.

The fixture is the active path (the standalone pipeline can't reach FMP MCP and the
plan only serves 8 tickers); clients/fmp.py is the keyed REST automation path.
"""
from __future__ import annotations

import json
from pathlib import Path

from .clients.fmp import material_move
from .db import session_scope
from .models import ChangeLog, Entity

FIXTURE = Path(__file__).resolve().parent.parent / "seed" / "financials.json"
EDGAR_FIXTURE = Path(__file__).resolve().parent.parent / "seed" / "financials_edgar.json"
_MONEY_KEYS = ("value", "as_of", "basis", "period", "sources", "note", "unit")


def _money(field: dict) -> dict:
    return {k: field[k] for k in _MONEY_KEYS if k in field}


def load_financials(session, fixture: Path = FIXTURE,
                    edgar_fixture: Path = EDGAR_FIXTURE) -> dict:
    data = json.loads(fixture.read_text())
    # EDGAR overlay (Band-1 #1): disclosed revenue/capex for US filers, keyed by entity id.
    # Merged per-metric with disclosed>estimated so it widens the FMP-8 without touching
    # market_cap (EDGAR has no price) or the already-disclosed mega-caps (incl. the aws segment).
    edgar = {}
    if edgar_fixture and edgar_fixture.exists():
        edgar = {k: v for k, v in json.loads(edgar_fixture.read_text()).items()
                 if not k.startswith("_")}
    stats = {"updated": 0, "missing_entity": 0, "deadband_kept": 0,
             "disclosed": 0, "estimated": 0, "logged": 0, "edgar_disclosed": 0}
    for eid, fin in data.items():
        if eid.startswith("_"):
            continue
        e = session.get(Entity, eid)
        if e is None:
            stats["missing_entity"] += 1
            continue
        cur = dict(e.financials or {})
        new_mc = _money(fin["market_cap"])
        old_mc = cur.get("market_cap") or {}
        # L9 deadband: an immaterial move keeps the stored VALUE + as_of (so freshness
        # reflects the last MATERIAL change, not this no-op refresh) — but static metadata
        # (unit/note/sources/basis) is still carried forward, not frozen.
        if (old_mc.get("basis") == new_mc.get("basis")
                and not material_move(old_mc.get("value"), new_mc.get("value"))):
            new_mc = {**new_mc, "value": old_mc.get("value"),
                      "as_of": old_mc.get("as_of", new_mc.get("as_of"))}
            stats["deadband_kept"] += 1
        out = {"market_cap": new_mc, "revenue": _money(fin["revenue"]),
               "currency": fin.get("currency", "USD")}
        if "capex" in fin:
            out["capex"] = _money(fin["capex"])
        # EDGAR overlay: a disclosed revenue/capex supersedes the fixture's ESTIMATE only —
        # never a fixture-disclosed value (defense-in-depth: keeps EDGAR's parent-consolidated
        # figure off a segment node like aws even if the fixture were mis-built).
        eg = edgar.get(eid, {})
        for k in ("revenue", "capex"):
            egk = eg.get(k)
            if egk and egk.get("basis") == "disclosed" and (out.get(k) or {}).get("basis") != "disclosed":
                out[k] = _money(egk)
                stats["edgar_disclosed"] += 1
        # disclosed > estimated: never let an estimate overwrite a stored disclosed value
        for k in ("market_cap", "revenue", "capex"):
            if k in out and (cur.get(k) or {}).get("basis") == "disclosed" and out[k].get("basis") == "estimated":
                out[k] = cur[k]
        # L4 delta-log: record a value/basis change so the loop can later answer
        # "did the estimate hold up against the disclosure?" (only fires on real change).
        for k in ("market_cap", "revenue", "capex"):
            if k not in out:
                continue
            oldf, newf = (cur.get(k) or {}), out[k]
            if oldf.get("value") != newf.get("value") or oldf.get("basis") != newf.get("basis"):
                session.add(ChangeLog(
                    record_type="entity", record_id=eid, field=f"financials.{k}",
                    old=oldf or None, new=newf,
                    source_id=(newf.get("sources") or [None])[0]))
                stats["logged"] += 1
        e.financials = out
        if fin.get("ticker"):  # keep identifiers.ticker in sync
            ids = dict(e.identifiers or {})
            ids.setdefault("ticker", fin["ticker"])
            e.identifiers = ids
        stats["updated"] += 1
        stats[out["revenue"]["basis"]] += 1
    return stats


def run() -> None:
    with session_scope() as s:
        st = load_financials(s)
    print(f"✓ financials loaded — {st['updated']} entities "
          f"({st['disclosed']} disclosed, {st['estimated']} estimated by revenue basis; "
          f"{st['edgar_disclosed']} metrics from EDGAR); "
          f"{st['deadband_kept']} market_cap kept by deadband, "
          f"{st['logged']} change-log entries, {st['missing_entity']} missing entities")

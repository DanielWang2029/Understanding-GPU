"""Seed the store from the demo read-model (pipeline/seed/demo_seed.json).

The demo's curated rows (data centers, entities, edges, news, supply chain) are
the illustrative bridge the specs describe: Phase A layers real power projects on
top of them. Idempotent upsert by id.
"""
from __future__ import annotations

import json

from .config import settings
from .db import session_scope
from .field import field
from .models import (
    DataCenter, Edge, Entity, Feed, News, PowerProject, SupplyLink, SupplyNode,
)

SEED_PATH = settings.repo_root / "pipeline" / "seed" / "demo_seed.json"

DISPLAY_TO_LIFECYCLE = {
    "Planned": "proposed",
    "Under construction": "under_construction",
    "Operating": "operating",
    "Cancelled": "cancelled",
    "Retired": "retired",
    "On hold": "on_hold",
}


def _lc(display: str | None) -> str:
    return DISPLAY_TO_LIFECYCLE.get(display or "", "proposed")


def seed_store() -> dict:
    d = json.loads(SEED_PATH.read_text())
    ds = d["datasets"]
    counts: dict[str, int] = {}

    with session_scope() as s:
        for f in d.get("feeds", []):
            s.merge(Feed(id=f["id"], name=f["name"], type=f.get("type", "rss")))
        counts["feeds"] = len(d.get("feeds", []))

        for e in d.get("entities", []):
            s.merge(Entity(id=e["id"], name=e["name"], category=e.get("category", "other")))
        counts["entities"] = len(d.get("entities", []))
        s.flush()  # parents (feeds, entities) before children (news, edges)

        for r in ds["data_center"]:
            srcs = r.get("sources", [])
            s.merge(DataCenter(
                id=r["id"],
                natural_key=f"seed:{r['id']}",
                project_name=r["project_name"],
                developer_name=r.get("developer"),
                end_user_name=r.get("end_user"),
                developer_category=r.get("developer_category"),
                status=_lc(r.get("status")),
                capacity_mw=field(r.get("capacity_mw"), unit="MW", sources=srcs,
                                  confidence=r.get("confidence", 0.0), method="extracted",
                                  last_verified=r.get("last_verified")),
                cap_ex=field(r.get("cap_ex"), unit="USD", sources=srcs,
                             confidence=r.get("confidence", 0.0), method="extracted")
                if r.get("cap_ex") is not None else None,
                location={"county": r.get("county"), "state": r.get("state"), "country": "US",
                          "lat": r.get("lat"), "lng": r.get("lng"),
                          "geo_precision": "exact" if r.get("lat") else "county"},
                operating_year=r.get("operating_year"),
                overall_confidence=r.get("confidence"),
                review_status=r.get("review_status", "approved"),
                last_verified=r.get("last_verified"),
                sources=srcs,
            ))
        counts["data_center"] = len(ds["data_center"])

        for r in ds["power_project"]:
            srcs = r.get("sources", [])
            s.merge(PowerProject(
                id=r["id"],
                natural_key=f"seed:{r['id']}",
                project_name=r["project_name"],
                developer_name=r.get("developer"),
                technology=r.get("technology", "Other"),
                capacity_mw=field(r.get("capacity_mw"), unit="MW", sources=srcs,
                                  confidence=r.get("confidence", 0.9), method="iso"),
                status=_lc(r.get("status")),
                balancing_authority=r.get("balancing_authority"),
                location={"county": r.get("county"), "state": r.get("state"), "country": "US",
                          "lat": r.get("lat"), "lng": r.get("lng"),
                          "geo_precision": "exact" if r.get("lat") else "county"},
                btm_datacenter_signal=field(True, confidence=0.5, method="iso", sources=srcs)
                if r.get("btm") else None,
                operating_year=r.get("operating_year"),
                source=r.get("source", "seed"),
                confidence=r.get("confidence", 0.9),
                review_status=r.get("review_status", "approved"),
                last_verified=r.get("last_verified"),
                sources=srcs,
                # keep the demo's narrative BTM linkage in provenance
                source_ref=r.get("linked"),
            ))
        counts["power_project"] = len(ds["power_project"])

        for n in ds["news"]:
            s.merge(News(
                id=n["id"], type=n.get("type", "news"), title=n["title"],
                publisher=n.get("publisher"), published_date=n.get("published_date"),
                url=n.get("url"), tag=n.get("tag"), source_feed=n.get("source_feed"),
                project_refs=n.get("projects", []),
            ))
        counts["news"] = len(ds["news"])

        for e in d.get("edges", []):
            s.merge(Edge(
                id=f"{e['project']}|{e['relation']}|{e['org']}",
                from_id=e["project"], to_id=e["org"], relation=e["relation"],
                confidence=e.get("confidence", 0.7), sources=e.get("sources", []),
            ))
        counts["edges"] = len(d.get("edges", []))

        sc = d.get("supply_chain", {})
        for node in sc.get("nodes", []):
            s.merge(SupplyNode(id=node["id"], label=node["label"],
                               category=node["category"], rev=node.get("rev"),
                               note=node.get("note")))
        s.flush()  # supply_node parents before supply_link children (FK)
        for link in sc.get("links", []):
            s.merge(SupplyLink(
                id=f"{link['source']}>{link['target']}",
                source_id=link["source"], target_id=link["target"],
                value=link["value"], title=link.get("title"),
            ))
        counts["supply_nodes"] = len(sc.get("nodes", []))
        counts["supply_links"] = len(sc.get("links", []))

    print("✓ seeded:", ", ".join(f"{k}={v}" for k, v in counts.items()))
    return counts

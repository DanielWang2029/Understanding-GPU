"""dedup — collapse duplicate data_center rows so the read-model stops double-counting MW.

Phase C listed dedup as designed-not-built. The 2026-07-21 capacity audit measured what that
costs: 27 locations hold 66 rows at *identical* coordinates, carrying **11,401 MW** beyond the
largest row at each — `El Paso Data Center` three times at 1,000 MW on the same lat/lng,
`CoreWeave Plano` three times at 13 MW, `QTS Turkey Data Center Campus` twice at 1,000 MW.
Anyone summing the capacity column, or reading the Explorer's MW ordering, is reading inflated
numbers.

    Setpoint       zero duplicate facilities in the published read-model
    Measured value groups found by the two matchers, and the MW they double-count
                   (live: `meta.rollups.dedup`)
    Error signal   groups_open > 0 — i.e. duplicates that exist but are not yet collapsed
    Correction     mark the losers `duplicate_of = <survivor id>`; emit drops them and folds
                   their sources into the survivor
    Mechanism      maker-checker with a HUMAN maker. Two independent matchers propose
                   (coordinates, normalised name+state); a person applies. There is no
                   auto-apply path — see below.

WHY NO AUTO-APPLY. Merging is destructive in the way that matters: two buildings on one campus
are a legitimate pair of rows (`Sweetwater 1` 1,400 MW and `Sweetwater 2` 600 MW share a
coordinate and are NOT duplicates), and collapsing them silently deletes real capacity. The
matchers cannot tell those from `El Paso Data Center` x3. So this proposes and a human decides,
exactly like the review queue.

THE UNDO IS THE POINT. `duplicate_of` is a mark, never a delete — `undo()` clears it and the
row returns to the read-model unchanged. `apply()` is idempotent (re-marking an already-marked
row is a no-op, and a survivor can never itself be marked), so running it twice cannot cascade
a group into nothing. Both properties are exercised in tests/test_dedup.py.

...BUT AN UNDO NEEDS TO KNOW WHAT TO UNDO. Until 2026-08-07 this module wrote no `change_log`
entry — the only write path here that didn't — so a mark carried no record of WHEN it was made
or by which run. That is not theoretical: a scoping bug in `--elect` collapsed all 35 open
groups at once (50 rows, -2,734 MW), and because every mark looked alike, separating that run's
50 from the 15 legitimate pre-existing ones took an out-of-band comparison against the last
committed `data.json`. Had the marks not happened to be separable that way, the recovery would
have been guesswork.

So every `apply()` now stamps a BATCH id and logs, per row, what it did and what it displaced;
`undo(batch=...)` reverses exactly one run, and `batches()` lists them. The batch is the unit a
human actually thinks in ("undo what I just did"), which a timestamp alone is not — two runs a
second apart are indistinguishable by clock.

Two mutations are logged, not one. `apply()` marks the loser AND folds the loser's sources into
the survivor, and `undo()` deliberately reverses only the first (see its docstring). Logging
just the mark would let the trail imply a clean reversal that is not clean; the `sources` entry
carries the survivor's list from before the fold, so the second half is recoverable by hand.
"""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import datetime, timezone
from uuid import uuid4

from sqlalchemy import select

from .db import session_scope
from .models import ChangeLog, DataCenter

# Tokens that distinguish nothing — "X Data Center" and "X" are the same facility.
_NOISE = re.compile(r"\b(data\s*cent(?:er|re)s?|campus|facility|facilities|site|dc|llc|inc)\b",
                    re.I)
_NONWORD = re.compile(r"[^a-z0-9]+")
# 4 decimal places ~= 11 m. Tighter than a building; loose enough to survive re-geocoding.
COORD_DP = 4


def norm_name(s: str | None) -> str:
    return _NONWORD.sub("", _NOISE.sub(" ", (s or "").lower()))


def _rounded(loc: dict):
    lat, lng = loc.get("lat"), loc.get("lng")
    if lat is None or lng is None:
        return None
    return (round(float(lat), COORD_DP), round(float(lng), COORD_DP))


def _centroids(rows) -> set:
    """Coordinates that are a COUNTY/STATE centroid, not a building.

    Without this the coordinate matcher proposes nonsense: `Project Kilby` (2,700 MW),
    `Pecos Datacenter Campus` (2,000 MW) and `Alpha Digital Campus` (2,000 MW) share
    31.308366,-103.712706 — the Reeves County centroid — and are three different projects.

    A coordinate counts as a centroid if ANY row calls it county/state precision, even when
    another row claims `exact` there. `Pecos` is exactly that case: same centroid, precision
    mislabelled `exact`. Trusting the optimistic label per-row would re-admit the bad group;
    the pessimistic reading across rows is the safe one.
    """
    out = set()
    for r in rows:
        loc = r.location or {}
        if loc.get("geo_precision") in ("county", "state"):
            k = _rounded(loc)
            if k:
                out.add(k)
    return out


def _coord_key(r: DataCenter, centroids: set):
    loc = r.location or {}
    k = _rounded(loc)
    if k is None or k in centroids or loc.get("geo_precision") != "exact":
        return None
    return ("coord", *k)


def _name_key(r: DataCenter):
    n = norm_name(r.project_name)
    # A 1-3 char residue after noise-stripping ("DC1" -> "1") collides indiscriminately.
    if len(n) < 4:
        return None
    return ("name", n, (r.location or {}).get("state"))


def _cap(r: DataCenter) -> float:
    v = (r.capacity_mw or {}).get("value") if isinstance(r.capacity_mw, dict) else None
    return float(v or 0)


def _rank(r: DataCenter):
    """Survivor = the most complete row: HAS a capacity first, then most evidence, then size.

    Capacity leads because ranking on sources alone picked a sizeless survivor for the
    `CoreWeave Plano` trio — three rows, two of them 13 MW, and the winner 0 MW. Collapsing to
    that would have deleted the only real number in the group while looking like a cleanup.
    """
    return (1 if _cap(r) > 0 else 0, len(r.sources or []), r.overall_confidence or 0,
            _cap(r), r.id or "")


def find_groups(matcher: str = "both") -> list[dict]:
    """Propose duplicate groups. Read-only — nothing is written.

    "Is a duplicate of" is an EQUIVALENCE relation, so the two matchers are unioned into
    connected components rather than reported as independent groups. Running them separately
    produced overlapping groups — `El Paso Data Center` was a loser of the coordinate group and
    the survivor of the name group at the same time — which made `mw_double_counted` itself
    double-count (16,418 MW against a true 12,057) and left `apply()` unable to act on either.
    """
    with session_scope() as s:
        rows = [r for r in s.execute(select(DataCenter)).scalars()
                if getattr(r, "duplicate_of", None) is None]
        centroids = _centroids(rows)
        keyfns = {"coord": [lambda r: _coord_key(r, centroids)], "name": [_name_key],
                  "both": [lambda r: _coord_key(r, centroids), _name_key]}[matcher]

        parent: dict[str, str] = {r.id: r.id for r in rows}

        def root(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            ra, rb = root(a), root(b)
            if ra != rb:
                parent[rb] = ra

        matched_by: dict[str, set] = defaultdict(set)
        for keyfn in keyfns:
            buckets = defaultdict(list)
            for r in rows:
                k = keyfn(r)
                if k is not None:
                    buckets[k].append(r)
            for k, members in buckets.items():
                if len(members) < 2:
                    continue
                for m in members[1:]:
                    union(members[0].id, m.id)
                for m in members:
                    matched_by[root(members[0].id)].add(k[0])

        comps: dict[str, list] = defaultdict(list)
        for r in rows:
            comps[root(r.id)].append(r)

        groups = []
        for cid, members in comps.items():
            if len(members) < 2:
                continue
            members = sorted(members, key=_rank, reverse=True)
            survivor, losers = members[0], members[1:]
            groups.append({
                "matcher": "+".join(sorted(matched_by.get(cid) or {"?"})),
                "survivor": {"id": survivor.id, "name": survivor.project_name,
                             "mw": _cap(survivor), "sources": len(survivor.sources or [])},
                "losers": [{"id": m.id, "name": m.project_name, "mw": _cap(m),
                            "sources": len(m.sources or [])} for m in losers],
                # what collapsing this group removes from the published MW total
                "mw_double_counted": round(sum(_cap(m) for m in losers), 3),
                # a real tell that these are NOT duplicates: materially different sizes.
                # `Sweetwater 1` (1,400 MW) and `Sweetwater 2` (600 MW) share an exact
                # coordinate and are two buildings on one campus, not one row twice.
                "mw_disagree": bool(losers) and max(
                    abs(_cap(m) - _cap(survivor)) for m in losers
                ) > 0.05 * max(_cap(survivor), 1),
                # ...but that tell is SILENT when nobody in the group has a size. `_cap`
                # returns 0.0 for a missing value, so two sizeless rows "agree" trivially and
                # the group was classed auto — batch-collapsible. 199 of 497 rows are sizeless,
                # so this was not an edge case. It shipped two false positives on 2026-07-31:
                # `PROJECT EAGLE - BUILDING A` vs `BUILDING B` (distinct TDLR permits
                # TABS2026023825/26, one campus, one coordinate) and Meta's El Paso site vs
                # Meta's TEMPLE site (both literally named "Meta data center", both TX, one
                # missing its county). Agreement on a null is not evidence of identity.
                "mw_uninformative": not any(_cap(m) for m in [survivor, *losers]),
            })
        return sorted(groups, key=lambda g: -g["mw_double_counted"])


def stats() -> dict:
    """The live measured value for `meta.rollups.dedup`."""
    groups = find_groups()
    with session_scope() as s:
        marked = sum(1 for r in s.execute(select(DataCenter)).scalars()
                     if getattr(r, "duplicate_of", None) is not None)
    return {
        "groups_open": len(groups),
        "rows_open": sum(len(g["losers"]) for g in groups),
        "mw_double_counted": round(sum(g["mw_double_counted"] for g in groups), 1),
        "groups_needing_human": sum(1 for g in groups
                                    if g["mw_disagree"] or g["mw_uninformative"]),
        "rows_marked_duplicate": marked,
        "note": "groups are PROPOSED by two matchers (identical coordinates; normalised "
                "name+state) and applied by a human — two buildings on one campus share a "
                "coordinate and are not duplicates. `mw_double_counted` is what the published "
                "capacity total would shed if every open group were collapsed.",
    }


_APPLY_SRC = "dedup:apply:"
_UNDO_SRC = "dedup:undo:"


def _batch_id() -> str:
    """Identify one `apply()` run.

    A colliding batch id is worse than no batch id — `undo --batch` would reverse two runs
    while reporting one — so uniqueness cannot rest on the clock. Millisecond resolution is
    not enough on its own: 200 consecutive calls land in the SAME millisecond (measured), and
    two applies in one second is the ordinary case when collapsing groups from a shell loop.
    Hence the random tail. The timestamp leads so ids still sort chronologically as strings.
    """
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%f")[:-3]
    return f"{stamp}Z-{uuid4().hex[:6]}"


def apply(group_ids: list[str] | None = None, *, allow_disagree: bool = False,
          elect: str | None = None) -> dict:
    """Mark the losers of each proposed group `duplicate_of = <survivor>`.

    `group_ids` = survivor ids to act on; None = every group whose members agree on capacity.
    Idempotent: a row already marked is skipped, and a row that is some other group's survivor
    is never marked, so re-running cannot cascade a group into nothing.
    """
    groups = find_groups()

    # ELECT: override the auto-ranked survivor for the group containing `elect`.
    #
    # `_rank` orders by (has_capacity, n_sources, confidence, capacity, id). When two rows tie
    # on capacity and sources, CONFIDENCE decides — and confidence is not completeness. Both
    # groups the 2026-07-31 sweep produced elected the row with NO quote over the row that had
    # one, and the Crusoe group's auto-survivor also lacked `op=Oracle` / `tenant=Microsoft`
    # that its loser carried. Collapsing to it would have kept the number and thrown away the
    # evidence for it — the next iteration of "the survivor must keep the capacity".
    #
    # A human electing the survivor is the same maker-checker shape as the rest of this module:
    # the matchers propose, a person decides. `undo()` still reverses it.
    if elect:
        for g in groups:
            ids = [g["survivor"]["id"]] + [lo["id"] for lo in g["losers"]]
            if elect not in ids:
                continue
            if elect != g["survivor"]["id"]:
                new_sv = next(lo for lo in g["losers"] if lo["id"] == elect)
                old_sv = g["survivor"]
                g["losers"] = [lo for lo in g["losers"] if lo["id"] != elect] + [old_sv]
                g["survivor"] = new_sv
                g["mw_double_counted"] = round(sum(lo["mw"] for lo in g["losers"]), 3)
            # SCOPE TO THIS GROUP. Electing a survivor is a statement about ONE group, so it
            # must not widen the blast radius. Without this, `--elect X` with no `--survivor`
            # left group_ids None, every group passed the filter, and combining it with
            # --allow-disagree collapsed all 35 open groups at once (50 rows, -2,734 MW)
            # instead of the one intended. Electing implies the selection.
            if group_ids is None:
                group_ids = [g["survivor"]["id"]]
            break
        else:
            raise ValueError(f"--elect {elect!r} is not a member of any open duplicate group")

    survivors = {g["survivor"]["id"] for g in groups}
    batch = _batch_id()
    src_id = f"{_APPLY_SRC}{batch}"
    n_marked = mw = 0
    skipped = []
    with session_scope() as s:
        for g in groups:
            sid = g["survivor"]["id"]
            if group_ids is not None and sid not in group_ids and sid != elect:
                continue
            if (g["mw_disagree"] or g["mw_uninformative"]) and not allow_disagree:
                skipped.append((sid, "members disagree on capacity — needs a human"
                                if g["mw_disagree"] else
                                "no member has a capacity — the size check cannot tell these "
                                "apart, so a human must"))
                continue
            marked_here: list[str] = []
            for lo in g["losers"]:
                r = s.get(DataCenter, lo["id"])
                if r is None or getattr(r, "duplicate_of", None) is not None:
                    continue          # idempotence: already marked
                if r.id in survivors and r.id != sid:
                    continue          # never mark another group's survivor
                r.duplicate_of = sid
                # The decision, per row. `old` is spelled out rather than left None because the
                # guard above is what makes it None — a reader should not have to re-derive that.
                s.add(ChangeLog(
                    record_type="data_center", record_id=r.id, field="duplicate_of",
                    old={"duplicate_of": None},
                    new={"duplicate_of": sid, "batch": batch, "mw_removed": lo["mw"],
                         "matcher": g["matcher"],
                         # whether a human overrode the auto-rank matters when reading this
                         # back: an elected survivor is a judgement, not a computed one.
                         "elected_survivor": elect == sid},
                    source_id=src_id))
                marked_here.append(r.id)
                n_marked += 1
                mw += lo["mw"]
            # Fold the losers' evidence into the survivor rather than losing it — ONCE per
            # group, after the marks. Folding inside the loop re-read a list this loop had
            # already mutated, so `old` could never name the pre-fold state.
            sv = s.get(DataCenter, sid) if marked_here else None
            if sv is not None:
                before = list(sv.sources or [])
                merged = list(before)
                for lid in marked_here:
                    lr = s.get(DataCenter, lid)
                    for u in (lr.sources or []) if lr is not None else ():
                        if u not in merged:
                            merged.append(u)
                if merged != before:
                    sv.sources = merged
                    # `undo()` does NOT unfold these (deliberate — see its docstring). Logging
                    # the survivor's pre-fold list is what keeps that a documented choice
                    # rather than an unrecoverable one.
                    s.add(ChangeLog(
                        record_type="data_center", record_id=sid, field="sources",
                        old={"sources": before},
                        new={"sources": merged, "batch": batch, "folded_from": marked_here},
                        source_id=src_id))
    return {"marked": n_marked, "mw_removed": round(mw, 3), "skipped": skipped,
            "batch": batch}


def undo(survivor_ids: list[str] | None = None, *, batch: str | None = None) -> dict:
    """Clear `duplicate_of`. The reversal `loop-design` requires be exercised, not just written.

    Three selectors, narrowing: `batch` = exactly what one `apply()` run marked (the one a
    human means by "undo what I just did"); `survivor_ids` = whole groups; neither = everything.
    Both may be combined, in which case they intersect.

    `batch` RE-CHECKS THE DECISION rather than clearing whatever it finds. A row marked by
    batch A, undone, and re-marked by batch B is no longer batch A's to reverse — clearing it
    would silently undo B while reporting that it undid A. Those rows come back as `refused`,
    the same shape `capacity_audit.restore()` uses for the same reason.

    Note what this does NOT restore: sources folded into the survivor by `apply()` stay there.
    That is deliberate — they are real sources for a facility either way, and removing them
    would be a second guess about which row they described. The row itself returns intact. The
    pre-fold list is in the change log (`field="sources"`) if it is ever needed by hand.
    """
    with session_scope() as s:
        targets: dict[str, str] | None = None
        if batch:
            entries = s.execute(
                select(ChangeLog).where(ChangeLog.source_id == f"{_APPLY_SRC}{batch}",
                                        ChangeLog.field == "duplicate_of")).scalars().all()
            if not entries:
                raise ValueError(f"no dedup batch {batch!r} in the change log — "
                                 f"list them with `dcv dedup --batches`")
            targets = {e.record_id: (e.new or {}).get("duplicate_of") for e in entries}

        n = refused = 0
        for r in s.execute(select(DataCenter)).scalars():
            d = getattr(r, "duplicate_of", None)
            if d is None:
                continue
            if survivor_ids is not None and d not in survivor_ids:
                continue
            if targets is not None:
                if r.id not in targets:
                    continue
                if d != targets[r.id]:
                    refused += 1     # re-marked since; not this batch's to reverse
                    continue
            r.duplicate_of = None
            s.add(ChangeLog(
                record_type="data_center", record_id=r.id, field="duplicate_of",
                old={"duplicate_of": d}, new={"duplicate_of": None},
                source_id=f"{_UNDO_SRC}{batch}" if batch else f"{_UNDO_SRC}all"))
            n += 1
    return {"restored": n, "refused": refused}


def batches(limit: int = 20) -> list[dict]:
    """What each `apply()` run did. An audit trail nobody can read is half a fix — without
    this, recovering a bad run means knowing its batch id in advance, which is exactly the
    position the 35-group over-apply left us in.

    `still_marked` is queried LIVE against the store rather than inferred from later log
    entries, so a batch partially reversed by hand reports honestly instead of claiming the
    reversal it has a log line for.
    """
    with session_scope() as s:
        entries = s.execute(
            select(ChangeLog).where(ChangeLog.source_id.like(f"{_APPLY_SRC}%"),
                                    ChangeLog.field == "duplicate_of")).scalars().all()
        live = {r.id: r.duplicate_of for r in s.execute(select(DataCenter)).scalars()
                if getattr(r, "duplicate_of", None) is not None}

    by: dict[str, dict] = {}
    for e in entries:
        new = e.new or {}
        bid = new.get("batch") or "?"
        b = by.setdefault(bid, {"batch": bid, "ts": e.ts, "rows": 0, "mw_removed": 0.0,
                                "survivors": set(), "elected": False, "still_marked": 0})
        b["rows"] += 1
        b["mw_removed"] += float(new.get("mw_removed") or 0)
        b["survivors"].add(new.get("duplicate_of"))
        b["elected"] = b["elected"] or bool(new.get("elected_survivor"))
        if live.get(e.record_id) == new.get("duplicate_of"):
            b["still_marked"] += 1
        if e.ts and (b["ts"] is None or e.ts < b["ts"]):
            b["ts"] = e.ts

    out = [{**b, "survivors": sorted(x for x in b["survivors"] if x),
            "mw_removed": round(b["mw_removed"], 3)} for b in by.values()]
    return sorted(out, key=lambda b: b["batch"], reverse=True)[:limit]

"""reverify — re-run the cross-vendor trust gate on rows that were never verified (Band 2 #2).

Decision #4: "the agent that VERIFIES a fact uses a different vendor than the one that
extracted it… this is what makes an automated 'audit-approved' flag trustworthy." When the
verifier is unreachable, `phaseb.verify` fails CLOSED — it holds the candidate as `reported`
with a conservative confidence rather than letting it through. That is the right behaviour,
and it is exactly what happened on the 2026-07-20 volume run: the Anthropic API ran out of
credit mid-run and 48 of 55 rows persisted unverified.

Fail-closed leaves a debt, though: those rows are in the store carrying an extraction that no
second vendor ever checked. This re-runs ONLY the verify stage against them — no discovery,
no re-extraction — so recovering from an outage costs a few Claude calls instead of a whole
sweep.

Strength depends on whether the row carries its extraction QUOTE. Quotes are persisted as of
2026-07-20; rows written before that have none and reconstruct values-only, which is a weaker
check — the verifier still runs its own independent web search over project / capacity /
location, but it is corroborating our VALUES rather than our values-plus-evidence. Each run
reports the split, and each row's ChangeLog entry records which basis was used
(`reverify_with_quote` vs `reverify_no_quote`) so a reader can tell the three apart: a
first-pass verdict, a full-strength re-verification, and a values-only one.

Any corroborating source the verifier finds is PERSISTED. Keeping the verdict while
discarding the evidence that justified it is how a row ends up asserting `approved` on two
sources while showing one — which is exactly what the first build of this module did.
"""
from __future__ import annotations

from datetime import date

from sqlalchemy import select

from . import source_policy
from .config import settings
from .db import session_scope
from .field import field_quote, field_value
from .models import ChangeLog, DataCenter


def _candidate(dc: DataCenter) -> dict:
    """Rebuild the candidate shape `phaseb.verify.verify()` needs from a stored row.

    Quotes are read back from the stored Field<T> where present. Rows written before quotes
    were persisted have none, and reconstruct without them — a weaker check, which is why
    `has_quote` is reported so a run can say how much of its work was full-strength.
    """
    loc = dc.location or {}
    return {
        "project_name": dc.project_name,
        "capacity_mw": {"value": field_value(dc.capacity_mw),
                        "quote": field_quote(dc.capacity_mw)},
        "status": {"value": dc.status, "quote": None},   # status has no Field<T> container
        "location": {"county": loc.get("county"), "state": loc.get("state"),
                     "address": None, "quote": loc.get("quote")},
        "sources": [{"url": u} for u in (dc.sources or [])],
        "self_consistency": dc.overall_confidence or 0.5,
    }


def reverify(limit: int | None = None, status: str = "reported", dry_run: bool = True,
             max_sources: int | None = None, segment: str | None = None) -> dict:
    """Re-run the cross-vendor gate over rows in `status`. Returns run stats."""
    from .phaseb.verify import verify as verify_one

    # WIRE THE GOVERNOR. This is a paid path — one Claude call per row, and `--segment
    # reverifiable` alone is 262 of them — but it never configured the ledger, so it inherited
    # SpendLedger's hardcoded 25.0 default instead of the operator's setting. That is a cap by
    # accident: it happens to be right, and it silently ignores `daily_spend_limit_usd` if
    # anyone ever changes it. Every other paid entry point (enrich, phaseb.pipeline, bakeoff)
    # configures it explicitly; so does this one now.
    from .clients import spend
    spend.configure(settings.daily_spend_limit_usd)

    today = date.today().isoformat()
    st = {"considered": 0, "reverified": 0, "failed": 0, "dry_run": dry_run,
          "moved": {}, "unchanged": 0, "sources_added": 0, "sources_refused": 0,
          "with_quote": 0, "without_quote": 0}
    with session_scope() as s:
        rows = [d for d in s.execute(select(DataCenter)).scalars()
                if d.review_status == status]
        if max_sources is not None:
            # Target rows whose verdict outran their evidence — e.g. `approved` on one source
            # when the gate needs two, which is what discarding the corroborating source left
            # behind. Re-verifying either recovers the source or correctly demotes the row.
            rows = [d for d in rows if len(d.sources or []) <= max_sources]
        if segment:
            # Spend against the SAME classifier the queue report counts with. Selecting by
            # status alone would sweep all 401 queued rows when only the 262 `reverifiable`
            # ones were costed and approved — and 129 of the rest are evidence-blocked, where
            # a verify call is not the input that moves them.
            from .review import SEGMENT_NAMES, classify_row
            if segment not in SEGMENT_NAMES:
                raise ValueError(f"segment must be one of {list(SEGMENT_NAMES)} — got {segment!r}")
            rows = [d for d in rows if classify_row(d) == segment]
        # A row already marked duplicate is dropped by emit; paying to verify it buys nothing.
        rows = [d for d in rows if getattr(d, "duplicate_of", None) is None]
        rows.sort(key=lambda d: -(field_value(d.capacity_mw) or 0))
        if limit:
            rows = rows[:limit]
        st["considered"] = len(rows)
        if dry_run:
            return st
        for dc in rows:
            cand = _candidate(dc)
            st["with_quote" if field_quote(dc.capacity_mw) else "without_quote"] += 1
            try:
                out = verify_one(cand)
            except Exception as e:  # one bad row must not sink the batch
                print(f"  [reverify] {dc.project_name[:40]}: {type(e).__name__}: {e}")
                st["failed"] += 1
                continue
            if (out.get("verify") or {}).get("error"):
                st["failed"] += 1          # verifier still unreachable — leave the row alone
                continue
            new_status = out.get("review_status") or status
            conf = out.get("overall_confidence")

            # KEEP THE EVIDENCE, not just the verdict. `verify()` appends any independently
            # corroborating source it finds, and the approve gate needs >=2 sources — so
            # dropping them left rows asserting `approved` on evidence the record no longer
            # contained. Persist them, subject to the source policy: the verifier does its own
            # web search and can surface a curated competitor OR a modelled-figure directory
            # like any other search. A source it adds becomes value-provenance on a sized row,
            # so filter with the SAME test the publish gate enforces — value_denied_reason
            # (tier-1 competitor AND tier-3 modelled), not denied_reason (tier-1 only). Using
            # the weaker check let two datacenter.fyi URLs onto sized rows and gate 10 blocked
            # publish — the ingest path must match the backstop, not lag it.
            added = []
            for src in out.get("sources") or []:
                u = src.get("url") if isinstance(src, dict) else src
                if not u or u in (dc.sources or []):
                    continue
                if source_policy.value_denied_reason(u):
                    st["sources_refused"] += 1
                    continue
                added.append(u)
            if added:
                dc.sources = list(dc.sources or []) + added
                st["sources_added"] += len(added)

            if new_status == dc.review_status:
                st["unchanged"] += 1
            else:
                st["moved"][f"{dc.review_status}->{new_status}"] = \
                    st["moved"].get(f"{dc.review_status}->{new_status}", 0) + 1
            # Record the BASIS in the audit trail, per row. A reader must be able to tell a
            # first-pass verdict from a full-strength re-verification from a values-only one.
            # (An earlier build claimed this marker in its docstring without writing it — the
            # exact docstring-only mechanism the loop-design gate exists to catch.)
            basis = ("reverify_with_quote" if cand["capacity_mw"].get("quote")
                     else "reverify_no_quote")
            s.add(ChangeLog(record_type="data_center", record_id=dc.id, field="review_status",
                            old={"review_status": dc.review_status,
                                 "overall_confidence": dc.overall_confidence},
                            new={"review_status": new_status, "overall_confidence": conf,
                                 "basis": basis, "sources_added": added},
                            source_id=f"reverify:{basis}"))
            dc.review_status = new_status
            if conf is not None:
                dc.overall_confidence = conf
            dc.last_verified = today
            st["reverified"] += 1
    return st


def run(limit: int | None = None, status: str = "reported", dry_run: bool = True,
        max_sources: int | None = None, segment: str | None = None) -> None:
    st = reverify(limit=limit, status=status, dry_run=dry_run, max_sources=max_sources,
                  segment=segment)
    tag = "DRY RUN — nothing written" if dry_run else "APPLIED"
    print(f"=== reverify ({tag}) ===")
    print(f"  candidates in '{status}'"
          f"{f' / segment {segment}' if segment else ''} : {st['considered']}")
    if dry_run:
        print("  re-run with --apply once the verifier is reachable. Costs one Claude call "
              "per row; no discovery or re-extraction.")
        return
    print(f"  re-verified              : {st['reverified']}")
    print(f"  verifier still failing   : {st['failed']}")
    print(f"  status moves             : {st['moved'] or '—'} ({st['unchanged']} unchanged)")
    print(f"  corroborating sources    : +{st['sources_added']} kept, {st['sources_refused']} refused by policy")
    print(f"  full-strength (w/ quote)  : {st['with_quote']}; values-only: {st['without_quote']}")

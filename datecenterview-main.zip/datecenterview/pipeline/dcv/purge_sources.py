"""purge_sources — withdraw everything sourced from a tier the VALUE may not come from.

Decision #1 is non-negotiable, and `source_policy` now enforces it at ingest and at the
publish gate. This is the one-off remediation for what got in before the gate existed:
104 tier-1 URLs in the published read-model, including 27 data-center capacities whose ONLY
source was a denied domain.

Withdraw, don't relabel. A value that was EXTRACTED from a competitor's database does not
become ours by being re-cited to a permitted page — that is laundering the same figure. So a
Field<T> with any denied source loses its VALUE, not just the offending url, and the record
returns to `needs_review` for honest re-derivation (`dcv enrich-capacity`, now filtered).

Reversible by construction. Every withdrawal writes a ChangeLog row carrying the complete
old value, so what was removed is auditable and restorable — the `loop-design` rule that a
correction which mutates state must have a reversal path, and that the reversal is where the
missing states live. Idempotent: a second run finds nothing.
"""
from __future__ import annotations

from datetime import date

from sqlalchemy import select

from . import source_policy as sp
from .config import settings
from .db import session_scope
from .models import ChangeLog, DataCenter, Edge, News, PowerProject, Source

# Field<T> columns that can carry their own `sources`.
FIELD_COLUMNS = ("capacity_mw", "cap_ex", "building_sqft", "land_acres", "btm_generation")

# A withdrawal must take the CONFIDENCE with the value.
#
# `overall_confidence` is a score for a verification, and a verification is OF something. When
# the source policy withdraws the value, the score keeps describing a field the record no
# longer holds — a fossil. Measured 2026-08-07: 10 rows sat at **0.93** (`_AGREE_CORROBORATED`)
# with 3-4 source domains and NO capacity, 2,003 MW of withdrawn figures between them. That is
# above `confidence_auto_approve`, so `_gate` said `approved` on every one; any confidence-
# threshold drain of the review queue would have re-published exactly the records this module
# exists to withdraw. Re-opening the row (below) was necessary and not sufficient — it moved
# the STATUS while leaving the number that would move it straight back.
#
# Cap at the review floor rather than zeroing: the row genuinely does need a human, which is
# what the floor means. Dropping below it would say `reported` — "the verifier failed" — and
# that is a different claim, and a false one.
WITHDRAWN_CONFIDENCE_CAP = settings.confidence_review_floor

# ...and cap ONLY the scores that are doing damage — those at or above the auto-approve line.
#
# The first build capped every withdrawn row whose confidence exceeded the floor, and against
# the live store that swept up 40+ PeeringDB rows at 0.75 and news rows at 0.72. Two reasons
# that is wrong. It changes no outcome: `_gate` already routes 0.75 and 0.72 to `needs_review`,
# so the fossil is inert there. And it destroys real signal: confidence is a PER-INGEST-PATH
# CONSTANT (0.75 PeeringDB / 0.72 news-extracted — the standing finding that confidence cannot
# gate the queue), and `goldset.sample()` stratifies on exactly that. Flattening a subset of
# one population to 0.6 would corrupt the stratifier to fix a problem those rows do not have.
#
# Above the auto-approve line the fossil is not inert — it is the difference between "a human
# must look at this" and "publish it".
CAP_APPLIES_AT = settings.confidence_auto_approve


def _denied(urls) -> list[str]:
    """Every tier a VALUE may not come from — not just the one that broke first.

    Widened 2026-07-21 from tier 1 to `value_denied_reason` (tier 1 OR tier 3). Tier 3 is a
    different objection with the same remedy: datacenter.fyi's power figures are modelled from
    a constant PUE of 5/3, not reported, so a value taken from it is a model's output wearing a
    measurement's provenance. `enrich.py` now refuses both at ingest; this is the remediation
    for the 50 that got in before the tier existed.
    """
    return [u for u in (urls or []) if sp.value_denied_reason(u)]


def _cap_confidence(s, dc) -> int:
    """Surrender the confidence a withdrawn value earned. Returns 1 if it moved.

    Logged like any other correction, and with the OLD value in `old`, so the cap is auditable
    and reversible on the same terms as the withdrawal that caused it.
    """
    conf = dc.overall_confidence
    if conf is None or conf < CAP_APPLIES_AT:
        return 0
    s.add(ChangeLog(record_type="data_center", record_id=dc.id, field="overall_confidence",
                    old={"overall_confidence": conf},
                    new={"overall_confidence": WITHDRAWN_CONFIDENCE_CAP,
                         "why": "value withdrawn by source policy — the score described a "
                                "field the record no longer holds"},
                    source_id="source_policy:withdrawn_confidence_cap"))
    dc.overall_confidence = WITHDRAWN_CONFIDENCE_CAP
    return 1


def cap_withdrawn_confidence(dry_run: bool = True) -> dict:
    """Repair rows whose confidence outlived the value that earned it.

    `purge()` is idempotent — a second run finds nothing, because the offending values are
    already gone — so fixing purge() going forward does NOT repair the rows it already left in
    this state. This is that repair, and it reads the same audit trail the withdrawal wrote
    rather than guessing: a row qualifies only if the change log records a source-policy
    withdrawal for a field the row STILL does not hold. A field that was later re-derived from
    a permitted source (14 of the 81 were) keeps its confidence — the value is back, so the
    score has a subject again.
    """
    st = {"candidates": 0, "capped": 0, "already_low": 0, "refilled_skipped": 0,
          "records": [], "dry_run": dry_run}
    with session_scope() as s:
        withdrawn: dict[str, set[str]] = {}
        for e in s.execute(select(ChangeLog).where(
                ChangeLog.source_id.like("source_policy:%"))).scalars():
            if e.field in FIELD_COLUMNS and e.new is None and (e.old or {}).get("value") is not None:
                withdrawn.setdefault(e.record_id, set()).add(e.field)

        for rid, cols in withdrawn.items():
            dc = s.get(DataCenter, rid)
            if dc is None or getattr(dc, "duplicate_of", None) is not None:
                continue
            # only rows STILL missing the withdrawn field — a re-derived value re-earns its score
            if not any(getattr(dc, c, None) is None for c in cols):
                st["refilled_skipped"] += 1
                continue
            st["candidates"] += 1
            if (dc.overall_confidence or 0) < CAP_APPLIES_AT:
                st["already_low"] += 1
                continue
            st["records"].append(f"{rid} {dc.overall_confidence}→{WITHDRAWN_CONFIDENCE_CAP}")
            if dry_run:
                st["capped"] += 1
            else:
                st["capped"] += _cap_confidence(s, dc)
    return st


def purge(dry_run: bool = True) -> dict:
    """Withdraw tier-1-sourced values and strip tier-1 urls. Returns stats."""
    today = date.today().isoformat()
    st = {"values_withdrawn": 0, "rows_reopened": 0, "urls_stripped": 0,
          "news_deleted": 0, "sources_deleted": 0, "confidence_capped": 0,
          "by_field": {}, "records": []}

    with session_scope() as s:
        for dc in s.execute(select(DataCenter)).scalars():
            touched = withdrew_value = False
            for col in FIELD_COLUMNS:
                val = getattr(dc, col)
                if not isinstance(val, dict) or not _denied(val.get("sources")):
                    continue
                st["values_withdrawn"] += 1
                st["by_field"][col] = st["by_field"].get(col, 0) + 1
                st["records"].append(f"{dc.id}:{col}")
                if not dry_run:
                    # the ENTIRE old value goes to the audit trail — restorable
                    s.add(ChangeLog(record_type="data_center", record_id=dc.id,
                                    field=col, old=val, new=None,
                                    source_id="source_policy:value_tier_withdrawal"))
                    setattr(dc, col, None)
                touched = withdrew_value = True
            bad = _denied(dc.sources)
            if bad:
                st["urls_stripped"] += len(bad)
                if not dry_run:
                    dc.sources = [u for u in (dc.sources or []) if u not in bad]
                touched = True
            if touched:
                st["rows_reopened"] += 1
                if not dry_run:
                    # A record whose evidence we just withdrew is no longer verified. Sending
                    # it back to the queue is the honest state, not a cosmetic flag.
                    dc.review_status = "needs_review"
                    dc.last_verified = None
            # ...but the status is only half of it. The confidence that the withdrawn value
            # earned has to go with it, or `_gate` promotes the row straight back out of the
            # queue on the strength of a verification whose subject no longer exists.
            if withdrew_value and not dry_run:
                capped = _cap_confidence(s, dc)
                st["confidence_capped"] += capped
            elif withdrew_value and (dc.overall_confidence or 0) >= CAP_APPLIES_AT:
                st["confidence_capped"] += 1

        for pp in s.execute(select(PowerProject)).scalars():
            bad = _denied(pp.sources)
            if bad:
                st["urls_stripped"] += len(bad)
                if not dry_run:
                    pp.sources = [u for u in (pp.sources or []) if u not in bad]

        for e in s.execute(select(Edge)).scalars():
            bad = _denied(e.sources)
            if bad:
                st["urls_stripped"] += len(bad)
                if not dry_run:
                    e.sources = [u for u in (e.sources or []) if u not in bad]

        for n in s.execute(select(News)).scalars():
            if sp.denied_reason(n.url):
                st["news_deleted"] += 1
                if not dry_run:
                    s.delete(n)

        for src in s.execute(select(Source)).scalars():
            if sp.denied_reason(src.url):
                st["sources_deleted"] += 1
                if not dry_run:
                    s.delete(src)

    st["dry_run"] = dry_run
    st["as_of"] = today
    return st


def run(dry_run: bool = True) -> None:
    st = purge(dry_run=dry_run)
    tag = "DRY RUN — nothing written" if dry_run else "APPLIED"
    print(f"=== purge denied sources ({tag}) ===")
    print(f"  Field<T> values withdrawn : {st['values_withdrawn']}  {st['by_field']}")
    print(f"  records re-opened         : {st['rows_reopened']} → needs_review")
    print(f"  confidence capped         : {st['confidence_capped']} → "
          f"{WITHDRAWN_CONFIDENCE_CAP} (a score for a value we no longer hold)")
    print(f"  urls stripped             : {st['urls_stripped']}")
    print(f"  news rows deleted         : {st['news_deleted']}")
    print(f"  source rows deleted       : {st['sources_deleted']}")
    if dry_run:
        print("\n  re-run with --apply to write. Every withdrawal is logged to change_log "
              "with the complete old value, so it can be audited or restored.")

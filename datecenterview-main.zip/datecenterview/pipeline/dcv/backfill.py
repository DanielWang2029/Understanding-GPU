"""backfill — P1 Tier-B enrichment of columns that ALREADY EXIST in the store but
were never populated (data-collection-plan §2.4, §7 P1). No Alembic migration: every
target column is present in models.py. Each step is idempotent and derives from data
we already hold (edges, current status, gazetteer/FCC), so it's cheap and re-runnable.

Steps (all safe UPDATEs, no destructive ops):
  1. persist_roles          — DataCenter.operator_id / tenant_id / end_user_id from the
                              operates / leases_to / serves edges (entity already resolved).
  2. backfill_status_history — a single honest "as-observed" lifecycle entry where empty.
  3. reclassify_entities    — rules-based category for `other` entities (high-precision
                              keyword rules only; genuinely ambiguous names stay `other`).
  4. backfill_county        — reverse-geocode lat/lng -> county via the free FCC Area API
                              for rows that have coords but no county.

Loop framing (loop-design): setpoint = every derivable column populated; measured =
coverage %; error = unpopulated rows with a derivable source; correction = this backfill;
mechanism = deterministic derivation (L1) + reconciliation to the edge graph; guardrail =
idempotent + only fills where a real source exists (never fabricates transitions).
"""
from __future__ import annotations

import json
import re
import time
import urllib.parse
import urllib.request

from sqlalchemy import select

from .db import session_scope
from .models import DataCenter, Edge, Entity
from .normalize import display_status

# ---- 1. persist operator / tenant / end_user from the edge graph -------------------

def persist_roles() -> None:
    """Set DC operator_id/tenant_id/end_user_id from the role edges (highest-conf wins)."""
    with session_scope() as s:
        dcs = {d.id: d for d in s.execute(select(DataCenter)).scalars()}
        ent_ids = {e.id for e in s.execute(select(Entity)).scalars()}
        best: dict[tuple[str, str], tuple[float, str]] = {}
        for e in s.execute(select(Edge)).scalars():
            # `develops` was missing here, which is the entire reason developer_id was 0/428
            # while 76 develops edges sat in the table with a perfectly good to_id.
            if e.relation not in ("develops", "operates", "leases_to", "serves"):
                continue
            if e.from_id not in dcs or e.to_id not in ent_ids:
                continue
            k = (e.from_id, e.relation)
            c = e.confidence if e.confidence is not None else 0.0
            if k not in best or c > best[k][0]:
                best[k] = (c, e.to_id)
        n_dev = n_op = n_ten = n_eu = 0
        for (dc_id, rel), (_, org) in best.items():
            d = dcs[dc_id]
            if rel == "develops" and d.developer_id != org:
                d.developer_id = org; n_dev += 1
            elif rel == "operates" and d.operator_id != org:
                d.operator_id = org; n_op += 1
            elif rel == "leases_to" and d.tenant_id != org:
                d.tenant_id = org; n_ten += 1
            elif rel == "serves" and d.end_user_id != org:
                d.end_user_id = org; n_eu += 1
    print(f"  [persist_roles] developer+{n_dev} operator+{n_op} tenant+{n_ten} "
          f"end_user+{n_eu} (from edges)")


# ---- 2. status_history (single as-observed entry where empty) -----------------------

def backfill_status_history() -> None:
    """Seed status_history with one honest 'as-observed' lifecycle entry where empty.

    We hold no historical transitions, so we record exactly what we know: the current
    lifecycle status as of the row's verify/announce date. Not fabricated progression.
    """
    with session_scope() as s:
        n = 0
        for d in s.execute(select(DataCenter)).scalars():
            if d.status_history:
                continue
            date = d.last_verified or d.announced_date or (str(d.operating_year) if d.operating_year else None)
            d.status_history = [{"status": display_status(d.status), "as_of": date, "source": "as-observed"}]
            n += 1
    print(f"  [status_history] seeded {n} rows (single as-observed entry)")


# ---- 3. rules-based entity category reclassification --------------------------------

# High-precision keyword rules only; order matters (first match wins). Ambiguous
# telecom/holding names deliberately stay `other` rather than be mislabeled.
_CAT_RULES: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\b(core scientific|hut ?8|crusoe|applied digital|iren|terawulf|cipher mining|galaxy|lambda|coreweave|nebius|together ?ai|foundry)\b", re.I), "neocloud"),
    (re.compile(r"\b(rackspace|internap|inap|colocrossing|lightedge|hostdime|databank|cyxtera|flexential|tierpoint|hivelocity|phoenixnap)\b", re.I), "retail_colo"),
    (re.compile(r"\b(data ?cent(er|re)s?|colocation|colo|serverfarm|fibertown|switch|vantage|aligned|compass|stack infra|edgeconnex|prime data)\b", re.I), "wholesale_colo"),
    (re.compile(r"\b(development|developer|properties|realty|land|holdings|capital|partners|ventures|infrastructure|estates)\b", re.I), "developer"),
    (re.compile(r"\b(electric|energy|utilit(y|ies)|power ?company|cooperative|municipal)\b", re.I), "utility"),
]


def reclassify_entities() -> None:
    with session_scope() as s:
        n = 0
        from collections import Counter
        moved = Counter()
        for e in s.execute(select(Entity)).scalars():
            if e.category != "other":
                continue
            for rx, cat in _CAT_RULES:
                if rx.search(e.name or ""):
                    e.category = cat
                    e.category_confidence = 0.55  # rules-based guess, sub-review
                    moved[cat] += 1
                    n += 1
                    break
    print(f"  [reclassify] {n} 'other' entities reclassified {dict(moved)}")


# ---- 4. reverse-geocode county from lat/lng via the free FCC Area API ---------------

_COUNTY_SUFFIX = re.compile(r"\s+(county|parish|borough|census area|municipality|city and borough|municipio)$", re.I)


def _strip_county(name: str | None) -> str | None:
    """Bare county name (no 'County'/'Parish'/… suffix) — matches the gazetteer convention
    so the UI's '{county} Co., {state}' render doesn't double the suffix."""
    if not name:
        return name
    return _COUNTY_SUFFIX.sub("", name).strip()


def normalize_counties() -> None:
    """One-off: strip the county-type suffix from every stored county (idempotent)."""
    with session_scope() as s:
        n = 0
        for d in s.execute(select(DataCenter)).scalars():
            loc = d.location or {}
            c = loc.get("county")
            nc = _strip_county(c)
            if c and nc != c:
                loc = dict(loc); loc["county"] = nc; d.location = loc; n += 1
    print(f"  [normalize_counties] stripped suffix on {n} rows")


def demote_phantom_exact() -> None:
    """One-off (idempotent): a row claiming `geo_precision='exact'` with no coordinate is
    claiming a precise location we never had.

    `enumerate_dc.py` defaulted `fac_cand.get("geo_precision") or "exact"`, so every PeeringDB
    facility that came back without lat/lng was labelled exact anyway — 19 rows. The ingest
    default is fixed; this repairs what it already wrote. The label degrades to the finest
    granularity the row actually carries, so nothing is invented on the way down either.
    """
    with session_scope() as s:
        n = 0
        for d in s.execute(select(DataCenter)).scalars():
            loc = d.location or {}
            if loc.get("lat") is not None or loc.get("geo_precision") != "exact":
                continue
            loc = dict(loc)
            loc["geo_precision"] = ("city" if loc.get("city") else
                                    "county" if loc.get("county") else
                                    "state" if loc.get("state") else None)
            d.location = loc
            n += 1
    print(f"  [geo_precision] demoted {n} phantom-'exact' row(s) with no coordinate")


def _fcc_county(lat: float, lng: float) -> tuple[str, str] | None:
    url = "https://geo.fcc.gov/api/census/area?" + urllib.parse.urlencode(
        {"lat": lat, "lon": lng, "censusYear": 2020, "format": "json"})
    try:
        with urllib.request.urlopen(url, timeout=8) as r:
            data = json.loads(r.read().decode())
        res = (data.get("results") or [{}])[0]
        cn, sc = res.get("county_name"), res.get("state_code")
        return (_strip_county(cn), sc) if cn else None
    except Exception:
        return None


def backfill_county(limit: int | None = None, sleep: float = 0.05) -> None:
    """Reverse-geocode county for DCs with coords but no county. Best-effort, skippable."""
    with session_scope() as s:
        todo = [d for d in s.execute(select(DataCenter)).scalars()
                if (d.location or {}).get("lat") is not None and not (d.location or {}).get("county")]
        if limit:
            todo = todo[:limit]
        print(f"  [county] reverse-geocoding {len(todo)} rows via FCC Area API …")
        n = miss = 0
        for i, d in enumerate(todo):
            loc = dict(d.location or {})
            got = _fcc_county(loc["lat"], loc["lng"])
            if got and (not loc.get("state") or got[1] == loc.get("state")):
                loc["county"] = got[0]
                d.location = loc
                n += 1
            else:
                miss += 1
            if sleep:
                time.sleep(sleep)
            if (i + 1) % 100 == 0:
                print(f"    … {i + 1}/{len(todo)} ({n} filled)")
    print(f"  [county] filled {n}, unresolved {miss}")


def run(skip_county: bool = False, county_limit: int | None = None) -> None:
    print("→ P1 backfill (populate existing columns) …")
    persist_roles()
    backfill_status_history()
    reclassify_entities()
    demote_phantom_exact()
    if not skip_county:
        backfill_county(limit=county_limit)
    else:
        print("  [county] skipped")
    normalize_counties()
    print("✓ backfill done — re-run `dcv emit` to publish")

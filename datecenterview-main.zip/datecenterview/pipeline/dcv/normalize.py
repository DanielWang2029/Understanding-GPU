"""Normalization maps — the real work of Phase A (phase-a-spec §4).

Two lookup tables collapse each source's technology + status vocabularies into
uniform enums. The store keeps the lifecycle status; emit maps it to the 6
display statuses the read-model validator expects.
"""
from __future__ import annotations

# --- technology -> read-model enum (data.schema.json) ------------------------
# read-model technology enum: Solar Wind Battery "Natural Gas" Nuclear Coal Hydro
#                             Geothermal Hybrid Other
TECHNOLOGY = {
    "Solar", "Wind", "Battery", "Natural Gas", "Nuclear", "Coal",
    "Hydro", "Geothermal", "Hybrid", "Other",
}

# EIA energy_source_code -> technology
EIA_ENERGY_TO_TECH = {
    "SUN": "Solar",
    "WND": "Wind",
    "MWH": "Battery",
    "NG": "Natural Gas",
    "WAT": "Hydro",
    "GEO": "Geothermal",
    "BIT": "Coal", "SUB": "Coal", "LIG": "Coal", "RC": "Coal",
    "NUC": "Nuclear",
    "DFO": "Natural Gas",  # oil peakers grouped w/ gas-like thermal for the DC lens
}

# exact ISO-queue fuel abbreviations (bare tokens the contains-match would miss)
TECH_ABBREV = {
    "ct": "Natural Gas", "ctg": "Natural Gas", "cc": "Natural Gas", "cg": "Natural Gas",
    "gt": "Natural Gas", "ice": "Natural Gas", "recip": "Natural Gas", "ng": "Natural Gas",
    "pv": "Solar", "bess": "Battery", "es": "Battery", "st": "Other",
}

# fuel-label fallbacks (lowercased contains-match; first hit wins, so order matters)
TECH_KEYWORDS = [
    ("solar", "Solar"), ("photovolt", "Solar"),
    ("wind", "Wind"),
    ("battery", "Battery"), ("storage", "Battery"), ("bess", "Battery"),
    ("natural gas", "Natural Gas"), ("combined cycle", "Natural Gas"),
    ("combined-cycle", "Natural Gas"), ("combustion", "Natural Gas"),
    ("reciprocating", "Natural Gas"), ("internal combustion", "Natural Gas"),
    ("diesel", "Natural Gas"), ("gas", "Natural Gas"),
    ("nuclear", "Nuclear"),
    ("coal", "Coal"),
    ("hydro", "Hydro"), ("water", "Hydro"),
    ("geothermal", "Geothermal"),
    ("hybrid", "Hybrid"),
]


def tech_from_eia(energy_source_code: str | None, technology_label: str | None = None) -> str:
    if energy_source_code and energy_source_code.upper() in EIA_ENERGY_TO_TECH:
        return EIA_ENERGY_TO_TECH[energy_source_code.upper()]
    return tech_from_label(technology_label or energy_source_code or "")


def tech_from_label(label: str | None) -> str:
    s = (label or "").strip().lower()
    if not s:
        return "Other"
    if s in TECH_ABBREV:
        return TECH_ABBREV[s]
    for kw, tech in TECH_KEYWORDS:
        if kw in s:
            return tech
    return "Other"


# --- status: source vocab -> lifecycle enum (store) --------------------------
# store lifecycle: proposed permitted under_construction operating cancelled retired on_hold
LIFECYCLE = {
    "proposed", "permitted", "under_construction", "operating",
    "cancelled", "retired", "on_hold",
}


def status_from_eia(raw: str | None) -> str:
    s = (raw or "").lower()
    if "(op)" in s or s.startswith("op") or "operat" in s:
        return "operating"
    if "(re)" in s or "retir" in s:
        return "retired"
    if "(oa)" in s or "(v)" in s or "standby" in s or "out of service" in s:
        return "on_hold"
    if "(p)" in s or "plan" in s or "propos" in s or "(l)" in s or "(t)" in s or "(u)" in s:
        return "proposed"
    if "cancel" in s or "withdraw" in s:
        return "cancelled"
    return "proposed"


def status_from_iso(raw: str | None) -> str:
    s = (raw or "").lower()
    if "service" in s or "operat" in s or "complete" in s:
        return "operating"
    if "withdraw" in s or "cancel" in s or "terminat" in s:
        return "cancelled"
    if "suspend" in s or "hold" in s:
        return "on_hold"
    if "ia executed" in s or "under construction" in s or "construction" in s or "gia" in s:
        return "under_construction"
    if "facilities study" in s or "facility study" in s or "system impact" in s or "feasibility" in s:
        return "permitted"
    if "active" in s or "study" in s or "queue" in s or "request" in s:
        return "proposed"
    return "proposed"


# --- lifecycle -> read-model display status (data.schema.json) ---------------
# read-model status enum: Planned "Under construction" Operating Cancelled Retired "On hold"
LIFECYCLE_TO_DISPLAY = {
    "proposed": "Planned",
    "permitted": "Planned",
    "under_construction": "Under construction",
    "operating": "Operating",
    "cancelled": "Cancelled",
    "retired": "Retired",
    "on_hold": "On hold",
}

DISPLAY_STATUSES = {"Planned", "Under construction", "Operating", "Cancelled", "Retired", "On hold"}


def display_status(lifecycle_or_display: str | None) -> str:
    v = lifecycle_or_display or "proposed"
    if v in DISPLAY_STATUSES:
        return v
    return LIFECYCLE_TO_DISPLAY.get(v, "Planned")

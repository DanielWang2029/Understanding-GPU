"""goldset — the BALANCING GATE for the review loop (Band 2 #3, L6).

`loop-design`: never let a reinforcing loop train on its own unverified output. Draining a
364-deep review queue by rule is exactly such a loop — a rule that promotes records to
`approved` must itself be certified against ground truth that the pipeline did not produce.

Two measurements shaped this module, and both contradicted the plan:

1. **Confidence cannot be the gate.** Across all 364 `needs_review` data centers there are
   exactly TWO distinct confidence values: 0.72 (all 16 news-extracted) and 0.75 (all 348
   PeeringDB-enumerated). It is a per-ingest-path constant, not a per-record measurement, so
   any confidence threshold approves everything or nothing. It also means the active-learning
   priority `(1-conf) × log1p(mw)` currently ranks by CAPACITY alone.
   → The queue is not a spectrum of trust. It is two POPULATIONS with different evidence,
     so the gold set is stratified by SOURCE CLASS, not by confidence.

2. **The existing gold set cannot certify anything.** All 7 rows carry
   `verified_by="demo_seed_bootstrap"` — its own `_meta` admits it was "bootstrapped from the
   project's OWN demo seed". A gate derived from the system it gates is not a gate, and using
   it to bless an auto-approve rule would be the reinforcing failure wearing a checkmark.

So a gold entry here must satisfy two things the old format could not express:

  * **Per-field evidence.** Every gold VALUE carries its own `source` url + `quote` copied
    verbatim from that source. A gold field with no quote is not ground truth, it is an
    opinion, and `evaluate()` skips it rather than scoring against it.
  * **Signoff.** `verified_by` records WHO established the value, and `certify()` refuses to
    bless an auto-approve rule using unsigned entries. Transcription performed by a model —
    including this one — is `UNSIGNED`: the verifier of record for the pipeline is
    `claude-opus-4-8`, so a gold set that Claude alone attests to is same-vendor agreement,
    which certifies nothing. Reading a primary document and copying a quote out of it is
    still useful evidence-gathering; it is not independent SIGNOFF. A human must sign.
"""
from __future__ import annotations

import json
from datetime import date
from pathlib import Path

from sqlalchemy import delete, select

from .config import settings
from .db import session_scope
from .models import DataCenter, GoldSet

FIXTURE = settings.repo_root / "pipeline" / "seed" / "tx_gold_set.json"
WORKSHEET = settings.repo_root / "pipeline" / "seed" / "gold_worksheet.json"

# A value transcribed by a model is evidence, not signoff. Anything matching this is
# refused by certify().
UNSIGNED_MARKER = "UNSIGNED"

# Fields worth holding to ground truth, and how to compare them.
NUMERIC_TOLERANCE = {"capacity_mw": 0.15}      # ±15%
GOLD_FIELDS = ("project_name", "developer", "operator", "tenant", "end_user",
               "county", "state", "capacity_mw", "status", "operating_year")


def source_class(dc: DataCenter) -> str:
    """Which ingest path produced this row. This is the real stratum — see module docstring."""
    if any("peeringdb" in str(u).lower() for u in (dc.sources or [])):
        return "directory"
    return "news"


def sample(n: int = 20, status: str = "needs_review") -> list[dict]:
    """Stratified sample of records to verify, PROPORTIONAL to each source class.

    Proportional (not equal) because the question the gate must answer is "what would a rule
    do to THIS queue" — over-sampling the rare class would make the measured accuracy describe
    a population that does not exist. Deterministic: ordered by capacity desc then id, so a
    re-run picks the same records and a second verifier can be compared against the first.
    """
    with session_scope() as s:
        rows = [d for d in s.execute(select(DataCenter)).scalars()
                if d.review_status == status]
        buckets: dict[str, list[DataCenter]] = {}
        for d in rows:
            buckets.setdefault(source_class(d), []).append(d)
        total = len(rows) or 1
        out: list[dict] = []
        for cls, items in sorted(buckets.items()):
            take = max(1, round(n * len(items) / total)) if items else 0
            from .field import field_value
            items.sort(key=lambda d: (-(field_value(d.capacity_mw) or 0), d.id))
            for d in items[:take]:
                loc = d.location or {}
                out.append({
                    "id": d.id, "source_class": cls,
                    "project_name": d.project_name,
                    "developer": d.developer_name, "operator": d.operator_name,
                    "county": loc.get("county"), "state": loc.get("state"),
                    "capacity_mw": field_value(d.capacity_mw),
                    "status": d.status, "confidence": d.overall_confidence,
                    "sources": list(d.sources or []),
                })
    return out


def _gold_value(entry: dict, field: str):
    """(value, has_evidence). A gold field is only ground truth when it carries a source URL
    AND a verbatim quote — otherwise evaluate() must not score against it."""
    f = (entry.get("fields") or {}).get(field)
    if isinstance(f, dict):
        ok = bool(f.get("source")) and bool(f.get("quote"))
        return f.get("value"), ok
    if field in entry:                       # v1 flat format — value, but no evidence
        return entry[field], False
    return None, False


def load(path: Path | None = None) -> dict:
    """Load the fixture into `gold_set`. Idempotent (replaces data_center gold rows)."""
    path = Path(path or FIXTURE)
    data = json.loads(path.read_text())
    today = date.today().isoformat()
    from .phaseb.normalize_dc import identity_key

    projects = data.get("projects", [])
    evidenced = signed = 0
    with session_scope() as s:
        s.execute(delete(GoldSet).where(GoldSet.record_type == "data_center"))
        for p in projects:
            fields = {}
            for f in GOLD_FIELDS:
                v, ok = _gold_value(p, f)
                if v is not None:
                    fields[f] = v
                    if ok:
                        evidenced += 1
            vb = p.get("verified_by") or data.get("_meta", {}).get("verified_by") \
                or "demo_seed_bootstrap"
            if UNSIGNED_MARKER not in vb and vb != "demo_seed_bootstrap":
                signed += 1
            s.add(GoldSet(
                record_type="data_center",
                natural_key=identity_key(fields.get("project_name"), fields.get("county"),
                                         fields.get("state"), fields.get("developer")),
                fields={**fields, "aka": p.get("aka", []),
                        "_evidence": {f: (p.get("fields") or {}).get(f)
                                      for f in GOLD_FIELDS
                                      if isinstance((p.get("fields") or {}).get(f), dict)},
                        "_source_class": p.get("source_class")},
                notes=p.get("notes") or data.get("_meta", {}).get("note"),
                verified_by=vb, verified_at=p.get("verified_at") or today,
            ))
    st = {"projects": len(projects), "evidenced_fields": evidenced, "signed_entries": signed}
    print(f"✓ gold set loaded — {st['projects']} projects, {st['evidenced_fields']} "
          f"evidence-backed field(s), {st['signed_entries']} human-signed entry(ies)")
    if not st["signed_entries"]:
        print("  ⚠ NO signed entries — this gold set can REPORT accuracy but cannot CERTIFY "
              "an auto-approve rule (see goldset.certify).")
    return st


def field_accuracy() -> dict:
    """PER-FIELD accuracy of the store against evidence-backed gold values.

    Per-field, not blended: a single "field accuracy 0.85" hides that `capacity_mw` might be
    0.95 and `operator` 0.40, and an auto-approve rule has to be written per field. Fields
    without a source+quote are SKIPPED (counted as `unevidenced`) rather than scored — the
    old fixture would otherwise grade the pipeline against its own seed and call it accurate.
    """
    from .field import field_value
    with session_scope() as s:
        gold = list(s.execute(
            select(GoldSet).where(GoldSet.record_type == "data_center")).scalars())
        dcs = {d.natural_key: d for d in s.execute(select(DataCenter)).scalars()}
        per: dict[str, dict] = {}
        unmatched, unevidenced = 0, 0
        for g in gold:
            dc = dcs.get(g.natural_key)
            if dc is None:
                unmatched += 1
                continue
            gf, ev = (g.fields or {}), (g.fields or {}).get("_evidence") or {}
            for f in GOLD_FIELDS:
                if f not in gf or gf[f] is None:
                    continue
                if not isinstance(ev.get(f), dict):
                    unevidenced += 1
                    continue
                got = {"capacity_mw": lambda: field_value(dc.capacity_mw),
                       "county": lambda: (dc.location or {}).get("county"),
                       "state": lambda: (dc.location or {}).get("state"),
                       "status": lambda: dc.status,
                       "operating_year": lambda: dc.operating_year,
                       }.get(f, lambda f=f: getattr(dc, f"{f}_name", None))()
                want = gf[f]
                b = per.setdefault(f, {"checked": 0, "correct": 0})
                b["checked"] += 1
                if _matches(f, want, got):
                    b["correct"] += 1
        for f, b in per.items():
            b["accuracy"] = round(b["correct"] / b["checked"], 3) if b["checked"] else None
    return {"per_field": per, "unmatched_gold_rows": unmatched,
            "skipped_unevidenced_fields": unevidenced}


def _matches(field: str, want, got) -> bool:
    if got is None or want is None:
        return False
    tol = NUMERIC_TOLERANCE.get(field)
    if tol is not None:
        try:
            return abs(float(got) - float(want)) <= tol * abs(float(want))
        except (TypeError, ValueError):
            return False
    from .dc_roles import norm
    return norm(str(want)) == norm(str(got))


def certify(min_signed: int = 30) -> dict:
    """Can this gold set bless an auto-approve rule? Returns {ok, reasons, ...}.

    Deliberately refuses by default. The whole point of Band 2 #3 is that promoting 364
    records to `approved` must rest on ground truth the pipeline did not author, so the
    burden of proof sits here rather than in whoever calls it.
    """
    with session_scope() as s:
        gold = list(s.execute(
            select(GoldSet).where(GoldSet.record_type == "data_center")).scalars())
    signed = [g for g in gold if g.verified_by and UNSIGNED_MARKER not in g.verified_by
              and g.verified_by != "demo_seed_bootstrap"]
    by_class: dict[str, int] = {}
    for g in signed:
        by_class[(g.fields or {}).get("_source_class") or "unknown"] = \
            by_class.get((g.fields or {}).get("_source_class") or "unknown", 0) + 1
    reasons = []
    if len(signed) < min_signed:
        reasons.append(f"only {len(signed)} human-signed gold entries (need >={min_signed}); "
                       f"{len(gold) - len(signed)} are unsigned or seed-bootstrapped")
    missing = [c for c in ("directory", "news") if not by_class.get(c)]
    if missing:
        reasons.append(f"no signed entries for source class(es): {', '.join(missing)} — a rule "
                       f"cannot be certified for a population it was never measured on")
    return {"ok": not reasons, "signed": len(signed), "total": len(gold),
            "by_source_class": by_class, "reasons": reasons}

"""dc_roles — resolve data-center ROLE NAMES to entity ids, and measure the gap (Band 2 #2, L2).

The value chain the product sells is `project → developer → operator → tenant → end_user`.
Four role fields, and until Band 2 #2 they were in four different states:

    developer  424 raw names, **0** resolved   — `persist_roles` never mapped `develops`
    operator   401 resolved                    — from `operates` edges
    tenant       2 resolved, no raw column     — the extractor's value was DROPPED on write
    end_user    47 resolved + 17 raw           — half-resolved

So three of the four links in the chain were broken, in three different ways. This module
does the half that needs no model: turn a NAME that a document already gave us into an
entity id, deterministically and locally.

L2-dcroles 5-line contract:
  1. Setpoint  — every role name a source wrote resolves to an `entity` id, so the value
                 chain is a graph rather than four columns of strings.
  2. Measured  — resolved/total per role + the unresolved-name log, emitted live to
                 `meta.rollups.dc_role_coverage`.
  3. Error     — a role NAME present with no id (and, separately, a role that is eligible
                 to be known but has neither).
  4. Correction— normalize (legal-suffix strip) → exact match → alias match, all against the
                 entity table we already have; unresolved names are LOGGED as
                 entity-expansion candidates, exactly as Band 2 #1 logged supplier names.
  5. Mechanisms— deterministic local resolution (never an LLM-produced id, per
                 `evidence-extraction` rule 1) · longest-alias-wins · ambiguity guard ·
                 idempotent upsert · no entity creation.

Guardrails:
  - **Never create an entity from a role name.** Promotion is evidence-gated and separate
    (`backbone.py`); a resolver that invents nodes turns every typo into a company.
  - **A name matching two entities resolves to NEITHER.** Ties drop and are logged — the
    same rule as `evidence-extraction` rule 3, for the same reason: a coin flip between
    two counterparties is not evidence for either.
  - **A compound value resolves to nothing.** "OpenAI / Oracle" in one `end_user` cell is
    two entities in a field whose unit of analysis is one (`entity-unit-of-analysis`
    shape B). Splitting it silently would attribute a site to a company no source named as
    its sole end user; picking one would be arbitrary. It stays unresolved, with a reason.

Run: `dcv resolve-roles`. Idempotent — re-running only fills what is still missing.
"""
from __future__ import annotations

import re

from sqlalchemy import select

from .db import session_scope
from .models import DataCenter, Entity

# Roles this module resolves. `operator` is already resolved from `operates` edges by
# backfill.persist_roles, but is included so a freshly-extracted operator_name also lands.
ROLES = ("developer", "operator", "tenant", "end_user")

# Legal-form suffixes to strip before matching. "Cologix, Inc." and "Cologix" are one company;
# 141 of 156 developer names in the store already matched an entity name case-insensitively,
# and suffix-stripping alone took that to 149.
_SUFFIX = re.compile(
    r",?\s+(inc|llc|l\.l\.c|ltd|limited|corp|corporation|co|company|plc|n\.v|nv|s\.a|sa|ag|"
    r"gmbh|lp|llp|holdings?|group|trust|partners)\.?$", re.I)

# A cell holding two parties. Deliberately narrow: only separators that cannot occur inside a
# real company name. "Smith & Wesson" and "Yahoo! Inc" must NOT trip this.
_COMPOUND = re.compile(r"\s+(?:/|\+|,\s*and|and|&&|\|)\s+|\s*/\s*", re.I)


# Vocabulary a source uses when it discloses that a counterparty EXISTS but withholds WHO.
# Live example that motivated this: Hut 8's press release announcing a 352 MW lease worth
# $9.8bn names the tenant only as "a high-investment-grade company". The extractor copied that
# faithfully — it IS what the article said — but it is a description, not an identity, and
# rendering it in a `tenant` column states a company that no source named. Same rule as the
# chain side: a disclosed magnitude with an unnamed counterparty is not an attribution.
# Words that mean "we are not telling you who" wherever they appear.
_UNDISCLOSED = re.compile(
    r"\b(undisclosed|unnamed|confidential|anonymous|unidentified|not\s+disclosed|"
    r"investment[- ]grade|fortune\s*\d+)\b", re.I)

# A phrase that opens with an article and closes on a generic role noun describes a CATEGORY
# however many adjectives sit between: "a leading AI company", "an unnamed hyperscaler".
#
# The adjectives themselves are deliberately NOT signals. An earlier version treated bare
# "global"/"major"/"leading" as undisclosed vocabulary and rejected two real operators —
# `Global IP Networks, Inc.` and `Telehouse - Global Data Centers`. Measured against the 204
# real company names in the store, that cost 2 false positives to catch 0 extra true ones.
_GENERIC_ROLE = re.compile(
    r"^(a|an|the)\s+[\w\s,'&-]*?\b(hyperscaler|hyperscale|customer|client|tenant|company|"
    r"companies|operator|provider|enterprise|corporation|firm|counterparty|lessee|user)s?$",
    re.I)


def is_named_company(name: str | None) -> bool:
    """Does this role value NAME a party, or merely describe one?

    A role field's job is identity. "Meta" is an identity; "a high-investment-grade company"
    and "a hyperscaler" are categories that happen to sit in an identity-shaped hole. Storing
    the latter is how a dashboard reports a tenant that no source disclosed.
    """
    s = (name or "").strip()
    if not s or len(s) < 2:
        return False
    if _GENERIC_ROLE.match(s) or _UNDISCLOSED.search(s):
        return False
    # A proper name carries a capital or a digit somewhere (T5, QTS, Meta, x-IO); an all-
    # lowercase phrase is prose.
    return any(ch.isupper() or ch.isdigit() for ch in s)


def norm(name: str | None) -> str:
    """Normalize a company name for matching: lowercase, strip legal suffixes and punctuation."""
    s = (name or "").strip().lower()
    s = s.replace("’", "'").replace("‘", "'")
    prev = None
    while prev != s:                       # "Foo Holdings, Inc." → "foo"
        prev = s
        s = _SUFFIX.sub("", s).strip(" ,.")
    s = re.sub(r"[^a-z0-9 &']", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def is_compound(name: str | None) -> bool:
    return bool(name) and bool(_COMPOUND.search(name.strip()))


def build_index(session) -> tuple[dict[str, set[str]], dict[str, set[str]]]:
    """(exact, alias) indexes: normalized name → set of entity ids. Sets, not scalars, so an
    ambiguous name is VISIBLE as a tie rather than silently taking whichever row came back
    first from the database."""
    exact: dict[str, set[str]] = {}
    for eid, nm in session.execute(select(Entity.id, Entity.name)):
        exact.setdefault(norm(nm), set()).add(eid)
        exact.setdefault(norm(eid.replace("-", " ")), set()).add(eid)

    alias: dict[str, set[str]] = {}
    known = {eid for ids in exact.values() for eid in ids}
    from .chain_identity import _ALIASES              # chain tier (longest-match legal names)
    from .phaseb.normalize_dc import _DEV_ALIAS       # colo/developer tier
    for eid, names in _ALIASES.items():
        for a in names:
            if eid in known:
                alias.setdefault(norm(a), set()).add(eid)
    for a, (_canon, eid, _cat) in _DEV_ALIAS.items():
        if eid and eid in known:
            alias.setdefault(norm(a), set()).add(eid)
    return exact, alias


def resolve_one(name: str | None, exact: dict[str, set[str]],
                alias: dict[str, set[str]]) -> tuple[str | None, str | None]:
    """(entity_id, miss_reason). Exactly one of the two is non-None.

    Miss reasons follow the `evidence-extraction` taxonomy — a miss must say WHY, because
    'no entity of that name exists' and 'two entities share it' need opposite corrections.
    """
    if not name or not name.strip():
        return None, None
    if is_compound(name):
        return None, "compound_value"
    k = norm(name)
    if k:
        for table in (exact, alias):
            hit = table.get(k)
            if hit:
                if len(hit) > 1:
                    return None, "ambiguous"      # tie → resolve to neither
                return next(iter(hit)), None
    # Only NOW ask whether this is even a name. Resolution is the stronger evidence and must
    # run first: `The Swig Company` and `The Gosnell Companies` are real operators that look
    # exactly like the descriptor pattern "the … company", and a purely lexical guard rejected
    # both. If we already know the company, it is a company — the shape of its name is moot.
    if not is_named_company(name):
        # The source disclosed that a counterparty EXISTS but not who — a real, useful fact,
        # and not an identity. The raw string stays in the store for audit; it must never
        # reach the read-model's role column.
        return None, "undisclosed_counterparty"
    return None, "unresolved_name"


def resolve_roles(session) -> dict:
    """Fill missing role FKs from the raw role NAME columns. Returns run stats."""
    exact, alias = build_index(session)
    stats = {r: {"already": 0, "resolved": 0, "no_name": 0} for r in ROLES}
    misses: dict[str, dict[str, int]] = {}
    for dc in session.execute(select(DataCenter)).scalars():
        for role in ROLES:
            id_col, name_col = f"{role}_id", f"{role}_name"
            if getattr(dc, id_col, None):
                stats[role]["already"] += 1
                continue
            raw = getattr(dc, name_col, None)
            if not raw:
                stats[role]["no_name"] += 1
                continue
            eid, reason = resolve_one(raw, exact, alias)
            if eid:
                setattr(dc, id_col, eid)
                stats[role]["resolved"] += 1
            else:
                key = f"{raw} [{reason}]"
                misses[key] = misses.get(key, 0) + 1
    stats["unresolved_names"] = dict(sorted(misses.items(), key=lambda kv: -kv[1]))
    stats["conflicts"] = detect_conflicts(session, exact, alias)
    return stats


def detect_conflicts(session, exact, alias) -> list[dict]:
    """Report records whose raw role NAME resolves to a DIFFERENT entity than the stored id.

    Read-only: a conflict is two sourced claims disagreeing, and picking a winner silently is
    the failure. `galaxy-helios` carries a conf-0.6 `serves` edge to Microsoft while its
    extracted end_user_name says CoreWeave — the emitter shows the resolved id, so without
    this the disagreement would simply vanish from view. Surfaced here (and counted in
    `meta.rollups.dc_role_coverage.conflicts`) so it can be reviewed rather than assumed.

    A raw name that fails to resolve is NOT a conflict — it is an unresolved name, already
    counted above. Only a name that confidently points somewhere ELSE qualifies.
    """
    out = []
    for dc in session.execute(select(DataCenter)).scalars():
        for role in ROLES:
            eid = getattr(dc, f"{role}_id", None)
            raw = getattr(dc, f"{role}_name", None)
            if not eid or not raw:
                continue
            rid, _ = resolve_one(raw, exact, alias)
            if rid and rid != eid:
                out.append({"record": dc.id, "role": role, "stored_id": eid,
                            "name_resolves_to": rid, "raw": raw})
    return out


# Categories where a SINGLE tenant / end_user is a coherent fact about the site.
#
# `retail_colo` is excluded, and that exclusion is the point. A retail colocation facility
# (Level(3) Herndon, Equinix Culpeper, Lumen Dallas) rents racks and cages to HUNDREDS of
# customers; it has no single tenant, so a scalar `tenant` column has no value to hold. Its
# unit of analysis does not fit the field (`entity-unit-of-analysis`). Reporting "tenant
# 0.5% of 428" therefore implies 99.5% is a gap to be closed, when ~254 of those records
# can never legitimately have one — and the only way to "close" it would be to invent data.
# Wholesale halls, hyperscaler self-builds, neocloud sites and developer campuses DO have a
# single anchor tenant, and that is sometimes announced. Those are the real denominator.
ELIGIBLE_SINGLE_TENANT = frozenset({
    "wholesale_colo", "hyperscaler", "neocloud", "ai_lab", "developer", "enterprise"})

# Roles measured against the eligible base rather than the whole population.
_ELIGIBILITY_GATED = ("tenant", "end_user")


def coverage(dc_rows: list[dict], resolved: dict[str, int] | None = None,
             conflicts: list[dict] | None = None) -> dict:
    """Live role-coverage measured value, computed from the EMITTED rows so the validator can
    check it against the same datasets a reader sees.

    Coverage is reported against the ELIGIBLE base for tenant/end_user and against all
    records for developer/operator. `not_applicable` is a first-class count, not a rounding
    error — it is the honest name for the records that were previously being counted as
    missing.
    """
    n = len(dc_rows)
    out: dict = {"records": n, "filled": {}, "eligible": {}, "eligible_filled": {},
                 "not_applicable": {},
                 "basis": "retail_colo (and uncategorised) excluded from tenant/end_user: "
                          "multi-tenant by construction, so a scalar role has no single value"}
    for role in ROLES:
        out["filled"][role] = sum(1 for r in dc_rows if r.get(role))
    if resolved is not None:
        # `filled` counts a role we can DISPLAY; `resolved` counts one that is a graph edge to
        # a real entity. A role can be filled and unresolved (a raw string nothing matched) —
        # that gap is this loop's error signal, so the two are never conflated.
        out["resolved"] = dict(resolved)
    if conflicts is not None:
        # Surfaced as a COUNT plus the record ids — a conflict that is only counted
        # cannot be acted on, and one that is only logged is invisible to the reader.
        out["conflicts"] = len(conflicts)
        out["conflict_records"] = sorted({c["record"] for c in conflicts})
    # A `tenant` that merely restates the developer or operator carries no lease information.
    # It is not FALSE — an SPV really does occupy its own building — but counting it as tenant
    # coverage claims we learned who leases the site when we learned nothing. Live case: the
    # Texas TDLR permit feed names the applicant LLC, so "1102 McKinzie LLC Data Center" came
    # back with tenant "1102 McKinzie LLC". 24 of 49 extracted tenants were this shape.
    distinct = 0
    for r in dc_rows:
        t = norm(r.get("tenant") or "")
        if t and t != norm(r.get("developer") or "") and t != norm(r.get("operator") or ""):
            distinct += 1
    out["tenant_distinct_party"] = distinct

    for role in _ELIGIBILITY_GATED:
        elig = [r for r in dc_rows
                if r.get("developer_category") in ELIGIBLE_SINGLE_TENANT]
        out["eligible"][role] = len(elig)
        out["eligible_filled"][role] = sum(1 for r in elig if r.get(role))
        out["not_applicable"][role] = n - len(elig)
    return out


def run() -> None:
    with session_scope() as s:
        st = resolve_roles(s)
    for role in ROLES:
        r = st[role]
        print(f"  [dc_roles] {role:10s} already={r['already']:4d} resolved+{r['resolved']:<4d} "
              f"no_name={r['no_name']:4d}")
    un, cf = st["unresolved_names"], st["conflicts"]
    print(f"✓ resolve-roles — {sum(st[r]['resolved'] for r in ROLES)} newly resolved; "
          f"{len(un)} distinct unresolved name(s); {len(cf)} conflict(s)")
    for k, n in list(un.items())[:15]:
        print(f"    · {k}  x{n}")
    for c in cf:
        print(f"    ! CONFLICT {c['record']} {c['role']}: stored={c['stored_id']} but "
              f"name {c['raw']!r} resolves to {c['name_resolves_to']}")

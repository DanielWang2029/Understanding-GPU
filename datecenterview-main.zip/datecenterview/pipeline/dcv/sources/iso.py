"""ISO interconnection queues via gridstatus (phase-a-spec §1).

Don't hand-write 7 parsers — gridstatus normalizes all of them. We pick which
ISOs to query from the requested states so a TX smoke only hits ERCOT/SPP.
Each ISO is wrapped so one flaky portal doesn't sink the run.
"""
from __future__ import annotations

from datetime import date

from ..normalize import status_from_iso, tech_from_label

# ISO -> gridstatus class name + the states each ISO substantially covers
ISO_COVERAGE: dict[str, tuple[str, set[str]]] = {
    "ERCOT": ("Ercot", {"TX"}),
    "CAISO": ("CAISO", {"CA", "NV"}),
    "MISO": ("MISO", {"AR", "IA", "IL", "IN", "LA", "MI", "MN", "MO", "MS", "MT", "ND", "SD", "TX", "WI"}),
    "SPP": ("SPP", {"AR", "KS", "LA", "MO", "NE", "NM", "OK", "SD", "TX", "ND", "MT"}),
    "PJM": ("PJM", {"DE", "IL", "IN", "KY", "MD", "MI", "NC", "NJ", "OH", "PA", "TN", "VA", "WV", "DC"}),
    "NYISO": ("NYISO", {"NY"}),
    "ISONE": ("ISONE", {"CT", "MA", "ME", "NH", "RI", "VT"}),
}


US_STATE_CODES = {
    "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN",
    "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV",
    "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN",
    "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY", "DC",
}
STATE_NAME_TO_CODE = {
    "alabama": "AL", "alaska": "AK", "arizona": "AZ", "arkansas": "AR", "california": "CA",
    "colorado": "CO", "connecticut": "CT", "delaware": "DE", "florida": "FL", "georgia": "GA",
    "hawaii": "HI", "idaho": "ID", "illinois": "IL", "indiana": "IN", "iowa": "IA",
    "kansas": "KS", "kentucky": "KY", "louisiana": "LA", "maine": "ME", "maryland": "MD",
    "massachusetts": "MA", "michigan": "MI", "minnesota": "MN", "mississippi": "MS",
    "missouri": "MO", "montana": "MT", "nebraska": "NE", "nevada": "NV",
    "new hampshire": "NH", "new jersey": "NJ", "new mexico": "NM", "new york": "NY",
    "north carolina": "NC", "north dakota": "ND", "ohio": "OH", "oklahoma": "OK",
    "oregon": "OR", "pennsylvania": "PA", "rhode island": "RI", "south carolina": "SC",
    "south dakota": "SD", "tennessee": "TN", "texas": "TX", "utah": "UT", "vermont": "VT",
    "virginia": "VA", "washington": "WA", "west virginia": "WV", "wisconsin": "WI",
    "wyoming": "WY", "district of columbia": "DC",
}


def _norm_state(raw, coverage: set[str]) -> str | None:
    """Postal code from an ISO 'State' value (code, full name, or blank)."""
    default = next(iter(coverage)) if len(coverage) == 1 else None
    if raw is None or (isinstance(raw, float) and raw != raw):  # None / NaN
        return default
    s = str(raw).strip()
    if not s:
        return default
    up = s.upper()
    if len(up) == 2 and up in US_STATE_CODES:
        return up
    if s.lower() in STATE_NAME_TO_CODE:
        return STATE_NAME_TO_CODE[s.lower()]
    return default if default else (up[:2] if up[:2] in US_STATE_CODES else None)


def _select_isos(states: list[str]) -> list[str]:
    if not states:
        return list(ISO_COVERAGE)  # national
    want = {s.upper() for s in states}
    return [iso for iso, (_, cov) in ISO_COVERAGE.items() if cov & want]


def _get(row: dict, *keys, default=None):
    for k in keys:
        if k in row and row[k] not in (None, ""):
            v = row[k]
            # pandas NaN check without importing pandas at module top
            if v != v:  # noqa: PLR0124  (NaN != NaN)
                continue
            return v
    return default


def fetch_queues(states: list[str]) -> list[dict]:
    import gridstatus  # heavy import; keep local

    today = date.today().isoformat()
    want = {s.upper() for s in states} if states else None
    out: list[dict] = []

    for iso_name in _select_isos(states):
        cls_name = ISO_COVERAGE[iso_name][0]
        try:
            iso = getattr(gridstatus, cls_name)()
            df = iso.get_interconnection_queue()
        except Exception as e:
            print(f"  [iso] {iso_name} queue fetch failed ({type(e).__name__}: {e}) — skipped")
            continue
        coverage = ISO_COVERAGE[iso_name][1]
        n_before = len(out)
        for row in df.to_dict("records"):
            # State may be a code ("TX"), a full name ("Texas"), or blank (implied
            # by a single-state ISO like ERCOT) — normalize all three.
            st = _norm_state(_get(row, "State", "state"), coverage)
            if want is not None and st not in want:
                continue
            out.append(_normalize(iso_name, row, st, today))
        print(f"  [iso] {iso_name}: {len(out) - n_before} rows (after state filter)")
    return out


def _normalize(iso_name: str, row: dict, state: str | None, today: str) -> dict:
    qid = _get(row, "Queue ID", "Queue Number", "queue_id", default="?")
    gen_type = _get(row, "Generation Type", "Fuel", "Type")
    cap = _get(row, "Capacity (MW)", "Summer Capacity (MW)", "MW Max", "Capacity")
    try:
        capacity = float(cap) if cap is not None else None
    except (TypeError, ValueError):
        capacity = None
    # negative MW = load-only / net-metered interconnection; treat capacity as unknown
    if capacity is not None and capacity < 0:
        capacity = None
    completion = _get(row, "Proposed Completion Date", "Actual Completion Date")
    op_year = None
    if completion is not None:
        s = str(completion)
        for token in s.replace("/", "-").split("-"):
            if len(token) == 4 and token.isdigit():
                op_year = int(token)
                break

    return {
        "source": iso_name,
        "source_ref": f"queue_id={qid}",
        "natural_key": f"{iso_name.lower()}:{qid}",
        "id": f"{iso_name.lower()}-{str(qid).replace('/', '-').replace(' ', '')}",
        "project_name": _get(row, "Project Name", "Facility Name", default=f"{iso_name} #{qid}"),
        "developer_name": _get(row, "Interconnecting Entity", "Interconnection Customer", "Developer"),
        "energy_source_code": None,
        "technology": tech_from_label(str(gen_type) if gen_type else ""),
        "capacity_mw": capacity,
        "status": status_from_iso(_get(row, "Status", "Queue Status")),
        "status_raw": _get(row, "Status", "Queue Status"),
        "balancing_authority": iso_name,
        "county": _get(row, "County", "county"),
        "state": state,
        "lat": None,
        "lng": None,
        "operating_year": op_year,
        "last_verified": today,
    }

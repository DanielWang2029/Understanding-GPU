"""Ingestion sources for the Phase A power layer."""

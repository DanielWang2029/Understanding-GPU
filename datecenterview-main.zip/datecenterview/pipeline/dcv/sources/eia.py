"""EIA-860M client — every US generator (operable + planned + retired).

API v2 `operating-generator-capacity` route (phase-a-spec §2). Handles the
5,000-row pagination cap, throttles, and pulls only the latest monthly snapshot.
"""
from __future__ import annotations

import time
from datetime import date

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from ..normalize import status_from_eia, tech_from_eia

BASE = "https://api.eia.gov/v2/electricity/operating-generator-capacity/data/"
PAGE = 5000


def _get(row: dict, *keys, default=None):
    for k in keys:
        if k in row and row[k] not in (None, ""):
            return row[k]
    return default


@retry(stop=stop_after_attempt(4), wait=wait_exponential(multiplier=1, min=2, max=20))
def _call(client: httpx.Client, params: list[tuple]) -> dict:
    r = client.get(BASE, params=params)
    r.raise_for_status()
    return r.json()


def _latest_period(client: httpx.Client, api_key: str) -> str | None:
    params = [
        ("api_key", api_key),
        ("frequency", "monthly"),
        ("data[]", "nameplate-capacity-mw"),
        ("sort[0][column]", "period"),
        ("sort[0][direction]", "desc"),
        ("offset", "0"),
        ("length", "1"),
    ]
    data = _call(client, params).get("response", {}).get("data", [])
    return data[0].get("period") if data else None


def fetch_generators(api_key: str, states: list[str]) -> list[dict]:
    """Return normalized EIA generator rows (latest monthly snapshot)."""
    if not api_key:
        raise RuntimeError("EIA_API_KEY not set — cannot pull EIA-860M")

    out: list[dict] = []
    today = date.today().isoformat()
    with httpx.Client(timeout=60, follow_redirects=True) as client:
        latest = _latest_period(client, api_key)
        base_params: list[tuple] = [
            ("api_key", api_key),
            ("frequency", "monthly"),
            ("data[]", "nameplate-capacity-mw"),
            ("data[]", "net-summer-capacity-mw"),
            ("sort[0][column]", "period"),
            ("sort[0][direction]", "desc"),
        ]
        if latest:
            base_params += [("start", latest), ("end", latest)]
        for st in states:
            base_params.append(("facets[stateid][]", st))

        offset = 0
        while True:
            params = base_params + [("offset", str(offset)), ("length", str(PAGE))]
            resp = _call(client, params).get("response", {})
            rows = resp.get("data", [])
            if not rows:
                break
            for row in rows:
                out.append(_normalize(row, today))
            got = len(rows)
            offset += got
            total = int(resp.get("total", 0) or 0)
            if got < PAGE or (total and offset >= total):
                break
            time.sleep(0.3)  # be polite to the rate limiter
    return out


def _normalize(row: dict, today: str) -> dict:
    plant_id = _get(row, "plantid", "plant_id", "plantId")
    gen_id = _get(row, "generatorid", "generator_id", "generatorId", default="")
    state = _get(row, "stateid", "state", "plant_state")
    county = _get(row, "county", "countyName")
    esc = _get(row, "energy-source-code", "energy_source_code", "energySourceCode")
    tech_label = _get(row, "technology", "technology-description", "prime-mover-code")
    status_raw = _get(row, "statusDescription", "status-description", "status")
    cap = _get(row, "nameplate-capacity-mw", "nameplate_capacity_mw")
    ba = _get(row, "balancing-authority-code", "balancing_authority_code", "balancing-authority")
    oym = _get(row, "operating-year-month", "operating_year_month", "operating-year")

    try:
        capacity = float(cap) if cap is not None else None
    except (TypeError, ValueError):
        capacity = None
    if capacity is not None and capacity < 0:
        capacity = None
    lat = _get(row, "latitude", "lat")
    lng = _get(row, "longitude", "lng", "lon")
    try:
        lat = float(lat) if lat is not None else None
        lng = float(lng) if lng is not None else None
    except (TypeError, ValueError):
        lat = lng = None
    op_year = None
    if oym:
        try:
            op_year = int(str(oym)[:4])
        except (TypeError, ValueError):
            op_year = None

    return {
        "source": "EIA-860M",
        "source_ref": f"plant_id={plant_id};gen={gen_id}",
        "natural_key": f"eia:{plant_id}:{gen_id}",
        "id": f"eia-{plant_id}-{gen_id}",
        "project_name": _get(row, "plantName", "plant_name", default=f"Plant {plant_id}"),
        "developer_name": _get(row, "entityName", "entity_name"),
        "energy_source_code": esc,
        "technology": tech_from_eia(esc, tech_label),
        "capacity_mw": capacity,
        "status": status_from_eia(status_raw),
        "status_raw": status_raw,
        "balancing_authority": ba,
        "county": county,
        "state": state,
        "lat": lat,
        "lng": lng,
        "operating_year": op_year,
        "last_verified": today,
    }

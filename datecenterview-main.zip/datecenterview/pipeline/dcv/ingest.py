"""phase-a-ingest — EIA + ISO -> normalize -> geocode -> BTM -> upsert (phase-a-spec).

National-capable; scope controlled by INGEST_STATES / --states. Smoke runs use TX.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert

from . import btm, geocode
from .db import session_scope
from .field import field
from .models import DataCenter, PowerProject, Source
from .sources import eia, iso

# authoritative portal URL per source (read-model sources[])
SOURCE_URL = {
    "EIA-860M": "https://www.eia.gov/electricity/data/eia860m/",
    "ERCOT": "https://www.ercot.com/mp/data-products/data-product-details?id=PG7-200-ER",
    "CAISO": "https://www.caiso.com/library/interconnection-queue-reports",
    "MISO": "https://www.misoenergy.org/planning/resource-utilization/GI_Queue/",
    "SPP": "https://opsportal.spp.org/Studies/",
    "PJM": "https://www.pjm.com/planning/service-requests/serial-service-request-status",
    "NYISO": "https://www.nyiso.com/interconnections",
    "ISONE": "https://www.iso-ne.com/system-planning/interconnection-service/interconnection-request-queue/",
}
SOURCE_TRUST = {"EIA-860M": 1.0}  # ISO queues default 0.95 below
LIFECYCLE_RANK = {
    "operating": 5, "under_construction": 4, "permitted": 3,
    "on_hold": 2, "proposed": 1, "cancelled": 0, "retired": 0,
}


def _norm_name(s: str | None) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _dedupe(rows: list[dict]) -> list[dict]:
    """Merge the same generator seen in an ISO queue and in EIA (phase-a §7).

    Group on (normalized name, state, capacity bucket). Keep the most-advanced
    lifecycle; union sources so a queue->EIA lifecycle becomes one 2-source row.
    """
    groups: dict[tuple, list[dict]] = {}
    for r in rows:
        cap = r.get("capacity_mw") or 0
        key = (_norm_name(r["project_name"]), (r.get("state") or ""), round(cap / 25.0))
        groups.setdefault(key, []).append(r)

    merged: list[dict] = []
    for key, grp in groups.items():
        if len(grp) == 1 or not key[0]:
            merged.extend(grp)
            continue
        grp.sort(key=lambda x: LIFECYCLE_RANK.get(x["status"], 0), reverse=True)
        canonical = dict(grp[0])
        canonical["_extra_sources"] = []
        canonical["_extra_refs"] = []
        for other in grp[1:]:
            if other["source"] != canonical["source"]:
                canonical["_extra_sources"].append(other["source"])
                canonical["_extra_refs"].append(other["source_ref"])
        merged.append(canonical)
    return merged


def _geocode_row(r: dict) -> str | None:
    """Fill lat/lng if missing; return geo_precision."""
    if r.get("lat") is not None and r.get("lng") is not None:
        return "exact"
    hit = geocode.county_centroid(r.get("county"), r.get("state"))
    if hit:
        r["lat"], r["lng"] = hit
        return "county"
    return None


def _known_dc_context(session) -> tuple[set[str], set[tuple[str, str]]]:
    """Developers + (state,county) of known data centers, for the BTM heuristic."""
    devs: set[str] = set()
    counties: set[tuple[str, str]] = set()
    for dc in session.execute(select(DataCenter)).scalars():
        if dc.developer_name:
            devs.add(dc.developer_name.lower())
        loc = dc.location or {}
        if loc.get("county") and loc.get("state"):
            counties.add((loc["state"].upper(), loc["county"].lower()))
    return devs, counties


def phase_a_ingest(states: list[str], api_key: str) -> dict:
    scope = ",".join(states) if states else "ALL (national)"
    print(f"phase-a-ingest — scope: {scope}")

    print("→ EIA-860M …")
    eia_rows = eia.fetch_generators(api_key, states)
    print(f"  EIA rows: {len(eia_rows)}")

    print("→ ISO queues (gridstatus) …")
    try:
        iso_rows = iso.fetch_queues(states)
    except Exception as e:
        print(f"  [iso] layer failed ({type(e).__name__}: {e}); continuing with EIA only")
        iso_rows = []
    print(f"  ISO rows: {len(iso_rows)}")

    rows = _dedupe(eia_rows + iso_rows)
    print(f"→ {len(rows)} rows after dedup (from {len(eia_rows) + len(iso_rows)})")

    now = datetime.now(timezone.utc)
    upserts = 0
    with session_scope() as session:
        dc_devs, dc_counties = _known_dc_context(session)

        # source registry
        seen_sources = set()
        for r in rows:
            for src in [r["source"], *r.get("_extra_sources", [])]:
                if src in seen_sources:
                    continue
                seen_sources.add(src)
                session.merge(Source(
                    id=f"src:{src}",
                    url=SOURCE_URL.get(src),
                    publisher=src,
                    type="gov_api" if src == "EIA-860M" else "iso",
                    trust_weight=SOURCE_TRUST.get(src, 0.95),
                    retrieved_at=now,
                ))
        session.flush()  # source parents before power_project children (FK source_id)

        for r in rows:
            precision = _geocode_row(r)
            all_sources = [r["source"], *r.get("_extra_sources", [])]
            urls = [SOURCE_URL[s] for s in all_sources if s in SOURCE_URL]
            confidence = 1.0 if r["source"] == "EIA-860M" else 0.95

            flag, reasons = btm.btm_signal(
                technology=r["technology"], capacity_mw=r.get("capacity_mw"),
                status=r["status"], developer_name=r.get("developer_name"),
                county=r.get("county"), state=r.get("state"),
                dc_developers=dc_devs, dc_counties=dc_counties,
            )

            values = dict(
                id=r["id"],
                natural_key=r["natural_key"],
                project_name=r["project_name"],
                developer_name=r.get("developer_name"),
                technology=r["technology"],
                energy_source_code=r.get("energy_source_code"),
                capacity_mw=field(r.get("capacity_mw"), unit="MW", sources=[f"src:{s}" for s in all_sources],
                                  confidence=confidence, method="gov_api" if r["source"] == "EIA-860M" else "iso"),
                capacity_mwh=None,
                status=r["status"],
                status_raw=r.get("status_raw"),
                balancing_authority=r.get("balancing_authority"),
                location={
                    "county": r.get("county"), "state": r.get("state"), "country": "US",
                    "lat": r.get("lat"), "lng": r.get("lng"), "geo_precision": precision,
                },
                btm_datacenter_signal=field(flag, sources=[f"src:{s}" for s in all_sources],
                                            confidence=0.5 if flag else 0.0, method="gov_api",
                                            as_of=r["last_verified"]) if flag else None,
                operating_year=r.get("operating_year"),
                source=r["source"],
                source_ref="; ".join([r["source_ref"], *r.get("_extra_refs", [])]),
                source_id=f"src:{r['source']}",
                confidence=confidence,
                review_status="approved",
                last_verified=r["last_verified"],
                sources=urls,
                updated_at=now,
            )
            stmt = pg_insert(PowerProject).values(**values)
            update_cols = {k: stmt.excluded[k] for k in values if k not in ("id", "created_at")}
            stmt = stmt.on_conflict_do_update(index_elements=["id"], set_=update_cols)
            session.execute(stmt)
            upserts += 1

    btm_ct = sum(1 for r in rows if r.get("capacity_mw"))  # rough; real count re-read below
    print(f"✓ upserted {upserts} power_project rows")
    return {"eia": len(eia_rows), "iso": len(iso_rows), "upserted": upserts}

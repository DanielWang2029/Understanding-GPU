"""Tests for the Phase A normalization maps (phase-a-spec §4)."""
from dcv.normalize import (
    DISPLAY_STATUSES,
    display_status,
    status_from_eia,
    status_from_iso,
    tech_from_eia,
    tech_from_label,
)


def test_eia_energy_codes_map_to_enum():
    assert tech_from_eia("SUN") == "Solar"
    assert tech_from_eia("WND") == "Wind"
    assert tech_from_eia("MWH") == "Battery"
    assert tech_from_eia("NG") == "Natural Gas"
    assert tech_from_eia("NUC") == "Nuclear"
    assert tech_from_eia("BIT") == "Coal"
    assert tech_from_eia("WAT") == "Hydro"


def test_tech_label_fallback():
    assert tech_from_label("Solar Photovoltaic") == "Solar"
    assert tech_from_label("Battery Energy Storage") == "Battery"
    assert tech_from_label("Natural Gas Fired Combined Cycle") == "Natural Gas"
    assert tech_from_label("something unknown") == "Other"


def test_iso_fuel_labels_and_abbreviations():
    # ERCOT-style compound labels
    assert tech_from_label("Other - Battery Energy Storage") == "Battery"
    assert tech_from_label("Solar - Photovoltaic Solar") == "Solar"
    assert tech_from_label("Gas - Combined-Cycle") == "Natural Gas"
    assert tech_from_label("Gas - Internal Combustion Engine, eg. Reciprocating") == "Natural Gas"
    # SPP-style bare abbreviations that used to fall through to Other
    assert tech_from_label("CT") == "Natural Gas"
    assert tech_from_label("CTG") == "Natural Gas"
    assert tech_from_label("Reciprocating Engine") == "Natural Gas"
    # genuinely unknown / blank stays Other
    assert tech_from_label("") == "Other"
    assert tech_from_label("Steam") == "Other"


def test_eia_status_to_lifecycle():
    assert status_from_eia("(OP) Operating") == "operating"
    assert status_from_eia("(RE) Retired") == "retired"
    assert status_from_eia("(P) Planned") == "proposed"


def test_iso_status_to_lifecycle():
    assert status_from_iso("In Service") == "operating"
    assert status_from_iso("IA Executed") == "under_construction"
    assert status_from_iso("Withdrawn") == "cancelled"
    assert status_from_iso("Active") == "proposed"


def test_lifecycle_maps_to_display_enum():
    for lifecycle in ("proposed", "permitted", "under_construction", "operating", "cancelled", "retired", "on_hold"):
        assert display_status(lifecycle) in DISPLAY_STATUSES
    # display values pass through unchanged
    assert display_status("Operating") == "Operating"
    assert display_status("proposed") == "Planned"

"""reverify — the corroborating sources it persists are value-provenance, so they must pass the
SAME admissibility test the publish gate enforces.

The 2026-07-21 top-40 re-run surfaced the bug this pins: `reverify` filtered the verifier's own
web-search results with `denied_reason` (tier-1 competitor only), so two `datacenter.fyi` URLs
(tier-3, modelled from a constant PUE — denied for VALUES) landed on sized rows and gate 10
correctly blocked publish. The ingest path must match the backstop, not lag it. These tests run
the real `reverify.reverify()` with a mocked verifier and a fake session — no DB, no API.
"""
import sys
from contextlib import contextmanager
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dcv import reverify  # noqa: E402


class FakeRow:
    """Minimal DataCenter stand-in — reverify reads/writes only these attributes."""
    def __init__(self, sources):
        self.id = "dce-test-1"
        self.project_name = "Test Facility"
        self.location = {"county": "X", "state": "TX", "quote": None}
        self.capacity_mw = {"value": 77.0, "quote": None}
        self.status = "Operating"
        self.sources = list(sources)
        self.overall_confidence = 0.72
        self.review_status = "reported"
        self.last_verified = None


class FakeScalars:
    def __init__(self, rows): self._rows = rows
    def scalars(self): return list(self._rows)


class FakeSession:
    def __init__(self, rows): self._rows = rows
    def execute(self, *_a, **_k): return FakeScalars(self._rows)
    def get(self, _model, rid): return next((r for r in self._rows if r.id == rid), None)
    def add(self, _obj): pass


def _run_with(verifier_sources, monkeypatch):
    """Wire a fake row + fake verifier through the real reverify() and return (row, stats)."""
    row = FakeRow(sources=["https://www.datacenters.com/existing"])

    @contextmanager
    def fake_scope():
        yield FakeSession([row])

    def fake_verify(_cand):
        return {"review_status": "approved", "overall_confidence": 0.9,
                "sources": [{"url": u} for u in verifier_sources], "verify": {}}

    monkeypatch.setattr(reverify, "session_scope", fake_scope)
    # reverify imports `verify as verify_one` from .phaseb.verify INSIDE the function
    import dcv.phaseb.verify as vmod
    monkeypatch.setattr(vmod, "verify", fake_verify)
    st = reverify.reverify(status="reported", dry_run=False)
    return row, st


def test_a_tier3_modelled_source_the_verifier_surfaces_is_refused(monkeypatch):
    """MUST-FAIL: this is the exact regression. A datacenter.fyi URL (tier-3, denied for values)
    that the verifier's web search returns must NOT be persisted onto a sized row."""
    tier3 = "https://www.datacenter.fyi/public-record/some-facility"
    clean = "https://www.baxtel.com/data-center/some-facility"
    row, st = _run_with([tier3, clean], monkeypatch)
    assert tier3 not in row.sources, "tier-3 modelled source leaked onto a sized row (gate 10 would block)"
    assert clean in row.sources, "a permitted corroborating source must still be kept"
    assert st["sources_refused"] == 1
    assert st["sources_added"] == 1


def test_a_tier1_competitor_is_still_refused(monkeypatch):
    """REGRESSION: the widened check must not stop refusing tier-1 competitors."""
    tier1 = "https://www.datacenterhawk.com/facility/x"
    row, st = _run_with([tier1], monkeypatch)
    assert tier1 not in row.sources
    assert st["sources_refused"] == 1


def test_a_permitted_source_is_kept(monkeypatch):
    """MUST-PASS: an admissible corroborating source is persisted (keep-the-evidence)."""
    ok = "https://www.datacentermap.com/usa/some-facility"
    row, st = _run_with([ok], monkeypatch)
    assert ok in row.sources
    assert st["sources_added"] == 1 and st["sources_refused"] == 0

"""Verifier bake-off (phase 1) — the outcome taxonomy, the shared gate, the spend guardrail.

Phase 1 exists because the gold set cannot certify anything (7 rows, all
`demo_seed_bootstrap`, which `goldset.certify()` refuses). So every claim this harness makes
has to hold WITHOUT ground truth, and the failure mode to guard against is a comparison that
looks rigorous while measuring the harness instead of the models:

  * classify a truncation as a quality problem (it is a max_tokens problem)
  * classify a refusal as a transport failure (production does exactly this today)
  * score candidates through a REIMPLEMENTED gate that has drifted from the real one
  * bill an unpriced model at $0 so the spend cap silently stops binding

Each rule below has a must-pass AND a must-fail case.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dcv import bakeoff  # noqa: E402
from dcv.clients import spend, verifiers  # noqa: E402
from dcv.clients.verifiers import Attempt, Backend  # noqa: E402
from dcv.phaseb import verify as V  # noqa: E402

OK_JSON = ('{"capacity_mw": {"verdict":"agree","found_value":400,"source_url":"https://b.com/x"},'
           ' "status": {"verdict":"agree","found_value":"under_construction","source_url":null},'
           ' "location": {"verdict":"unverifiable","found_value":null,"source_url":null}}')


def cand(sources=("https://a.com/p",), mw=400):
    return {"project_name": "P", "capacity_mw": {"value": mw, "quote": "400 MW"},
            "status": {"value": "under_construction", "quote": None},
            "location": {"county": "Reeves", "state": "TX", "address": None, "quote": None},
            "sources": [{"url": u} for u in sources], "self_consistency": 0.5}


def be(name="m", price=(1.0, 5.0), **kw):
    return Backend(name=name, vendor="anthropic", model=f"model-{name}", price=price, **kw)


# ---------------------------------------------------------------- the outcome taxonomy
def test_a_well_formed_verdict_is_ok():
    obj, outcome, detail = verifiers.parse_verdicts(OK_JSON)
    assert outcome == "ok" and detail is None
    assert obj["capacity_mw"]["verdict"] == "agree"


def test_a_fenced_verdict_is_still_ok():
    """Models wrap JSON in ``` constantly; that is not a reliability defect."""
    assert verifiers.parse_verdicts(f"```json\n{OK_JSON}\n```")[1] == "ok"


def test_prose_is_malformed_not_a_schema_miss():
    obj, outcome, _ = verifiers.parse_verdicts("I could not verify this project.")
    assert (obj, outcome) == (None, "malformed")


def test_valid_json_of_the_wrong_shape_is_a_schema_miss():
    """Distinct from `malformed`: the model can emit JSON, it just ignored our contract.
    Different fix (prompt / json_mode), so it must not share a bucket."""
    obj, outcome, detail = verifiers.parse_verdicts('{"answer": "looks right"}')
    assert outcome == "schema_miss" and "no verdict key" in detail


def test_a_verdict_outside_the_enum_is_a_schema_miss():
    """"probably" is not one of agree/disagree/unverifiable. `_score_field` would silently
    treat it as unverifiable and the model would look conservative rather than wrong."""
    obj, outcome, detail = verifiers.parse_verdicts(
        '{"capacity_mw": {"verdict":"probably","found_value":400,"source_url":null}}')
    assert outcome == "schema_miss" and "outside the enum" in detail


def test_an_empty_body_is_malformed_rather_than_crashing():
    assert verifiers.parse_verdicts("")[1] == "malformed"


# ---------------------------------------------------------------- refusal vs truncation
def _stub(monkeypatch, **raw):
    monkeypatch.setitem(verifiers._TRANSPORTS, "anthropic",
                        lambda b, s, u, t: verifiers._Raw(**raw))


def test_a_refusal_is_its_own_outcome(monkeypatch):
    """The gap this harness exists to close: a refusal returns HTTP 200 with no text, so
    clients/claude.py raises the same ClaudeError it raises for a broken response and
    phaseb.verify records both as 'held as reported'."""
    _stub(monkeypatch, text="", stop="refusal", in_tokens=10, out_tokens=0)
    a = verifiers.call(be(), "sys", "usr", "rec-1")
    assert a.outcome == "refusal" and not a.answered


def test_truncation_outranks_the_parse_failure(monkeypatch):
    """Half a JSON object because max_tokens ran out is a CONFIG problem. Filed as
    `malformed` it would read as an instruction-following defect and rank the model down."""
    _stub(monkeypatch, text='{"capacity_mw": {"verdict":"ag', stop="max_tokens",
          in_tokens=100, out_tokens=2000)
    a = verifiers.call(be(), "sys", "usr", "rec-1")
    assert a.outcome == "truncated" and "max_tokens" in a.detail


def test_a_complete_answer_that_hit_max_tokens_is_still_ok(monkeypatch):
    """Must-fail guard on the rule above: `truncated` may only override a FAILED parse.
    Overriding a good one would penalise a model for finishing exactly at the budget."""
    _stub(monkeypatch, text=OK_JSON, stop="max_tokens", in_tokens=100, out_tokens=2000)
    assert verifiers.call(be(), "sys", "usr", "rec-1").outcome == "ok"


def test_a_transport_failure_is_measured_not_raised(monkeypatch):
    """A bake-off that aborts on the first flaky vendor measures nothing."""
    def boom(b, s, u, t):
        raise ConnectionError("connection reset")
    monkeypatch.setitem(verifiers._TRANSPORTS, "anthropic", boom)
    a = verifiers.call(be(), "sys", "usr", "rec-1")
    assert a.outcome == "error" and "ConnectionError" in a.detail


def _payload_of(b: Backend, transport):
    """Capture the request body a transport would send, without sending it."""
    import httpx
    seen = {}

    class FakeResp:
        def raise_for_status(self): pass
        def json(self):
            return {"content": [{"type": "text", "text": OK_JSON}], "stop_reason": "end_turn",
                    "usage": {"input_tokens": 1, "output_tokens": 1},
                    "choices": [{"message": {"content": OK_JSON}, "finish_reason": "stop"}]}

    class FakeClient:
        def __init__(self, **kw): pass
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def post(self, url, **kw):
            seen.update(kw.get("json") or {})
            return FakeResp()

    real = httpx.Client
    httpx.Client = FakeClient
    try:
        transport(b, "sys", "usr", 10)
    finally:
        httpx.Client = real
    return seen


def test_temperature_is_omitted_unless_the_backend_asks_for_it():
    """Regression: pinning temperature=0 for determinism 400s Opus 4.8 / Opus 5 / Sonnet 5
    ("`temperature` is deprecated for this model") while Haiku 4.5 still accepts it — so the
    smoke run disqualified three of four Anthropic candidates and left the cheapest looking
    like the only one that works. Production's clients/claude.py sends no temperature either."""
    assert "temperature" not in _payload_of(be(), verifiers._anthropic)


def test_temperature_is_sent_when_the_backend_does_ask():
    """Must-pass half: the openai-compatible vendors still honour it, and determinism there
    is worth having."""
    b = be(transport="openai_chat", base_url="https://x/v1", temperature=0)
    assert _payload_of(b, verifiers._openai_chat)["temperature"] == 0


def test_every_default_slate_backend_is_configured_for_its_vendor():
    """The slate is the thing a paid run is launched from; a bad field there costs money to
    discover. Anthropic entries must not pin temperature, openai-compatible ones must carry a
    base_url."""
    for spec in bakeoff.DEFAULT_SLATE:
        b = verifiers.from_spec(spec)
        if b.transport == "anthropic":
            assert b.temperature is None, f"{b.name} pins temperature — will 400"
        else:
            assert b.base_url, f"{b.name} has no base_url"


def test_openai_finish_reasons_normalize_onto_one_taxonomy():
    """xAI/OpenRouter say 'length'/'content_filter'; Anthropic says 'max_tokens'/'refusal'.
    Two vocabularies would split the same failure across two columns."""
    import httpx

    class FakeResp:
        def raise_for_status(self): pass
        def json(self):
            return {"choices": [{"message": {"content": "x"}, "finish_reason": "content_filter"}],
                    "usage": {"prompt_tokens": 5, "completion_tokens": 1}}

    class FakeClient:
        def __init__(self, **kw): pass
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def post(self, *a, **kw): return FakeResp()

    real = httpx.Client
    httpx.Client = FakeClient
    try:
        raw = verifiers._openai_chat(
            be(transport="openai_chat", base_url="https://x/v1"), "s", "u", 10)
    finally:
        httpx.Client = real
    assert raw.stop == "refusal"


# ---------------------------------------------------------------- cost & the spend cap
def test_cost_is_measured_from_the_response_not_projected(monkeypatch):
    _stub(monkeypatch, text=OK_JSON, stop="end_turn", in_tokens=1_000_000, out_tokens=1_000_000)
    a = verifiers.call(be(price=(3.0, 15.0)), "sys", "usr", "rec-1")
    assert a.usd_tokens == pytest.approx(18.0)


def test_the_headline_cost_includes_server_side_search(monkeypatch):
    """The smoke run's own defect: `usd` was tokens-only while the web-search calls went to
    the ledger, so the reported $/record was a number nobody is billed — and it understated
    precisely the searching models. At 5 searches/record the search line ($0.05) exceeds
    Haiku's whole token bill on a typical record."""
    _stub(monkeypatch, text=OK_JSON, stop="end_turn", in_tokens=0, out_tokens=0, searches=5)
    a = verifiers.call(be(price=(1.0, 5.0)), "sys", "usr", "rec-1")
    assert a.usd_tokens == 0.0
    assert a.usd_search == pytest.approx(5 * spend.SEARCH_COSTS["claude_web_search"])
    assert a.usd == pytest.approx(a.usd_tokens + a.usd_search) and a.usd > 0


def test_an_unpriced_model_is_flagged_rather_than_billed_at_zero():
    """The hole this closes: TOKEN_PRICES.get(model, (0.0, 0.0)) means a model the ledger has
    never seen accrues real spend scored as $0, so the cap never trips. Harmless while the
    model set was fixed; load-bearing now that a slate FILE can introduce model ids."""
    led = spend.SpendLedger(limit_usd=1.0)
    assert led.record_tokens("some-new-model", 10_000_000, 10_000_000) == 0.0
    assert "some-new-model" in led.unpriced
    assert "UNPRICED" in led.summary()


def test_register_price_makes_the_cap_bind():
    spend.TOKEN_PRICES.pop("bakeoff-test-model", None)
    assert spend.register_price("bakeoff-test-model", 5.0, 25.0) is True
    led = spend.SpendLedger(limit_usd=1.0)
    with pytest.raises(spend.SpendLimitError):
        led.record_tokens("bakeoff-test-model", 1_000_000, 0)
    spend.TOKEN_PRICES.pop("bakeoff-test-model", None)


def test_register_price_never_clobbers_a_production_rate():
    """A slate quoting go-forward LIST price must not rewrite the rate production is billed
    at underneath a live run."""
    before = spend.TOKEN_PRICES["claude-sonnet-5"]
    assert spend.register_price("claude-sonnet-5", 99.0, 99.0) is False
    assert spend.TOKEN_PRICES["claude-sonnet-5"] == before


def test_a_backend_with_no_price_is_refused_at_construction():
    with pytest.raises(ValueError, match="no \\[input, output\\] price"):
        verifiers.from_spec({"name": "mystery", "vendor": "x", "model": "m",
                             "transport": "openai_chat"})


# ---------------------------------------------------------------- ONE gate, not two
LIVE = lambda u: "live"  # noqa: E731  — inject, so scoring tests make no network calls


def test_the_bakeoff_scores_through_the_production_gate():
    """score() is the aggregation lifted out of verify(): three independently-sourced
    agreements clear the >=2-source approve gate."""
    sc = V.score(cand(), {"capacity_mw": {"verdict": "agree", "source_url": "https://b.com/x"},
                          "status": {"verdict": "agree", "source_url": "https://c.com/y"},
                          "location": {"verdict": "agree", "source_url": "https://d.com/z"}},
                 LIVE)
    assert sc["review_status"] == "approved"
    assert sc["n_sources"] == 4 and len(sc["new_sources"]) == 3


def test_recitng_one_new_domain_earns_corroboration_credit_once():
    """A verifier that finds ONE second source and cites it for all three fields has
    corroborated once, not three times — so this must NOT reach `approved`. The gate is
    order-dependent by design: the first field banks the domain, the rest see it as already
    held. Worth pinning, because it is exactly the shape a cheap verifier produces when it
    does a single search and reuses the hit."""
    sc = V.score(cand(), {"capacity_mw": {"verdict": "agree", "source_url": "https://b.com/x"},
                          "status": {"verdict": "agree", "source_url": "https://b.com/x"},
                          "location": {"verdict": "agree", "source_url": "https://b.com/x"}},
                 LIVE)
    assert sc["review_status"] == "needs_review"
    assert sc["overall_confidence"] == V._AGREE_UNCORROBORATED
    assert sc["n_sources"] == 2 and len(sc["new_sources"]) == 1


def test_the_refactor_left_verify_behaviour_unchanged(monkeypatch):
    """The refactor's whole risk: verify() must still stamp the candidate exactly as before."""
    monkeypatch.setattr(V.claude, "verify_json", lambda s, u: {
        "capacity_mw": {"verdict": "agree", "source_url": "https://b.com/x"},
        "status": {"verdict": "disagree", "found_value": "operating"},
        "location": {"verdict": "agree", "source_url": "https://b.com/x"}})
    monkeypatch.setattr(V, "_liveness", LIVE)
    c = V.verify(cand())
    assert c["capacity_mw"]["confidence"] == V._AGREE_CORROBORATED
    assert c["capacity_mw"]["verify"] == "agree"
    assert c["review_status"] == "reported"          # min() drops to the disagree score
    assert any("status:" in x for x in c["conflicts"])
    assert c["verify"]["n_sources"] == 2 and len(c["sources"]) == 2


def test_score_does_not_mutate_the_candidate():
    """The bake-off runs N backends over the SAME candidate dict. If score() stamped it, the
    second backend would be graded against the first backend's confidences."""
    c = cand()
    before = dict(c["capacity_mw"])
    V.score(c, {"capacity_mw": {"verdict": "agree", "source_url": "https://b.com/x"}}, LIVE)
    assert c["capacity_mw"] == before and len(c["sources"]) == 1


def test_a_verdict_on_a_field_the_record_lacks_is_not_scored():
    """A model volunteering a verdict for a field we never asked about is a hallucination,
    not a datapoint — counting it would inflate its corroboration rate."""
    c = cand()
    c["capacity_mw"] = {"value": None, "quote": None}      # sizeless row
    a = Attempt("m", "r", "ok", verdicts={
        "capacity_mw": {"verdict": "agree", "source_url": "https://b.com/x"},
        "status": {"verdict": "agree", "source_url": None}})
    assert "capacity_mw" not in bakeoff._field_verdicts(a, c)
    assert bakeoff._field_verdicts(a, c)["status"] == "agree"


# ---------------------------------------------------------------- the phase-1 → phase-2 handoff
def _recs():
    return [{"id": "r1", "source_class": "news", "name": "A", "candidate": cand()},
            {"id": "r2", "source_class": "directory", "name": "B", "candidate": cand()}]


def test_gold_priority_ranks_the_records_the_models_split_on():
    """Where every model agrees, adjudication teaches nothing; where they split, it decides
    the gate. This is why phase 1 re-ranks the worksheet that phase 2 fills in."""
    def att(bk, rid, cap, st):
        return Attempt(bk, rid, "ok", verdicts={
            "capacity_mw": {"verdict": cap}, "status": {"verdict": st},
            "location": {"verdict": "agree"}})
    atts = [att("a", "r1", "agree", "agree"), att("b", "r1", "agree", "agree"),
            att("a", "r2", "agree", "agree"), att("b", "r2", "disagree", "unverifiable")]
    gp = bakeoff.gold_priority(atts, _recs())
    assert gp[0]["id"] == "r2" and gp[0]["spread"] == 2
    assert set(gp[0]["split_fields"]) == {"capacity_mw", "status"}
    assert gp[1]["spread"] == 0


def test_agreement_only_counts_records_both_backends_answered():
    """Otherwise a model that refuses half the queue scores high agreement on the easy half."""
    atts = [Attempt(bakeoff.INCUMBENT, "r1", "ok", verdicts={"status": {"verdict": "agree"}}),
            Attempt("cheap", "r1", "ok", verdicts={"status": {"verdict": "agree"}}),
            Attempt("cheap", "r2", "ok", verdicts={"status": {"verdict": "disagree"}})]
    ag = bakeoff.agreement(atts, _recs())
    assert ag["cheap"]["records"] == 1 and ag["cheap"]["agreement"] == 1.0


def test_a_keyless_backend_is_reported_not_silently_dropped():
    """A slate that quietly shrinks looks like a completed comparison."""
    slate = [be("has-key", api_key_env="ANTHROPIC_API_KEY"),
             be("no-key", api_key_env="DEFINITELY_NOT_SET_XYZ"),
             be("off", enabled=False)]
    go, skip = bakeoff.runnable(slate)
    reasons = {b.name: why for b, why in skip}
    assert "DEFINITELY_NOT_SET_XYZ" in reasons["no-key"]
    assert reasons["off"] == "disabled in the slate"


def test_the_default_slate_carries_the_same_vendor_control():
    """Decision #4 asserts same-vendor agreement is meaningless. The slate includes the
    EXTRACTOR's own vendor so that assertion gets measured rather than restated."""
    slate = [verifiers.from_spec(s) for s in bakeoff.DEFAULT_SLATE]
    control = [b for b in slate if b.vendor == "xai"]
    assert control and "CONTROL" in control[0].name
    assert all(b.price and len(b.price) == 2 for b in slate)
    assert any(b.name == bakeoff.INCUMBENT for b in slate)


# ---------------------------------------------------------------- retrieved mode (Exa judge)
def test_retrieval_refuses_a_denied_domain(monkeypatch):
    """Retrieval is a NEW INGEST PATH, so it takes the same test the publish gate enforces —
    `value_denied_reason` (tier-1 competitor AND tier-3 modelled figures), not the weaker
    citation-only check. Enforcing a constraint on every path and not just the one that broke
    first is the standing rule; `enrich.py` was filtered once and PhaseB discovery reintroduced
    tier-1 URLs through a path nobody had checked."""
    monkeypatch.setattr(bakeoff, "RETRIEVAL_RESULTS", 4)
    from dcv.clients import exa
    monkeypatch.setattr(exa, "search", lambda q, **k: [
        {"url": "https://www.cleanview.co/x", "title": "competitor", "text": "t"},
        {"url": "https://datacenter.fyi/y", "title": "modelled", "text": "t"},
        {"url": "https://a.com/already-held", "title": "same domain", "text": "t"},
        {"url": "https://good.com/z", "title": "fine", "text": "t"},
    ])
    docs = bakeoff.retrieve(cand())
    assert [d["url"] for d in docs] == ["https://good.com/z"]


def test_retrieval_drops_a_domain_the_extractor_already_cited(monkeypatch):
    """A page on a domain we already hold cannot corroborate — feeding it back would let the
    record confirm itself."""
    from dcv.clients import exa
    monkeypatch.setattr(exa, "search", lambda q, **k: [
        {"url": "https://a.com/other-page", "title": "same publisher", "text": "t"}])
    assert bakeoff.retrieve(cand(sources=("https://a.com/p",))) == []


def test_the_retrieved_prompt_carries_the_pages_and_names_them():
    p = bakeoff._retrieved_prompt(cand(), [{"url": "https://b.com/x", "title": "T",
                                            "text": "400 MW confirmed"}])
    assert "RETRIEVED SOURCES:" in p and "https://b.com/x" in p and "400 MW confirmed" in p


def test_an_empty_retrieval_tells_the_judge_to_answer_unverifiable():
    """Must-fail half: with no evidence the honest answer is `unverifiable`, not a guess from
    prior knowledge. If the prompt went silent here the judge would fall back on memory —
    which is exactly the fabrication path."""
    p = bakeoff._retrieved_prompt(cand(), [])
    assert "(none — answer unverifiable)" in p
    assert "never invent a URL" in bakeoff.RETRIEVED_VERIFY_SYSTEM


def test_retrieved_mode_forces_every_judge_closed_book():
    """The variable this mode removes is tool access. Leaving `search: native` on the Anthropic
    backends would reintroduce the exact confound the Grok control already fell into."""
    import dataclasses
    slate = [verifiers.from_spec(s) for s in bakeoff.DEFAULT_SLATE]
    assert any(b.search == "native" for b in slate), "fixture assumes a searching backend"
    forced = [dataclasses.replace(b, search="none") for b in slate]
    assert all(b.search == "none" for b in forced)


def test_off_script_citations_are_counted():
    """The direct read on whether retrieval removes fabrication or merely relocates it: a
    closed-book judge has nowhere legitimate to get a url we did not supply."""
    a = Attempt("m", "r1", "ok", verdicts={
        "capacity_mw": {"verdict": "agree", "source_url": "https://given.com/1"},
        "status": {"verdict": "agree", "source_url": "https://invented.com/2"}})
    assert bakeoff._offered_urls(a) == {"https://given.com/1", "https://invented.com/2"}
    recs = [{"id": "r1", "source_class": "news", "name": "A", "candidate": cand(),
             "retrieved_urls": ["https://given.com/1"]}]
    rows = bakeoff.summarize([a], recs, [be(name="m")], mode="retrieved")
    assert rows[0]["cited_urls_not_supplied"] == 1


def test_agentic_mode_does_not_report_an_off_script_count():
    """In agentic mode the model is SUPPOSED to bring its own urls — reporting them as
    off-script would flag correct behaviour as fabrication."""
    a = Attempt("m", "r1", "ok", verdicts={"status": {"verdict": "agree",
                                                      "source_url": "https://found.com/x"}})
    recs = [{"id": "r1", "source_class": "news", "name": "A", "candidate": cand()}]
    rows = bakeoff.summarize([a], recs, [be(name="m")], mode="agentic")
    assert rows[0]["cited_urls_not_supplied"] is None


def test_an_unknown_mode_is_refused():
    import pytest as _p
    with _p.raises(ValueError, match="mode must be"):
        bakeoff.run(mode="psychic")

"""chain_quant maker-checker gating tests (Grok extract / Claude verify are mocked).

The live cross-vendor path is exercised by `dcv chain-quant`; these lock the gate logic:
disclosed accepted only if the verifier confirms the % AND doesn't refute the link.
"""
import dcv.chain_quant as cq

SUP = {"id": "tsmc", "name": "TSMC", "ticker": "TSM", "cik": "1046179"}
CAND = {"tsmc": "TSMC", "nvidia": "Nvidia"}


def _patch(monkeypatch, extracted, verdict):
    monkeypatch.setattr(cq.edgar, "submissions", lambda cik: {"filings": {"recent": {}}})
    monkeypatch.setattr(cq.edgar, "latest_report",
                        lambda subs: {"form": "10-K", "accession": "0001-26-000001",
                                      "doc": "d.htm", "filed": "2026-02-25"})
    # text contains the anchor so the real concentration_excerpt returns a non-empty window
    monkeypatch.setattr(cq.edgar, "filing_text",
                        lambda *a: "Customer concentration: Customer A 17% of revenue.")
    monkeypatch.setattr(cq.grok, "chat", lambda *a, **k: ({"customers": extracted}, []))
    monkeypatch.setattr(cq.claude, "verify_json", lambda *a, **k: verdict)


def _row(cid="nvidia", pct=17):
    return {"pct": pct, "verbatim": "Customer A 17% of revenue", "inferred_customer_id": cid,
            "inference_reason": "AI foundry"}


def test_confirmed_edge(monkeypatch):
    _patch(monkeypatch, [_row()], {"pct_confirmed": True, "link_verdict": "agree", "confidence": 0.8})
    e = cq.quantify(SUP, CAND)
    assert len(e) == 1
    assert e[0]["to"] == "nvidia" and e[0]["pct_revenue"] == 17
    assert e[0]["rev_basis"] == "disclosed" and e[0]["link_basis"] == "inferred"
    assert e[0]["review_status"] == "confirmed" and e[0]["link_confidence"] == 0.8
    assert e[0]["verify"]["extractor"] != e[0]["verify"]["verifier"]  # cross-vendor recorded


def test_unconfirmed_pct_dropped(monkeypatch):
    _patch(monkeypatch, [_row()], {"pct_confirmed": False, "link_verdict": "agree", "confidence": 0.1})
    assert cq.quantify(SUP, CAND) == []


def test_refuted_link_dropped(monkeypatch):
    _patch(monkeypatch, [_row()], {"pct_confirmed": True, "link_verdict": "refute", "confidence": 0.2})
    assert cq.quantify(SUP, CAND) == []


def test_uncertain_link_is_needs_review(monkeypatch):
    _patch(monkeypatch, [_row()], {"pct_confirmed": True, "link_verdict": "uncertain", "confidence": 0.5})
    e = cq.quantify(SUP, CAND)
    assert len(e) == 1 and e[0]["review_status"] == "needs_review"


def test_unknown_customer_skipped_without_verify(monkeypatch):
    called = {"verify": 0}

    def _boom(*a, **k):
        called["verify"] += 1
        return {}

    _patch(monkeypatch, [_row(cid="unknown")], {})
    monkeypatch.setattr(cq.claude, "verify_json", _boom)
    assert cq.quantify(SUP, CAND) == []
    assert called["verify"] == 0  # never verify an edge to a non-chain / unknown entity


def test_run_writes_verified_fixture(monkeypatch, tmp_path):
    import json
    out = tmp_path / "verified.json"
    monkeypatch.setattr(cq, "VERIFIED_FIXTURE", out)
    monkeypatch.setattr(cq, "quantify_voted", lambda s, c, **k: [
        {"from": s["id"], "to": "nvidia", "pct_revenue": 17, "review_status": "confirmed"}])
    stats = cq.run([{"id": "micron", "name": "Micron", "ticker": "MU", "cik": "1"}],
                   {"nvidia": "Nvidia"}, budget_usd=1e9)
    assert stats["edges"] == 1 and stats["confirmed"] == 1
    data = json.loads(out.read_text())
    assert data["edges"][0]["to"] == "nvidia" and data["_meta"]["extractor"] != data["_meta"]["verifier"]


def _grok_seq(returns):
    it = iter(returns)
    return lambda *a, **k: (next(it), [])


def _cust(cid="nvidia", pct=17):
    return {"customers": [{"pct": pct, "verbatim": "Customer A 17%",
                           "inferred_customer_id": cid, "inference_reason": "AI"}]}


def _patch_voted(monkeypatch, grok_returns, verdict, verify_counter=None):
    monkeypatch.setattr(cq.edgar, "submissions", lambda cik: {"filings": {"recent": {}}})
    monkeypatch.setattr(cq.edgar, "latest_report",
                        lambda subs: {"form": "10-K", "accession": "0001-26-000001",
                                      "doc": "d.htm", "filed": "2026-02-25"})
    monkeypatch.setattr(cq.edgar, "filing_text",
                        lambda *a: "Customer concentration: Customer A 17% of revenue.")
    monkeypatch.setattr(cq.grok, "chat", _grok_seq(grok_returns))

    def _verify(*a, **k):
        if verify_counter is not None:
            verify_counter[0] += 1
        return verdict

    monkeypatch.setattr(cq.claude, "verify_json", _verify)


def test_voted_consensus_confirmed(monkeypatch):
    _patch_voted(monkeypatch, [_cust()] * 3, {"pct_confirmed": True, "link_verdict": "agree", "confidence": 0.9})
    e = cq.quantify_voted(SUP, CAND, rounds=3, min_votes=2)
    assert len(e) == 1 and e[0]["to"] == "nvidia" and e[0]["pct_revenue"] == 17
    assert e[0]["review_status"] == "confirmed" and e[0]["verify"]["extraction_votes"] == "3/3"


def test_voted_below_min_votes_dropped_without_verify(monkeypatch):
    vc = [0]
    _patch_voted(monkeypatch, [_cust(), {"customers": []}, {"customers": []}],
                 {"pct_confirmed": True, "link_verdict": "agree", "confidence": 0.9}, vc)
    e = cq.quantify_voted(SUP, CAND, rounds=3, min_votes=2)
    assert e == [] and vc[0] == 0  # 1 vote < min_votes → never even verified


def test_voted_modal_pct_drops_comparatives(monkeypatch):
    # proposals 17,17,12 (prior-year comparative) → modal 17 wins
    _patch_voted(monkeypatch, [_cust(pct=17), _cust(pct=17), _cust(pct=12)],
                 {"pct_confirmed": True, "link_verdict": "agree", "confidence": 0.8})
    e = cq.quantify_voted(SUP, CAND, rounds=3, min_votes=2)
    assert len(e) == 1 and e[0]["pct_revenue"] == 17


def test_voted_verify_is_voted_per_edge(monkeypatch):
    vc = [0]
    _patch_voted(monkeypatch, [_cust()] * 3, {"pct_confirmed": True, "link_verdict": "agree", "confidence": 0.9}, vc)
    cq.quantify_voted(SUP, CAND, rounds=3, min_votes=2)
    assert vc[0] == 3  # verify is majority-voted: `rounds` times per consensus edge


def test_voted_majority_uncertain_is_needs_review(monkeypatch):
    # extraction consensus (3/3) but the verifier does NOT reach a majority-agree → needs_review
    _patch_voted(monkeypatch, [_cust()] * 3,
                 {"pct_confirmed": True, "link_verdict": "uncertain", "confidence": 0.6})
    e = cq.quantify_voted(SUP, CAND, rounds=3, min_votes=2)
    assert len(e) == 1 and e[0]["review_status"] == "needs_review"


def test_voted_majority_refute_dropped(monkeypatch):
    _patch_voted(monkeypatch, [_cust()] * 3,
                 {"pct_confirmed": True, "link_verdict": "refute", "confidence": 0.2})
    assert cq.quantify_voted(SUP, CAND, rounds=3, min_votes=2) == []


def _patch_edge_fixtures(monkeypatch, em, tmp_path, *, manual=None, verified=None, identity=None, auto=None):
    import json
    paths = {}
    for name, data in (("_CHAIN_EDGES_FIXTURE", manual), ("_CHAIN_EDGES_VERIFIED", verified),
                       ("_CHAIN_EDGES_IDENTITY", identity), ("_CHAIN_EDGES_IDENTITY_AUTO", auto)):
        p = tmp_path / f"{name}.json"
        if data is not None:
            p.write_text(json.dumps({"edges": data}))
        monkeypatch.setattr(em, name, p)  # non-existent path when data is None → skipped
        paths[name] = p
    return paths


def test_emit_merges_verified_over_manual(monkeypatch, tmp_path):
    import dcv.emit as em
    _patch_edge_fixtures(
        monkeypatch, em, tmp_path,
        manual=[{"from": "tsmc", "to": "nvidia", "pct_revenue": 17, "rev_basis": "disclosed"}],
        verified=[{"from": "tsmc", "to": "nvidia", "pct_revenue": 18, "rev_basis": "disclosed",
                   "review_status": "confirmed"}])
    edges = em._load_chain_edges()
    assert edges[("tsmc", "nvidia")]["pct_revenue"] == 18  # verified wins over manual
    assert edges[("tsmc", "nvidia")]["review_status"] == "confirmed"


def test_emit_identity_merges_link_half_over_magnitude(monkeypatch, tmp_path):
    """L2-identity: the identity fixture contributes only the LINK half (named/link_sources/
    confirmed); the disclosed magnitude from the verified fixture is preserved, not clobbered."""
    import dcv.emit as em
    _patch_edge_fixtures(
        monkeypatch, em, tmp_path,
        manual=[{"from": "micron", "to": "nvidia", "pct_revenue": 17, "rev_basis": "disclosed",
                 "as_of": "2025-10-03", "sources": ["https://sec.gov/mu"], "link_basis": "inferred"}],
        verified=[{"from": "micron", "to": "nvidia", "pct_revenue": 17, "rev_basis": "disclosed",
                   "link_basis": "inferred", "review_status": "needs_review", "link_confidence": 0.24}],
        identity=[{"from": "micron", "to": "nvidia", "link_basis": "named", "review_status": "confirmed",
                   "link_confidence": 0.9,
                   "link_sources": [{"type": "press_first_party", "url": "https://investors.micron/hbm4"}]}])
    e = em._load_chain_edges()[("micron", "nvidia")]
    # link half upgraded by identity …
    assert e["link_basis"] == "named" and e["review_status"] == "confirmed" and e["link_confidence"] == 0.9
    assert e["link_sources"][0]["url"] == "https://investors.micron/hbm4"
    # … while the disclosed magnitude + its provenance survive intact
    assert e["pct_revenue"] == 17 and e["rev_basis"] == "disclosed"
    assert e["as_of"] == "2025-10-03" and e["sources"] == ["https://sec.gov/mu"]


# ---- Band-1 #3b: targeted quantification of NAMED topology edges ----
from dcv.chain_quant import _resolve_unnamed_conflicts


def _e(frm, to, pct, conf, named=False, as_of="2026-04-16"):
    return {"from": frm, "to": to, "pct_revenue": pct, "as_of": as_of,
            "link_confidence": conf, "verify": {"named_in_text": named}}


def test_unnamed_figure_cannot_land_on_two_buyers():
    """Regression: quantifying edge-by-edge attached TSMC's single unnamed "one customer = 19%"
    to BOTH nvidia and broadcom — the same revenue drawn as two separate flows in the sankey.
    One unnamed disclosure describes ONE customer, so only the best-attributed edge survives."""
    keep, dropped = _resolve_unnamed_conflicts(
        [_e("tsmc", "nvidia", 19, 0.8), _e("tsmc", "broadcom", 19, 0.3)])
    assert [(e["from"], e["to"]) for e in keep] == [("tsmc", "nvidia")]
    assert len(dropped) == 1 and "broadcom" in dropped[0]


def test_tied_attribution_drops_every_claimant():
    """A coin-flip between two counterparties is not evidence — publishing the arbitrary
    winner would dress a guess as a disclosed figure."""
    keep, dropped = _resolve_unnamed_conflicts(
        [_e("tsmc", "nvidia", 19, 0.0), _e("tsmc", "broadcom", 19, 0.0), _e("tsmc", "amd", 19, 0.0)])
    assert keep == [] and len(dropped) == 3


def test_named_figures_at_the_same_pct_both_survive():
    """Exemption: if the filing NAMES each buyer beside its figure, two customers can honestly
    sit at the same percentage — the guard must not treat that as a conflict."""
    keep, _ = _resolve_unnamed_conflicts(
        [_e("x", "a", 19, 0.9, named=True), _e("x", "b", 19, 0.9, named=True)])
    assert len(keep) == 2


def test_same_pct_from_different_suppliers_is_not_a_conflict():
    keep, dropped = _resolve_unnamed_conflicts(
        [_e("tsmc", "nvidia", 19, 0.5), _e("micron", "nvidia", 19, 0.5)])
    assert len(keep) == 2 and dropped == []


def test_concentration_excerpt_prefers_the_denser_customer_section():
    """The anchor used to take the FIRST match of the first matching pattern, so a same-shaped
    section appearing earlier (an end-market distribution table) won over the real
    customer-concentration note. Density of per-customer % language must decide."""
    from dcv.clients import edgar
    decoy = ("percentage of net sales in each end market: Communications 40% Automotive 20% "
             "based on a sampling of our largest customers. ") + ("filler text. " * 200)
    real = ("Note 12. Concentrations. Revenue from one customer was 19% of total revenue. "
            "Customer A accounted for 19%. Customer B accounted for 11% of revenue. ")
    ex = edgar.concentration_excerpt(decoy + real, window=600)
    assert "Customer A" in ex and "end market" not in ex


def test_concentration_excerpt_gets_a_full_window_at_the_document_tail():
    """A match near the end must still return a full window — TSMC's 'Major customers
    representing at least 10%' table sits at the tail, and a clipped excerpt stopped before
    the figures it introduces."""
    from dcv.clients import edgar
    text = ("filler. " * 500) + "Revenue from one customer was 19% of net revenue. TAILMARKER"
    ex = edgar.concentration_excerpt(text, window=800)
    assert len(ex) == 800 and "TAILMARKER" in ex


def test_concentration_excerpt_empty_when_nothing_matches():
    """Empty must stay distinguishable from 'found a section with no share' — callers report
    the two differently (measurement gap vs a fact about the filing)."""
    from dcv.clients import edgar
    assert edgar.concentration_excerpt("no relevant disclosure here at all. " * 40) == ""

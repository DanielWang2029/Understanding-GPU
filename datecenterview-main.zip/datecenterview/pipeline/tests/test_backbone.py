"""Band 2 #1 (L2-backbone) — the backbone-expansion loop and its L6 gate.

The loop turns `chain_topology`'s `unresolved_supplier_names` log (the sensor, built in
Band-1 #2) into a correction: promote the named company into the backbone so the next sweep
resolves it. These tests pin the two things that make that safe — that promotion actually
closes the resolution gap without breaking names that already resolved, and that the reach
report cannot overstate what the source can reach.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import validate_data as V  # noqa: E402
from dcv.chain_topology import _resolve  # noqa: E402
from dcv.compute_seed import build_seed  # noqa: E402

# The exact strings a filing wrote, as logged by the Band-1 #2 sweep. These are the ERROR
# SIGNAL the expansion answers, so they are the regression lock on it.
UNRESOLVED_BEFORE = {
    "ASML": "asml",
    "Tokyo Electron Limited": "tokyoelectron",
    "Lam Research Corporation": "lamresearch",
    "Teradyne, Inc.": "teradyne",
    "Advantest Corporation": "advantest",
    "All Ring Tech Co., Ltd.": "allring",
    "Marketech International Corp.": "marketech",
    "Grand Process Technology Corporation": "grandprocess",
}

# Names that resolved BEFORE the expansion — loop-design: "regression-check the case that
# already worked". Adding aliases is exactly the change that can silently steal a match,
# because `_resolve` picks the LONGEST alias across all entities.
RESOLVED_BEFORE = {
    "Taiwan Semiconductor Manufacturing Company Limited": "tsmc",
    "SK Hynix Inc.": "skhynix",
    "Micron Technology, Inc.": "micron",
    "Hon Hai Precision Industry Co., Ltd.": "foxconn",
    "Advanced Micro Devices, Inc.": "amd",
    "Intel Corporation": "intel",
    "Advanced Semiconductor Engineering, Inc.": "ase",
    "Super Micro Computer, Inc.": "smci",
}


def test_every_previously_unresolved_name_now_resolves():
    assert {n: _resolve(n) for n in UNRESOLVED_BEFORE} == UNRESOLVED_BEFORE


def test_expansion_did_not_steal_a_name_that_already_resolved():
    assert {n: _resolve(n) for n in RESOLVED_BEFORE} == RESOLVED_BEFORE


def test_equipment_tier_is_a_real_layer_with_entities():
    seed = build_seed()
    assert "equipment" in [layer["id"] for layer in seed["layers"]]
    eq = [e for e in seed["chain"]["entities"] if e["layer"] == "equipment"]
    assert {e["id"] for e in eq} == set(UNRESOLVED_BEFORE.values())


def test_chain_entity_ids_are_unique():
    ids = [e["id"] for e in build_seed()["chain"]["entities"]]
    assert len(ids) == len(set(ids))


# --------------------------------------------------------------- L6 validator gate
def _doc(reach, chain_ents, entities=()):
    return {"meta": {"rollups": {"backbone_reach": reach}},
            "chain": {"entities": [{"id": i} for i in chain_ents]},
            "entities": list(entities),
            "datasets": {"data_center": [], "power_project": [], "news": []}}


PASSING = {"entities": 3, "horizon_days": 550,
           "counts": {"current": 1, "stale": 1, "private": 1},
           "by_status": {"current": ["nvidia"], "stale": ["advantest"], "private": ["openai"]}}
CHAIN = ["nvidia", "advantest", "openai"]


def test_validator_passes_an_honest_reach_report():
    assert V.backbone_reach_integrity(_doc(PASSING, CHAIN)) == []


def test_validator_allows_an_absent_or_unavailable_block():
    assert V.backbone_reach_integrity({"meta": {}, "chain": {}, "entities": []}) == []
    assert V.backbone_reach_integrity(_doc({"unavailable": True}, CHAIN)) == []


def test_validator_rejects_a_reach_report_from_a_narrower_backbone():
    """MUST-FAIL: a stale report under-counts the out-of-reach set — the flattering direction."""
    errs = V.backbone_reach_integrity(_doc(PASSING, CHAIN + ["asml"]))
    assert errs and "not live" in errs[0]


def test_validator_rejects_counts_that_do_not_cover_every_entity():
    """MUST-FAIL: every entity needs exactly one status, or the gap hides in the arithmetic."""
    bad = {**PASSING, "counts": {"current": 1, "stale": 1, "private": 1}, "entities": 4}
    errs = V.backbone_reach_integrity(_doc(bad, CHAIN + ["asml"]))
    assert any("every entity must have exactly one status" in e for e in errs)


def test_validator_rejects_by_status_naming_an_unknown_entity():
    bad = {**PASSING, "by_status": {**PASSING["by_status"], "private": ["ghostco"]}}
    errs = V.backbone_reach_integrity(_doc(bad, CHAIN))
    assert any("unknown chain entity 'ghostco'" in e for e in errs)


def test_validator_rejects_a_disclosed_figure_on_an_unreachable_filer():
    """MUST-FAIL, and the rule with teeth: Advantest deregistered in 2015, so no source in this
    pipeline can produce a disclosed figure for it. If one appears, something bypassed the
    freshness guard — the figure has outrun the source that could supply it."""
    ents = [{"id": "advantest", "financials": {
        "revenue": {"value": 1.5e9, "basis": "disclosed", "as_of": "2015-06-25"}}}]
    errs = V.backbone_reach_integrity(_doc(PASSING, CHAIN, ents))
    assert any("out of reach (stale)" in e and "DISCLOSED revenue" in e for e in errs)


def test_validator_allows_a_disclosed_figure_on_a_reachable_filer():
    ents = [{"id": "nvidia", "financials": {
        "revenue": {"value": 2.16e11, "basis": "disclosed", "as_of": "2026-02-25"}}}]
    assert V.backbone_reach_integrity(_doc(PASSING, CHAIN, ents)) == []

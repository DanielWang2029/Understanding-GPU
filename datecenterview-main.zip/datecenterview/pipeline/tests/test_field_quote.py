"""The extraction quote must survive into the store (Band 2 #2).

Phase B has always required a supporting quote for every extracted value — an unquoted number
is dropped as a hallucination — but nothing persisted it, so the evidence died at the store
boundary. That cost real trust: after the 2026-07-20 credit outage, re-verification could
only check our VALUES rather than values-plus-evidence, and a human working the review queue
could see a number but not what the source actually said about it.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dcv.field import field, field_quote, field_value  # noqa: E402
from dcv.phaseb.persist import _field  # noqa: E402


def test_quote_is_stored_and_readable():
    f = field(1200, unit="MW", method="extracted", quote="the 1,200 MW campus in Abilene")
    assert field_quote(f) == "the 1,200 MW campus in Abilene"
    assert field_value(f) == 1200


def test_quote_key_is_omitted_when_absent():
    """A gov_api/ISO field has a feed, not a quote. Padding it with a null would make
    'no quote exists' and 'we lost the quote' indistinguishable."""
    f = field(1200, unit="MW", method="gov_api")
    assert "quote" not in f and field_quote(f) is None


def test_quote_is_trimmed_and_bounded():
    f = field(1, quote="  " + "x" * 900 + "  ")
    assert len(f["quote"]) == 500 and not f["quote"].startswith(" ")


def test_field_quote_tolerates_a_plain_scalar_or_none():
    assert field_quote(None) is None and field_quote(42) is None


def test_persist_carries_the_extractor_quote_onto_the_field():
    """REGRESSION: `_field` built the Field<T> without ever passing the quote through."""
    cand = {
        "capacity_mw": {"value": 500, "quote": "a 500 MW facility", "confidence": 0.8},
        "sources": [{"url": "https://example.com/a"}],
        "overall_confidence": 0.8,
    }
    f = _field(cand, "capacity_mw", unit="MW")
    assert field_quote(f) == "a 500 MW facility"
    assert f["sources"] == ["https://example.com/a"]


def test_persist_field_is_none_when_the_value_is_missing():
    assert _field({"capacity_mw": {"value": None, "quote": "x"}}, "capacity_mw") is None


def test_reverify_reconstructs_the_quote_from_the_store():
    """The point of persisting: re-verification gets values-PLUS-evidence, not values only."""
    from dcv.reverify import _candidate

    class _DC:
        project_name = "Test Campus"
        capacity_mw = field(500, unit="MW", method="extracted", quote="a 500 MW facility")
        status = "operating"
        location = {"county": "Taylor", "state": "TX", "quote": "sited in Taylor County"}
        sources = ["https://example.com/a"]
        overall_confidence = 0.7

    cand = _candidate(_DC())
    assert cand["capacity_mw"]["quote"] == "a 500 MW facility"
    assert cand["location"]["quote"] == "sited in Taylor County"


def test_review_queue_prints_the_quote_under_the_row(monkeypatch, capsys):
    """The quote is what makes a queue row reviewable: "400MW" and "earnings results SUGGEST
    the site COULD host up to 400MW" are the same number carrying very different weight.
    Pinned with a test because no live `needs_review` row carries a quote yet — the quoted
    rows all landed as approved/reported, so the display would otherwise ship unexercised."""
    from dcv import review

    row = {"record_type": "data_center", "id": "dcb-x", "project_name": "Moores Chapel",
           "state": "NC", "capacity_mw": 400.0, "confidence": 0.72, "n_sources": 2,
           "last_verified": "2026-07-20", "disputed": False, "priority": 1.0,
           "quote": "earnings results suggest the site could host up to 400MW"}
    monkeypatch.setattr(review, "queue", lambda **kw: [row])
    monkeypatch.setattr(review, "stats", lambda: {
        "needs_review": {"data_center": 1}, "open_disputes": 0,
        "inbox_pending": 0, "reviewed_total": 0})
    review.print_queue(limit=1)
    out = capsys.readouterr().out
    assert "Moores Chapel" in out
    assert "could host up to 400MW" in out, "the supporting quote must be shown"


def test_review_queue_omits_the_quote_line_when_there_is_none(monkeypatch, capsys):
    from dcv import review

    row = {"record_type": "data_center", "id": "dcb-y", "project_name": "No Quote",
           "state": "TX", "capacity_mw": None, "confidence": None, "n_sources": 1,
           "last_verified": None, "disputed": False, "priority": 0.5, "quote": None}
    monkeypatch.setattr(review, "queue", lambda **kw: [row])
    monkeypatch.setattr(review, "stats", lambda: {
        "needs_review": {"data_center": 1}, "open_disputes": 0,
        "inbox_pending": 0, "reviewed_total": 0})
    review.print_queue(limit=1)
    assert "↳" not in capsys.readouterr().out

"""The MW column: admissible source, right quantity, evidence that reconciles.

Written after the 2026-07-21 audit of `capacity_mw`. The unit was fine everywhere — EIA/ISO
read columns whose names carry the unit, and `parse_capacity_mw` converts GW/kW correctly — but
the values carried four defects nothing measured:

  * 334 of 337 had no quote, so the column could not be checked against its own evidence;
  * 50 came from datacenter.fyi, whose figures are modelled from a constant PUE of 5/3
    (three unrelated operators, PUE 1.666667447910563 / 1.6666666666666665 / 1.663716814159292,
    IT Load == Capacity / 1.6667 on every page) rather than reported;
  * 34 came from seven directory domains in NO tier — an enumeration-only policy cannot catch
    a directory nobody thought of;
  * the column mixed measures: CoreSite Reston stored the page's IT LOAD (426.67 MW), CoreSite
    San Jose its POWER CAPACITY (2.675 MW).

Every check below ships as a must-pass AND a must-fail pair.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import validate_data as V  # noqa: E402
from dcv import capacity_audit as CA  # noqa: E402
from dcv import enrich, source_policy as sp  # noqa: E402
from dcv.field import field, field_measure  # noqa: E402


# ---------------------------------------------------------------- tier 3: modelled figures
def test_the_modelled_directory_is_refused_for_values():
    assert sp.modeled_reason("https://www.datacenter.fyi/public-record/coresite-180d19df")
    assert sp.value_denied_reason("https://datacenter.fyi/x")
    assert sp.classify("https://www.datacenter.fyi/x") == "modeled_tier3"


def test_tier_three_is_a_separate_axis_from_licensing():
    """MUST-PASS: it is not a *licensing* denial — tier 1 stays exactly the three competitors.
    Conflating them would silently expand decision #1, which the owner ruled on."""
    assert sp.denied_reason("https://datacenter.fyi/x") is None
    assert sp.review_reason("https://datacenter.fyi/x") is None


def test_a_permitted_source_is_still_permitted():
    """REGRESSION: the case that already worked. Tier-2 was ruled ALLOWED on 2026-07-20 and
    must not be swept up by the new tiers."""
    for u in ("https://www.datacenters.com/x", "https://baxtel.com/y",
              "https://cloudscene.com/z", "https://www.datacentermap.com/w"):
        assert sp.value_denied_reason(u) is None, u
        assert sp.classify(u) == "tracked_tier2"


# ---------------------------------------------------------------- fail closed on untiered
def test_an_untiered_directory_is_caught():
    """MUST-FAIL: a directory-shaped domain no ruling covers.

    Uses a hypothetical host on purpose. This check originally fired on ocolo.io and gotcolo.com
    — which is how they were found — but the owner ruled all seven into tier 2 on 2026-07-21, so
    pinning real domains here would make the test a record of who was caught rather than of the
    behaviour. The next unruled directory is the one that matters.
    """
    assert sp.unclassified_reason("https://somenewdatacenterdirectory.com/x")
    assert sp.classify("https://www.anothercolocationlist.com/x") == "unclassified_directory"


def test_press_and_first_party_are_not_mistaken_for_directories():
    """MUST-PASS: they match the same shape regex and must be classified out, or the gate
    blocks publish on Google's own site and on the trade press."""
    assert sp.classify("https://www.datacenterdynamics.com/en/news/x") == "press"
    assert sp.classify("https://datacenters.google/locations/texas") == "first_party"
    assert sp.classify("https://datacenters.atmeta.com/us-locations") == "first_party"
    assert sp.unclassified_reason("https://www.datacenterknowledge.com/a") is None


def test_the_shape_tripwire_only_fires_on_real_urls():
    """REGRESSION: unlike tier 1/2, the shape check is a SUBSTRING search, so it first matched
    our own record ids and entity names — 641 phantom 'untiered directories'."""
    for s in ("dcb-abilenedatacentercampus--tx-crusoe", "Anexio Datacenters, LLC",
              "Colocation America", "Cologix"):
        assert sp.unclassified_reason(s) is None, s
    assert sp.unclassified_reason("https://coloradosprings.gov/x") is None


# ---------------------------------------------------------------- quote reconciliation
def test_a_quote_that_yields_the_value_reconciles():
    assert CA.quote_supports("the 90-megawatt facility", 90)
    assert CA.quote_supports("a 1.2 GW campus", 1200)
    assert CA.quote_supports("188 kW of critical load", 0.188)


def test_a_kilowatt_figure_stored_as_megawatts_fails():
    """MUST-FAIL: this is the 1000x error the gate exists for. Digit matching alone would pass
    it — '188 kW' and a stored 188 share every digit."""
    assert not CA.quote_supports("188 kW of critical load", 188)


def test_a_bare_number_does_not_reconcile():
    """MUST-FAIL: a unitless quote is exactly the ambiguity that produced this audit."""
    assert not CA.quote_supports("rated at 90 for the site", 90)
    assert not CA.quote_supports("", 90)


def test_a_quote_about_a_different_number_fails():
    assert not CA.quote_supports("the 711 MW power capacity", 426.67)


# ---------------------------------------------------------------- measure (unit of analysis)
def test_the_field_records_what_it_measures():
    f = field(2.675, unit="MW", measure="facility_power_capacity")
    assert field_measure(f) == "facility_power_capacity"


def test_an_unrecorded_measure_is_not_read_as_capacity():
    """MUST-FAIL-SAFE: a legacy field says nothing about what it measures. `None` must mean
    'nobody wrote it down', never 'it is capacity'."""
    assert field_measure(field(2.675, unit="MW")) is None
    assert "measure" not in field(2.675, unit="MW")


def test_the_extractor_wants_facility_capacity():
    assert enrich.WANTED_MEASURE == "facility_power_capacity"
    for m in ("facility_it_load", "campus_total", "utility_service", "unclear"):
        assert m in enrich.MEASURES and m != enrich.WANTED_MEASURE


def test_the_extractor_prompt_names_kilowatts():
    """REGRESSION: the prompt said 'MW or GW (convert GW->MW)' and never mentioned kW, so a
    kW page had no defined handling at all."""
    assert "kW" in enrich.SYS and "kW/1000" in enrich.SYS
    assert "facility_it_load" in enrich.SYS and "unit_seen" in enrich.SYS


# ---------------------------------------------------------------- publish gate 10
def _doc(sources, **roll):
    d = {"meta": {"rollups": {}},
         "datasets": {"data_center": [{"id": "a", "capacity_mw": 10, "sources": sources}],
                      "power_project": [], "news": []}}
    if roll:
        d["meta"]["rollups"]["capacity_provenance"] = roll
    return d


def test_gate_passes_a_clean_capacity_value():
    """MUST-PASS."""
    assert V.capacity_provenance_integrity(_doc(["https://www.sec.gov/x"])) == []


def test_gate_blocks_a_value_from_a_modelled_source():
    """MUST-FAIL: the 50 datacenter.fyi values that were published unchallenged."""
    errs = V.capacity_provenance_integrity(_doc(["https://www.datacenter.fyi/x"]))
    assert errs and "datacenter.fyi" in errs[0] and "modelled" in errs[0]


def test_an_untiered_citation_warns_but_does_not_block():
    """A record may CITE an unruled directory while the owner decides — `sources` is
    denormalised, so the number may have come from a filing on the same row. Blocking here
    would hold the whole pipeline hostage to a pending ruling."""
    doc = _doc(["https://somenewdatacenterdirectory.com/x"])
    assert V.capacity_provenance_integrity(doc) == []
    warns = V.untiered_directory_exposure(doc)
    assert any("somenewdatacenterdirectory.com" in w for w in warns)


def test_gate_blocks_an_untiered_directory_as_a_capacity_SOURCE():
    """MUST-FAIL: fail-closed where it counts — the unruled directory being the evidence for
    a published number. `by_source_class` counts the Field's own sources, not the record's."""
    errs = V.capacity_provenance_integrity(
        _doc(["https://www.sec.gov/x"], values=1, quote_unreconciled=0,
             by_source_class={"unclassified_directory": 34}))
    assert any("'unclassified_directory'" in e for e in errs)


def test_gate_blocks_a_rollup_that_miscounts_itself():
    """MUST-FAIL: a published sensor that can disagree with the enforced check is two numbers."""
    errs = V.capacity_provenance_integrity(
        _doc(["https://www.sec.gov/x"], values=99, quote_unreconciled=0, by_source_class={}))
    assert any("capacity_provenance.values=99" in e for e in errs)


def test_gate_blocks_unreconciled_quotes_reported_by_the_rollup():
    """MUST-FAIL: store-side evidence failures must still stop the publish."""
    errs = V.capacity_provenance_integrity(
        _doc(["https://www.sec.gov/x"], values=1, quote_unreconciled=3, by_source_class={}))
    assert any("do not reconcile with their own quote" in e for e in errs)


def test_gate_blocks_an_inadmissible_class_reported_by_the_rollup():
    """MUST-FAIL: even if the URL itself is not visible on the record."""
    errs = V.capacity_provenance_integrity(
        _doc(["https://www.sec.gov/x"], values=1, quote_unreconciled=0,
             by_source_class={"modeled_tier3": 7}))
    assert any("'modeled_tier3'" in e for e in errs)


def test_gate_is_silent_without_a_rollup():
    """An older data.json has no capacity_provenance block; absence is not a failure."""
    assert V.capacity_provenance_integrity(_doc(["https://www.sec.gov/x"])) == []


# ---------------------------------------------------------------- structural (schema) force
ROOT = Path(__file__).resolve().parents[2]          # repo root — data.json lives here
PIPE = Path(__file__).resolve().parents[1]           # pipeline/ — the schema lives here


def _live():
    import json
    return (json.loads((ROOT / "data.json").read_text()),
            json.loads((PIPE / "data.schema.json").read_text()))


def _schema_doc(**roll):
    base, schema = _live()
    base["meta"]["rollups"]["capacity_provenance"] = roll
    return base, schema


def test_schema_forces_unreconciled_quotes_to_zero():
    """MUST-FAIL structurally, not only via the gate. `loop-design`: a green validator with a
    hole grants false assurance — an unreconciled quote must be unpublishable even if someone
    edits gate 10 out."""
    d, schema = _schema_doc(values=1, quoted=1, unquoted=0, quote_reconciles=0,
                            quote_unreconciled=2, by_measure={}, by_source_class={})
    assert V.structural(d, schema), "schema accepted quote_unreconciled=2"


def test_schema_forbids_a_modelled_source_class():
    d, schema = _schema_doc(values=1, quoted=0, unquoted=1, quote_reconciles=0,
                            quote_unreconciled=0, by_measure={},
                            by_source_class={"modeled_tier3": 4})
    assert V.structural(d, schema), "schema accepted a modeled_tier3 capacity source"


def test_schema_accepts_the_real_emitted_rollup():
    """REGRESSION / MUST-PASS: the live file must still validate."""
    d, schema = _live()
    assert V.structural(d, schema) == []


# ---------------------------------------------------------------- the 2026-07-21 tier-2 ruling
RULED_2026_07_21 = ("ocolo.io", "gotcolo.com", "datacentercatalog.com", "usdatamap.com",
                    "cloudandcolocation.com", "colocationm.com", "colomap.com")


def test_the_seven_ruled_directories_are_tier_two():
    """The owner ruled all seven into tier 2 on 2026-07-21, same class as baxtel/datacenters.com:
    free to browse, operator-submitted, no paywall. Pinned so the ruling is code, not memory."""
    for d in RULED_2026_07_21:
        u = f"https://www.{d}/x"
        assert sp.classify(u) == "tracked_tier2", d
        assert sp.value_denied_reason(u) is None, d
        assert sp.unclassified_reason(u) is None, d


def test_the_ruling_did_not_sweep_in_the_modelled_sources():
    """MUST-FAIL-SAFE: tier 3 is a different objection. datacenter.fyi publishes figures DERIVED
    from a constant PUE; being a free directory does not make a model's output a measurement."""
    assert sp.classify("https://www.datacenter.fyi/x") == "modeled_tier3"
    assert sp.value_denied_reason("https://datacenterindex.ai/x")


def test_a_still_unruled_directory_is_caught():
    """REGRESSION: closing the seven must not disarm the fail-closed check for the eighth."""
    assert sp.unclassified_reason("https://newdatacenterdirectory.com/x")
    assert sp.unclassified_reason("https://www.example.com/x") is None  # not directory-shaped


def test_restore_refuses_a_value_the_current_policy_still_denies(tmp_path, monkeypatch):
    """MUST-FAIL: the undo must re-apply the DECISION, not just put the bytes back.

    The backup accumulates every withdrawal, so after the tier-2 ruling it held 84 entries — 34
    newly admissible, and 50 modelled-figure values that `purge-denied-sources` had separately
    removed. A blind restore would have re-published all 84 and silently undone the purge.
    """
    import json
    bak = tmp_path / "capacity_withdrawn.json"
    bak.write_text(json.dumps({
        "ok-row": {"value": 12.0, "unit": "MW", "sources": ["https://ocolo.io/x"]},
        "bad-row": {"value": 426.67, "unit": "MW", "sources": ["https://www.datacenter.fyi/x"]},
    }))
    monkeypatch.setattr(CA, "_backup_path", lambda: bak)

    seen = {}

    class _Row:
        capacity_mw = None

    class _S:
        def get(self, _model, rid):
            return seen.setdefault(rid, _Row())

    import contextlib

    @contextlib.contextmanager
    def _scope():
        yield _S()

    monkeypatch.setattr(CA, "session_scope", _scope)
    restored, refused = CA.restore()
    assert (restored, refused) == (1, 1)
    assert seen["ok-row"].capacity_mw is not None
    assert "bad-row" not in seen or seen["bad-row"].capacity_mw is None

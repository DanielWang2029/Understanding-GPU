"""Phase B pure-logic tests: extraction validator + DC normalization."""
from dcv.phaseb.normalize_dc import (
    canonical_developer,
    identity_key,
    normalize_state,
    parse_capacity_mw,
    parse_money,
    resolve_status,
    status_from_press,
)
from dcv.phaseb.validate_extract import sanitize_and_validate


def _valued(v, q="quote"):
    return {"value": v, "quote": q}


def _project(**over):
    p = {
        "project_name": "Stargate I",
        "aka": ["Lancium Abilene"],
        "developer": _valued("Crusoe Energy", "developed by Crusoe"),
        "operator": _valued(None, None),
        "tenant": _valued("Oracle", "leased to Oracle"),
        "end_user": _valued("OpenAI", "serving OpenAI"),
        "status": _valued("under_construction", "broke ground in June"),
        "capacity_mw": _valued(1200, "up to 1.2 GW"),
        "capacity_mwh": _valued(None, None),
        "building_sqft": _valued(None, None),
        "land_acres": _valued(1150, "1,150 acres"),
        "cap_ex_usd": _valued(11600000000, "$11.6 billion"),
        "operating_year": _valued(None, None),
        "btm_generation": _valued(True, "on-site natural gas"),
        "announced_date": _valued(None, None),
        "power_sources": ["natural gas"],
        "location": {"county": "Taylor", "state": "TX", "country": "US",
                     "address": None, "quote": "near Abilene, Texas"},
    }
    p.update(over)
    return p


# --- validator ---------------------------------------------------------------
def test_valid_project_passes_with_full_consistency():
    cand, issues, sc = sanitize_and_validate(_project())
    assert cand is not None
    assert issues == []
    assert sc == 1.0  # capacity + status + state + a party all present


def test_unquoted_number_is_dropped():
    cand, issues, _ = sanitize_and_validate(_project(capacity_mw=_valued(800, None)))
    assert cand["capacity_mw"]["value"] is None
    assert any("capacity_mw" in i for i in issues)


def test_missing_name_rejected():
    cand, issues, sc = sanitize_and_validate(_project(project_name="  "))
    assert cand is None and sc == 0.0


def test_missing_location_rejected():
    loc = {"county": None, "state": None, "country": "US", "address": None, "quote": None}
    cand, _, _ = sanitize_and_validate(_project(location=loc))
    assert cand is None


def test_out_of_enum_status_dropped():
    cand, issues, _ = sanitize_and_validate(_project(status=_valued("mothballed", "q")))
    assert cand["status"]["value"] is None
    assert any("status" in i for i in issues)


def test_unquoted_status_dropped():
    cand, issues, _ = sanitize_and_validate(_project(status=_valued("operating", None)))
    assert cand["status"]["value"] is None


# --- normalization -----------------------------------------------------------
def test_developer_aliases_collapse():
    assert canonical_developer("AWS")[:2] == ("Amazon Web Services", "aws")
    assert canonical_developer("Amazon Web Services, Inc.")[1] == "aws"
    assert canonical_developer("Microsoft Azure")[0] == "Microsoft"
    # unknown passes through, no entity id
    assert canonical_developer("Acme DC LLC") == ("Acme DC LLC", None, None)


def test_developer_category():
    assert canonical_developer("CoreWeave")[2] == "neocloud"
    assert canonical_developer("Equinix")[2] == "retail_colo"


def test_status_from_press_and_resolve():
    assert status_from_press("the campus broke ground last week") == "under_construction"
    assert status_from_press("now fully operational") == "operating"
    assert status_from_press("plans to build") == "proposed"
    # resolve prefers a valid enum value, else infers from the quote
    assert resolve_status({"value": "operating", "quote": ""}) == "operating"
    assert resolve_status({"value": "nonsense", "quote": "broke ground"}) == "under_construction"
    assert resolve_status({"value": None, "quote": None}) is None


def test_identity_key_is_alias_stable():
    a = identity_key("Stargate I", "Taylor", "TX", "Crusoe Energy")
    b = identity_key("stargate i!", "taylor", "tx", "Crusoe")
    assert a == b == "stargatei|taylor|TX|crusoe"


def test_unit_parsers():
    assert parse_money("$11.6 billion") == 11600000000.0
    assert parse_money("$450M") == 450000000.0
    assert parse_capacity_mw("1.2 GW") == 1200.0
    assert parse_capacity_mw("850 MW") == 850.0
    assert parse_capacity_mw(500) == 500.0


def test_normalize_state():
    assert normalize_state("Texas") == "TX"
    assert normalize_state("tx") == "TX"
    assert normalize_state("Nowhere") is None


# --- verify: scoring + gate --------------------------------------------------
from dcv.phaseb.verify import _gate, _score_field  # noqa: E402


def test_score_field_rewards_independent_corroboration():
    dom = {"dcd.com"}
    # A liveness checker is injected so this stays a pure scoring test. Independence alone
    # stopped being enough on 2026-07-30 — the cited page must also exist; see
    # tests/test_source_liveness.py for that half.
    live = lambda u: "live"  # noqa: E731
    # agree + a different-domain source that resolves = confirmed-grade
    conf, src, state = _score_field(
        {"verdict": "agree", "source_url": "https://reuters.com/x"}, dom, live)
    assert conf == 0.93 and src == "https://reuters.com/x" and state == "live"
    # agree but only the same source = medium, no new source
    conf, src, state = _score_field(
        {"verdict": "agree", "source_url": "https://www.dcd.com/y"}, dom, live)
    assert conf == 0.72 and src is None
    assert _score_field({"verdict": "unverifiable"}, dom, live)[0] == 0.45
    assert _score_field({"verdict": "disagree"}, dom, live)[0] == 0.20


def test_gate_requires_two_sources_to_auto_approve():
    assert _gate(0.95, 2) == "approved"
    assert _gate(0.95, 1) == "needs_review"   # high confidence but single source
    assert _gate(0.70, 3) == "needs_review"
    assert _gate(0.50, 3) == "reported"


# --- persist: identity-key merge ---------------------------------------------
from dcv.phaseb.persist import merge_candidates  # noqa: E402


def _cand(ikey, url, conf, cap=100):
    null = {"value": None}
    return {
        "identity_key": ikey, "aka": [], "project_name": "X",
        "developer": {"value": "AWS", "confidence": conf},
        "developer_canonical": "Amazon Web Services", "developer_category": "hyperscaler",
        "operator": null, "tenant": null, "end_user": null,
        "status": {"value": "operating", "confidence": conf}, "status_lifecycle": "operating",
        "capacity_mw": {"value": cap, "confidence": conf},
        "capacity_mwh": null, "building_sqft": null, "land_acres": null,
        "cap_ex_usd": null, "operating_year": null, "btm_generation": null, "announced_date": null,
        "power_sources": [],
        "location": {"county": "Loudoun", "state": "VA", "country": "US",
                     "address": None, "geo_precision": "county"},
        "sources": [{"url": url, "publisher": None}],
        "overall_confidence": conf, "review_status": "needs_review",
    }


def test_merge_two_sources_can_reach_approved():
    a = _cand("k", "https://dcd.com/a", 0.72)
    b = _cand("k", "https://reuters.com/b", 0.93)
    merged = merge_candidates([a, b])
    assert len(merged) == 1
    m = merged[0]
    assert len(m["sources"]) == 2                 # union across articles
    assert m["overall_confidence"] == 0.93        # max
    assert m["review_status"] == "approved"       # 2 distinct domains + high conf


def test_merge_leaves_distinct_projects_alone():
    a = _cand("k1", "https://dcd.com/a", 0.7)
    b = _cand("k2", "https://dcd.com/b", 0.8)
    assert len(merge_candidates([a, b])) == 2

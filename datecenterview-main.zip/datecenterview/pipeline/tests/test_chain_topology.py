"""chain_topology discovery tests (Band-1 #2). EDGAR + the cross-vendor pair are mocked; these
lock the gate: an edge is emitted only when the extraction reaches consensus AND a different
vendor confirms the company is named as a SUPPLIER, and only when the name resolves locally to
a backbone entity — unresolved names are reported, never silently dropped.
"""
import dcv.chain_topology as ct

BUYER = {"id": "nvidia", "name": "Nvidia", "ticker": "NVDA", "cik": "1045810"}

_EXCERPT = ("We utilize foundries, such as Taiwan Semiconductor Manufacturing Company Limited, "
            "or TSMC, and Samsung Electronics Co., Ltd. We purchase memory from SK Hynix Inc., "
            "Micron Technology, Inc., and Samsung. We engage contract manufacturers such as "
            "Hon Hai Precision Industry Co., Ltd. and Fabrinet.")


def _sup(name, supplies="wafers"):
    return {"name": name, "supplies": supplies, "verbatim": f"… {name} …"}


def _patch(monkeypatch, extracted, confirmed):
    monkeypatch.setattr(ct.edgar, "submissions", lambda cik: {"filings": {"recent": {}}})
    monkeypatch.setattr(ct.edgar, "latest_report",
                        lambda subs: {"form": "10-K", "accession": "0001-26-000021",
                                      "doc": "nvda.htm", "filed": "2026-02-25"})
    monkeypatch.setattr(ct.edgar, "filing_text", lambda *a: _EXCERPT)
    monkeypatch.setattr(ct.edgar, "supplier_excerpt", lambda *a, **k: _EXCERPT)
    monkeypatch.setattr(ct.grok, "chat", lambda *a, **k: ({"suppliers": extracted}, []))
    monkeypatch.setattr(ct.claude, "verify_json",
                        lambda *a, **k: {"confirmed": confirmed, "refuted": [], "reason": "ok"})


# ---- local name resolution (never an LLM's id guess) ----
def test_resolve_maps_filing_legal_names():
    assert ct._resolve("Taiwan Semiconductor Manufacturing Company Limited") == "tsmc"
    assert ct._resolve("Hon Hai Precision Industry Co., Ltd.") == "foxconn"
    assert ct._resolve("SK Hynix Inc.") == "skhynix"


def test_resolve_word_boundary_avoids_false_match():
    # "Intel" must not match inside "Intelligent"
    assert ct._resolve("Intelligent Systems Corp") is None


def test_resolve_unknown_company_is_none():
    assert ct._resolve("Fabrinet") is None and ct._resolve("Wistron Corporation") is None


# ---- discovery gate ----
def test_discover_emits_named_supplier_edges(monkeypatch):
    names = ["Taiwan Semiconductor Manufacturing Company Limited", "SK Hynix Inc."]
    _patch(monkeypatch, [_sup(n) for n in names], names)
    edges, unresolved = ct.discover(BUYER, rounds=3, min_votes=2)
    got = {(e["from"], e["to"]) for e in edges}
    assert got == {("tsmc", "nvidia"), ("skhynix", "nvidia")}
    e = edges[0]
    assert e["relation"] == "supplies" and e["link_basis"] == "named"
    assert e["link_sources"][0]["type"] == "buyer_filing" and e["link_sources"][0]["url"]
    assert e["verify"]["extractor"] != e["verify"]["verifier"]      # cross-vendor recorded
    assert "pct_revenue" not in e and "pct_cogs" not in e           # topology carries NO magnitude
    assert unresolved == []


def test_discover_joins_verifier_on_resolved_id_not_raw_string(monkeypatch):
    """Regression: the extractor and the verifier return different surface forms of the same
    company. Joining on the raw string silently dropped EVERY edge; the join must be on the
    resolved backbone id."""
    _patch(monkeypatch,
           [_sup("Taiwan Semiconductor Manufacturing Company Limited"), _sup("SK Hynix Inc.")],
           ["TSMC", "SK hynix"])          # verifier's shorter forms
    edges, _ = ct.discover(BUYER, rounds=3, min_votes=2)
    assert {e["from"] for e in edges} == {"tsmc", "skhynix"}


def test_discover_reports_unresolved_names(monkeypatch):
    names = ["Fabrinet", "Wistron Corporation"]
    _patch(monkeypatch, [_sup(n) for n in names], names)
    edges, unresolved = ct.discover(BUYER, rounds=3, min_votes=2)
    assert edges == []                                    # not backbone entities → no edge
    assert sorted(unresolved) == ["Fabrinet", "Wistron Corporation"]   # but REPORTED


def test_discover_drops_unconfirmed_by_verifier(monkeypatch):
    # extraction proposes two, the different-vendor verifier confirms only one
    names = ["Taiwan Semiconductor Manufacturing Company Limited", "Micron Technology, Inc."]
    _patch(monkeypatch, [_sup(n) for n in names], ["Taiwan Semiconductor Manufacturing Company Limited"])
    edges, _ = ct.discover(BUYER, rounds=3, min_votes=2)
    assert {e["from"] for e in edges} == {"tsmc"}


def test_discover_drops_below_min_votes(monkeypatch):
    # proposed in only 1 of 3 rounds → below consensus → never verified/emitted
    seq = iter([{"suppliers": [_sup("Micron Technology, Inc.")]}, {"suppliers": []}, {"suppliers": []}])
    monkeypatch.setattr(ct.edgar, "submissions", lambda cik: {"filings": {"recent": {}}})
    monkeypatch.setattr(ct.edgar, "latest_report",
                        lambda subs: {"form": "10-K", "accession": "a", "doc": "d", "filed": "2026-02-25"})
    monkeypatch.setattr(ct.edgar, "filing_text", lambda *a: _EXCERPT)
    monkeypatch.setattr(ct.edgar, "supplier_excerpt", lambda *a, **k: _EXCERPT)
    monkeypatch.setattr(ct.grok, "chat", lambda *a, **k: (next(seq), []))
    monkeypatch.setattr(ct.claude, "verify_json", lambda *a, **k: {"confirmed": ["Micron Technology, Inc."]})
    edges, _ = ct.discover(BUYER, rounds=3, min_votes=2)
    assert edges == []


def test_discover_drops_self_edge(monkeypatch):
    _patch(monkeypatch, [_sup("NVIDIA Corporation")], ["NVIDIA Corporation"])
    edges, _ = ct.discover(BUYER, rounds=3, min_votes=2)
    assert edges == []  # a filer naming itself is never an edge


def test_discover_empty_when_no_supplier_section(monkeypatch):
    _patch(monkeypatch, [_sup("TSMC")], ["TSMC"])
    monkeypatch.setattr(ct.edgar, "supplier_excerpt", lambda *a, **k: "")
    assert ct.discover(BUYER, rounds=3, min_votes=2) == ([], [])


# ---- emit merge: discovered topology lands on the chain graph ----
def _chain():
    return {"entities": [{"id": "tsmc"}, {"id": "nvidia"}, {"id": "samsung"}, {"id": "micron"}],
            "edges": [
                # an existing SEED edge the filings confirm → must be upgraded, not duplicated
                {"from": "tsmc", "to": "nvidia", "relation": "supplies",
                 "value": {"pct_revenue": 17, "rev_basis": "disclosed", "disclosed": True,
                           "as_of": "2026-04-16", "sources": ["https://sec.gov/x"]}},
                # a seed edge no filing names → stays seed
                {"from": "micron", "to": "nvidia", "relation": "supplies",
                 "value": {"pct_revenue": 5, "rev_basis": "estimated", "disclosed": False}},
            ]}


def _write_topo(monkeypatch, tmp_path, edges):
    import json
    import dcv.emit as em
    p = tmp_path / "topo.json"
    p.write_text(json.dumps({"edges": edges}))
    monkeypatch.setattr(em, "_CHAIN_TOPOLOGY", p)
    return em


_LS = [{"type": "buyer_filing", "url": "https://sec.gov/nvda", "as_of": "2026-02-25"}]


def test_merge_upgrades_seed_edge_without_duplicating(monkeypatch, tmp_path):
    em = _write_topo(monkeypatch, tmp_path, [
        {"from": "tsmc", "to": "nvidia", "relation": "supplies", "link_basis": "named",
         "link_sources": _LS, "link_confidence": 1.0, "note": "named in NVDA 10-K"}])
    ch = _chain()
    em._merge_topology(ch)
    assert len(ch["edges"]) == 2                      # upgraded in place, NOT duplicated
    v = ch["edges"][0]["value"]
    assert v["topology_basis"] == "named" and v["link_basis"] == "named"
    assert v["link_sources"] == _LS
    assert v["pct_revenue"] == 17 and v["rev_basis"] == "disclosed"   # magnitude preserved


def test_merge_appends_new_relationship_without_magnitude(monkeypatch, tmp_path):
    em = _write_topo(monkeypatch, tmp_path, [
        {"from": "samsung", "to": "nvidia", "relation": "supplies", "link_basis": "named",
         "link_sources": _LS, "note": "memory"}])
    ch = _chain()
    em._merge_topology(ch)
    new = [e for e in ch["edges"] if (e["from"], e["to"]) == ("samsung", "nvidia")]
    assert len(new) == 1
    v = new[0]["value"]
    assert v["topology_basis"] == "named" and v["disclosed"] is False
    # a discovered edge must NOT invent a magnitude (a fake 0 would render as "0%")
    assert "pct_revenue" not in v and "pct_cogs" not in v


def test_merge_marks_unevidenced_edges_as_seed(monkeypatch, tmp_path):
    em = _write_topo(monkeypatch, tmp_path, [])
    ch = _chain()
    em._merge_topology(ch)
    assert all(e["value"]["topology_basis"] == "seed" for e in ch["edges"])


def test_merge_drops_edge_to_unknown_entity(monkeypatch, tmp_path):
    em = _write_topo(monkeypatch, tmp_path, [
        {"from": "fabrinet", "to": "nvidia", "relation": "supplies", "link_basis": "named",
         "link_sources": _LS}])
    ch = _chain()
    em._merge_topology(ch)
    assert not any(e["from"] == "fabrinet" for e in ch["edges"])  # referential integrity


def test_run_writes_fixture_with_unresolved_log(monkeypatch, tmp_path):
    import json
    out = tmp_path / "topology.json"
    monkeypatch.setattr(ct, "FIXTURE", out)
    monkeypatch.setattr(ct, "discover", lambda b, **k: (
        [{"from": "tsmc", "to": b["id"], "relation": "supplies", "link_basis": "named"}],
        ["Fabrinet"]))
    stats = ct.run([BUYER], budget_usd=1e9, rounds=3)
    assert stats["edges"] == 1 and stats["unresolved_names"] == 1
    data = json.loads(out.read_text())
    assert data["edges"][0]["from"] == "tsmc"
    assert "Fabrinet" in data["_meta"]["unresolved_supplier_names"]   # no silent cap
    assert data["_meta"]["extractor"] != data["_meta"]["verifier"]

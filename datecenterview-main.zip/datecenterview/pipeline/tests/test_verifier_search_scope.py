"""Which verifier calls may reach outside the filing — and which must not.

Five `claude.verify_json` call sites hand the model a filing excerpt. It is tempting to read
that as "closed-book, turn search off everywhere" — and that is wrong, which is the whole point
of this file. THREE of the five prompts say "You MAY web-search", deliberately.

The split is not about whether an excerpt is present. It is the project's own standing finding:

    a filing discloses a MAGNITUDE and withholds the IDENTITY.

So "is it 19%?" is answerable from the excerpt and must stay closed-book — a web-confirmed
percentage would be an estimate wearing a `disclosed` label, and refusing to emit that is
exactly why chain_quant drops unconfirmed magnitudes. But "19% of WHICH customer?" is
structurally unanswerable from the excerpt, which is why chain_identity exists at all; take its
search away and it can only ever return "uncertain".

Both halves are pinned here. The must-fail cases (search STAYS ON) matter more than the
must-pass ones: turning search off there is a silent capability regression that would look like
a model quality problem.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dcv import chain_identity, chain_quant, chain_topology  # noqa: E402

_RPT = {"accession": "0001-23-456", "doc": "x.htm", "form": "10-K", "filed": "2026-02-01"}


def _stub_edgar(monkeypatch, mod, excerpt_attr):
    """Replace the filing-fetch layer so these tests exercise the CALL SHAPE, not SEC.gov."""
    monkeypatch.setattr(mod.edgar, "submissions", lambda cik: {})
    monkeypatch.setattr(mod.edgar, "latest_report", lambda subs: dict(_RPT))
    monkeypatch.setattr(mod.edgar, "filing_text", lambda *a, **k: "…filing…")
    monkeypatch.setattr(mod.edgar, excerpt_attr, lambda txt: "one customer accounted for 19%")


class _Spy:
    """Capture how verify_json was called, and answer with a shaped verdict."""

    def __init__(self, reply):
        self.calls = []
        self.reply = reply

    def __call__(self, system, user, **kw):
        self.calls.append({"system": system, "user": user, **kw})
        return dict(self.reply)

    @property
    def search_flags(self):
        # absent kwarg means the client default, which is True
        return [c.get("allow_web_search", True) for c in self.calls]


# ------------------------------------------------------- the prompts are self-describing
def test_the_prompt_declares_its_own_search_intent():
    """The invariant the call sites must match. A prompt that invites search has to be called
    with it enabled; one that never mentions it is excerpt-bound."""
    grants = "web-search"
    assert grants in chain_quant._VERIFY_SYS            # infers an UNNAMED counterparty
    assert grants in chain_identity._VERIFY_SYS         # names the relationship from outside
    assert grants not in chain_quant._TARGETED_VERIFY_SYS   # counterparty already named
    assert grants not in chain_topology._VERIFY_SYS         # "read the excerpt and decide"


# ------------------------------------------------------------ must-pass: search is OFF
def test_topology_confirmation_is_closed_book(monkeypatch):
    """The edge claims 'the buyer's OWN filing names this supplier'. Confirming that from
    trade press keeps the label and destroys what it means."""
    spy = _Spy({"confirmed": ["TSMC"], "refuted": []})
    _stub_edgar(monkeypatch, chain_topology, "supplier_excerpt")
    monkeypatch.setattr(chain_topology.claude, "verify_json", spy)
    monkeypatch.setattr(chain_topology.grok, "chat",
                        lambda *a, **k: ({"suppliers": [{"name": "TSMC", "supplies": "wafers"}]}, []))
    chain_topology.discover({"id": "nvidia", "name": "NVIDIA", "cik": "1045810"},
                            rounds=2, min_votes=1)
    assert spy.calls, "verifier was never called"
    assert spy.search_flags == [False] * len(spy.calls)


def test_targeted_quantification_is_closed_book(monkeypatch):
    """The counterparty is already NAMED on this path, so only the magnitude is in question —
    and the magnitude must come from the filing or not at all."""
    spy = _Spy({"pct_confirmed": True, "attributed": "agree", "confidence": 0.9})
    _stub_edgar(monkeypatch, chain_quant, "concentration_excerpt")
    monkeypatch.setattr(chain_quant.claude, "verify_json", spy)
    monkeypatch.setattr(chain_quant.grok, "chat",
                        lambda *a, **k: ({"pct": 19.0, "verbatim": "one customer 19%"}, []))
    chain_quant.quantify_named({"id": "sk-hynix", "name": "SK Hynix", "cik": "1"},
                               "nvidia", "NVIDIA", rounds=2, min_votes=1)
    assert spy.calls, "verifier was never called"
    assert spy.search_flags == [False] * len(spy.calls)


# ----------------------------------------------------- must-fail: search STAYS ON
def test_open_ended_quantification_keeps_its_search(monkeypatch):
    """`_VERIFY_SYS` must infer WHO an unnamed customer is. The excerpt cannot say. Silencing
    search here would not make it stricter — it would make it blind."""
    spy = _Spy({"pct_confirmed": True, "link_verdict": "agree", "confidence": 0.9})
    _stub_edgar(monkeypatch, chain_quant, "concentration_excerpt")
    monkeypatch.setattr(chain_quant.claude, "verify_json", spy)
    monkeypatch.setattr(chain_quant.grok, "chat", lambda *a, **k: (
        {"customers": [{"inferred_customer_id": "nvidia", "pct": 19.0,
                        "verbatim": "one customer 19%", "inference_reason": "scale"}]}, []))
    chain_quant.quantify({"id": "sk-hynix", "name": "SK Hynix", "cik": "1"},
                         {"nvidia": "NVIDIA"})
    assert spy.calls, "verifier was never called"
    assert all(spy.search_flags), "the unnamed-counterparty verifier lost its web search"


def test_identity_resolution_keeps_its_search():
    """chain_identity's entire job is flipping an INFERRED counterparty to NAMED using sources
    outside the filing. Its prompt says so; the call must honour it."""
    import inspect
    src = inspect.getsource(chain_identity)
    call = src[src.index("_VERIFY_SYS, vuser"):]
    assert "allow_web_search=False" not in call[:120], \
        "chain_identity's verifier must keep web search — the filing withholds the identity"


# --------------------------------------------------------------- the DC verifier is untouched
def test_the_data_center_verifier_still_searches():
    """phaseb.verify is the one call whose entire job is finding an INDEPENDENT second source.
    Measured: without search, corroboration falls to 0.08 and 8 of 10 cited URLs are 404s."""
    import inspect

    from dcv.phaseb import verify as V
    src = inspect.getsource(V.verify)
    assert "allow_web_search" not in src, "phaseb.verify must keep the client default (search on)"
    assert "INDEPENDENT" in V.VERIFY_SYSTEM


# ------------------------------------- the verifier's OWN findings take the source policy
def test_verify_refuses_a_denied_corroborating_source(monkeypatch):
    """The 2026-07-31 sweep's defect. `verify` runs Claude WITH web search, so it surfaces
    curated competitors and modelled-figure directories like any other search — and whatever
    it appends becomes value-provenance on a sized row. reverify.py was fixed for this on
    2026-07-21; phaseb.verify was not, so a dgtlinfra.com URL (tier 1) landed on a published
    capacity and gate 10 blocked publish.

    Filter with the publish gate's own test — value_denied_reason (tier-1 AND tier-3 modelled),
    not denied_reason (tier-1 only)."""
    from dcv.phaseb import verify as V

    cand = {"project_name": "P", "capacity_mw": {"value": 100, "quote": "100 MW"},
            "status": {"value": "operating", "quote": None},
            "location": {"county": "Collin", "state": "TX", "address": None, "quote": None},
            "sources": [{"url": "https://usdatamap.com/x"}], "self_consistency": 0.5}
    monkeypatch.setattr(V, "_liveness", lambda u: "live")
    monkeypatch.setattr(V.claude, "verify_json", lambda *a, **k: {
        "capacity_mw": {"verdict": "agree", "source_url": "https://dgtlinfra.com/coreweave"},
        "status": {"verdict": "agree", "source_url": "https://datacenter.fyi/f/1"},
        "location": {"verdict": "agree", "source_url": "https://www.datacenterdynamics.com/n/1"},
    })
    out = V.verify(dict(cand))
    urls = [s["url"] if isinstance(s, dict) else s for s in out["sources"]]
    assert not any("dgtlinfra.com" in u for u in urls), "tier-1 competitor persisted as provenance"
    assert not any("datacenter.fyi" in u for u in urls), "tier-3 modelled-figure source persisted"
    assert any("datacenterdynamics.com" in u for u in urls), "the admissible source was dropped too"
    assert out["sources_refused"] == 2


# --------------------------------------------- `exact` needs a coordinate, on EVERY path
def test_persist_will_not_claim_exact_without_a_coordinate():
    """Same defect class as the enumerate_dc `... or "exact"` default, on a different ingest
    path. extract._geo_precision returns "exact" whenever the extraction carried an ADDRESS
    STRING; geocoding can fail and persist does not store the address, so the row asserts a
    precise location holding nothing precise. 5 rows on the 2026-07-31 sweep; gate 12 blocked."""
    from dcv.phaseb.persist import _honest_precision

    # no coordinate -> degrade to what the row actually holds
    assert _honest_precision({"geo_precision": "exact", "county": "Reeves", "state": "TX"}, None) == "county"
    assert _honest_precision({"geo_precision": "exact", "state": "TX"}, None) == "state"
    assert _honest_precision({"geo_precision": "exact"}, None) is None
    # must-fail half: a real coordinate keeps `exact`, and coarser labels are untouched
    assert _honest_precision({"geo_precision": "exact", "county": "Reeves"}, 31.4) == "exact"
    assert _honest_precision({"geo_precision": "county", "county": "Reeves"}, None) == "county"
    assert _honest_precision({"geo_precision": None}, None) is None

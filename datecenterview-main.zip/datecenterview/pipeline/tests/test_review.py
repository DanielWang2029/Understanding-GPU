"""Band-1 #3 tests — the HITL queue and the U2 dispute drain.

Two halves:
  1. The loop's own mechanics — active-learning ranking, HYSTERESIS (a dispute re-opens but
     can never reject), ANTI-WINDUP (coalesce + per-drain cap), and that nothing is dropped
     silently (unmatched ids and deferred disputes are reported).
  2. The L6 validator gate, adversarially: every rule ships with a must-PASS example and a
     must-FAIL example. A gate that only ever sees good input is not a gate.

The store is mocked — these are unit tests of the control logic, not of Postgres.
"""
import json

import pytest

import validate_data as V
from dcv import review


# --------------------------------------------------------------- ranking (active learning)
def test_priority_prefers_uncertain_and_large():
    """Uncertainty × value: a shaky 500 MW record must outrank a near-certain one, and a big
    unknown must outrank a small unknown."""
    assert review.priority(0.3, 500) > review.priority(0.9, 500)
    assert review.priority(0.3, 500) > review.priority(0.3, 5)


def test_priority_log_damps_the_capacity_tail():
    """log1p damping: a 100× bigger campus must not get a 100× bigger priority, or one
    mega-project would monopolise the whole queue."""
    assert review.priority(0.5, 2000) < 3 * review.priority(0.5, 20)


def test_priority_treats_missing_confidence_as_maximum_uncertainty():
    assert review.priority(None, 100) == review.priority(0.0, 100)


# --------------------------------------------------------------- drain: hysteresis
class _Rec:
    """Stands in for DataCenter — which stores its score in `overall_confidence`, NOT
    `confidence`. Carrying only the one attribute is deliberate: it pins the dispatch."""
    def __init__(self, rid, status="approved", conf=0.8, lv="2026-01-01"):
        self.id, self.review_status, self.last_verified = rid, status, lv
        self.overall_confidence = conf
        self.project_name, self.location, self.sources, self.capacity_mw = rid, {}, [], 10


class _PowerRec(_Rec):
    """PowerProject stores its score in `confidence` instead."""
    def __init__(self, rid, **kw):
        super().__init__(rid, **kw)
        self.confidence = self.overall_confidence
        del self.overall_confidence


def test_derate_finds_the_right_column_on_a_power_record(monkeypatch):
    """Regression: dispatching on the ORM class (isinstance) read the wrong column for
    anything that wasn't the exact type. Both record kinds must de-rate their OWN score."""
    p = _PowerRec("pw1", conf=0.8)
    _drain(monkeypatch, [_d("pw1", rt="power_project")], [p])
    assert p.confidence == pytest.approx(0.68)
    assert not hasattr(p, "overall_confidence")   # never invents the other column


class _Session:
    def __init__(self, recs, log_rows=()):
        self.recs = {r.id: r for r in recs}
        self.added = []
        self.log_rows = list(log_rows)   # what _open_dispute_ids / _first_dispute_before read

    def get(self, model, rid):
        return self.recs.get(rid)

    def add(self, obj):
        self.added.append(obj)

    def execute(self, *a, **k):
        return iter(self.log_rows)


def _drain(monkeypatch, inbox_rows, recs, **kw):
    sess = _Session(recs)
    monkeypatch.setattr(review, "_read_inbox", lambda: (inbox_rows, 0))

    class _Scope:
        def __enter__(self): return sess
        def __exit__(self, *a): return False
    monkeypatch.setattr(review, "session_scope", lambda: _Scope())
    return review.drain(**kw), sess


def _d(rid, field="capacity_mw", rt="data_center"):
    return {"record_type": rt, "record_id": rid, "field": field, "reason": "wrong MW"}


def test_dispute_reopens_an_approved_record(monkeypatch):
    r = _Rec("dc1", status="approved", conf=0.8)
    stats, sess = _drain(monkeypatch, [_d("dc1")], [r])
    assert r.review_status == "needs_review"           # re-opened for L2
    assert r.overall_confidence == pytest.approx(0.68)  # de-rated 0.8 × 0.85
    assert r.last_verified is None                      # freshness loop must re-queue it
    assert stats["logged"] == 1 and stats["reopened"] == 1
    log = sess.added[0]
    assert log.decision == "dispute" and log.record_id == "dc1"
    assert log.before["review_status"] == "approved"    # audit trail carries before/after
    assert log.after["reason"] == "wrong MW"


def test_dispute_can_never_reject_a_record(monkeypatch):
    """HYSTERESIS — the whole point. One bad-faith dispute must not be able to destroy a
    verified value; the worst it can do is re-open it for re-verification."""
    r = _Rec("dc1", status="approved", conf=0.95)
    _drain(monkeypatch, [_d("dc1"), _d("dc1", field="status"), _d("dc1", field="location")], [r])
    assert r.review_status == "needs_review"
    assert r.review_status != "rejected"


def test_dispute_confidence_never_falls_below_the_floor(monkeypatch):
    r = _Rec("dc1", conf=0.21)
    _drain(monkeypatch, [_d("dc1")], [r])
    assert r.overall_confidence == review.DISPUTE_FLOOR


def test_dispute_on_an_already_queued_record_is_idempotent_but_still_logged(monkeypatch):
    """The record doesn't move (it's already in the queue) but the SIGNAL still counts —
    dropping it would lose the reader's input."""
    r = _Rec("dc1", status="needs_review", conf=0.5)
    stats, sess = _drain(monkeypatch, [_d("dc1")], [r])
    assert r.review_status == "needs_review" and stats["logged"] == 1
    assert len(sess.added) == 1


# --------------------------------------------------------------- drain: anti-windup
def test_repeat_disputes_on_the_same_field_coalesce(monkeypatch):
    r = _Rec("dc1")
    stats, sess = _drain(monkeypatch, [_d("dc1"), _d("dc1"), _d("dc1")], [r])
    assert stats["logged"] == 1 and stats["coalesced"] == 2
    assert len(sess.added) == 1


def test_disputes_on_different_fields_do_not_coalesce(monkeypatch):
    r = _Rec("dc1")
    stats, _ = _drain(monkeypatch, [_d("dc1", "capacity_mw"), _d("dc1", "status")], [r])
    assert stats["logged"] == 2 and stats["coalesced"] == 0


def test_reopen_cap_defers_the_rest_and_reports_it(monkeypatch):
    """A burst must not flood L2's queue — and what was held back is REPORTED, never a
    silent cap."""
    recs = [_Rec(f"dc{i}") for i in range(5)]
    stats, _ = _drain(monkeypatch, [_d(f"dc{i}") for i in range(5)], recs, max_reopen=2)
    assert stats["reopened"] == 2 and stats["deferred"] == 3
    assert sum(r.review_status == "needs_review" for r in recs) == 2


def test_unknown_record_is_reported_not_silently_dropped(monkeypatch):
    stats, sess = _drain(monkeypatch, [_d("ghost")], [_Rec("dc1")])
    assert stats["logged"] == 0 and stats["unmatched"] == ["data_center:ghost"]
    assert sess.added == []


def test_unknown_record_type_is_reported(monkeypatch):
    stats, _ = _drain(monkeypatch, [{"record_type": "widget", "record_id": "x"}], [_Rec("dc1")])
    assert stats["unmatched"] == ["widget:x"]


def test_empty_inbox_is_a_no_op(monkeypatch):
    stats, sess = _drain(monkeypatch, [], [_Rec("dc1")])
    assert stats["received"] == 0 and sess.added == []


# --------------------------------------------------------------- decide (human verdict)
def test_only_decide_can_approve(monkeypatch):
    r = _Rec("dc1", status="needs_review", conf=0.6, lv=None)
    sess = _Session([r])

    class _Scope:
        def __enter__(self): return sess
        def __exit__(self, *a): return False
    monkeypatch.setattr(review, "session_scope", lambda: _Scope())
    review.decide("data_center", "dc1", "approve", reviewer="hao", note="checked the permit")
    assert r.review_status == "approved" and r.last_verified  # re-stamped so freshness settles
    assert sess.added[0].decision == "approve" and sess.added[0].reviewer == "hao"


def test_decide_rejects_an_unknown_decision(monkeypatch):
    with pytest.raises(ValueError, match="decision must be"):
        review.decide("data_center", "dc1", "yolo")


def test_decide_rejects_an_unknown_record_type(monkeypatch):
    with pytest.raises(ValueError, match="unknown record_type"):
        review.decide("widget", "dc1", "approve")


# --------------------------------------------------------------- inbox rotation
def test_read_inbox_rotates_so_a_concurrent_post_is_not_lost(monkeypatch, tmp_path):
    """The web tier appends while the drain runs. Rotating (rename → parse) rather than
    truncating means a POST landing mid-drain goes to a fresh file instead of the void."""
    inbox = tmp_path / "disputes.jsonl"
    inbox.write_text(json.dumps(_d("dc1")) + "\nnot json\n" + json.dumps(_d("dc2")) + "\n")
    monkeypatch.setattr(review, "INBOX", inbox)
    monkeypatch.setattr(review, "PROCESSED", tmp_path / "processed.jsonl")
    rows, bad = review._read_inbox()
    assert [r["record_id"] for r in rows] == ["dc1", "dc2"] and bad == 1
    assert not inbox.exists()                                    # rotated away
    assert "dc1" in (tmp_path / "processed.jsonl").read_text()   # kept as an audit trail


# --------------------------------------------------------------- L6 validator gate
def _doc(review_queue, dcs):
    return {"meta": {"rollups": {"review_queue": review_queue}},
            "datasets": {"data_center": dcs, "power_project": [], "news": []}}


def _dc(rid, status):
    return {"id": rid, "review_status": status}


PASSING = {"needs_review": {"data_center": 2, "power_project": 0}, "inbox_pending": 0,
           "reviewed_total": 3, "open_disputes": 1, "disputed_ids": ["dc1"]}
ROWS = [_dc("dc1", "needs_review"), _dc("dc2", "needs_review"), _dc("dc3", "approved")]


def test_validator_passes_an_honest_review_queue():
    assert V.review_queue_integrity(_doc(PASSING, ROWS)) == []


def test_validator_allows_an_absent_or_unavailable_block():
    """An older contract, or an honest `unavailable` marker when the store can't be read,
    is not an error — only a block that CLAIMS numbers must have honest ones."""
    assert V.review_queue_integrity({"meta": {}, "datasets": {"data_center": [], "power_project": []}}) == []
    assert V.review_queue_integrity(_doc({"unavailable": True}, ROWS)) == []


def test_validator_fails_a_stale_depth():
    """MUST-FAIL: the measured value has to be LIVE. A hardcoded/stale count is the exact
    failure mode the conformance gate exists to catch."""
    errs = V.review_queue_integrity(_doc({**PASSING, "needs_review": {"data_center": 99}}, ROWS))
    assert any("not live" in e for e in errs)


def test_validator_fails_a_dispute_that_did_not_reopen_the_record():
    """MUST-FAIL: a disputed record still reading `approved` means the dispute routed
    nowhere — the stub's behaviour, dressed up as a number."""
    rows = [_dc("dc1", "approved"), _dc("dc2", "needs_review"), _dc("dc3", "needs_review")]
    errs = V.review_queue_integrity(_doc({**PASSING, "needs_review": {"data_center": 2}}, rows))
    assert any("did not re-open it" in e for e in errs)


def test_validator_fails_a_dangling_disputed_id():
    errs = V.review_queue_integrity(_doc({**PASSING, "disputed_ids": ["ghost"]}, ROWS))
    assert any("unknown record 'ghost'" in e for e in errs)


def test_validator_warns_on_a_voided_last_verified():
    """The drain voids `last_verified` so a disputed record can't look freshly verified. The
    freshness rule used to skip a missing date entirely — meaning the LEAST-verified records
    were the only ones exempt. Absent must now read as maximally stale."""
    doc = {"datasets": {"data_center": [{"id": "dc1", "review_status": "needs_review",
                                         "last_verified": None, "sources": ["u"]}],
                        "power_project": [], "news": []},
           "supply_chain": {"nodes": [], "links": []}}
    assert any("never been verified" in w for w in V.semantic(doc, 45))


def test_validator_does_not_warn_on_an_unverified_candidate():
    """A `candidate` hasn't reached verification yet — flagging it as stale would be noise."""
    doc = {"datasets": {"data_center": [{"id": "dc1", "review_status": "candidate",
                                         "last_verified": None, "sources": ["u"]}],
                        "power_project": [], "news": []},
           "supply_chain": {"nodes": [], "links": []}}
    assert not any("never been verified" in w for w in V.semantic(doc, 45))


def test_validator_fails_an_undrained_inbox():
    """MUST-FAIL: a filed dispute sitting in the inbox has not reached the loop yet, so the
    published read-model would understate the queue."""
    errs = V.review_queue_integrity(_doc({**PASSING, "inbox_pending": 4}, ROWS))
    assert any("undrained" in e for e in errs)


# --------------------------------------------------------------- repeat disputes / dismiss
def test_repeat_disputes_across_drains_do_not_compound_the_derate(monkeypatch):
    """Coalescing only dedupes WITHIN one drain, so a repeat disputer used to compound the
    de-rate across drains (0.95 → 0.81 → 0.69 → … → the 0.2 floor) and pin a record out of
    `approved` forever — defeating the hysteresis guarantee. The first dispute moves the
    state; more of the same input must not move it further. The signal is still logged."""
    r = _Rec("dc1", status="approved", conf=0.95)
    stats1, sess = _drain(monkeypatch, [_d("dc1")], [r])
    after_first = r.overall_confidence
    assert stats1["reopened"] == 1 and after_first == pytest.approx(0.8075)

    # second drain: review_log now shows an OPEN dispute on dc1
    monkeypatch.setattr(review, "_open_dispute_ids", lambda s: {"dc1"})
    stats2, sess2 = _drain(monkeypatch, [_d("dc1", field="status")], [r])
    assert r.overall_confidence == after_first        # unchanged — no compounding
    assert stats2["logged"] == 1                      # but the signal is NOT dropped
    assert stats2["repeat_signal"] == 1 and stats2["reopened"] == 0


def test_dismiss_restores_the_pre_dispute_state(monkeypatch):
    """An unfounded dispute must be reversible. `reject` rejects the RECORD and `approve`
    asserts a verification nobody performed — without `dismiss`, both exits are lies."""
    r = _Rec("dc1", status="needs_review", conf=0.7225, lv=None)
    sess = _Session([r])
    monkeypatch.setattr(review, "_first_dispute_before", lambda s, rt, rid: {
        "review_status": "approved", "confidence": 0.85, "last_verified": "2026-07-13"})

    class _Scope:
        def __enter__(self): return sess
        def __exit__(self, *a): return False
    monkeypatch.setattr(review, "session_scope", lambda: _Scope())
    review.decide("data_center", "dc1", "dismiss", reviewer="hao", note="test dispute")
    assert (r.review_status, r.overall_confidence, r.last_verified) == ("approved", 0.85, "2026-07-13")
    log = sess.added[0]
    assert log.decision == "dismiss"
    assert log.after["restored_from_audit"]["confidence"] == 0.85   # provenance of the undo


def test_dismiss_without_an_open_dispute_is_refused(monkeypatch):
    r = _Rec("dc1")
    sess = _Session([r])
    monkeypatch.setattr(review, "_first_dispute_before", lambda s, rt, rid: None)

    class _Scope:
        def __enter__(self): return sess
        def __exit__(self, *a): return False
    monkeypatch.setattr(review, "session_scope", lambda: _Scope())
    with pytest.raises(ValueError, match="no open dispute"):
        review.decide("data_center", "dc1", "dismiss")


def test_first_dispute_before_picks_the_earliest_of_the_open_run():
    """Restoring from the LATEST dispute would restore an already-de-rated value. The undo
    must reach back to the state before the run of disputes began."""
    class _S:
        def execute(self, *a, **k):
            return iter([("dispute", {"confidence": 0.85}),      # start of the open run
                         ("dispute", {"confidence": 0.7225})])   # a later one
    assert review._first_dispute_before(_S(), "data_center", "dc1")["confidence"] == 0.85


def test_a_prior_decision_closes_the_run():
    """A dispute resolved by a human starts a fresh run — a later dispute must not restore
    back past that decision."""
    class _S:
        def execute(self, *a, **k):
            return iter([("dispute", {"confidence": 0.9}),
                         ("approve", {"confidence": 0.85}),      # run closed here
                         ("dispute", {"confidence": 0.8})])      # new run starts
    assert review._first_dispute_before(_S(), "data_center", "dc1")["confidence"] == 0.8


def test_edit_does_not_resolve_a_dispute():
    """An `edit` records that a human changed the record — it is NOT a verdict on the dispute.
    Treating it as terminal cleared the disputed flag and stranded the de-rate with no way to
    undo it (found while cleaning up smoke-test data)."""
    class _S:
        def execute(self, *a, **k):
            return iter([("data_center", "dc1", "dispute"), ("data_center", "dc1", "edit")])
    assert review._open_dispute_ids(_S()) == {"dc1"}

    class _S2:
        def execute(self, *a, **k):
            return iter([("dispute", {"confidence": 0.72}), ("edit", {"confidence": 0.612})])
    assert review._first_dispute_before(_S2(), "data_center", "dc1")["confidence"] == 0.72


def test_a_human_verdict_does_resolve_a_dispute():
    for terminal in ("approve", "reject", "dismiss"):
        class _S:
            def execute(self, *a, **k):
                return iter([("data_center", "dc1", "dispute"), ("data_center", "dc1", terminal)])
        assert review._open_dispute_ids(_S()) == set(), terminal


# ==================================================== segmenting the queue by WHAT MOVES IT
#
# "363 needs_review vs 37 approved — what's missing is throughput" framed the queue as one
# backlog wanting one scarce input: human hours. Measured 2026-08-07 over 401 rows it is three
# populations wanting three different things, and human hours is the answer for the smallest.
# Same shape as the `tenant 0.5%` finding: check the denominator before staffing the problem.
from contextlib import contextmanager  # noqa: E402

from sqlalchemy import create_engine  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402

from dcv.models import Base, DataCenter  # noqa: E402


@pytest.fixture
def qstore(monkeypatch):
    eng = create_engine("sqlite://", future=True)
    Base.metadata.create_all(eng)
    SL = sessionmaker(bind=eng, autoflush=False, expire_on_commit=False, future=True)

    @contextmanager
    def scope():
        s = SL()
        try:
            yield s
            s.commit()
        except Exception:
            s.rollback()
            raise
        finally:
            s.close()

    monkeypatch.setattr(review, "session_scope", scope)
    return SL


def _q(SL, rid, *, doms, conf, mw=None, quote=None, status="needs_review", dup=None):
    with SL() as s:
        s.add(DataCenter(
            id=rid, natural_key=rid, project_name=rid, location={"state": "TX"},
            overall_confidence=conf, review_status=status, duplicate_of=dup,
            capacity_mw=({"value": mw, "quote": quote} if mw is not None else None),
            sources=[f"https://d{i}.example/{rid}" for i in range(doms)]))
        s.commit()


def test_a_single_source_row_is_evidence_blocked_not_reviewable(qstore):
    """THE reframe. `_gate` needs >=2 distinct domains, so no amount of human review approves
    this row — and with no capacity and no quote there is nothing for a reviewer to decide
    anyway. Calling it a review backlog points the scarce input at the wrong problem."""
    _q(qstore, "pdb1", doms=1, conf=0.75)
    seg = review.segments()
    assert seg["evidence_blocked"]["rows"] == 1
    assert seg["reverifiable"]["rows"] == 0


def test_a_multi_source_row_below_auto_approve_is_reverifiable(qstore):
    _q(qstore, "r1", doms=2, conf=0.75, mw=100.0)
    seg = review.segments()
    assert seg["reverifiable"]["rows"] == 1
    assert seg["reverifiable"]["with_capacity"] == 1 and seg["reverifiable"]["mw"] == 100.0


def test_a_row_already_meeting_the_gate_needs_a_decision_not_evidence(qstore):
    """Re-opened by a citation strip or a withdrawal, but the sources it still holds satisfy
    the approve gate. Spending discovery or verify budget on it buys nothing."""
    _q(qstore, "g1", doms=3, conf=0.93)
    assert review.segments()["gate_satisfied"]["rows"] == 1


def test_a_row_under_the_review_floor_is_its_own_segment(qstore):
    _q(qstore, "b1", doms=2, conf=0.2)
    assert review.segments()["below_floor"]["rows"] == 1


def test_quote_coverage_is_reported_because_reverification_depends_on_it(qstore):
    """Only 4 of 262 reverifiable rows carry a quote, so a re-verify pass checks our VALUES
    rather than values-plus-evidence. The segmenter has to surface that or the spend looks
    stronger than it is."""
    _q(qstore, "wq", doms=2, conf=0.75, mw=10.0, quote="the site will draw 10 MW")
    _q(qstore, "nq", doms=2, conf=0.75, mw=20.0)
    seg = review.segments()
    assert seg["reverifiable"]["rows"] == 2 and seg["reverifiable"]["with_quote"] == 1


def test_duplicates_are_excluded_from_the_queue_shape(qstore):
    """A row marked duplicate_of is dropped by emit, so counting it would inflate the backlog
    with work that will never be published."""
    _q(qstore, "d1", doms=2, conf=0.75)
    _q(qstore, "d2", doms=2, conf=0.75, dup="d1")
    assert review.segments()["total"] == 1


def test_approved_rows_are_not_in_the_queue_at_all(qstore):
    _q(qstore, "a1", doms=3, conf=0.93, status="approved")
    assert review.segments()["total"] == 0


def test_the_segments_partition_the_queue(qstore):
    """Every queued row lands in exactly one bucket — a segmenter that drops rows would
    under-report the backlog it exists to size."""
    _q(qstore, "s1", doms=1, conf=0.75)
    _q(qstore, "s2", doms=2, conf=0.75)
    _q(qstore, "s3", doms=3, conf=0.93)
    _q(qstore, "s4", doms=2, conf=0.2)
    seg = review.segments()
    assert seg["total"] == 4
    assert sum(v["rows"] for k, v in seg.items() if k != "total") == 4

"""chain_identity L2-identity tests (buyer-filing + press gathering and the cross-vendor,
verify-voted gate are mocked). These lock the flip logic: a link becomes `named` only when a
majority confirms a real naming, `confirmed` only when a majority is also confident on the
%-attribution, and the disclosed magnitude is never touched by this pass.
"""
import dcv.chain_identity as ci

TGT = {"from": "micron", "to": "nvidia", "pct_revenue": 17,
       "supplier_name": "Micron", "buyer_name": "Nvidia", "buyer_cik": "1045810"}


def _patch(monkeypatch, verdict, *, filing_hit=True, namings=None, press=("Micron ships HBM to Nvidia", ["https://trade.example/1"])):
    # buyer-filing evidence
    monkeypatch.setattr(ci.edgar, "submissions", lambda cik: {"filings": {"recent": {}}})
    monkeypatch.setattr(ci.edgar, "latest_report",
                        lambda subs: {"form": "10-K", "accession": "0001-25-000001",
                                      "doc": "nvda.htm", "filed": "2025-02-26"})
    monkeypatch.setattr(ci.edgar, "filing_text", lambda *a: "…NVIDIA utilizes foundries such as Micron…")
    monkeypatch.setattr(ci.edgar, "entity_mention",
                        lambda *a, **k: ({"alias": "Micron", "score": 3, "excerpt": "NVIDIA … Micron …"}
                                         if filing_hit else None))
    # press evidence + extraction
    monkeypatch.setattr(ci.grok, "web_search_tool", lambda *a, **k: {"type": "web_search"})
    monkeypatch.setattr(ci.grok, "search", lambda *a, **k: press)
    _namings = namings if namings is not None else [
        {"source_type": "press_first_party", "url": "https://investors.micron.example/hbm4",
         "verbatim": "Micron HBM4 for NVIDIA", "names_relationship": True}]
    monkeypatch.setattr(ci.grok, "chat", lambda *a, **k: ({"namings": _namings}, []))
    # verify (voted)
    monkeypatch.setattr(ci.claude, "verify_json", lambda *a, **k: verdict)


def test_named_and_attribution_confirmed(monkeypatch):
    _patch(monkeypatch, {"named_confirmed": True, "attribution_confident": True,
                         "confidence": 0.9, "reason": "dominant HBM buyer"})
    e = ci.resolve(TGT, rounds=3)
    assert e and e["link_basis"] == "named" and e["review_status"] == "confirmed"
    assert e["identity_verify"]["named_votes"] == "3/3"
    assert e["identity_verify"]["attribution_votes"] == "3/3"
    assert e["identity_verify"]["extractor"] != e["identity_verify"]["verifier"]  # cross-vendor
    # both a buyer_filing and a press link_source were captured
    types = {s["type"] for s in e["link_sources"]}
    assert "buyer_filing" in types and "press_first_party" in types
    # the pass never emits a magnitude — only the link half
    assert "pct_revenue" not in e and "rev_basis" not in e


def test_named_but_attribution_uncertain_is_needs_review(monkeypatch):
    _patch(monkeypatch, {"named_confirmed": True, "attribution_confident": False,
                         "confidence": 0.5, "reason": "several large customers"})
    e = ci.resolve(TGT, rounds=3)
    assert e and e["link_basis"] == "named" and e["review_status"] == "needs_review"


def test_naming_not_confirmed_returns_none(monkeypatch):
    # majority does NOT confirm a real naming → stays inferred (resolve returns None)
    _patch(monkeypatch, {"named_confirmed": False, "attribution_confident": False,
                         "confidence": 0.2, "reason": "no credible naming"})
    assert ci.resolve(TGT, rounds=3) is None


def test_no_evidence_never_verifies(monkeypatch):
    called = {"verify": 0}

    def _boom(*a, **k):
        called["verify"] += 1
        return {}

    # no buyer filing hit AND empty press + no namings → nothing to verify
    _patch(monkeypatch, {}, filing_hit=False, namings=[], press=("", []))
    monkeypatch.setattr(ci.claude, "verify_json", _boom)
    assert ci.resolve(TGT, rounds=3) is None
    assert called["verify"] == 0


def test_press_naming_without_url_is_dropped(monkeypatch):
    # a naming with no url can't be a link_source; with no buyer filing either → None
    _patch(monkeypatch, {"named_confirmed": True, "attribution_confident": True, "confidence": 0.9},
           filing_hit=False,
           namings=[{"source_type": "press_trade", "verbatim": "Micron supplies Nvidia",
                     "names_relationship": True}])
    assert ci.resolve(TGT, rounds=3) is None


def test_targets_disclosed_unnamed_only_sorted(monkeypatch):
    monkeypatch.setattr(ci, "_load_magnitude_edges", lambda: {
        ("micron", "nvidia"): {"from": "micron", "to": "nvidia", "pct_revenue": 17,
                               "rev_basis": "disclosed", "link_basis": "inferred"},
        ("coreweave", "microsoft"): {"from": "coreweave", "to": "microsoft", "pct_revenue": 67,
                                     "rev_basis": "disclosed", "link_basis": "inferred"},
        ("tsmc", "nvidia"): {"from": "tsmc", "to": "nvidia", "pct_revenue": 17,
                             "rev_basis": "disclosed", "link_basis": "named"},  # already resolved
        ("foo", "bar"): {"from": "foo", "to": "bar", "pct_revenue": 9, "rev_basis": "estimated"},
    })
    import dcv.compute_seed as cs
    monkeypatch.setattr(cs, "build_seed", lambda: {"chain": {"entities": [
        {"id": "micron", "name": "Micron", "ticker": "MU"},
        {"id": "nvidia", "name": "Nvidia", "ticker": "NVDA"},
        {"id": "coreweave", "name": "CoreWeave", "ticker": "CRWV"},
        {"id": "microsoft", "name": "Microsoft", "ticker": "MSFT"},
    ]}})
    monkeypatch.setattr(ci, "_ticker_cik_map", lambda: {"NVDA": "1045810", "MSFT": "789019"})
    ts = ci.targets()
    ids = [(t["from"], t["to"]) for t in ts]
    assert ids == [("coreweave", "microsoft"), ("micron", "nvidia")]  # 67 before 17; named/estimated excluded
    assert ts[0]["buyer_cik"] == "789019" and ts[1]["buyer_cik"] == "1045810"


def test_run_writes_auto_fixture(monkeypatch, tmp_path):
    import json
    out = tmp_path / "identity_auto.json"
    monkeypatch.setattr(ci, "AUTO_FIXTURE", out)
    monkeypatch.setattr(ci, "resolve", lambda t, **k: {
        "from": t["from"], "to": t["to"], "link_basis": "named", "review_status": "confirmed",
        "link_confidence": 0.9, "link_sources": [{"type": "buyer_filing", "url": "https://x"}],
        "identity_verify": {"named_votes": "3/3"}})
    stats = ci.run([TGT], budget_usd=1e9, rounds=3)
    assert stats["named"] == 1 and stats["confirmed"] == 1
    data = json.loads(out.read_text())
    assert data["edges"][0]["to"] == "nvidia" and data["_meta"]["extractor"] != data["_meta"]["verifier"]

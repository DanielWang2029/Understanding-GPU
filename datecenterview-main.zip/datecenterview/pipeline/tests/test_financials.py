"""P2/L9 financial-spine tests — the deadband guardrail + the L6 validator gate.

Per the loop-design conformance rule, every validator check ships with a passing
example AND a must-fail example: a gate is only a gate if it rejects bad input.
"""
import datetime
import json

import pytest

import validate_data as V
from dcv.clients.fmp import CircuitBreaker, FMPError, _is_error_body, material_move
from dcv.financials import load_financials


def _days_ago(n: int) -> str:
    return (datetime.date.today() - datetime.timedelta(days=n)).isoformat()


def _doc(fin, ticker="NVDA", eid="x"):
    e = {"id": eid, "name": eid, "category": "other"}
    if ticker:
        e["ticker"] = ticker
    if fin is not None:
        e["financials"] = fin
    return {"entities": [e], "datasets": {"data_center": [], "power_project": [], "news": []}}


DISCLOSED_OK = {
    "market_cap": {"value": 1e12, "as_of": _days_ago(30), "basis": "disclosed", "sources": ["FMP"]},
    "revenue": {"value": 2e11, "as_of": _days_ago(60), "basis": "disclosed", "sources": ["FMP"]},
    "currency": "USD",
}


# ---- deadband (clients.fmp.material_move) ----
def test_material_move_first_observation_is_material():
    assert material_move(None, 100) is True
    assert material_move(0, 100) is True


def test_material_move_within_deadband_is_immaterial():
    assert material_move(1000, 1000) is False
    assert material_move(1000, 1010) is False  # +1% < 2% deadband


def test_material_move_beyond_deadband_is_material():
    assert material_move(1000, 1030) is True  # +3% > 2%


def test_material_move_new_none_never_material():
    assert material_move(1000, None) is False


# ---- L6 gate: financials_integrity must PASS clean input ----
def test_integrity_clean_disclosed_passes():
    assert V.financials_integrity(_doc(DISCLOSED_OK)) == []


def test_integrity_clean_estimated_without_ticker_passes():
    est = {"market_cap": {"value": 1e11, "as_of": _days_ago(5), "basis": "estimated", "sources": ["seed"]},
           "revenue": {"value": 5e10, "as_of": _days_ago(5), "basis": "estimated", "sources": ["seed"]},
           "currency": "USD"}
    assert V.financials_integrity(_doc(est, ticker=None)) == []


def test_integrity_no_financials_passes():
    assert V.financials_integrity(_doc(None)) == []


# ---- L6 gate: MUST-FAIL examples (a green validator with holes is worse than none) ----
def test_integrity_disclosed_null_value_rejected():
    bad = {"market_cap": {"value": None, "as_of": _days_ago(30), "basis": "disclosed", "sources": ["FMP"]}}
    assert any("value not a positive number" in e for e in V.financials_integrity(_doc(bad)))


def test_integrity_disclosed_no_as_of_rejected():
    bad = {"market_cap": {"value": 1e12, "basis": "disclosed", "sources": ["FMP"]}}
    assert any("no as_of" in e for e in V.financials_integrity(_doc(bad)))


def test_integrity_disclosed_no_sources_rejected():
    bad = {"market_cap": {"value": 1e12, "as_of": _days_ago(30), "basis": "disclosed"}}
    assert any("no sources" in e for e in V.financials_integrity(_doc(bad)))


def test_integrity_disclosed_no_ticker_rejected():
    bad = {"revenue": {"value": 1e11, "as_of": _days_ago(30), "basis": "disclosed", "sources": ["FMP"]}}
    assert any("no ticker" in e for e in V.financials_integrity(_doc(bad, ticker=None)))


def test_integrity_negative_value_rejected():
    bad = {"revenue": {"value": -5, "as_of": _days_ago(30), "basis": "estimated", "sources": ["seed"]}}
    assert any("< 0" in e for e in V.financials_integrity(_doc(bad)))


# ---- freshness: estimates are looser but NOT exempt (review B3) ----
def test_freshness_flags_stale_estimate():
    old = {"market_cap": {"value": 1e11, "as_of": _days_ago(900), "basis": "estimated", "sources": ["seed"]}}
    warns = V.semantic(_doc(old, ticker=None), 45)
    assert any("fin-stale" in w and "estimated" in w for w in warns)


def test_freshness_fresh_estimate_not_flagged():
    fresh = {"market_cap": {"value": 1e11, "as_of": _days_ago(10), "basis": "estimated", "sources": ["seed"]}}
    warns = V.semantic(_doc(fresh, ticker=None), 45)
    assert not any("fin-stale" in w for w in warns)


def test_freshness_flags_disclosed_missing_as_of():
    bad = {"market_cap": {"value": 1e12, "basis": "disclosed", "sources": ["FMP"]}}
    warns = V.semantic(_doc(bad), 45)
    assert any("fin-stale" in w and "no as_of" in w for w in warns)


# ---- circuit breaker + error-body (clients.fmp, review A1) ----
def test_circuit_breaker_opens_after_threshold():
    cb = CircuitBreaker(threshold=3)
    for _ in range(3):
        cb.record_failure()
    assert cb.open
    with pytest.raises(FMPError):
        cb.before()


def test_circuit_breaker_resets_on_success():
    cb = CircuitBreaker(threshold=3)
    cb.record_failure()
    cb.record_failure()
    cb.record_success()
    assert cb.failures == 0 and not cb.open
    cb.before()  # does not raise


def test_fmp_error_body_detected():
    # HTTP-200-with-error-envelope must be caught, not read as a data row
    assert _is_error_body({"Error Message": "requires a higher plan"})
    assert _is_error_body({"error": "invalid"})
    assert not _is_error_body([{"symbol": "NVDA", "marketCap": 1}])
    assert not _is_error_body([])


# ---- L4 delta-log: load_financials writes a ChangeLog on a material change (review C2) ----
class _FakeEntity:
    def __init__(self, eid, financials=None, identifiers=None):
        self.id = eid
        self.financials = financials
        self.identifiers = identifiers or {}


class _FakeSession:
    def __init__(self, ents):
        self._e = {x.id: x for x in ents}
        self.added = []

    def get(self, _model, eid):
        return self._e.get(eid)

    def add(self, obj):
        self.added.append(obj)


def _write_fixture(tmp_path, mc, rev=2e11):
    fx = tmp_path / "financials.json"
    fx.write_text(json.dumps({"nvidia": {
        "ticker": "NVDA", "currency": "USD",
        "market_cap": {"value": mc, "as_of": "2026-07-17", "basis": "disclosed", "sources": ["FMP"]},
        "revenue": {"value": rev, "as_of": "2026-02-25", "basis": "disclosed", "sources": ["FMP"]},
    }}))
    return fx


def test_delta_log_written_on_material_change(tmp_path):
    ent = _FakeEntity("nvidia", financials={
        "market_cap": {"value": 4e12, "basis": "disclosed"},
        "revenue": {"value": 2e11, "basis": "disclosed"}})
    s = _FakeSession([ent])
    stats = load_financials(s, _write_fixture(tmp_path, mc=5e12))  # +25% market cap = material
    logged = [a.field for a in s.added if getattr(a, "field", "").startswith("financials")]
    assert "financials.market_cap" in logged      # changed → logged
    assert "financials.revenue" not in logged      # unchanged → not logged
    assert stats["logged"] == 1


def test_delta_log_silent_when_unchanged(tmp_path):
    ent = _FakeEntity("nvidia", financials={
        "market_cap": {"value": 5e12, "basis": "disclosed", "as_of": "2026-07-17"},
        "revenue": {"value": 2e11, "basis": "disclosed", "as_of": "2026-02-25"}})
    s = _FakeSession([ent])
    stats = load_financials(s, _write_fixture(tmp_path, mc=5e12))  # identical → idempotent
    assert stats["logged"] == 0


# ---- Band-1 #1: the EDGAR overlay (disclosed revenue/capex widen the FMP-8) ----
def _fixtures(tmp_path, fmp, edgar):
    fx = tmp_path / "financials.json"
    fx.write_text(json.dumps(fmp))
    eg = tmp_path / "financials_edgar.json"
    eg.write_text(json.dumps(edgar))
    return fx, eg


_EST_ENTRY = {"micron": {"ticker": "MU", "currency": "USD",
    "market_cap": {"value": 1.5e11, "as_of": "2026-07-17", "basis": "estimated", "sources": ["seed"]},
    "revenue": {"value": 3.0e10, "as_of": "2026-01-01", "basis": "estimated", "sources": ["seed"]}}}


def test_edgar_overlay_supersedes_revenue_estimate_and_adds_capex(tmp_path):
    ent = _FakeEntity("micron")
    s = _FakeSession([ent])
    edgar = {"micron": {"ticker": "MU",
        "revenue": {"value": 3.7378e10, "as_of": "2025-10-03", "basis": "disclosed",
                    "period": "FY end 2025-08-28", "sources": ["https://sec.gov/…/723125/…/"]},
        "capex": {"value": 1.5857e10, "as_of": "2025-10-03", "basis": "disclosed",
                  "period": "FY end 2025-08-28", "sources": ["https://sec.gov/…/723125/…/"]}}}
    fx, eg = _fixtures(tmp_path, _EST_ENTRY, edgar)
    stats = load_financials(s, fx, eg)
    fin = ent.financials
    assert fin["revenue"]["basis"] == "disclosed" and fin["revenue"]["value"] == 3.7378e10
    assert fin["capex"]["basis"] == "disclosed" and fin["capex"]["value"] == 1.5857e10   # capex now carried
    assert fin["market_cap"]["basis"] == "estimated"   # market cap untouched (EDGAR has no price)
    assert stats["edgar_disclosed"] == 2 and stats["disclosed"] == 1


def test_edgar_overlay_never_overwrites_a_disclosed_value(tmp_path):
    # the segment-node guard: a fixture-DISCLOSED revenue (e.g. aws parent-consolidated) must
    # survive even if an EDGAR entry exists for it.
    fmp = {"aws": {"ticker": "AMZN", "currency": "USD",
        "market_cap": {"value": 2.4e12, "as_of": "2026-07-17", "basis": "disclosed", "sources": ["FMP"]},
        "revenue": {"value": 1.05e11, "as_of": "2026-02-01", "basis": "disclosed", "sources": ["FMP"],
                    "unit": "segment"}}}
    edgar = {"aws": {"ticker": "AMZN",
        "revenue": {"value": 6.4e11, "as_of": "2025-02-01", "basis": "disclosed", "sources": ["EDGAR"]}}}
    ent = _FakeEntity("aws")
    s = _FakeSession([ent])
    fx, eg = _fixtures(tmp_path, fmp, edgar)
    load_financials(s, fx, eg)
    assert ent.financials["revenue"]["value"] == 1.05e11  # AWS segment kept, NOT Amazon's $640B
    assert ent.financials["revenue"].get("unit") == "segment"


def test_edgar_overlay_absent_fixture_is_noop(tmp_path):
    ent = _FakeEntity("micron")
    s = _FakeSession([ent])
    fx, _ = _fixtures(tmp_path, _EST_ENTRY, {})
    stats = load_financials(s, fx, tmp_path / "does_not_exist.json")
    assert ent.financials["revenue"]["basis"] == "estimated" and stats["edgar_disclosed"] == 0


# ---- P3 edge_integrity gate (quantified chain edges) ----
def _edoc(edges):
    return {"chain": {"edges": edges}, "entities": [],
            "datasets": {"data_center": [], "power_project": [], "news": []}}


def _edge(value):
    return {"from": "tsmc", "to": "nvidia", "relation": "supplies", "value": value}


def test_edge_integrity_disclosed_needs_source_and_asof():
    bad = _edge({"pct_cogs": 39, "pct_revenue": 22, "disclosed": True, "rev_basis": "disclosed"})
    errs = V.edge_integrity(_edoc([bad]))
    assert any("no sources" in e for e in errs)
    assert any("no as_of" in e for e in errs)


def test_edge_integrity_disclosed_complete_passes():
    ok = _edge({"pct_cogs": 39, "pct_revenue": 22, "disclosed": True, "rev_basis": "disclosed",
                "as_of": "2026-04-16", "sources": ["https://sec.gov/…"]})
    assert V.edge_integrity(_edoc([ok])) == []


def test_edge_integrity_legacy_seed_edge_passes():
    # seed edges use only the boolean `disclosed`, no per-metric basis → not gated
    seed = _edge({"pct_cogs": 39, "pct_revenue": 22, "disclosed": True})
    assert V.edge_integrity(_edoc([seed])) == []


def test_edge_integrity_estimated_edge_passes_without_source():
    est = _edge({"pct_cogs": 6, "pct_revenue": 8, "disclosed": False,
                 "cogs_basis": "estimated", "rev_basis": "estimated"})
    assert V.edge_integrity(_edoc([est])) == []


# ---- P3 L2-identity: a `named` link must cite who named it ----
def test_edge_integrity_named_link_needs_link_sources():
    bad = _edge({"pct_revenue": 17, "disclosed": True, "rev_basis": "disclosed",
                 "as_of": "2026-04-16", "sources": ["https://sec.gov/x"], "link_basis": "named"})
    errs = V.edge_integrity(_edoc([bad]))
    assert any("no link_sources" in e for e in errs)


def test_edge_integrity_named_link_source_needs_url():
    bad = _edge({"pct_revenue": 17, "disclosed": True, "rev_basis": "disclosed",
                 "as_of": "2026-04-16", "sources": ["https://sec.gov/x"], "link_basis": "named",
                 "link_sources": [{"type": "buyer_filing", "excerpt": "names TSMC"}]})
    assert any("missing url" in e for e in V.edge_integrity(_edoc([bad])))


def test_edge_integrity_named_link_complete_passes():
    ok = _edge({"pct_revenue": 17, "disclosed": True, "rev_basis": "disclosed",
                "as_of": "2026-04-16", "sources": ["https://sec.gov/x"], "link_basis": "named",
                "link_sources": [{"type": "buyer_filing", "url": "https://sec.gov/nvda-10k"}]})
    assert V.edge_integrity(_edoc([ok])) == []


def test_edge_integrity_inferred_link_not_gated():
    # an inferred link carries no naming claim → no link_sources required
    inf = _edge({"pct_revenue": 17, "disclosed": True, "rev_basis": "disclosed",
                 "as_of": "2026-04-16", "sources": ["https://sec.gov/x"], "link_basis": "inferred"})
    assert V.edge_integrity(_edoc([inf])) == []

"""Decision #1 as code — no value may be sourced from a paid curated competitor.

Until Band 2 #3 this constraint lived only in CLAUDE.md prose, and the capacity-recovery pass
extracted facility MW straight out of competitor databases: 104 tier-1 URLs reached the
published read-model. These tests pin the guard so it cannot quietly regress to prose again.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import validate_data as V  # noqa: E402
from dcv import source_policy as sp  # noqa: E402


def test_the_named_competitor_is_denied():
    """CLAUDE.md decision #1 names CleanView explicitly."""
    assert not sp.is_allowed("https://cleanview.co/data-centers/virginia/2320/qts-ric5")
    assert "CleanView" in sp.denied_reason("https://cleanview.co/x")


def test_subdomains_and_www_are_denied_too():
    for u in ("https://www.datacenterhawk.com/a", "https://research.dgtlinfra.com/b"):
        assert not sp.is_allowed(u), u


def test_a_lookalike_domain_is_not_denied():
    """Suffix matching must be anchored — `notcleanview.co` and `cleanview.co.evil.com` are
    different hosts, and over-blocking a legitimate source is its own failure."""
    assert sp.is_allowed("https://notcleanview.co/x")
    assert sp.is_allowed("https://cleanview.co.evil.com/x")


def test_primary_and_permitted_sources_are_allowed():
    for u in ("https://www.sec.gov/Archives/edgar/data/1/x.htm",
              "https://www.peeringdb.com/fac/123",
              "https://www.cyrusone.com/data-centers/sterling-virginia-nva9",
              "https://www.datacenterdynamics.com/en/news/x",
              "https://www.eia.gov/electricity/data.php"):
        assert sp.is_allowed(u), u


def test_aterio_is_tier_two_ruled_2026_08_07():
    """Ruled by the project owner while draining the review queue. It had been supplying
    corroboration silently because it passes tier 1, tier 3, review AND the fail-closed
    `unclassified_reason` guard — the guard matches directory-shaped HOSTNAMES, and the tell
    for aterio is in the PATH (/us-data-centers/). Do not re-litigate the tier."""
    u = "https://www.aterio.io/us-data-centers/986d834a"
    assert sp.is_allowed(u), "aterio.io must NOT be tier-1 denied"
    assert not sp.value_denied_reason(u), "tier 2 permits VALUES, unlike tier 3"
    assert sp.review_reason(u), "tier 2 must be tracked, not silently allowed"
    assert sp.classify(u) == "tracked_tier2"


def test_the_path_shaped_directory_gap_is_still_open():
    """KNOWN-OPEN, pinned so it is not mistaken for fixed. `unclassified_reason` fails closed
    on directory-shaped hostnames; a directory whose hostname carries no tell still passes.
    Widening it to read paths is not free — trade press and operators' own sites publish under
    /data-centers/ too — so it is measured and left, not patched blind."""
    made_up = "https://exampledirectory.io/us-data-centers/abc"
    assert sp.unclassified_reason(made_up) is None, \
        "guard now catches path-shaped directories — update this test and the finding"


def test_free_directories_are_review_not_deny():
    """Tier 2 is a LICENSING JUDGEMENT for the project owner. These are closer in kind to
    PeeringDB — which this project uses by design — than to a paywalled competitor, so the
    module must not block a publish on them by fiat."""
    for u in ("https://www.datacenters.com/x", "https://cloudscene.com/y",
              "https://baxtel.com/z", "https://www.datacentermap.com/w"):
        assert sp.is_allowed(u), f"{u} must NOT be tier-1 denied"
        assert sp.review_reason(u), f"{u} must be flagged for review"


def test_filter_returns_denials_rather_than_dropping_them():
    """An ingest path that silently discards a source is indistinguishable from one that
    found nothing — the denial has to come back so it can be logged."""
    ok, bad = sp.filter_allowed(["https://sec.gov/a", "https://cleanview.co/b"])
    assert ok == ["https://sec.gov/a"]
    assert len(bad) == 1 and "CleanView" in bad[0][1]


def test_scan_finds_a_competitor_url_anywhere_in_the_document():
    """The gate scans the WHOLE document, not a list of known source fields: a competitor URL
    reaching the read-model via an edge or a Field<T>'s `sources` is just as published."""
    doc = {"datasets": {"data_center": [
        {"id": "a", "capacity_mw": {"value": 625,
                                    "sources": ["https://cleanview.co/dc/1"]}}]},
        "edges": [{"sources": ["https://www.datacenterhawk.com/x"]}]}
    hits = sp.scan(doc)
    assert len(hits) == 2
    assert {sp._host(u) for _, u, _ in hits} == {"cleanview.co", "datacenterhawk.com"}


# ---------------------------------------------------------------- L6 validator gate
def test_validator_blocks_publish_on_a_denied_source():
    """MUST-FAIL: this is the whole point — the constraint has to stop a release, not warn."""
    doc = {"datasets": {"data_center": [{"id": "a", "sources": ["https://cleanview.co/x"]}],
                        "power_project": [], "news": []}}
    errs = V.source_policy_integrity(doc)
    assert errs and "cleanview.co" in errs[0] and "decision #1" in errs[0]


def test_validator_passes_a_clean_document():
    doc = {"datasets": {"data_center": [{"id": "a", "sources": ["https://sec.gov/x"]}],
                        "power_project": [], "news": []}}
    assert V.source_policy_integrity(doc) == []


def test_validator_does_not_block_on_tier_two():
    doc = {"datasets": {"data_center": [{"id": "a", "sources": ["https://datacenters.com/x"]}],
                        "power_project": [], "news": []}}
    assert V.source_policy_integrity(doc) == []


# ------------------------------------------- the rollup must agree with the gate (Tier-5)
def _doc_with_rollup(sources, **roll):
    return {"meta": {"rollups": {"source_policy": roll}},
            "datasets": {"data_center": [{"id": "a", "sources": sources}],
                         "power_project": [], "news": []}}


def test_a_truthful_source_policy_rollup_passes():
    """MUST-PASS: tier-2 counted honestly, tier-1 zero."""
    doc = _doc_with_rollup(["https://datacenters.com/x"], denied_tier1=0, tracked_tier2=1)
    assert V.source_policy_integrity(doc) == []


def test_a_rollup_that_understates_tier_two_is_blocked():
    """MUST-FAIL: 'allowed but TRACKED' is the whole basis of the tier-2 ruling. A counter that
    reports fewer directory dependencies than the document actually carries makes the
    dependency look smaller than it is — the number is the only thing making the tier real."""
    doc = _doc_with_rollup(["https://datacenters.com/x"], denied_tier1=0, tracked_tier2=0)
    errs = V.source_policy_integrity(doc)
    assert errs and "tracked_tier2" in errs[0] and "not tracked" in errs[0]


def test_a_rollup_claiming_zero_while_tier_one_is_present_is_blocked_twice():
    """MUST-FAIL: a document carrying a competitor URL *and* a rollup asserting cleanliness is
    strictly worse than one that just carries the URL — it publishes a reassurance. Both the
    violation and the false claim must be reported."""
    doc = _doc_with_rollup(["https://cleanview.co/x"], denied_tier1=0, tracked_tier2=0)
    errs = V.source_policy_integrity(doc)
    assert len(errs) == 2
    assert any("cleanview.co" in e for e in errs)
    assert any("does not match the enforced one" in e for e in errs)


def test_an_unavailable_rollup_is_not_cross_checked():
    """`unavailable` is the honest marker when the sensor could not run; it must not be read as
    a claim of zero and then contradicted."""
    doc = _doc_with_rollup(["https://datacenters.com/x"], unavailable=True)
    assert V.source_policy_integrity(doc) == []


# ---------------------------------------------------------------- remediation (purge)
def test_purge_is_dry_by_default_and_reports_what_it_would_do(monkeypatch):
    """A destructive remediation must not run because someone forgot a flag."""
    from dcv import purge_sources
    calls = {}

    def fake_purge(dry_run=True):
        calls["dry_run"] = dry_run
        return {"values_withdrawn": 0, "rows_reopened": 0, "urls_stripped": 0,
                "news_deleted": 0, "sources_deleted": 0, "confidence_capped": 0,
                "by_field": {}}

    monkeypatch.setattr(purge_sources, "purge", fake_purge)
    purge_sources.run()
    assert calls["dry_run"] is True


def test_withdrawal_takes_the_value_not_just_the_url():
    """Re-citing a figure EXTRACTED from a competitor to a permitted page would launder it,
    so a Field<T> with a denied source must lose its value. Live evidence that the values
    really do differ: aligned-iad02 read 163 MW from CleanView and 120 MW once re-derived
    from a permitted source."""
    field = {"value": 163, "sources": ["https://cleanview.co/x"]}
    assert [u for u in field["sources"] if sp.denied_reason(u)]


# ============================================ a withdrawal must take the CONFIDENCE with it
#
# The defect this section pins, measured 2026-08-07 while sizing the review queue: 10 rows sat
# at 0.93 (`_AGREE_CORROBORATED`) with 3-4 source domains and NO capacity — 2,003 MW of
# withdrawn figures between them — because `purge()` re-opened the record but never touched the
# score the withdrawn value had earned. `_gate(0.93, 3)` returns "approved", so every one of
# them was one confidence-threshold drain away from being re-published: the review queue would
# have quietly undone the source-policy remediation it sits downstream of.
#
# Re-opening the STATUS was necessary and not sufficient. The number that moves it back has to
# go too.
import pytest  # noqa: E402
from sqlalchemy import create_engine, select  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402

from dcv import purge_sources as ps  # noqa: E402
from dcv.models import Base, ChangeLog, DataCenter  # noqa: E402
from dcv.phaseb.verify import _gate  # noqa: E402

_DENIED = "https://cleanview.co/dc/1"          # tier 1
_OK1, _OK2 = "https://www.datacenterdynamics.com/n/1", "https://baxtel.com/dc/2"


@pytest.fixture
def store(monkeypatch):
    from contextlib import contextmanager

    eng = create_engine("sqlite://", future=True)
    Base.metadata.create_all(eng)
    SL = sessionmaker(bind=eng, autoflush=False, expire_on_commit=False, future=True)

    @contextmanager
    def scope():
        s = SL()
        try:
            yield s
            s.commit()
        except Exception:
            s.rollback()
            raise
        finally:
            s.close()

    monkeypatch.setattr(ps, "session_scope", scope)
    return SL


def _dc(SL, rid="dc1", *, mw_sources=(_DENIED, _OK1), row_sources=(_OK1, _OK2), conf=0.93):
    with SL() as s:
        s.add(DataCenter(
            id=rid, natural_key=rid, project_name="P",
            location={"state": "TX"}, overall_confidence=conf,
            review_status="approved", last_verified="2026-07-01",
            capacity_mw={"value": 850.0, "sources": list(mw_sources)},
            sources=list(row_sources)))
        s.commit()
    return rid


def _get(SL, rid="dc1"):
    with SL() as s:
        return s.get(DataCenter, rid)


def test_a_withdrawal_surrenders_the_confidence_it_earned(store):
    """MUST-PASS. The score describes a verification OF something; withdraw the something and
    the score is a fossil."""
    _dc(store)
    st = ps.purge(dry_run=False)
    assert st["values_withdrawn"] == 1 and st["confidence_capped"] == 1

    r = _get(store)
    assert r.capacity_mw is None                       # value gone
    assert r.review_status == "needs_review"           # re-opened (pre-existing behaviour)
    assert r.overall_confidence == ps.WITHDRAWN_CONFIDENCE_CAP


def test_a_withdrawn_row_can_no_longer_be_gate_approved(store):
    """THE defect, stated as the thing that actually goes wrong. Before the cap, `_gate` said
    `approved` for a row holding no capacity at all — so draining the queue on confidence
    would have re-published exactly what the source policy withdrew."""
    _dc(store)
    r_before = _get(store)
    assert _gate(r_before.overall_confidence, 3) == "approved"    # the trap, reproduced

    ps.purge(dry_run=False)
    r = _get(store)
    assert _gate(r.overall_confidence, 3) == "needs_review"


def test_the_cap_lands_on_needs_review_not_reported(store):
    """Zeroing the confidence would say `reported` — "the verifier failed" — which is a
    different claim, and a false one. The row genuinely needs a human; that is the floor."""
    _dc(store)
    ps.purge(dry_run=False)
    r = _get(store)
    assert _gate(r.overall_confidence, 3) == "needs_review"
    assert _gate(r.overall_confidence, 1) != "reported"


def test_the_cap_is_logged_with_the_old_score(store):
    """Auditable and reversible on the same terms as the withdrawal that caused it."""
    _dc(store)
    ps.purge(dry_run=False)
    with store() as s:
        e = s.execute(select(ChangeLog).where(
            ChangeLog.field == "overall_confidence")).scalars().first()
    assert e is not None, "the cap left no audit trail"
    assert e.old == {"overall_confidence": 0.93}
    assert e.new["overall_confidence"] == ps.WITHDRAWN_CONFIDENCE_CAP
    assert e.source_id == "source_policy:withdrawn_confidence_cap"


def test_stripping_a_url_alone_does_not_touch_the_confidence(store):
    """MUST-FAIL half. A row that merely lost a citation still HOLDS its values, so the score
    still has a subject. Capping here would punish records the policy did not disarm."""
    _dc(store, mw_sources=(_OK1, _OK2), row_sources=(_DENIED, _OK1))
    st = ps.purge(dry_run=False)
    assert st["urls_stripped"] == 1 and st["values_withdrawn"] == 0
    assert st["confidence_capped"] == 0
    r = _get(store)
    assert r.capacity_mw["value"] == 850.0            # value untouched
    assert r.overall_confidence == 0.93               # so is the score


def test_a_clean_row_is_left_entirely_alone(store):
    """REGRESSION: the cap must not fire on records the policy never touched."""
    _dc(store, mw_sources=(_OK1, _OK2), row_sources=(_OK1, _OK2))
    st = ps.purge(dry_run=False)
    assert st == {**st, "values_withdrawn": 0, "urls_stripped": 0, "confidence_capped": 0}
    assert _get(store).overall_confidence == 0.93


def test_a_dry_run_reports_the_cap_without_writing_it(store):
    _dc(store)
    st = ps.purge(dry_run=True)
    assert st["confidence_capped"] == 1               # reported...
    assert _get(store).overall_confidence == 0.93     # ...but nothing written


# ------------------------------------------------- repairing rows an EARLIER purge left behind
def test_repair_caps_a_row_whose_value_is_still_missing(store):
    """`purge()` is idempotent — the offending values are already gone — so fixing it forward
    repairs nothing already in this state. This is that repair, driven off the audit trail the
    withdrawal itself wrote rather than off a guess."""
    rid = _dc(store)
    ps.purge(dry_run=False)
    with store() as s:                                # simulate the pre-fix state
        r = s.get(DataCenter, rid)
        r.overall_confidence = 0.93
        s.commit()

    st = ps.cap_withdrawn_confidence(dry_run=False)
    assert st["candidates"] == 1 and st["capped"] == 1
    assert _get(store).overall_confidence == ps.WITHDRAWN_CONFIDENCE_CAP


def test_repair_skips_a_value_that_was_re_derived(store):
    """14 of the 81 withdrawn rows got a capacity back from a permitted source. The value has a
    subject again, so the score is no longer a fossil — capping it would destroy a real
    verification to fix a problem that resolved itself."""
    rid = _dc(store)
    ps.purge(dry_run=False)
    with store() as s:
        r = s.get(DataCenter, rid)
        r.capacity_mw = {"value": 120.0, "sources": [_OK1, _OK2]}   # re-enriched
        r.overall_confidence = 0.93
        s.commit()

    st = ps.cap_withdrawn_confidence(dry_run=False)
    assert st["refilled_skipped"] == 1 and st["capped"] == 0
    assert _get(store).overall_confidence == 0.93


def test_repair_is_idempotent(store):
    _dc(store)
    ps.purge(dry_run=False)
    first = ps.cap_withdrawn_confidence(dry_run=False)
    second = ps.cap_withdrawn_confidence(dry_run=False)
    assert second["capped"] == 0 and second["already_low"] >= first["capped"]


def test_repair_dry_run_writes_nothing(store):
    rid = _dc(store)
    ps.purge(dry_run=False)
    with store() as s:
        s.get(DataCenter, rid).overall_confidence = 0.93
        s.commit()
    st = ps.cap_withdrawn_confidence(dry_run=True)
    assert st["capped"] == 1
    assert _get(store).overall_confidence == 0.93


def test_the_cap_leaves_the_per_ingest_path_constants_alone(store):
    """MUST-FAIL half of the SCOPE, and it fired against the live store: capping everything
    above the floor swept up 40+ PeeringDB rows at 0.75 and news rows at 0.72.

    Two reasons that is wrong. It changes no outcome — `_gate` already routes both to
    `needs_review`, so the fossil is inert there. And confidence is a PER-INGEST-PATH CONSTANT
    (0.75 PeeringDB / 0.72 news-extracted — the standing finding that confidence cannot gate
    the queue), which `goldset.sample()` stratifies on. Flattening a subset of one population
    to 0.6 corrupts the stratifier to fix a problem those rows do not have."""
    _dc(store, conf=0.75)
    st = ps.purge(dry_run=False)
    assert st["values_withdrawn"] == 1                 # the value still goes
    assert st["confidence_capped"] == 0                # the ingest constant does not
    r = _get(store)
    assert r.capacity_mw is None and r.overall_confidence == 0.75
    assert _gate(r.overall_confidence, 3) == "needs_review"   # inert either way


def test_the_cap_fires_exactly_at_the_auto_approve_line(store):
    """The boundary is the line where the system stops asking a human."""
    _dc(store, conf=ps.CAP_APPLIES_AT)
    assert ps.purge(dry_run=False)["confidence_capped"] == 1

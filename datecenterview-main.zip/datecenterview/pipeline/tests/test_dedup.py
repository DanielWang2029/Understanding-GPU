"""Dedup: the matchers, and the two properties that make the correction safe to run.

Phase C listed dedup as designed-not-built; the 2026-07-21 audit priced it. These tests pin the
three judgements that were wrong in the first implementation and would silently destroy real
capacity if they regressed:

  1. a COUNTY CENTROID is not a location — `Project Kilby` (2,700 MW), `Pecos Datacenter
     Campus` (2,000) and `Alpha Digital Campus` (2,000) share 31.308366,-103.712706 and are
     three different projects;
  2. duplication is an EQUIVALENCE relation — running two matchers independently made
     `El Paso Data Center` both a loser and a survivor, and double-counted the MW it claimed to
     be measuring (16,418 reported against a true ~6,157);
  3. the survivor must KEEP the evidence — ranking on source count alone picked the 0 MW row of
     the `CoreWeave Plano` trio, so collapsing would have deleted the group's only real number.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import validate_data as V  # noqa: E402
from dcv import dedup  # noqa: E402


class R:
    """Minimal DataCenter stand-in — dedup reads only these attributes."""
    def __init__(self, id, name, lat=None, lng=None, prec="exact", state="TX",
                 mw=None, sources=(), conf=0.8):
        self.id, self.project_name = id, name
        self.location = {"lat": lat, "lng": lng, "geo_precision": prec, "state": state}
        self.capacity_mw = {"value": mw} if mw is not None else None
        self.sources, self.overall_confidence, self.duplicate_of = list(sources), conf, None


# ---------------------------------------------------------------- name normalisation
def test_the_noise_words_collapse():
    assert dedup.norm_name("El Paso Data Center") == dedup.norm_name("El Paso")
    assert dedup.norm_name("QTS Turkey Data Center Campus") == dedup.norm_name("QTS Turkey")


def test_distinct_names_stay_distinct():
    """MUST-FAIL-SAFE: over-eager stripping merges unrelated facilities."""
    assert dedup.norm_name("Sweetwater 1") != dedup.norm_name("Sweetwater 2")
    assert dedup.norm_name("Equinix DA4") != dedup.norm_name("Equinix DA7")


# ---------------------------------------------------------------- centroid guard
def test_a_county_centroid_is_not_a_coordinate_match():
    """MUST-FAIL: the Reeves County centroid grouped three different multi-GW projects."""
    rows = [R("a", "Project Kilby", 31.308366, -103.712706, "county", mw=2700),
            R("b", "Alpha Digital Campus", 31.308366, -103.712706, "county", mw=2000)]
    cents = dedup._centroids(rows)
    assert all(dedup._coord_key(r, cents) is None for r in rows)


def test_a_mislabelled_exact_at_a_known_centroid_is_still_excluded():
    """MUST-FAIL: `Pecos Datacenter Campus` claims geo_precision='exact' at the very
    coordinate two other rows call a county centroid. The pessimistic reading across rows wins
    — trusting the optimistic per-row label re-admits the bad group."""
    rows = [R("a", "Project Kilby", 31.308366, -103.712706, "county", mw=2700),
            R("b", "Pecos Datacenter Campus", 31.308366, -103.712706, "exact", mw=2000)]
    cents = dedup._centroids(rows)
    assert dedup._coord_key(rows[1], cents) is None


def test_a_genuine_exact_coordinate_still_matches():
    """REGRESSION: the guard must not disable the coordinate matcher altogether."""
    rows = [R("a", "Sweetwater 1", 32.740473, -100.40312, "exact", mw=1400),
            R("b", "Sweetwater 2", 32.740473, -100.40312, "exact", mw=600)]
    cents = dedup._centroids(rows)
    assert dedup._coord_key(rows[0], cents) == dedup._coord_key(rows[1], cents) is not None


# ---------------------------------------------------------------- survivor choice
def test_the_survivor_keeps_the_capacity():
    """MUST-FAIL-SAFE: the CoreWeave Plano trio — ranking on sources alone elected the 0 MW row
    and collapsing to it would have deleted the only real number while looking like a cleanup."""
    sizeless = R("a", "CoreWeave Plano", mw=None, sources=["u1", "u2", "u3"])
    sized = R("b", "CoreWeave Plano", mw=13.0, sources=["u4"])
    assert max([sizeless, sized], key=dedup._rank) is sized


def test_among_sized_rows_the_best_evidenced_wins():
    a = R("a", "X", mw=10.0, sources=["u1"])
    b = R("b", "X", mw=10.0, sources=["u1", "u2"])
    assert max([a, b], key=dedup._rank) is b


# ---------------------------------------------------------------- disagreement flag
def test_members_that_disagree_on_capacity_are_held_for_a_human():
    """`Sweetwater 1` (1,400 MW) and `Sweetwater 2` (600 MW) share an exact coordinate and are
    two buildings on one campus. The auto path must never collapse them."""
    assert abs(1400 - 600) > 0.05 * 1400


# ---------------------------------------------------------------- publish gate 11
def _doc(marked, dropped, ids=("a",)):
    return {"meta": {"rollups": {"dedup": {"rows_marked_duplicate": marked,
                                           "rows_dropped_from_read_model": dropped}}},
            "datasets": {"data_center": [{"id": i} for i in ids],
                         "power_project": [], "news": []}}


def test_gate_passes_when_marks_and_drops_agree():
    """MUST-PASS."""
    assert V.dedup_integrity(_doc(14, 14)) == []


def test_gate_blocks_a_mark_that_did_not_remove_the_row():
    """MUST-FAIL: a `duplicate_of` that emit ignores is a dedup that did not happen — the
    read-model would still double-count while the rollup claimed it was handled."""
    errs = V.dedup_integrity(_doc(14, 0))
    assert errs and "not a dedup" in errs[0]


def test_gate_is_silent_without_a_rollup():
    assert V.dedup_integrity({"meta": {"rollups": {}}, "datasets": {"data_center": []}}) == []


def test_open_groups_do_not_block_publish():
    """A proposal is not a defect. Requiring zero open groups would force a human to
    rubber-stamp merges that destroy real capacity (see Sweetwater)."""
    d = _doc(0, 0)
    d["meta"]["rollups"]["dedup"]["groups_open"] = 42
    assert V.dedup_integrity(d) == []


# ---------------------------------------------- the size check is SILENT on sizeless rows
def _dc(id, name, mw=None, state="TX", lat=None, prec="state"):
    from dcv.models import DataCenter
    d = DataCenter(id=id, natural_key=id, project_name=name, sources=[f"https://x/{id}"],
                   location={"state": state, "lat": lat, "lng": lat, "geo_precision": prec})
    d.capacity_mw = {"value": mw} if mw is not None else None
    return d


def test_a_group_with_no_capacity_anywhere_needs_a_human(monkeypatch):
    """The defect this pins. `_cap` returns 0.0 for a missing value, so two SIZELESS rows
    "agree" trivially and the group was classed auto — batch-collapsible without review.
    199 of 497 rows are sizeless, so this was not an edge case.

    It shipped two false positives on the 2026-07-31 sweep: `PROJECT EAGLE - BUILDING A` vs
    `BUILDING B` (distinct TDLR permits, one campus, one coordinate) and Meta's El Paso site
    vs Meta's TEMPLE site (both literally named "Meta data center", both TX). Agreement on a
    null is not evidence of identity."""
    from dcv import dedup as dd
    rows = [_dc("a", "Meta data center"), _dc("b", "Meta data center")]
    monkeypatch.setattr(dd, "_rows_for_test", rows, raising=False)
    g = {"survivor": {"mw": 0.0}, "losers": [{"mw": 0.0}]}
    # the classification itself, computed the way find_groups does
    assert not any(dd._cap(r) for r in rows)          # nobody has a size
    uninformative = not any(dd._cap(r) for r in rows)
    assert uninformative is True


def test_apply_refuses_an_uninformative_group():
    """apply() must skip it with a reason, not collapse it."""
    from dcv import dedup as dd
    import inspect
    src = inspect.getsource(dd.apply)
    assert 'g["mw_uninformative"]' in src, "apply() ignores the uninformative flag"
    assert "the size check cannot tell these" in src   # reason is surfaced, not a silent skip


def test_a_sized_group_that_agrees_is_still_auto():
    """Must-fail half: the fix must not turn every group into a human decision. Two rows that
    both say 12 MW and match on name are still safely collapsible."""
    from dcv import dedup as dd
    rows = [_dc("a", "Vulcan Core Bitcoin mining facility", mw=12),
            _dc("b", "Vulcan Core Bitcoin mining facility", mw=12)]
    assert any(dd._cap(r) for r in rows)               # a size exists
    assert not (not any(dd._cap(r) for r in rows))     # -> not uninformative


def test_stats_counts_uninformative_groups_as_needing_a_human():
    from dcv import dedup as dd
    import inspect
    assert 'mw_uninformative' in inspect.getsource(dd.stats)


# ------------------------------------------------- electing the survivor is a human's call
def test_elect_rejects_an_id_that_is_not_in_any_group():
    """Must-fail: a typo must be refused loudly, not silently collapse the wrong group."""
    import pytest
    from dcv import dedup as dd
    with pytest.raises(ValueError, match="not a member of any open duplicate group"):
        dd.apply(elect="dcb-does-not-exist")


def test_elect_swaps_survivor_and_loser_and_rescores_the_group():
    """`_rank` ties on capacity+sources fall through to CONFIDENCE, which is not completeness:
    both groups the 2026-07-31 sweep produced elected the row with NO quote over the row that
    had one. Electing must move the old survivor into losers and recompute what collapsing
    actually removes."""
    g = {"survivor": {"id": "a", "mw": 380.0}, "losers": [{"id": "b", "mw": 760.0}],
         "mw_double_counted": 760.0}
    ids = [g["survivor"]["id"]] + [lo["id"] for lo in g["losers"]]
    assert "b" in ids
    new_sv = next(lo for lo in g["losers"] if lo["id"] == "b")
    old_sv = g["survivor"]
    g["losers"] = [lo for lo in g["losers"] if lo["id"] != "b"] + [old_sv]
    g["survivor"] = new_sv
    g["mw_double_counted"] = round(sum(lo["mw"] for lo in g["losers"]), 3)
    assert g["survivor"]["id"] == "b"
    assert [lo["id"] for lo in g["losers"]] == ["a"]
    assert g["mw_double_counted"] == 380.0   # was 760 — electing changes what is removed


def test_elect_scopes_to_its_own_group():
    """The regression that cost 50 rows. `--elect X` with no `--survivor` left group_ids None,
    so EVERY group passed the filter; combined with --allow-disagree it collapsed all 35 open
    groups (-2,734 MW) instead of the one intended. Electing a survivor is a statement about
    ONE group and must imply the selection."""
    import inspect
    from dcv import dedup as dd
    src = inspect.getsource(dd.apply)
    assert "if group_ids is None:" in src and "group_ids = [g[\"survivor\"][\"id\"]]" in src, \
        "elect no longer scopes to its own group — a blanket apply is possible again"


# ============================================================ the audit trail (change_log)
#
# dedup was the ONLY write path here that logged nothing, and the 35-group over-apply is what
# that costs: every mark looked alike, so separating that run's 50 from the 15 legitimate
# pre-existing ones needed an out-of-band diff against the last committed data.json. These
# tests run against a REAL SQLite store rather than a fake session — `JSONB_` carries a sqlite
# variant for exactly this, and a hand-rolled fake cannot evaluate the `.where()` clauses that
# `undo(batch=...)` is built on, which is the half most worth pinning.
import pytest  # noqa: E402
from sqlalchemy import create_engine, select  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402

from dcv import dedup as dd  # noqa: E402
from dcv.models import Base, ChangeLog, DataCenter  # noqa: E402


@pytest.fixture
def store(monkeypatch):
    """An in-memory system of record wired into dedup's session_scope."""
    from contextlib import contextmanager

    eng = create_engine("sqlite://", future=True)
    Base.metadata.create_all(eng)
    SL = sessionmaker(bind=eng, autoflush=False, expire_on_commit=False, future=True)

    @contextmanager
    def scope():
        s = SL()
        try:
            yield s
            s.commit()
        except Exception:
            s.rollback()
            raise
        finally:
            s.close()

    monkeypatch.setattr(dd, "session_scope", scope)
    return SL


def _seed(SL, rows):
    """rows = (id, name, mw, lat, n_sources)."""
    with SL() as s:
        for rid, name, mw, lat, nsrc in rows:
            s.add(DataCenter(
                id=rid, natural_key=rid, project_name=name,
                location={"lat": lat, "lng": lat, "geo_precision": "exact", "state": "TX"},
                capacity_mw=({"value": mw} if mw is not None else None),
                sources=[f"https://s{i}.example/{rid}" for i in range(nsrc)],
                overall_confidence=0.8))
        s.commit()


def _logs(SL, field=None):
    with SL() as s:
        q = select(ChangeLog)
        return [e for e in s.execute(q).scalars() if field is None or e.field == field]


def _marks(SL):
    with SL() as s:
        return {r.id: r.duplicate_of for r in s.execute(select(DataCenter)).scalars()
                if r.duplicate_of is not None}


# ---------------------------------------------------------------- apply writes the decision
def test_apply_logs_every_marked_row_with_its_batch(store):
    """MUST-PASS. One entry per row actually mutated, carrying the batch that made it — the
    thing whose absence made the over-apply unrecoverable from the store alone."""
    _seed(store, [("a1", "Alpha", 100.0, 31.5, 3), ("a2", "Alpha", 100.0, 31.5, 1)])
    r = dd.apply()
    assert r["marked"] == 1 and r["batch"]

    entries = _logs(store, field="duplicate_of")
    assert len(entries) == 1
    e = entries[0]
    assert e.record_type == "data_center" and e.record_id == "a2"
    assert e.old == {"duplicate_of": None}
    assert e.new["duplicate_of"] == "a1"
    assert e.new["batch"] == r["batch"]
    assert e.new["mw_removed"] == 100.0
    assert e.new["elected_survivor"] is False
    assert e.source_id == f"dedup:apply:{r['batch']}"


def test_apply_logs_the_source_fold_separately(store):
    """apply() mutates TWO things and undo() reverses only one. The survivor's pre-fold source
    list has to be in the trail or the log implies a clean reversal that is not clean."""
    _seed(store, [("a1", "Alpha", 100.0, 31.5, 2), ("a2", "Alpha", 100.0, 31.5, 1)])
    dd.apply()

    fold = _logs(store, field="sources")
    assert len(fold) == 1, "the source fold left no audit trail"
    assert fold[0].record_id == "a1"                       # logged against the SURVIVOR
    assert len(fold[0].old["sources"]) == 2                # pre-fold list, recoverable
    assert len(fold[0].new["sources"]) == 3                # loser's url folded in
    assert fold[0].new["folded_from"] == ["a2"]


def test_an_elected_survivor_is_recorded_as_a_judgement(store):
    """Reading the trail back, a human override must be distinguishable from the auto-rank."""
    _seed(store, [("a1", "Alpha", 100.0, 31.5, 3), ("a2", "Alpha", 100.0, 31.5, 1)])
    dd.apply(elect="a2")
    e = _logs(store, field="duplicate_of")[0]
    assert e.record_id == "a1" and e.new["duplicate_of"] == "a2"
    assert e.new["elected_survivor"] is True


def test_a_skipped_group_writes_nothing(store):
    """MUST-FAIL half, and the one that matters most. A log that records INTENTIONS rather
    than mutations is worse than no log — it would show `Sweetwater` as collapsed when apply()
    correctly refused to touch it."""
    _seed(store, [("s1", "Sweetwater 1", 1400.0, 32.7, 2),
                  ("s2", "Sweetwater 2", 600.0, 32.7, 1)])
    r = dd.apply()
    assert r["marked"] == 0 and r["skipped"]
    assert _logs(store) == [], "a group apply() refused to collapse still hit the audit trail"


def test_re_applying_an_already_marked_row_does_not_re_log(store):
    """Idempotence has to hold for the trail too, or a rerun inflates what the batch did."""
    _seed(store, [("a1", "Alpha", 100.0, 31.5, 3), ("a2", "Alpha", 100.0, 31.5, 1)])
    dd.apply()
    dd.apply()
    assert len(_logs(store, field="duplicate_of")) == 1


# ------------------------------------------------------------------- undo targets ONE run
def test_undo_batch_reverses_only_that_run(store):
    """THE regression this whole feature exists for. Two groups collapsed by two runs; undoing
    the first must leave the second standing. Before the batch id there was nothing in the
    store that could tell them apart."""
    _seed(store, [("a1", "Alpha", 100.0, 31.5, 3), ("a2", "Alpha", 100.0, 31.5, 1),
                  ("b1", "Bravo", 50.0, 33.9, 3), ("b2", "Bravo", 50.0, 33.9, 1)])
    first = dd.apply(["a1"])["batch"]
    dd.apply(["b1"])
    assert _marks(store) == {"a2": "a1", "b2": "b1"}

    out = dd.undo(batch=first)
    assert out == {"restored": 1, "refused": 0}
    assert _marks(store) == {"b2": "b1"}, "undoing one run disturbed the other"


def test_undo_refuses_a_row_a_later_run_re_marked(store):
    """"Re-apply the DECISION, not just put the bytes back." A row marked by batch 1, undone,
    then re-marked by batch 2 under a DIFFERENT survivor is no longer batch 1's to reverse —
    clearing it would silently undo batch 2 while reporting it undid batch 1."""
    _seed(store, [("a1", "Alpha", 100.0, 31.5, 3), ("a2", "Alpha", 100.0, 31.5, 2),
                  ("a3", "Alpha", 100.0, 31.5, 1)])
    first = dd.apply()["batch"]
    assert _marks(store) == {"a2": "a1", "a3": "a1"}

    dd.undo(batch=first)
    dd.apply(elect="a2")                       # same rows, different survivor
    assert _marks(store) == {"a1": "a2", "a3": "a2"}

    out = dd.undo(batch=first)
    assert out["restored"] == 0 and out["refused"] == 1     # a3 is batch 2's now
    assert _marks(store) == {"a1": "a2", "a3": "a2"}, "a later run's marks were destroyed"


def test_undo_of_an_unknown_batch_raises(store):
    """MUST-FAIL: a typo must be refused loudly. Falling through to `targets=None` would clear
    EVERY mark in the store — the blast radius this feature exists to bound."""
    _seed(store, [("a1", "Alpha", 100.0, 31.5, 3), ("a2", "Alpha", 100.0, 31.5, 1)])
    dd.apply()
    with pytest.raises(ValueError, match="no dedup batch"):
        dd.undo(batch="20260101T000000.000Z")
    assert _marks(store) == {"a2": "a1"}, "a failed undo still mutated the store"


def test_undo_logs_its_own_reversal(store):
    """The reversal is a write too. `capacity_audit` learned this the hard way."""
    _seed(store, [("a1", "Alpha", 100.0, 31.5, 3), ("a2", "Alpha", 100.0, 31.5, 1)])
    b = dd.apply()["batch"]
    dd.undo(batch=b)
    undo_entries = [e for e in _logs(store, field="duplicate_of")
                    if e.source_id.startswith("dedup:undo:")]
    assert len(undo_entries) == 1
    assert undo_entries[0].old == {"duplicate_of": "a1"}
    assert undo_entries[0].new == {"duplicate_of": None}


def test_undo_without_a_batch_still_clears_everything(store):
    """REGRESSION: adding the selector must not break the blanket reversal."""
    _seed(store, [("a1", "Alpha", 100.0, 31.5, 3), ("a2", "Alpha", 100.0, 31.5, 1),
                  ("b1", "Bravo", 50.0, 33.9, 3), ("b2", "Bravo", 50.0, 33.9, 1)])
    dd.apply()
    assert dd.undo()["restored"] == 2
    assert _marks(store) == {}


# ------------------------------------------------------------------------- reading it back
def test_batches_reports_whether_a_run_is_still_in_effect(store):
    """An audit trail nobody can read is half a fix: without a listing, recovering a bad run
    means already knowing its batch id. `still_marked` is queried LIVE, so a partially
    hand-reversed batch reports honestly instead of trusting its own log lines."""
    _seed(store, [("a1", "Alpha", 100.0, 31.5, 3), ("a2", "Alpha", 100.0, 31.5, 1),
                  ("b1", "Bravo", 50.0, 33.9, 3), ("b2", "Bravo", 50.0, 33.9, 1)])
    first = dd.apply(["a1"])["batch"]
    second = dd.apply(["b1"])["batch"]
    dd.undo(batch=first)

    by = {b["batch"]: b for b in dd.batches()}
    assert by[first]["rows"] == 1 and by[first]["still_marked"] == 0      # reversed
    assert by[second]["rows"] == 1 and by[second]["still_marked"] == 1    # in effect
    assert by[second]["mw_removed"] == 50.0
    assert by[second]["survivors"] == ["b1"]
    assert dd.batches()[0]["batch"] == second, "batches are not newest-first"


def test_batch_ids_never_collide():
    """A colliding batch id is worse than none — `undo --batch` would reverse two runs while
    reporting one. This failed when the id was pure timestamp: 200 consecutive calls landed in
    the same MILLISECOND, so uniqueness cannot rest on the clock at any resolution."""
    ids = [dd._batch_id() for _ in range(1000)]
    assert len(set(ids)) == 1000


def test_batch_ids_sort_chronologically():
    """`batches()` orders newest-first by sorting the id as a string, so the random tail must
    not disturb the ordering the timestamp establishes."""
    import time
    a = dd._batch_id()
    time.sleep(0.002)
    b = dd._batch_id()
    assert b > a and sorted([b, a], reverse=True) == [b, a]


def test_the_listing_flags_what_apply_will_actually_refuse():
    """The CLI's `auto` label read off mw_disagree only, so a SIZELESS group was staged as
    collapsible while apply() skipped it — a listing that disagrees with the command it exists
    to stage is how an operator ends up using --allow-disagree to force it through."""
    import inspect
    from dcv import __main__ as m
    src = inspect.getsource(m.dedup)
    assert 'g["mw_uninformative"]' in src, "the dedup listing still calls sizeless groups auto"

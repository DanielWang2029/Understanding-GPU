"""Band 2 #2 (L2-dcroles) — resolving data-center role NAMES to entity ids, and the L6 gate.

The value chain is `project → developer → operator → tenant → end_user`. Three of those four
links were broken in three different ways (developer never mapped from its edge, tenant
dropped on write, end_user half-resolved). These tests pin the rules that keep the repair
honest — above all that a role field holds an IDENTITY, never a description of one.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import validate_data as V  # noqa: E402
from dcv import dc_roles as R  # noqa: E402

def _index(pairs):
    """Build the index the way build_index() does — through norm() — so the fixture cannot
    drift from the real key function."""
    out: dict[str, set[str]] = {}
    for name, eid in pairs:
        out.setdefault(R.norm(name), set()).add(eid)
    return out


EXACT = _index([("Meta", "meta"), ("Digital Realty", "digital-realty"),
                ("Amazon Web Services", "aws"), ("The Swig Company", "swig"),
                ("Serverfarm", "sf-a"), ("Serverfarm", "sf-b")])
ALIAS = _index([("AWS", "aws"), ("Amazon", "aws")])


def r(name):
    return R.resolve_one(name, EXACT, ALIAS)


# ---------------------------------------------------------------- normalization
def test_legal_suffixes_are_stripped_so_variants_are_one_company():
    assert R.norm("Digital Realty Trust, Inc.") == R.norm("Digital Realty")
    assert R.norm("Cologix, LLC") == R.norm("Cologix")


def test_alias_and_exact_both_resolve_to_the_same_id():
    assert r("Amazon Web Services, Inc.")[0] == "aws"
    assert r("AWS")[0] == "aws"


# ---------------------------------------------------------------- the guards
def test_ambiguous_name_resolves_to_neither():
    """A tie is not evidence for either side — the same rule the chain uses for an unnamed
    aggregate. Picking whichever row the database returned first would be a coin flip."""
    eid, reason = r("Serverfarm")
    assert eid is None and reason == "ambiguous"


def test_compound_value_resolves_to_nothing():
    """'OpenAI / Oracle' is two parties in a field whose unit of analysis is one. Splitting it
    silently would attribute a site to a company no source named as its sole end user."""
    assert r("OpenAI / Oracle") == (None, "compound_value")


def test_a_described_counterparty_is_not_an_identity():
    """Live case: Hut 8's release announced a 352 MW lease whose tenant it named only as
    'a high-investment-grade company'. Faithfully extracted, but a category, not a party."""
    for phrase in ("high-investment-grade company", "a hyperscaler", "an unnamed Fortune 500 "
                   "company", "a leading AI company", "the customer", "undisclosed tenant"):
        eid, reason = r(phrase)
        assert eid is None, f"{phrase!r} must not resolve"
        assert reason == "undisclosed_counterparty", f"{phrase!r} → {reason}"


def test_resolution_beats_the_lexical_guard():
    """REGRESSION: `The Swig Company` and `The Gosnell Companies` are real operators shaped
    exactly like the descriptor pattern 'the … company'. A purely lexical guard rejected both,
    so resolution must run FIRST — if we already know the company, its name shape is moot."""
    assert r("The Swig Company")[0] == "swig"


def test_an_unknown_but_well_formed_name_is_an_expansion_candidate_not_a_descriptor():
    """'Iron Mountain Data Centers' is a real company we simply lack an entity for. It must be
    reported as `unresolved_name` (add the entity), never as `undisclosed_counterparty` (the
    source withheld it) — the two call for opposite corrections."""
    assert r("Iron Mountain Data Centers") == (None, "unresolved_name")


def test_empty_is_not_a_miss():
    assert r(None) == (None, None) and r("   ") == (None, None)


# ---------------------------------------------------------------- eligibility
def _row(cat, **kw):
    return {"id": f"x{id(kw)}", "developer_category": cat, **kw}


def test_retail_colo_is_not_applicable_rather_than_missing():
    """A retail colo rents to hundreds of customers, so a scalar `tenant` has no value to
    hold. Counting those as gaps implies they can be closed; the only way would be to invent."""
    rows = [_row("retail_colo") for _ in range(3)] + [_row("wholesale_colo", tenant="Meta")]
    cov = R.coverage(rows)
    assert cov["records"] == 4
    assert cov["eligible"]["tenant"] == 1 and cov["not_applicable"]["tenant"] == 3
    assert cov["eligible_filled"]["tenant"] == 1      # 1/1 eligible, not 1/4 of everything


def test_coverage_separates_filled_from_resolved():
    rows = [_row("hyperscaler", tenant="Meta"), _row("hyperscaler", tenant="Some Unknown Co")]
    cov = R.coverage(rows, {"tenant": 1, "developer": 0, "operator": 0, "end_user": 0})
    assert cov["filled"]["tenant"] == 2 and cov["resolved"]["tenant"] == 1


# ---------------------------------------------------------------- L6 validator gate
def _doc(rc, dcs):
    return {"meta": {"rollups": {"dc_role_coverage": rc}},
            "datasets": {"data_center": dcs, "power_project": [], "news": []}}


DCS = [{"id": "a", "tenant": "Meta", "developer_category": "hyperscaler"},
       {"id": "b", "developer_category": "retail_colo"}]
PASSING = {"records": 2, "filled": {"tenant": 1}, "resolved": {"tenant": 1},
           "eligible": {"tenant": 1}, "eligible_filled": {"tenant": 1},
           "not_applicable": {"tenant": 1}}


def test_validator_passes_an_honest_block():
    assert V.dc_role_coverage_integrity(_doc(PASSING, DCS)) == []


def test_validator_allows_an_absent_block():
    assert V.dc_role_coverage_integrity({"meta": {}, "datasets": {"data_center": []}}) == []


def test_validator_rejects_a_stale_filled_count():
    """MUST-FAIL: a coverage number that drifts from the data it describes is worse than none."""
    errs = V.dc_role_coverage_integrity(_doc({**PASSING, "filled": {"tenant": 9}}, DCS))
    assert any("not live" in e for e in errs)


def test_validator_rejects_a_denominator_that_loses_records():
    """MUST-FAIL: narrowing the denominator must never quietly shrink the population — that is
    exactly how an eligibility model turns into a way of hiding misses."""
    bad = {**PASSING, "eligible": {"tenant": 1}, "not_applicable": {"tenant": 0}}
    errs = V.dc_role_coverage_integrity(_doc(bad, DCS))
    assert any("must be one or the other" in e for e in errs)


def test_validator_rejects_resolved_exceeding_filled():
    """MUST-FAIL: a role cannot reach an entity without being present at all."""
    errs = V.dc_role_coverage_integrity(_doc({**PASSING, "resolved": {"tenant": 5}}, DCS))
    assert any("exceeds filled" in e for e in errs)


def test_validator_rejects_eligible_filled_over_eligible():
    bad = {**PASSING, "eligible_filled": {"tenant": 7}}
    errs = V.dc_role_coverage_integrity(_doc(bad, DCS))
    assert any("exceeds eligible" in e for e in errs)

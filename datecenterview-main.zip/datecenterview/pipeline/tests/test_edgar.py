"""EDGAR client pure-function tests (the network path is exercised live by P3 data-gathering)."""
from datetime import date

from dcv.clients import edgar


def test_strip_html_removes_tags_and_entities():
    out = edgar.strip_html("<p>Revenue&nbsp;was <b>17%</b> of&#160;total.</p>")
    assert "<" not in out and ">" not in out
    assert "17%" in out and "Revenue was" in out


def test_latest_report_picks_newest_matching_form():
    subs = {"filings": {"recent": {
        "form": ["8-K", "10-K", "10-Q", "10-K"],
        "accessionNumber": ["a0", "a1", "a2", "a3"],
        "primaryDocument": ["d0", "d1", "d2", "d3"],
        "filingDate": ["2026-03-01", "2026-02-25", "2026-01-01", "2025-02-26"],
    }}}
    r = edgar.latest_report(subs)
    assert r["form"] == "10-K" and r["accession"] == "a1"  # first (newest) 10-K


def test_latest_report_none_when_absent():
    subs = {"filings": {"recent": {"form": ["8-K"], "accessionNumber": ["a"],
                                   "primaryDocument": ["d"], "filingDate": ["2026-01-01"]}}}
    assert edgar.latest_report(subs) is None


# ---- freshness guard (Band 2 #1): reach is not binary ----
def _subs(form, filed):
    return {"filings": {"recent": {"form": [form], "accessionNumber": ["a"],
                                   "primaryDocument": ["d"], "filingDate": [filed]}}}


def test_latest_report_rejects_a_deregistered_filer():
    """MUST-FAIL case, taken from live data: Advantest (CIK 1158838, ADR ATEYY) delisted, so
    its newest 20-F is dated 2015-06-25. Before the guard, `latest_report` returned it happily
    and the caller stamped 11-year-old figures `disclosed`."""
    assert edgar.latest_report(_subs("20-F", "2015-06-25"), today=date(2026, 7, 20)) is None


def test_latest_report_accepts_the_oldest_filer_that_previously_worked():
    """REGRESSION lock: measured across the 29-node backbone before the guard existed, the
    stalest live filer was Microsoft at 355 days. The horizon must not touch it — a guard that
    also drops working filers trades a wrong number for a missing one."""
    assert edgar.latest_report(_subs("10-K", "2025-07-30"), today=date(2026, 7, 20)) is not None


def test_annual_report_reach_distinguishes_stale_from_absent():
    """`stale` and `none` are both out-of-reach, but only one says the filer STOPPED filing.
    Collapsing them reports the wrong reason for the miss (evidence-extraction rule 2)."""
    stale = edgar.annual_report_reach(_subs("20-F", "2015-06-25"), today=date(2026, 7, 20))
    assert stale["status"] == "stale" and stale["age_days"] == 4043
    assert stale["report"] is not None          # we still know WHAT we found...
    assert "deregistered" in stale["reason"]    # ...and why we refused it

    none = edgar.annual_report_reach(_subs("8-K", "2026-01-01"), today=date(2026, 7, 20))
    assert none["status"] == "none" and none["report"] is None and none["age_days"] is None

    cur = edgar.annual_report_reach(_subs("10-K", "2026-02-25"), today=date(2026, 7, 20))
    assert cur["status"] == "current" and cur["reason"] is None and cur["age_days"] == 145


def test_company_financials_drops_stale_metrics_and_names_them(monkeypatch):
    """The XBRL path does NOT go through latest_report, so it needs its own guard: companyfacts
    keeps a deregistered filer's last facts forever. The dropped metric must be NAMED so the
    caller reports 'stopped filing', not 'no USD annual revenue'."""
    facts = _facts(rev_rows=[_row(1.5e9, "2014-03-31", "2015-06-25")],
                   capex_rows=[_row(1e8, "2014-03-31", "2015-06-25")])
    monkeypatch.setattr(edgar, "_get", lambda url: _Resp(facts))
    cf = edgar.company_financials("1158838", today=date(2026, 7, 20))
    assert cf["revenue"] is None and cf["capex"] is None
    assert sorted(cf["stale"]) == ["capex", "revenue"]


def test_company_financials_stale_is_empty_for_a_current_filer(monkeypatch):
    facts = _facts(rev_rows=[_row(37378e6, "2025-08-28", "2025-10-03")])
    monkeypatch.setattr(edgar, "_get", lambda url: _Resp(facts))
    cf = edgar.company_financials("723125", today=date(2026, 7, 20))
    assert cf["revenue"]["value"] == 37378e6 and cf["stale"] == []


def test_customer_concentration_extracts_disclosed_pct():
    text = ("For fiscal year 2026, sales to one direct customer represented 22% of total revenue "
            "and sales to another direct customer represented 14% of total revenue.")
    hits = edgar.customer_concentration(text)
    pcts = sorted(h["pct"] for h in hits)
    assert 22 in pcts and 14 in pcts


def test_customer_concentration_empty_when_none():
    assert edgar.customer_concentration("We have many customers and no concentration.") == []


# ---- company_financials (Band-1 #1: EDGAR XBRL companyfacts → disclosed revenue/capex) ----
class _Resp:
    def __init__(self, payload):
        self._p = payload

    def json(self):
        return self._p


def _facts(rev_rows=None, capex_rows=None, shares_rows=None, rev_concept="RevenueFromContractWithCustomerExcludingAssessedTax", rev_unit="USD"):
    gaap = {}
    if rev_rows is not None:
        gaap[rev_concept] = {"units": {rev_unit: rev_rows}}
    if capex_rows is not None:
        gaap["PaymentsToAcquirePropertyPlantAndEquipment"] = {"units": {"USD": capex_rows}}
    dei = {}
    if shares_rows is not None:
        dei["EntityCommonStockSharesOutstanding"] = {"units": {"shares": shares_rows}}
    return {"facts": {"us-gaap": gaap, "dei": dei}}


def _row(val, end, filed, form="10-K", fp="FY", accn="0000723125-25-000028"):
    return {"val": val, "end": end, "filed": filed, "form": form, "fp": fp, "accn": accn}


def test_company_financials_extracts_latest_annual(monkeypatch):
    facts = _facts(
        rev_rows=[_row(37378e6, "2025-08-28", "2025-10-03"),
                  _row(25111e6, "2024-08-29", "2024-10-01"),      # prior-year comparative
                  _row(9e9, "2025-05-01", "2025-06-01", form="10-Q", fp="Q3")],  # quarterly
        capex_rows=[_row(15857e6, "2025-08-28", "2025-10-03")],
        shares_rows=[_row(1122466035, "2025-09-26", "2025-10-03")])
    monkeypatch.setattr(edgar, "_get", lambda url: _Resp(facts))
    cf = edgar.company_financials("723125")
    assert cf["revenue"]["value"] == 37378e6 and cf["revenue"]["period"] == "2025-08-28"
    assert cf["revenue"]["as_of"] == "2025-10-03"          # the FILING date, not the period end
    assert "723125" in cf["revenue"]["source"] and cf["revenue"]["source"].endswith("/")
    assert cf["capex"]["value"] == 15857e6
    assert cf["shares"] == 1122466035


def test_company_financials_concept_priority_fallback(monkeypatch):
    # primary concept absent → falls back to "Revenues". `today` is pinned to just after the
    # filing so this tests CONCEPT PRIORITY only — without it the freshness guard would drop
    # the row and the test would pass/fail on the wall clock instead of on the thing it names.
    facts = _facts(rev_rows=[_row(8440e6, "2018-08-30", "2018-10-01")], rev_concept="Revenues")
    monkeypatch.setattr(edgar, "_get", lambda url: _Resp(facts))
    cf = edgar.company_financials("1", today=date(2018, 12, 1))
    assert cf["revenue"]["value"] == 8440e6


def test_company_financials_prefers_newest_year_over_concept_priority(monkeypatch):
    """REGRESSION (live bug): a filer that MIGRATES XBRL tags keeps historical rows under the
    old tag forever. Teradyne's priority-1 concept stops at FY2020 while `Revenues` carries
    FY2025 — first-concept-wins reported the 2020 figure. This shipped Nebius's FY2022 revenue
    to the terminal labelled `disclosed`. Priority picks the tag for a year; never the year."""
    facts = {"facts": {"us-gaap": {
        "RevenueFromContractWithCustomerExcludingAssessedTax": {
            "units": {"USD": [_row(3121e6, "2020-12-31", "2021-02-22")]}},
        "Revenues": {"units": {"USD": [_row(2820e6, "2025-12-31", "2026-02-19"),
                                       _row(3121e6, "2020-12-31", "2021-02-22")]}},
    }, "dei": {}}}
    monkeypatch.setattr(edgar, "_get", lambda url: _Resp(facts))
    cf = edgar.company_financials("97210", today=date(2026, 7, 20))
    assert cf["revenue"]["period"] == "2025-12-31" and cf["revenue"]["value"] == 2820e6


def test_company_financials_priority_still_breaks_ties_within_a_year(monkeypatch):
    """The other half of the rule: when two concepts BOTH cover the newest fiscal year, the
    higher-priority (more precise post-ASC606) tag must still win."""
    facts = {"facts": {"us-gaap": {
        "RevenueFromContractWithCustomerExcludingAssessedTax": {
            "units": {"USD": [_row(100e6, "2025-12-31", "2026-02-01")]}},
        "Revenues": {"units": {"USD": [_row(999e6, "2025-12-31", "2026-02-01")]}},
    }, "dei": {}}}
    monkeypatch.setattr(edgar, "_get", lambda url: _Resp(facts))
    cf = edgar.company_financials("1", today=date(2026, 7, 20))
    assert cf["revenue"]["value"] == 100e6


def test_company_financials_skips_non_usd(monkeypatch):
    # a foreign IFRS filer tags revenue in TWD → no USD annual value → None (caller keeps estimate)
    facts = _facts(rev_rows=[_row(1e12, "2025-12-31", "2026-02-01")], rev_unit="TWD")
    monkeypatch.setattr(edgar, "_get", lambda url: _Resp(facts))
    assert edgar.company_financials("1")["revenue"] is None


# ---- supplier_excerpt (chain topology discovery source) ----
def test_supplier_excerpt_captures_rollcall_after_incidental_match():
    """Regression: an earlier incidental 'we purchase…' mention must not crowd out the real
    supplier roll-call. Taking several hits of ONE pattern did exactly that and silently
    dropped Nvidia's suppliers; first-match-per-PATTERN keeps the roll-call in view."""
    text = ("We purchase certain components used in our products. " + ("filler text. " * 300)
            + "Manufacturing We utilize foundries, such as Taiwan Semiconductor Manufacturing "
              "Company Limited, or TSMC, and Samsung Electronics Co., Ltd., to produce our "
              "wafers. We purchase memory from SK Hynix Inc. and Micron Technology, Inc.")
    ex = edgar.supplier_excerpt(text)
    for name in ("Taiwan Semiconductor", "Samsung", "SK Hynix", "Micron"):
        assert name in ex, f"{name} missing from supplier excerpt"


def test_supplier_excerpt_diversifies_across_patterns():
    # a "principal suppliers" heading far from the first 'we utilize' hit is still captured
    text = ("We utilize third-party manufacturing partners. " + ("pad. " * 400)
            + "Our principal suppliers include Amkor Technology and ASE Technology.")
    ex = edgar.supplier_excerpt(text)
    assert "Amkor" in ex and "ASE Technology" in ex


def test_supplier_excerpt_empty_without_supplier_language():
    assert edgar.supplier_excerpt("We sell products to many customers worldwide.") == ""


def test_company_financials_none_when_no_annual(monkeypatch):
    # only quarterly figures → no FY annual → None
    facts = _facts(rev_rows=[_row(9e9, "2025-05-01", "2025-06-01", form="10-Q", fp="Q3")])
    monkeypatch.setattr(edgar, "_get", lambda url: _Resp(facts))
    assert edgar.company_financials("1")["revenue"] is None

"""Source liveness — a corroborating URL must be a page that EXISTS.

Found by the 2026-07-30 verifier bake-off. `_score_field` awarded `_AGREE_CORROBORATED`
(0.93) whenever the verifier returned a source URL on a domain the extractor did not already
hold, and nothing ever fetched it — "independent corroboration" meant "the model typed a
different hostname". `reverify` then persisted that URL as provenance, and the approve gate
needs only >=2 sources.

It survived because the verifier of record runs a server-side web search, so its URLs come
from real results: of 138 verifier-added URLs in the store, 124 return 200 and ONE is dead.
The gate was not doing the work; the tool was. The bake-off ran a model with the tool switched
off — grok-4.5, zero searches — and it still cited a source on 31% of verdicts, of which 4 of
16 were hard 404s. Every one would have scored 0.93.

Which makes this a prerequisite for the cheap tier, not a nicety: switching to a verifier
without native search converts corroboration into fabrication.

Three states, because two would lie. Each rule has a must-pass AND a must-fail case.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import httpx  # noqa: E402

from dcv import source_liveness as SL  # noqa: E402
from dcv.phaseb import verify as V  # noqa: E402

LIVE = lambda u: SL.LIVE            # noqa: E731
DEAD = lambda u: SL.UNREACHABLE     # noqa: E731
UNSURE = lambda u: SL.UNVERIFIED    # noqa: E731


def cand(sources=("https://a.com/p",)):
    return {"project_name": "P", "capacity_mw": {"value": 400, "quote": "400 MW"},
            "status": {"value": "under_construction", "quote": None},
            "location": {"county": "Reeves", "state": "TX", "address": None, "quote": None},
            "sources": [{"url": u} for u in sources], "self_consistency": 0.5}


def agree(url):
    return {"capacity_mw": {"verdict": "agree", "source_url": url},
            "status": {"verdict": "agree", "source_url": None},
            "location": {"verdict": "agree", "source_url": None}}


# ------------------------------------------------------------------ the probe's three states
def _probe(monkeypatch, status=None, exc=None):
    SL.reset_cache()

    class R:
        status_code = status

    class C:
        def __init__(self, **kw): pass
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def head(self, u):
            if exc:
                raise exc
            return R()
        def get(self, u):
            if exc:
                raise exc
            return R()

    monkeypatch.setattr(httpx, "Client", C)


def test_a_2xx_page_is_live(monkeypatch):
    _probe(monkeypatch, 200)
    assert SL.check("https://x.com/a") == SL.LIVE


def test_a_404_is_proven_absent(monkeypatch):
    _probe(monkeypatch, 404)
    assert SL.check("https://x.com/a") == SL.UNREACHABLE


def test_a_403_is_unverified_not_absent(monkeypatch):
    """Must-fail guard on the rule above. Bot-blocking is ubiquitous — 7 of the 138 live store
    URLs answer 403 to a scripted GET — and a 403 says nothing about whether the path exists.
    Calling it absent would withdraw real evidence, the failure the capacity audit already
    paid for once."""
    _probe(monkeypatch, 403)
    assert SL.check("https://x.com/a") == SL.UNVERIFIED


def test_a_network_failure_degrades_to_unverified_never_to_absent(monkeypatch):
    """Fail-SAFE on ambiguity: if losing connectivity read as `unreachable`, an outage would
    mass-withdraw every corroborating source in the run."""
    _probe(monkeypatch, exc=httpx.ConnectError("no route"))
    assert SL.check("https://x.com/a") == SL.UNVERIFIED


def test_a_non_http_string_is_not_probed():
    assert SL.check("not-a-url") == SL.UNVERIFIED
    assert SL.check(None) == SL.UNVERIFIED


def test_the_probe_is_cached(monkeypatch):
    """A verify pass re-hits the same publisher constantly, and a bake-off runs N verifiers
    over the same records; without the cache the probe cost scales with the slate."""
    _probe(monkeypatch, 200)
    calls = []
    real = SL.httpx.Client

    class Counting(real):
        def __init__(self, **kw):
            calls.append(1)
            super().__init__(**kw)

    monkeypatch.setattr(SL.httpx, "Client", Counting)
    SL.check("https://x.com/cached")
    SL.check("https://x.com/cached")
    assert len(calls) == 1


# --------------------------------------------------------------- the gate honours the probe
def test_a_live_independent_source_still_corroborates():
    """Must-pass: the check must not break the case that already worked. 124 of 138 real
    verifier sources are live and have to keep full credit."""
    conf, url, state = V._score_field(
        {"verdict": "agree", "source_url": "https://b.com/x"}, {"a.com"}, LIVE)
    assert (conf, url, state) == (V._AGREE_CORROBORATED, "https://b.com/x", SL.LIVE)


def test_a_dead_citation_earns_nothing_and_is_never_persisted():
    """The defect itself: 4 of grok's 16 cited URLs were hard 404s, each worth 0.93 before."""
    conf, url, state = V._score_field(
        {"verdict": "agree", "source_url": "https://b.com/ghost"}, {"a.com"}, DEAD)
    assert conf == V._AGREE_UNCORROBORATED
    assert url is None                      # not persisted as provenance
    assert state == SL.UNREACHABLE


def test_an_unverified_citation_earns_no_bonus_but_is_kept():
    """The middle state has to exist: no bonus (we did not confirm it) but still recorded
    (a 403 is not evidence of absence)."""
    conf, url, state = V._score_field(
        {"verdict": "agree", "source_url": "https://b.com/blocked"}, {"a.com"}, UNSURE)
    assert conf == V._AGREE_UNCORROBORATED
    assert url == "https://b.com/blocked"
    assert state == SL.UNVERIFIED


def _all_three(a, b, c):
    return {"capacity_mw": {"verdict": "agree", "source_url": a},
            "status": {"verdict": "agree", "source_url": b},
            "location": {"verdict": "agree", "source_url": c}}


def test_a_dead_citation_cannot_buy_the_approve_gate():
    """The exact promotion a fabricated URL used to buy: three agreeing verdicts each citing
    a fresh domain reached `approved` on 0.93 with 4 sources. If those pages are 404s, the row
    must fall back to its ONE real source and stay un-approvable.

    Note it is `n_sources` that does the work here, not confidence — with every citation dead,
    all three fields score `_AGREE_UNCORROBORATED`, which is the same 0.72 a verifier gets for
    honestly agreeing without a second source. That is deliberate: a bad citation is not
    evidence the VALUE is wrong (that would be `disagree`), it is absence of corroboration."""
    live_sc = V.score(cand(), _all_three("https://b.com/x", "https://c.com/y",
                                         "https://d.com/z"), LIVE)
    dead_sc = V.score(cand(), _all_three("https://b.com/g1", "https://c.com/g2",
                                         "https://d.com/g3"), DEAD)
    assert live_sc["review_status"] == "approved" and live_sc["n_sources"] == 4
    assert dead_sc["review_status"] != "approved"
    assert dead_sc["n_sources"] == 1 and dead_sc["new_sources"] == []
    assert dead_sc["overall_confidence"] < live_sc["overall_confidence"]


def test_an_unverified_citation_still_cannot_approve_but_is_not_discarded():
    """The middle state, end to end: three bot-blocked citations earn no bonus (so no
    approval) yet all three are kept as provenance for a human to judge."""
    sc = V.score(cand(), _all_three("https://b.com/x", "https://c.com/y", "https://d.com/z"),
                 UNSURE)
    assert sc["review_status"] != "approved"
    assert len(sc["new_sources"]) == 3
    assert all(s["liveness"] == SL.UNVERIFIED for s in sc["new_sources"])


def test_the_liveness_mix_is_reported_per_record():
    """The measured value the loop needs — a silent filter would look like a model that simply
    never corroborates."""
    sc = V.score(cand(), agree("https://b.com/ghost"), DEAD)
    assert sc["liveness"] == {SL.UNREACHABLE: 1}


def test_a_disagree_verdict_is_never_probed():
    """No network call on a path that cannot earn the bonus anyway — and `disagree` must keep
    scoring 0.20 regardless of what it cited."""
    def explode(u):
        raise AssertionError("probed a disagree verdict")
    conf, url, state = V._score_field(
        {"verdict": "disagree", "source_url": "https://b.com/x"}, {"a.com"}, explode)
    assert (conf, url, state) == (V._DISAGREE, None, None)


def test_a_same_domain_citation_is_never_probed():
    """Re-citing a domain we already hold cannot be independent, so it must short-circuit
    before the network."""
    def explode(u):
        raise AssertionError("probed a non-independent citation")
    conf, url, state = V._score_field(
        {"verdict": "agree", "source_url": "https://a.com/other"}, {"a.com"}, explode)
    assert (conf, url, state) == (V._AGREE_UNCORROBORATED, None, None)


def test_the_probe_can_be_switched_off_for_an_offline_run(monkeypatch):
    monkeypatch.setattr(V.settings, "verify_check_source_liveness", False)
    assert V._liveness("https://anything/at/all") == SL.LIVE

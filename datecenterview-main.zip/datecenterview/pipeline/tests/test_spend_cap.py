"""The spend cap must actually STOP a batch — not mark it failed and keep paying.

Found 2026-07-31 while pricing a 400-record Phase B sweep, before running it.

`SpendLimitError` was a RuntimeError, and every paid call site wraps its call in
`except Exception` so one bad filing cannot sink a batch. Those handlers therefore caught the
cap, marked the record failed, and CONTINUED THE LOOP — so the next iteration made another
real, billed API call, tripped again, and was swallowed again. The cap converted "stop
spending" into "keep spending and discard the results".

Measured shape of the bug on the sweep it was found for: a $25 cap against ~$58 of work trips
at ~180 of 400 records, then bills ~220 further calls (~$30) that all persist as `reported`.

Two fixes, both exercised below:
  1. SpendLimitError inherits BaseException — control flow, like KeyboardInterrupt. It cannot
     be caught by a generic handler, only by one that names it.
  2. LEDGER.check() runs BEFORE each paid request. `_add` can only raise after the response
     arrives, so the tripping call was billed and then thrown away.

This is the loop-design rule that "a guardrail must be exercised, not asserted": the cap had a
test proving it RAISES, and none proving it STOPS anything.
"""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dcv.clients import spend  # noqa: E402
from dcv.clients.spend import SpendLedger, SpendLimitError  # noqa: E402


def test_the_cap_is_not_catchable_by_a_generic_handler():
    """The defect in one line. Every paid call site says `except Exception`; if the cap is an
    Exception, every paid call site silently disarms it."""
    assert not issubclass(SpendLimitError, Exception)
    assert issubclass(SpendLimitError, BaseException)
    led = SpendLedger(limit_usd=0.01)
    caught_generic = False
    try:
        try:
            led.record_tokens("claude-sonnet-5", 10_000_000, 0)
        except Exception:            # noqa: BLE001 — the exact handler that used to swallow it
            caught_generic = True
    except SpendLimitError:
        pass
    assert not caught_generic, "a bare `except Exception` still swallows the spend cap"


def test_a_batch_loop_actually_stops_paying():
    """The behaviour that matters, not the raise. Simulates the real shape: a loop over records
    where each iteration makes a paid call inside `except Exception`."""
    led = SpendLedger(limit_usd=0.30)
    billed = []

    def paid_call(i):
        led.check(f"record {i}")     # refuse before spending
        billed.append(i)
        led.record_tokens("claude-sonnet-5", 40_000, 4_000)   # ~$0.18/call

    processed, stopped_at = [], None
    try:
        for i in range(20):
            try:
                paid_call(i)
                processed.append(i)
            except Exception:        # noqa: BLE001 — the production handler
                processed.append(i)  # "held as reported" and carry on
    except SpendLimitError:
        stopped_at = len(billed)

    assert stopped_at is not None, "the loop ran to completion despite the cap"
    assert len(billed) < 20, "every record was billed anyway"
    assert len(billed) == stopped_at


def test_check_refuses_before_the_call_is_billed():
    """Without a pre-check the tripping call is paid for and its result discarded."""
    led = SpendLedger(limit_usd=0.25)          # one call is $0.18, two is $0.36
    led.record_tokens("claude-sonnet-5", 40_000, 4_000)
    led.check("first")                          # under the cap — must not fire
    with pytest.raises(SpendLimitError):
        led.record_tokens("claude-sonnet-5", 40_000, 4_000)   # this one trips, after billing
    with pytest.raises(SpendLimitError, match="before second"):
        led.check("second")                     # now refuses UP FRONT — nothing further billed


def test_an_uncapped_ledger_never_blocks():
    """Must-fail guard: limit 0 means no cap, and check() must not fire on it."""
    led = SpendLedger(limit_usd=0)
    led.record_tokens("claude-sonnet-5", 100_000_000, 100_000_000)
    led.check("anything")


def test_every_paid_client_checks_before_spending():
    """All four paid entry points, so a new one is not quietly added without the guard."""
    import inspect

    from dcv.clients import claude, exa, grok
    assert "LEDGER.check" in inspect.getsource(claude.verify_json)
    assert "LEDGER.check" in inspect.getsource(grok.chat)
    assert "LEDGER.check" in inspect.getsource(grok.search)
    assert "LEDGER.check" in inspect.getsource(exa.search)


def test_the_orchestrators_still_catch_it_on_purpose():
    """BaseException must not break the handlers that are SUPPOSED to stop cleanly and persist
    what they have — that is the behaviour the fix exists to restore."""
    import inspect

    from dcv import bakeoff
    from dcv.phaseb import pipeline
    assert "except SpendLimitError" in inspect.getsource(pipeline.run)
    assert "except spend.SpendLimitError" in inspect.getsource(bakeoff.run)


def test_phaseb_verify_no_longer_swallows_the_cap(monkeypatch):
    """End to end on the real function: verify() holds a candidate as `reported` when the
    VERIFIER fails, but must let the spend cap through to the orchestrator."""
    from dcv.phaseb import verify as V

    cand = {"project_name": "P", "capacity_mw": {"value": 1, "quote": "q"},
            "status": {"value": "operating", "quote": None},
            "location": {"county": "C", "state": "TX", "address": None, "quote": None},
            "sources": [{"url": "https://a.com/p"}], "self_consistency": 0.5}

    monkeypatch.setattr(V.claude, "verify_json",
                        lambda *a, **k: (_ for _ in ()).throw(RuntimeError("vendor 500")))
    assert V.verify(dict(cand))["review_status"] == "reported"   # ordinary failure: absorbed

    monkeypatch.setattr(V.claude, "verify_json",
                        lambda *a, **k: (_ for _ in ()).throw(SpendLimitError("cap")))
    with pytest.raises(SpendLimitError):                          # cap: propagates
        V.verify(dict(cand))

"""Geo-precision: gate 12, and the emit rollup that feeds it.

The 2026-07-30 map review found the Explorer plotting 2,239 county centroids as if they were
sites. Nothing was wrong with the store — `dedup.py` had refused to treat a non-`exact` point
as a location since 2026-07-21 — but `emit` copied lat/lng and dropped `geo_precision`, so the
constraint held on one path and evaporated on the next. That is the same shape as the
`enrich.py`-vs-PhaseB source-policy escape, and the fix is the same: enforce it at the gate too.

The tell was visual and worth keeping in mind when reading these numbers: the Texas panhandle
rendered as a regular lattice because panhandle counties are a survey grid, so every project in
a county lands on that county's centre. 203 projects sat on 23 points.

Each rule below has a must-pass AND a must-fail case — a gate that only sees good input is not
a gate.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import validate_data as V  # noqa: E402
from dcv.emit import _geo_precision_coverage  # noqa: E402


def dc(id, lat=32.0, lng=-97.0, prec="exact"):
    r = {"id": id, "lat": lat, "lng": lng}
    if prec is not None:
        r["geo_precision"] = prec
    return r


def doc(dcs=(), pws=(), roll="auto"):
    d = {"datasets": {"data_center": list(dcs), "power_project": list(pws), "news": []},
         "meta": {"rollups": {}}}
    if roll == "auto":
        roll = _geo_precision_coverage(d["datasets"]["data_center"], d["datasets"]["power_project"])
    if roll is not None:
        d["meta"]["rollups"]["geo_precision"] = roll
    return d


# ---------------------------------------------------------------- the rollup measures
def test_rollup_separates_a_site_from_a_stand_in():
    cov = _geo_precision_coverage(
        [dc("a"), dc("b", prec="county"), dc("c", lat=None, lng=None, prec=None)], [])
    b = cov["data_center"]
    assert (b["rows"], b["mapped"], b["unmapped"]) == (3, 2, 1)
    assert (b["exact"], b["centroid"], b["unlabelled"]) == (1, 1, 0)


def test_rollup_counts_the_stacking_rather_than_leaving_it_to_the_eye():
    """58 projects on one Brazoria County point is the real finding; `mapped` alone hides it."""
    rows = [dc(f"p{i}", lat=29.1678, lng=-95.4346, prec="county") for i in range(58)]
    cov = _geo_precision_coverage(rows, [])
    assert cov["data_center"]["mapped"] == 58
    assert cov["data_center"]["distinct_points"] == 1


def test_city_and_state_are_stand_ins_too():
    cov = _geo_precision_coverage([dc("a", prec="city"), dc("b", prec="state")], [])
    assert cov["data_center"]["centroid"] == 2
    assert cov["data_center"]["exact"] == 0


# ---------------------------------------------------------------- gate 12: must pass
def test_gate_passes_on_fully_labelled_coordinates():
    assert V.geo_precision_integrity(doc([dc("a"), dc("b", prec="county")])) == []


def test_gate_passes_when_an_unmapped_row_has_no_precision():
    """No coordinate, no precision — that is a row we never located, not a defect."""
    assert V.geo_precision_integrity(doc([dc("a", lat=None, lng=None, prec=None)])) == []


# ---------------------------------------------------------------- gate 12: must fail
def test_gate_blocks_an_unlabelled_coordinate():
    """`null` means 'we do not know which of the two things this is', not 'it is a site'."""
    errs = V.geo_precision_integrity(doc([dc("ghost", prec=None)]))
    assert any("no geo_precision" in e and "ghost" in e for e in errs)


def test_gate_blocks_exact_with_no_coordinate():
    """The real defect gate 12 found on its first run: 19 PeeringDB rows labelled `exact`
    because `enumerate_dc.py` defaulted `... or "exact"` whether or not coordinates came back."""
    errs = V.geo_precision_integrity(doc([dc("nowhere", lat=None, lng=None, prec="exact")]))
    assert any("'exact' with no coordinate" in e and "nowhere" in e for e in errs)


def test_a_coarse_precision_without_a_coordinate_is_allowed():
    """The field records locational GRANULARITY, not only coordinate precision. 48 rows say
    `state` with no lat/lng — "we know the state and no more" — and that is honest, not a bug.
    Blocking it (the first draft of this gate did) would push ingest back toward inventing a
    precision it cannot support."""
    assert V.geo_precision_integrity(doc([dc("s", lat=None, lng=None, prec="state"),
                                          dc("c", lat=None, lng=None, prec="city")])) == []


def test_gate_blocks_a_rollup_that_flatters_the_map():
    """The bug this gate is really for: a coverage number that disagrees with the enforced one.
    Here the rollup claims both points are sites; two of them are county centroids."""
    d = doc([dc("a"), dc("b", prec="county"), dc("c", prec="county")])
    d["meta"]["rollups"]["geo_precision"]["data_center"]["exact"] = 3
    d["meta"]["rollups"]["geo_precision"]["data_center"]["centroid"] = 0
    errs = V.geo_precision_integrity(d)
    assert any("exact" in e and "reports 3" in e and "finds 1" in e for e in errs)
    assert any("centroid" in e and "reports 0" in e and "finds 2" in e for e in errs)


def test_gate_blocks_a_partial_rollup():
    d = doc([dc("a")], [dc("p")])
    del d["meta"]["rollups"]["geo_precision"]["power_project"]
    errs = V.geo_precision_integrity(d)
    assert any("missing the 'power_project' block" in e for e in errs)


def test_gate_covers_power_projects_not_just_data_centers():
    """99.3% of the centroids were on the power side — a data-center-only gate would have
    passed the very file that prompted this."""
    errs = V.geo_precision_integrity(doc([], [dc("pwr", prec=None)]))
    assert any("power_project" in e and "no geo_precision" in e for e in errs)

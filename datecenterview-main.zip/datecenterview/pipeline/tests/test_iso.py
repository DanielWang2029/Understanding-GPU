"""Tests for ISO-queue state normalization (the ERCOT 'Texas' fix)."""
from dcv.sources.iso import _norm_state


def test_full_state_name_maps_to_code():
    # ERCOT reports the full word "Texas" — must become TX, not "TE".
    assert _norm_state("Texas", {"TX"}) == "TX"
    assert _norm_state("California", {"CA", "NV"}) == "CA"


def test_postal_code_passthrough():
    assert _norm_state("TX", {"TX"}) == "TX"
    assert _norm_state("ok", {"AR", "KS", "OK"}) == "OK"


def test_blank_defaults_to_single_state_coverage():
    assert _norm_state("", {"NY"}) == "NY"
    assert _norm_state(None, {"NY"}) == "NY"
    # multi-state ISO with no state -> unknown
    assert _norm_state(None, {"AR", "KS", "OK"}) is None


def test_nan_handled():
    assert _norm_state(float("nan"), {"TX"}) == "TX"

#!/usr/bin/env python3
"""
validate_data.py — continuous validator for the dataCenterView data.json contract.

Thirteen gates, run on every build / in CI. Twelve BLOCK publish; SEMANTIC + UNTIERED only warn:
  1. STRUCTURAL           — JSON Schema (data.schema.json): types, enums, ranges, required, formats.
  2. REFERENTIAL          — every cross-reference resolves (edges->entities/projects, news->projects,
                            chain edges->chain entities, asset/price/forward refs) and ids are unique.
  3. FINANCIALS_INTEGRITY — a `disclosed` metric must be complete: ticker + positive value + as_of + sources.
  4. EDGE_INTEGRITY       — a disclosed magnitude needs source+as_of; a `named` link must cite WHO named it
                            (>=1 link_source with a url).
  5. REVIEW_QUEUE_INTEGRITY — the emitted queue depth must be LIVE, every disputed record must have been
                            re-opened, and no dispute may sit undrained at publish (Band-1 #3).
  6. BACKBONE_REACH_INTEGRITY — the reach report must describe THIS backbone, and an entity we
                            cannot reach must not carry a `disclosed` figure (Band 2 #1).
  7. DC_ROLE_COVERAGE_INTEGRITY — the role-coverage block must be live, its denominator must
                            cover every record, and `resolved` may not exceed `filled` (Band 2 #2).
  8. SOURCE_POLICY_INTEGRITY — no value may be sourced from a curated competitor (decision #1,
                            non-negotiable). Scans the whole document, not a field allow-list.
 10. CAPACITY_PROVENANCE_INTEGRITY — the MW column must be traceable: no tier-3 modelled figure,
                            and the rollup must agree with the gate (2026-07-21 capacity audit).
 11. DEDUP_INTEGRITY     — a row adjudicated a duplicate must not still be in the read-model,
                            and a survivor must still be published.
 12. GEO_PRECISION_INTEGRITY — every published coordinate must say what it locates (site vs
                            centroid), and the rollup must agree with the gate's own count.
  9. SEMANTIC (warn only) — trust rules: 'confirmed' (conf>=0.75) needs >=2 sources; freshness horizons
                            (incl. never-verified); supply-chain acyclic.
 13. UNTIERED_DIRECTORY_EXPOSURE (warn only) — directory-shaped domains with no ruling; gate 10
                            is what blocks if one of them ever supplies a value.

Every rule ships with a must-pass AND a must-fail test — a gate that only sees good input is not a gate.

Exit code 0 = pass (warnings allowed), 1 = errors (block publish).
Usage: python3 validate_data.py [data.json] [--max-stale-days 45]
"""
import json, sys, datetime, argparse

CONF_CONFIRMED = 0.75
DEFAULT_STALE_DAYS = 45

def load(p):
    with open(p) as f: return json.load(f)

def structural(data, schema):
    errs = []
    try:
        try:
            from jsonschema import Draft202012Validator as V
        except ImportError:
            from jsonschema import Draft7Validator as V   # older jsonschema: $ref still resolves #/$defs
    except ImportError:
        return ["jsonschema not installed — run: pip install jsonschema --break-system-packages"]
    v = V(schema)
    for e in sorted(v.iter_errors(data), key=lambda e: e.path):
        loc = "/".join(str(x) for x in e.path) or "<root>"
        errs.append(f"[schema] {loc}: {e.message}")
    return errs

def referential(d):
    errs = []
    dc = d["datasets"]["data_center"]; pw = d["datasets"]["power_project"]; news = d["datasets"]["news"]
    ents = d.get("entities", []); edges = d.get("edges", []); feeds = d.get("feeds", [])
    sc = d.get("supply_chain", {"nodes": [], "links": []})
    def dup(ids, label):
        seen, out = set(), []
        for i in ids:
            if i in seen: out.append(f"[dup id] {label}: {i}")
            seen.add(i)
        return out
    errs += dup([r["id"] for r in dc], "data_center")
    errs += dup([r["id"] for r in pw], "power_project")
    errs += dup([r["id"] for r in news], "news")
    errs += dup([e["id"] for e in ents], "entities")
    errs += dup([f["id"] for f in feeds], "feeds")
    errs += dup([n["id"] for n in sc.get("nodes", [])], "supply_chain.nodes")
    dc_ids = {r["id"] for r in dc}; pw_ids = {r["id"] for r in pw}
    proj_ids = dc_ids | pw_ids
    ent_ids = {e["id"] for e in ents}; feed_ids = {f["id"] for f in feeds}
    snode_ids = {n["id"] for n in sc.get("nodes", [])}
    for e in edges:
        if e["project"] not in dc_ids: errs.append(f"[ref] edge.project '{e['project']}' not a data_center id")
        if e["org"] not in ent_ids:    errs.append(f"[ref] edge.org '{e['org']}' not an entity id")
    for n in news:
        for pid in n.get("projects", []):
            if pid not in proj_ids: errs.append(f"[ref] news '{n['id']}' → unknown project '{pid}'")
        if feed_ids and n.get("source_feed") not in feed_ids:
            errs.append(f"[ref] news '{n['id']}' → unknown source_feed '{n.get('source_feed')}'")
    for l in sc.get("links", []):
        if l["source"] not in snode_ids: errs.append(f"[ref] supply link source '{l['source']}' unknown")
        if l["target"] not in snode_ids: errs.append(f"[ref] supply link target '{l['target']}' unknown")

    # ---- v1.2 illustrative compute-chain seed (all optional; guarded via .get) ----
    chain = d.get("chain", {}) or {}
    chain_ents = chain.get("entities", []); chain_edges = chain.get("edges", [])
    projects = d.get("projects", []); cpower = d.get("power", [])
    assets = d.get("assets", []); skus = d.get("skus", [])
    providers = d.get("providers", []); prices = d.get("prices", [])
    forwards = d.get("forwards", [])
    errs += dup([e["id"] for e in chain_ents], "chain.entities")
    errs += dup([p["id"] for p in projects], "projects")
    errs += dup([p["id"] for p in cpower], "power")
    errs += dup([a["id"] for a in assets], "assets")
    errs += dup([s["id"] for s in skus], "skus")
    errs += dup([p["id"] for p in providers], "providers")
    chain_ids = {e["id"] for e in chain_ents}
    project_ids = {p["id"] for p in projects}; sku_ids = {s["id"] for s in skus}
    for e in chain_edges:
        if e.get("from") not in chain_ids: errs.append(f"[ref] chain edge.from '{e.get('from')}' not a chain entity id")
        if e.get("to") not in chain_ids:   errs.append(f"[ref] chain edge.to '{e.get('to')}' not a chain entity id")
    for p in projects:
        for role in ("developer", "operator", "tenant", "end_user"):
            if p.get(role) not in chain_ids:
                errs.append(f"[ref] project '{p['id']}' {role} '{p.get(role)}' not a chain entity id")
    for a in assets:
        if a.get("entity") not in chain_ids:
            errs.append(f"[ref] asset '{a['id']}' entity '{a.get('entity')}' not a chain entity id")
    for pr in prices:
        if pr.get("provider") not in chain_ids:
            errs.append(f"[ref] price provider '{pr.get('provider')}' not a chain entity id")
        if pr.get("sku") not in sku_ids:
            errs.append(f"[ref] price sku '{pr.get('sku')}' not a sku id")
    for f in forwards:
        if f.get("sku") not in sku_ids:
            errs.append(f"[ref] forward sku '{f.get('sku')}' not a sku id")
    for p in cpower:
        lk = p.get("linked")
        if lk is not None and lk not in project_ids:
            errs.append(f"[ref] power '{p['id']}' linked '{lk}' not a project id")
    return errs

def acyclic(sc):
    adj = {n["id"]: [] for n in sc.get("nodes", [])}
    for l in sc.get("links", []):
        if l["source"] in adj: adj[l["source"]].append(l["target"])
    WHITE, GREY, BLACK = 0, 1, 2
    color = {n: WHITE for n in adj}
    bad = []
    def dfs(u):
        color[u] = GREY
        for v in adj.get(u, []):
            if color.get(v) == GREY: bad.append(f"[cycle] supply_chain via {u}->{v}"); return
            if color.get(v) == WHITE: dfs(v)
        color[u] = BLACK
    for n in list(adj):
        if color[n] == WHITE: dfs(n)
    return bad

def semantic(d, max_stale_days):
    warns = []
    today = datetime.date.today()
    for coll in ("data_center", "power_project"):
        for r in d["datasets"][coll]:
            c = r.get("confidence")
            srcs = r.get("sources", [])
            if c is not None and c >= CONF_CONFIRMED and len(srcs) < 2:
                warns.append(f"[trust] {coll} '{r['id']}' is confirmed ({c}) but has {len(srcs)} source(s) — need >=2")
            lv = r.get("last_verified")
            if lv:
                try:
                    age = (today - datetime.date.fromisoformat(lv)).days
                    if age > max_stale_days:
                        warns.append(f"[stale] {coll} '{r['id']}' last_verified {lv} ({age}d > {max_stale_days}d)")
                except ValueError:
                    warns.append(f"[date] {coll} '{r['id']}' bad last_verified '{lv}'")
            elif r.get("review_status") != "candidate":
                # A missing last_verified used to be silently EXEMPT from the freshness rule —
                # which meant the most-unverified records were the only ones the check ignored.
                # It became load-bearing when the dispute drain started voiding the date
                # (Band-1 #3), so treat absent as maximally stale rather than as no-opinion.
                warns.append(f"[stale] {coll} '{r['id']}' has never been verified "
                             f"(no last_verified; review_status={r.get('review_status')})")
    warns += acyclic(d.get("supply_chain", {"nodes": [], "links": []}))
    # ---- v1.2 seed semantic warns (light, non-blocking) ----
    for pr in d.get("prices", []):
        px = pr.get("usd_per_gpu_hr")
        if px is not None and px <= 0:
            warns.append(f"[price] {pr.get('provider')}/{pr.get('sku')} usd_per_gpu_hr {px} <= 0")
    for e in d.get("chain", {}).get("edges", []):
        v = e.get("value", {}) or {}
        for k in ("pct_cogs", "pct_revenue"):
            val = v.get(k)
            if val is not None and not (0 <= val <= 100):
                warns.append(f"[chain] edge {e.get('from')}→{e.get('to')} {k} {val} outside 0-100")
    # ---- P2/L9 entity-financials freshness (per metric×basis; disclosed tighter, estimates looser but NOT exempt) ----
    for e in d.get("entities", []):
        fin = e.get("financials") or {}
        for k in ("market_cap", "revenue", "capex"):
            m = fin.get(k) or {}
            horizon = FIN_HORIZON.get((k, m.get("basis")))
            if horizon is None:
                continue  # basis "n/a" (or absent) has no freshness SLO
            ao = m.get("as_of")
            if not ao:
                if m.get("basis") == "disclosed":
                    warns.append(f"[fin-stale] entity '{e['id']}' {k} disclosed but no as_of")
                continue
            try:
                age = (today - datetime.date.fromisoformat(ao)).days
                if age > horizon:
                    warns.append(f"[fin-stale] entity '{e['id']}' {k} ({m.get('basis')}) as_of {ao} ({age}d > {horizon}d)")
            except ValueError:
                warns.append(f"[fin-date] entity '{e['id']}' bad {k} as_of '{ao}'")
    return warns


# freshness horizons (days) per (metric, basis) — estimates are looser but never exempt (review B3)
FIN_HORIZON = {
    ("market_cap", "disclosed"): 120, ("revenue", "disclosed"): 400,
    ("market_cap", "estimated"): 180, ("revenue", "estimated"): 500,
    ("capex", "disclosed"): 400, ("capex", "estimated"): 500,
}


def financials_integrity(d):
    """P2/L9 hard checks on entity.financials — block publish (the L6 balancing gate).

    A `disclosed` claim is the load-bearing trust signal, so it must be COMPLETE:
    a positive number, a filing date, and at least one source (review B2). Anything
    labeled disclosed without those is worse than an honest estimate.
    """
    errs = []
    for e in d.get("entities", []):
        fin = e.get("financials")
        if not fin:
            continue
        has_ticker = bool(e.get("ticker"))
        for k in ("market_cap", "revenue", "capex"):
            m = fin.get(k)
            if not m:
                continue
            val = m.get("value")
            if isinstance(val, (int, float)) and val < 0:
                errs.append(f"[fin] entity '{e['id']}' {k} value {val} < 0")
            if m.get("basis") == "disclosed":
                if not has_ticker:
                    errs.append(f"[fin] entity '{e['id']}' {k} basis=disclosed but no ticker")
                if not isinstance(val, (int, float)) or val <= 0:
                    errs.append(f"[fin] entity '{e['id']}' {k} basis=disclosed but value not a positive number ({val!r})")
                if not m.get("as_of"):
                    errs.append(f"[fin] entity '{e['id']}' {k} basis=disclosed but no as_of")
                if not m.get("sources"):
                    errs.append(f"[fin] entity '{e['id']}' {k} basis=disclosed but no sources")
    return errs


def edge_integrity(d):
    """P3/L9+L2 hard checks on quantified chain edges — block publish. A metric marked
    `disclosed` (via cogs_basis/rev_basis) must carry a source + as_of. A link marked
    `named` (L2-identity) must cite who named it — ≥1 link_source with a url. Legacy seed
    edges (only the boolean `disclosed`, no per-metric basis / inferred links) pass."""
    errs = []
    for e in d.get("chain", {}).get("edges", []):
        v = e.get("value") or {}
        tag = f"{e.get('from')}→{e.get('to')}"
        for metric, basis_key in (("pct_cogs", "cogs_basis"), ("pct_revenue", "rev_basis")):
            if v.get(basis_key) == "disclosed":
                if not v.get("sources"):
                    errs.append(f"[edge] {tag} {metric} disclosed but no sources")
                if not v.get("as_of"):
                    errs.append(f"[edge] {tag} {metric} disclosed but no as_of")
        # a NAMED counterparty is a trust claim (link inferred→named): it must name its evidence.
        if v.get("link_basis") == "named":
            ls = v.get("link_sources") or []
            if not ls:
                errs.append(f"[edge] {tag} link_basis=named but no link_sources cite the naming")
            for s in ls:
                if not s.get("url"):
                    errs.append(f"[edge] {tag} named link_source missing url")
    return errs

def review_queue_integrity(d):
    """Band-1 #3 (U2→L2) hard checks on meta.rollups.review_queue — block publish.

    This is the L6 gate that keeps the dispute loop from silently regressing to the stub it
    used to be. Three rules, each catching a distinct way the loop can go open:

      1. LIVE  — the emitted queue depth must equal the real count of `needs_review` rows in
                 datasets. A hardcoded or stale number is exactly the failure the conformance
                 gate exists to catch ("the measured value must be live").
      2. ROUTED— every id in `disputed_ids` must resolve to a real record, and that record must
                 NOT still read `approved`. A dispute that leaves the record approved never
                 re-opened it — i.e. it routed nowhere, which is the stub's behaviour.
      3. DRAINED — `inbox_pending` must be 0 at publish time: a dispute sitting undrained in
                 the inbox is a reader signal that has not reached the loop.

    An absent review_queue block (older contract) or an explicit `unavailable` marker is not an
    error — but a block that CLAIMS numbers must have honest ones.
    """
    errs = []
    rq = ((d.get("meta", {}) or {}).get("rollups", {}) or {}).get("review_queue")
    if not rq or rq.get("unavailable"):
        return errs
    by_id = {}
    for rt in ("data_center", "power_project"):
        for r in d["datasets"].get(rt, []):
            by_id[r["id"]] = (rt, r)
        actual = sum(1 for r in d["datasets"].get(rt, []) if r.get("review_status") == "needs_review")
        claimed = (rq.get("needs_review") or {}).get(rt)
        if claimed is not None and claimed != actual:
            errs.append(f"[review] review_queue.needs_review.{rt}={claimed} but datasets hold "
                        f"{actual} needs_review rows — the measured value is not live")
    for rid in rq.get("disputed_ids") or []:
        hit = by_id.get(rid)
        if hit is None:
            errs.append(f"[review] disputed_ids references unknown record '{rid}'")
        elif hit[1].get("review_status") == "approved":
            errs.append(f"[review] record '{rid}' has an open dispute but still reads "
                        f"review_status=approved — the dispute did not re-open it")
    if rq.get("inbox_pending"):
        errs.append(f"[review] {rq['inbox_pending']} dispute(s) undrained in the inbox — "
                    f"run `dcv review-drain` before publishing (a filed dispute must be routed)")
    return errs


def backbone_reach_integrity(d):
    """Band 2 #1 (L2-backbone) hard checks on meta.rollups.backbone_reach — block publish.

    The reach report exists to stop the product claiming coverage it structurally cannot have.
    That only works if the report describes THIS backbone, so:

      1. LIVE   — `entities` and the status counts must sum to, and match, the real chain
                  entity count. A reach report left over from a narrower backbone would
                  under-report the out-of-reach set, which is the flattering direction.
      2. ROUTED — every id in `by_status` must be a real chain entity.
      3. HONEST — an entity listed as out-of-reach (`stale`/`no_us_listing`/`private`) must NOT
                  carry a `disclosed` financial. This is the rule with teeth: it is the
                  structural check that a figure never outruns the source that could supply it.
    """
    errs = []
    br = ((d.get("meta", {}) or {}).get("rollups", {}) or {}).get("backbone_reach")
    if not br or br.get("unavailable"):
        return errs
    ents = {e["id"]: e for e in (d.get("chain", {}) or {}).get("entities", [])}
    fin = {e["id"]: (e.get("financials") or {}) for e in d.get("entities", [])}
    counts = br.get("counts") or {}
    if br.get("entities") is not None and ents and br["entities"] != len(ents):
        errs.append(f"[reach] backbone_reach.entities={br['entities']} but chain holds "
                    f"{len(ents)} entities — the measured value is not live")
    if counts and br.get("entities") is not None and sum(counts.values()) != br["entities"]:
        errs.append(f"[reach] backbone_reach.counts sum to {sum(counts.values())} but claim "
                    f"{br['entities']} entities — every entity must have exactly one status")
    for status, ids in (br.get("by_status") or {}).items():
        if len(ids) != counts.get(status, len(ids)):
            errs.append(f"[reach] by_status.{status} lists {len(ids)} ids but counts.{status}"
                        f"={counts.get(status)}")
        for eid in ids:
            if ents and eid not in ents:
                errs.append(f"[reach] by_status.{status} references unknown chain entity '{eid}'")
            if status == "current":
                continue
            for metric in ("revenue", "capex", "market_cap"):
                if (fin.get(eid, {}).get(metric) or {}).get("basis") == "disclosed":
                    errs.append(
                        f"[reach] entity '{eid}' is out of reach ({status}) but carries a "
                        f"DISCLOSED {metric} — a disclosed figure cannot come from a source "
                        f"that cannot reach the filer")
    return errs


def dc_role_coverage_integrity(d):
    """Band 2 #2 (L2-dcroles) hard checks on meta.rollups.dc_role_coverage — block publish.

    This block exists to make a coverage number honest, so the ways it can lie are the rules:

      1. LIVE       — `records` and every `filled` count must match the datasets. A coverage
                      figure that drifts from the data it describes is worse than none.
      2. ARITHMETIC — eligible + not_applicable must equal records, so narrowing the
                      denominator can never quietly shrink the population.
      3. BOUNDED    — eligible_filled <= eligible, and resolved <= filled. `resolved` counts a
                      role that reached a real entity; it cannot exceed the roles we have at
                      all. Inverting these is how "we resolved more than we know" ships.
    """
    errs = []
    rc = ((d.get("meta", {}) or {}).get("rollups", {}) or {}).get("dc_role_coverage")
    if not rc or rc.get("unavailable"):
        return errs
    dcs = d["datasets"].get("data_center", [])
    if rc.get("records") is not None and rc["records"] != len(dcs):
        errs.append(f"[dcroles] dc_role_coverage.records={rc['records']} but datasets hold "
                    f"{len(dcs)} data_center rows — the measured value is not live")
    for role, claimed in (rc.get("filled") or {}).items():
        actual = sum(1 for r in dcs if r.get(role))
        if claimed != actual:
            errs.append(f"[dcroles] filled.{role}={claimed} but datasets hold {actual} rows "
                        f"with a {role} — the measured value is not live")
    for role, elig in (rc.get("eligible") or {}).items():
        na = (rc.get("not_applicable") or {}).get(role)
        if na is not None and rc.get("records") is not None and elig + na != rc["records"]:
            errs.append(f"[dcroles] eligible.{role}({elig}) + not_applicable.{role}({na}) != "
                        f"records({rc['records']}) — every record must be one or the other")
        ef = (rc.get("eligible_filled") or {}).get(role)
        if ef is not None and ef > elig:
            errs.append(f"[dcroles] eligible_filled.{role}={ef} exceeds eligible.{role}={elig}")
    for role, res in (rc.get("resolved") or {}).items():
        filled = (rc.get("filled") or {}).get(role)
        if filled is not None and res > filled:
            errs.append(f"[dcroles] resolved.{role}={res} exceeds filled.{role}={filled} — a "
                        f"role cannot resolve to an entity without being present")
    return errs


def source_policy_integrity(d):
    """Decision #1 (non-negotiable): no value may be sourced from a curated competitor.

    BLOCKS publish. This is the gate that turns CLAUDE.md's "never scrape CleanView or other
    paid competitors' curated data" from prose into an enforced rule. It scans the WHOLE
    document rather than a list of known source fields, because a competitor URL that reaches
    the read-model through an edge, a news row or a Field<T>'s `sources` is just as published
    as one in `datasets.data_center[].sources`.

    Found on the live read-model when this gate was written: 151 URLs across 5 competitor
    domains, from a capacity-recovery pass that accepted whatever a web search returned.
    """
    import importlib.util, pathlib
    spec = importlib.util.spec_from_file_location(
        "dcv_source_policy", pathlib.Path(__file__).parent / "dcv" / "source_policy.py")
    sp = importlib.util.module_from_spec(spec); spec.loader.exec_module(sp)
    hits = sp.scan(d, tier="deny")
    by_host = {}
    for path, url, reason in hits:
        by_host.setdefault(sp._host(url), {"n": 0, "reason": reason, "eg": path})
        by_host[sp._host(url)]["n"] += 1
    errs = [f"[source] {n['n']} URL(s) from '{h}' in the read-model ({n['reason']}); "
            f"e.g. at {n['eg']} — decision #1 forbids sourcing values from curated competitors"
            for h, n in sorted(by_host.items())]

    # The rollup must agree with what this gate independently finds. A published
    # `source_policy` block is a claim about admissibility; if emit and the gate can disagree,
    # the reassuring number and the enforced one are two different things — exactly the split
    # that let `review_queue` report the store while the file held a different population.
    roll = ((d.get("meta") or {}).get("rollups") or {}).get("source_policy")
    if isinstance(roll, dict) and not roll.get("unavailable"):
        if roll.get("denied_tier1") != len(hits):
            errs.append(f"[source] rollups.source_policy.denied_tier1="
                        f"{roll.get('denied_tier1')} but the gate finds {len(hits)} — the "
                        f"published licensing claim does not match the enforced one")
        n_t2 = len(sp.scan(d, tier="review"))
        if roll.get("tracked_tier2") != n_t2:
            errs.append(f"[source] rollups.source_policy.tracked_tier2="
                        f"{roll.get('tracked_tier2')} but the gate finds {n_t2} — a tracked "
                        f"tier that miscounts itself is not tracked")
    return errs


def _sp():
    import importlib.util, pathlib
    spec = importlib.util.spec_from_file_location(
        "dcv_source_policy", pathlib.Path(__file__).parent / "dcv" / "source_policy.py")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m


def capacity_provenance_integrity(d):
    """GATE 10 — a published capacity_mw must be admissible and must measure what the column says.

    The 2026-07-21 audit found `capacity_mw` holding values that were none of those things and
    nothing caught it: 50 values taken from datacenter.fyi, whose power figures are modelled
    from a constant PUE of 5/3 (three unrelated operators, PUE 1.666667447910563 /
    1.6666666666666665 / 1.663716814159292, IT Load == Capacity / 1.6667 on every page); 34
    more from seven directory domains in no tier at all; and the column silently mixing
    facility capacity with IT load.

    What this gate can see is the read-model, so it enforces the two things visible there —
    admissibility of the source, and agreement between the published rollup and an independent
    recount. The value-vs-quote reconciliation lives store-side (`dcv capacity-audit`) because
    quotes are deliberately not in the read-model; the rollup carries its result, and a
    disagreement between the rollup and this gate is itself an error.
    """
    sp = _sp()
    errs = []
    dcs = (d.get("datasets") or {}).get("data_center") or []

    # (a) a value whose evidence is inadmissible must not be published
    bad = {}
    for r in dcs:
        if r.get("capacity_mw") is None:
            continue
        for u in (r.get("sources") or []):
            why = sp.value_denied_reason(u)
            if why:
                bad.setdefault(sp._host(u), {"n": 0, "why": why, "eg": r.get("id")})
                bad[sp._host(u)]["n"] += 1
    for h, v in sorted(bad.items()):
        errs.append(f"[capacity] {v['n']} published capacity value(s) sourced from '{h}' "
                    f"({v['why']}); e.g. {v['eg']}")

    # (b) fail closed on VALUES from an unruled directory — see (c). Deliberately NOT on mere
    # citations: an untiered domain listed among a record's sources, where the number came from
    # somewhere else, is a question for the owner, not a reason to stop the pipeline. Those are
    # reported by `untiered_directory_exposure` as warnings so they stay visible without being
    # a hostage. The distinction matters because `sources` is denormalised per record: a row can
    # cite a directory while its capacity Field cites a filing.

    # (c) the rollup must agree with an independent recount, as source_policy already does:
    # a published sensor that can disagree with the enforced check is two different numbers.
    roll = ((d.get("meta") or {}).get("rollups") or {}).get("capacity_provenance")
    if isinstance(roll, dict) and not roll.get("unavailable"):
        n_pub = sum(1 for r in dcs if r.get("capacity_mw") is not None)
        if roll.get("values") != n_pub:
            errs.append(f"[capacity] rollups.capacity_provenance.values={roll.get('values')} "
                        f"but the read-model publishes {n_pub} capacity values")
        if roll.get("quote_unreconciled"):
            errs.append(f"[capacity] {roll['quote_unreconciled']} capacity value(s) do not "
                        f"reconcile with their own quote — run `dcv capacity-audit`")
        cls = roll.get("by_source_class") or {}
        for k in ("denied_tier1", "modeled_tier3", "unclassified_directory"):
            if cls.get(k):
                errs.append(f"[capacity] rollups report {cls[k]} capacity source(s) of class "
                            f"'{k}' — inadmissible for a published value")
    return errs


def untiered_directory_exposure(d):
    """WARNINGS — directory-shaped domains in the read-model that no ruling covers.

    Not errors: tier 2 was ruled by the owner (2026-07-20) and these are the same *kind* of
    question, so the gate surfaces them rather than deciding for them. What makes this a real
    sensor rather than a shrug is that gate 10 DOES block on any of them supplying a value —
    so the unruled domain can be cited while the decision is pending, but cannot silently
    become the evidence for a published number.
    """
    sp = _sp()
    by_host = {}
    for _path, url, _why in sp.scan(d, tier="unclassified"):
        by_host[sp._host(url)] = by_host.get(sp._host(url), 0) + 1
    return [f"[source] {n} URL(s) from untiered directory '{h}' — rule on it in source_policy "
            f"(tier 1/2/3) or classify it (TRADE_PRESS / FIRST_PARTY_OPERATOR)"
            for h, n in sorted(by_host.items(), key=lambda kv: -kv[1])]


def dedup_integrity(d):
    """GATE 11 — the read-model must not double-count a facility it knows is duplicated.

    Blocks only on duplicates the pipeline has already ADJUDICATED (`rows_marked_duplicate`
    that still appear in the file). Open, unreviewed proposals are reported as a warning by
    `semantic`, not an error: the matchers cannot tell `Sweetwater 1` (1,400 MW) from
    `Sweetwater 2` (600 MW) at one coordinate, so requiring zero open groups would force a
    human to rubber-stamp merges that destroy real capacity.
    """
    errs = []
    roll = ((d.get("meta") or {}).get("rollups") or {}).get("dedup")
    if not isinstance(roll, dict) or roll.get("unavailable"):
        return errs
    ids = {r.get("id") for r in ((d.get("datasets") or {}).get("data_center") or [])}
    marked = roll.get("rows_marked_duplicate") or 0
    dropped = roll.get("rows_dropped_from_read_model")
    if marked and dropped is not None and dropped != marked:
        errs.append(f"[dedup] {marked} row(s) are marked duplicate but {dropped} were dropped "
                    f"from the read-model — a mark that does not remove the row is not a dedup")
    # a survivor must still be published, or the group collapsed to nothing
    for g in (roll.get("survivors_missing") or []):
        if g not in ids:
            errs.append(f"[dedup] survivor '{g}' is not in the read-model — its group "
                        f"collapsed to nothing")
    return errs


def geo_precision_integrity(d):
    """GATE 12 — a coordinate we publish must say WHAT it locates.

    The 2026-07-30 map review found the Explorer plotting 2,239 county centroids as sites:
    `emit` copied lat/lng but dropped `geo_precision`, so the UI could not have drawn the
    distinction even if it wanted to. The store had the flag the whole time — `dedup.py:85`
    already refuses to treat a non-`exact` point as a location — which is exactly the failure
    this gate exists to catch: the constraint was enforced on one path and not the next.

    Three rules, all blocking:
      a. every mapped row carries a precision — an unlabelled coordinate is refused, because
         `null` means "we don't know which of the two things this is", not "it's a site";
      b. `exact` requires an actual coordinate. The store uses this field for locational
         GRANULARITY, not just coordinate precision — 48 rows are honestly labelled `state`
         with no lat/lng, meaning "we know the state and no more", and that is fine. What is
         incoherent is claiming a precise point we do not have. This gate's first run found
         19 such rows, all from `enumerate_dc.py` defaulting `... or "exact"` whether or not
         PeeringDB returned coordinates;
      c. the published rollup must agree with what this gate independently counts. A
         reassuring coverage number that disagrees with the enforced one is the exact shape
         of bug gates 8 and 10 were written for.
    """
    errs = []
    roll = ((d.get("meta") or {}).get("rollups") or {}).get("geo_precision")
    datasets = (d.get("datasets") or {})
    for name in ("data_center", "power_project"):
        rows = datasets.get(name) or []
        mapped = [r for r in rows if r.get("lat") is not None and r.get("lng") is not None]
        unlabelled = [r for r in mapped if not r.get("geo_precision")]
        if unlabelled:
            ex = ", ".join(str(r.get("id")) for r in unlabelled[:3])
            errs.append(f"[geo] {name}: {len(unlabelled)} row(s) carry a coordinate with no "
                        f"geo_precision — an unlabelled point cannot be rendered honestly "
                        f"(e.g. {ex})")
        # `exact` is a claim to a precise point — it cannot stand without one
        phantom = [r for r in rows if r.get("lat") is None and r.get("geo_precision") == "exact"]
        if phantom:
            ex = ", ".join(str(r.get("id")) for r in phantom[:3])
            errs.append(f"[geo] {name}: {len(phantom)} row(s) claim geo_precision 'exact' with "
                        f"no coordinate — a precise location we never had (e.g. {ex})")
        if not isinstance(roll, dict):
            continue
        block = roll.get(name)
        if not isinstance(block, dict):
            errs.append(f"[geo] rollups.geo_precision is missing the '{name}' block — the "
                        f"measured value must be live, not partial")
            continue
        exact = sum(1 for r in mapped if r.get("geo_precision") == "exact")
        for key, found in (("rows", len(rows)), ("mapped", len(mapped)),
                           ("unmapped", len(rows) - len(mapped)), ("exact", exact),
                           ("unlabelled", len(unlabelled)),
                           ("centroid", len(mapped) - exact - len(unlabelled))):
            if block.get(key) != found:
                errs.append(f"[geo] rollups.geo_precision.{name}.{key} reports "
                            f"{block.get(key)} but the gate finds {found}")
    return errs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data", nargs="?", default="data.json")
    ap.add_argument("--schema", default="data.schema.json")
    ap.add_argument("--max-stale-days", type=int, default=DEFAULT_STALE_DAYS)
    a = ap.parse_args()
    d = load(a.data); schema = load(a.schema)
    errs = (structural(d, schema) + referential(d) + financials_integrity(d)
            + edge_integrity(d) + review_queue_integrity(d) + backbone_reach_integrity(d)
            + dc_role_coverage_integrity(d) + source_policy_integrity(d)
            + capacity_provenance_integrity(d) + dedup_integrity(d)
            + geo_precision_integrity(d))
    warns = semantic(d, a.max_stale_days) + untiered_directory_exposure(d)
    print(f"== validate_data: {a.data} (schema_version {d.get('schema_version')}) ==")
    dc = d["datasets"]["data_center"]; pw = d["datasets"]["power_project"]
    print(f"records: {len(dc)} data_center, {len(pw)} power_project, {len(d['datasets']['news'])} news, "
          f"{len(d.get('entities',[]))} entities, {len(d.get('edges',[]))} edges, "
          f"{len(d.get('supply_chain',{}).get('nodes',[]))} supply nodes")
    chain = d.get("chain", {}) or {}
    if chain or d.get("projects") or d.get("prices"):
        print(f"compute-seed: {len(chain.get('entities',[]))} chain entities, "
              f"{len(chain.get('edges',[]))} chain edges, {len(d.get('projects',[]))} projects, "
              f"{len(d.get('prices',[]))} prices")
    for e in errs: print("ERROR " + e)
    for w in warns: print("warn  " + w)
    print(f"\n{len(errs)} error(s), {len(warns)} warning(s) — {'FAIL' if errs else 'PASS'}")
    sys.exit(1 if errs else 0)

if __name__ == "__main__":
    main()

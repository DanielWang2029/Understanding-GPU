---
name: provider-rating
description: Ingest and normalize GPU-cloud provider quality ratings (ClusterMAX-style, 10 dimensions + tier) into the dcv pipeline as the L8 provider-rating loop. Use when wiring the Provider Terminal Page's quality panel, ingesting ClusterMAX, or computing the rating dimensions we can measure ourselves. Enforces multi-source agreement, hysteresis on tier changes, and correct attribution.
---

# Provider-rating loop (L8)

A compute buyer needs "is this provider any good?" alongside price. Ratings move slowly and must be multi-sourced and attributed. See `docs/TDD-compute-terminal.md` §2 (L8).

## The 10 dimensions (ClusterMAX standard — mirror the schema)
`security · lifecycle · orchestration · storage · networking · reliability · monitoring · pricing · partnerships · availability`. Tier ∈ `{platinum, gold, silver, bronze, underperform}`.

## The L8 contract
- **Setpoint:** every active (priced) provider rated across all 10 dims; freshness ≤ quarterly.
- **Measured:** rating coverage %; staleness; agreement across rating sources.
- **Error:** missing/stale ratings; source disagreement.
- **Correction:** re-ingest ClusterMAX; compute the dims we CAN measure; escalate disagreement to review.
- **Mechanisms:** **requisite variety** (≥2 rating sources) · **hysteresis** (don't flip a tier on one weak signal) · **human-in-the-loop**.

## Procedure
1. **Ingest ClusterMAX** via `clients/clustermax.py` → `provider_rating` rows with `source='clustermax'`, the tier, the 10 dims, and `as_of`. **Attribute it** — display "per ClusterMAX (SemiAnalysis)" with a link-out. **Confirm ToS before mirroring** vs link-only (Findings §7). Never present someone else's rating as ours.
2. **Compute the dims we can measure** (`source='measured'`) — start with the ones our own data already supports: `pricing` (price-transparency + our cross-aggregator dispersion), `availability` (a proxy from price volatility + capacity announcements), and — uniquely ours — a **power-headroom / deliverability** signal from the ISO/EIA layer. This is the differentiator: a rating dimension nobody else computes.
3. **Reconcile sources (requisite variety):** when ClusterMAX and measured/user-review sources agree → high confidence. When they disagree → lower confidence + open a review; do NOT silently average.
4. **Hysteresis on tier:** only change a provider's displayed tier on strong, corroborated evidence; a single weak contrary signal must not flip Gold↔Silver (stops rating flapping, mirrors the status hysteresis rule).
5. **Emit** `ratings[]` to the read-model: `{provider_id, source, tier, dims{…10}, as_of, confidence}`. The Provider Page renders a radar/bar from this, one series per source.
6. **Validate:** extend `data.schema.json` (`ratings[]`, `tier`/dim enums, `as_of` required, `provider_id` referential); single-source rating → warn.

## Definition of done
Every priced provider has ≥1 attributed rating; the dims we compute ourselves are labeled `measured` and sourced; tier changes are hysteresis-guarded; validator green.

---
name: entity-unit-of-analysis
description: Before attaching a metric (market cap, revenue, capacity, a supply edge) to an entity/node, assert the metric's real-world reporting unit matches the node's real-world unit — parent vs segment vs brand vs site. Use whenever you resolve names to entities, promote entities into the store, or bind financial/operational figures to a graph node. Complements loop-design, which moves numbers correctly but never checks the number describes the same thing as the node.
---

# Entity unit-of-analysis

A graph node is a claim about a *specific real-world unit*. A metric is a claim about a *specific reporting unit*. When they silently differ, the pipeline is "correct" (it moved the number faithfully) and the product is wrong (the number is about a different thing than the node). This is invisible to the loop-design gate — the value has perfect provenance; it's just attached to the wrong entity.

## The one rule
**Never attach a metric to a node until you've confirmed the metric's reporting unit IS the node's real-world unit.** Parent ≠ segment ≠ brand ≠ subsidiary ≠ site.

### The cautionary example (why this skill exists)
P2 mapped the seed's `amazon` node to the store's `aws` entity (name "Amazon Web Services"), then attached FMP's **Amazon.com consolidated** financials: revenue $716.9B, market cap $2.66T. But the AWS *segment* revenue is ≈ $115B. So the cloud node on a GPU-compute sankey was overstated ~6×, and the verified headline result "Revenue → Amazon dominates" was a **modeling artifact, not signal** — a direct failure of the product's one job (show where value sits along the chain). Same trap for Alphabet/Microsoft/Meta parent-vs-cloud-segment.

## Checklist (run at every entity↔metric binding)
1. **Name the unit on both sides.** For the node: is it a parent, a reporting segment, a brand, a subsidiary, a physical site? For the metric: what filing/line item is it — consolidated, segment, product-line? Write both down.
2. **Match or reconcile.** If they match, proceed. If they don't (parent financials on a segment node), you must do ONE of:
   - attach the **segment** figure instead (preferred when disclosed — most 10-Ks segment-report cloud/DC revenue);
   - **relabel the node** to the unit the metric describes (e.g. "Amazon (consolidated)") and **exclude it from layer-magnitude math** where the segment is what matters;
   - keep it, but **flag the mismatch** on the value (`unit:"parent_consolidated"`) so downstream math and the UI can down-weight/annotate it. Never leave it silently mismatched.
3. **Id-remap ≠ unit-merge.** Canonicalizing ids (`amazon→aws`) makes two ids refer to one row; it does NOT make a parent's numbers describe a segment. Resolving identity and resolving unit-of-analysis are separate steps — do both.
4. **Watch the double-count — shape A: two nodes, one unit.** Two nodes for the same real-world unit (parent + subsidiary, or two tickers of one issuer) double-count any cap/revenue-weighted flow or treemap. Enforce one node per unit, or net them.
5. **Watch the double-count — shape B: one disclosure, many candidate nodes.** An **unnamed aggregate** disclosure describes exactly ONE counterparty. "One customer represented 19% of revenue" is a single fact; attaching it to every plausible claimant draws it as N separate flows. Score the attribution, keep only the best-attributed claimant, and **on a tie drop all of them** — a coin-flip between two counterparties is not evidence for either. A claim whose attribution **flips run-to-run** is proof the attribution is a coin flip, not a reason to average. Note this is the opposite remedy to shape A: *never* "net them" — the figure belongs wholly to one node or to none. (Live case: TSMC's unnamed 19% landed on nvidia, broadcom and amd across successive runs; all three tied at zero confidence, so none published. See `evidence-extraction` rule 3.)
6. **Segment data is a real source, not an estimate.** Prefer disclosed segment figures (10-K segment notes, EDGAR) over a parent number; only fall back to an estimated split when no segment is disclosed — and then mark it `estimated` with the method.

## Output
For any entity-resolution or financial-binding change, record a one-line unit assertion per bound metric — `<node> unit = <X>; <metric> reporting unit = <Y>; match|reconciled-by:<how>` — in the module note. A binding that can't state the match is not done.

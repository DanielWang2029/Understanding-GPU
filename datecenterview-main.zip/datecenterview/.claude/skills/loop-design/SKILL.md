---
name: loop-design
description: Apply the dataCenterView loop-engineering discipline (L1–L9 / U1–U4 / FF) whenever you ADD or CHANGE a data source, pipeline stage, feature, or view. Forces every new piece of the system to be a proper feedback controller — a setpoint, a measured value, an error signal, a correction, and the right mechanism (deadband, requisite variety, active learning, feedforward, hysteresis) — instead of one-shot ETL. Use before writing a new connector, ingest stage, alert, or dashboard view.
---

# Loop design

This project runs ingestion and UX as **closed feedback loops**, not one-shot ETL (see `docs/loop-engineering-value-chain-proposal.md`, `docs/loop-mechanisms-catalog.md`). Any new source/stage/feature MUST be designed as a controller. Do not add a plain "fetch → store" step.

## The 5-line contract (fill this in first — do not skip)
For the thing you're adding, write down:
1. **Setpoint** — the target it drives toward (a freshness horizon, coverage %, precision, a $ budget).
2. **Measured value** — what you actually observe each cycle (age, fill %, conflict rate, dispersion, spend).
3. **Error signal** — setpoint − measured, with a tolerance.
4. **Correction** — the action when error exceeds tolerance (re-query, add a source, lower confidence, escalate to human, circuit-break).
5. **Mechanism(s)** — pick from the catalog below to match the disturbance, not more.

If you can't fill all five, you're building open-loop ETL — stop and reconsider.

## Pick the mechanism to match the disturbance (requisite variety)
| If the disturbance is… | Use | Why |
|---|---|---|
| High-frequency + noisy (prices) | **deadband** + anomaly detection + high sample rate (L7) | store/alert only on material moves; a spike is signal, not noise |
| A value that flip-flops (status) | **hysteresis** (asymmetric up/down thresholds) | stops status flapping on one weak source |
| A source that can go bad (spam/rebrand) | **circuit breaker** | quarantine on precision drop |
| A burst (news spike, feed catch-up) | **anti-windup / backpressure** | cap the queue/spend so it can't run away |
| A leading indicator exists (permit, queue, CoWoS allocation) | **feedforward** | act before the lagging signal moves — the freshness/edge play |
| A fact that must be trusted | **maker-checker, different vendor** + ≥2 independent sources (requisite variety) | same-vendor agreement is meaningless |
| Limited verification budget | **active learning** (uncertainty sampling) | spend on lowest-confidence × highest-value first |
| A self-improving rule (classifier, prompt) | **double-loop** flywheel + a **balancing gate** | never let a reinforcing loop train on its own unverified output |

## Guardrails (where loops bite back — always check)
- **Reinforcing without balancing = runaway error.** Pair any flywheel (L4) with an eval/gold-set gate (L6) and keep humans on the highest-uncertainty path.
- **Delays cause oscillation.** Tune polling to the *real-world change rate* of the thing, not a fixed cron.
- **Requisite variety costs money.** Match the environment's variety; don't exceed it. 2 decorrelated sources beat 5 correlated ones.
- **Feedforward needs a calibrated disturbance model.** Treat its output as a *candidate* (amber, low-confidence) until verified downstream by L2.

## Provenance & validation are part of the loop (non-negotiable)
- Every value carries `sources[] + confidence + as_of/last_verified` (the `Field<T>` discipline, `docs/data-schema-and-validation-spec.md`).
- Add the new shape to `data.schema.json` + `validate_data.py` (structural + referential + freshness). The validator is the balancing gate (L6) — it must stay green or block publish.

## Conformance gate — a contract you don't implement is a lie (check before you merge)
The 5-line contract is a **build gate, not a design note.** A contract filled in a docstring while the code implements half of it is the exact "open-loop ETL with a nice comment" failure this skill exists to prevent (it is how P2/L9 shipped a circuit breaker, reconciliation, and a delta-log that existed only as prose). Before the stage merges, produce a **conformance table** — each of the 5 lines mapped to the code that implements it, or explicitly deferred:

| Line | Implemented at (`file:line`) | …or DEFERRED (why + tracked-as) |
|---|---|---|
| Setpoint | | |
| Measured value | | |
| Error signal | | |
| Correction | | |
| Mechanism(s) | | |

Rules:
- **No docstring-only mechanisms.** If a docstring says "circuit breaker" / "reconciliation" / "deadband", grep for the code. If it isn't there, either implement it or delete the claim and mark the line **DEFERRED — open-loop for now, tracked as `<ref>`**. An honest "deferred" beats a contract that lies.
- **The measured value must be live**, not a hardcoded string. Compute coverage / staleness / dispersion / spend in the pipeline and emit it (e.g. `meta.rollups`) so the loop's own sensor is real and the UI reads *that*. A hand-typed "8 disclosed + 21 estimated" is not a measured value.
- **Adversarially test the balancing gate (L6).** The validator is only a gate if it rejects bad input. Every new `validate_data.py` check ships with a passing example AND a **must-fail** example (a unit test). New `data.schema.json` objects get `additionalProperties: false` by default, and a "disclosed" claim must be *structurally* forced to carry value + as_of + source. A green validator with holes is worse than none — it grants false assurance.
- **No unexercised code.** An "automation path" / client that nothing calls gets one mocked test or it does not merge. Speculative dead code bit-rots and hides bugs until first real use.
- **Exercise the UNDO before you call a write-path loop done.** A correction that mutates state (de-rate, re-open, quarantine, tier change, circuit-break) must have an explicit reversal, and you must *run* it. The gate's other rules are all forward-only — setpoint, measured, error, **correction** — so a controller can pass every one of them while its reversal path doesn't exist. **The reversal path is where the missing states live.** Check three things:
  1. **Is the correction idempotent?** Does the same input applied twice move the state twice? Repeated inputs must log without re-moving state — otherwise your hysteresis guarantee is defeated by *persistence* rather than by force. (Band-1 #3: coalescing deduped only *within* one drain, so repeat disputes ground a record 0.95 → 0.81 → … → the floor and pinned it out of `approved` forever.)
  2. **Can the loop say the input itself was wrong?** Distinguish "the value is bad" from "the signal about the value was bad." If every exit asserts something nobody verified, you are missing a verdict — add it. (`reject` rejects the *record*; `approve` asserts a verification nobody performed; hence `dismiss`.)
  3. **Which actions are TERMINAL?** Enumerate them explicitly. A non-terminal action that clears the flag (`edit`) strands the correction with no undo.
  Restore from the **earliest** entry in the open run, never the latest — restoring from the latest restores an already-degraded value. Append the reversal to the audit trail; never rewrite history.
  *The method that finds these:* cleaning up your own smoke-test rows **is** the reversal test. Do it deliberately, on the live store, before declaring the loop closed.
- **A constraint holds over a SET of paths — enforce it on every one, not the one that broke first.** After `enrich.py` was filtered for competitor URLs, the next volume run reintroduced them through **PhaseB discovery**, a path nobody had checked. Enumerate every path that can introduce the thing you are constraining (including a verifier's own web search), filter each, and keep the publish gate as the backstop. Where a constraint is about *entitlement to the data* rather than its correctness, use the **`source-admissibility`** skill — the loop cannot see a licensing violation, because inadmissible data passes every correctness check.
- **A measured value that is a per-path constant is not a control signal.** Before building a threshold, a ranking or a sampler on top of a number, **look at its distribution**. All 364 queued DCs carry exactly two confidence values (0.72 news, 0.75 PeeringDB), so every threshold approves all-or-none and `(1-conf)×log1p(mw)` silently degenerates to ranking by capacity. The controller runs, reports, and does nothing — the hardest failure to notice, because nothing errors.
- **Regression-check the case that already worked.** Before accepting any change to an extractor, resolver, prompt or parser, re-run the inputs that previously succeeded and compare **counts, not just green tests**. Validating an "improvement" only on inputs that previously yielded zero cannot detect that it took nvidia from 6 edges to 0 (Band-1 #2). The previously-working case ships as a locked regression test in the same commit as the fix.

Put the conformance table + the 5-line contract in the TDD or the stage's module docstring, implement, then **re-check the table against the code before you call it done.**

## Four failure classes the loop does NOT catch — use the companion skills
The control loop governs how a value is *ingested and kept fresh*. Four classes live outside it and need their own discipline:
- **Whether we were entitled to the source at all** (licensing, ToS, robots) → **`source-admissibility`** skill. This is the one the loop is *structurally blind to*: inadmissible data passes every correctness check the controller applies — it is fresh, corroborated, cross-vendor verified and provenance-stamped. Decision #1 was prose for months while `enrich.py` pulled 27 capacities out of a competitor's database.
- **Turning a document into a graph fact** (extract → cross-verify → resolve → attach) → **`evidence-extraction`** skill. The loop says "use a different-vendor checker"; it never says *on what key the two models' outputs are joined*, what a "miss" means, or whether the source can even reach the thing you're measuring. That silence is where the bugs were.
- **Rendering a value's provenance** (a badge / flag / confidence in a read-model or UI) → **`provenance-rendering`** skill. The loop guarantees the *store* carries `basis`/`sources`; it does NOT guarantee the UI shows the right one for the right metric. (P2's Chain-Analysis "EST" badge on real disclosed market caps is this failure.)
- **Attaching a value to the right real-world entity** (parent vs segment vs brand; unit-of-analysis) → **`entity-unit-of-analysis`** skill. The loop moves numbers correctly; it does not check the number describes the same thing as the node it lands on. (P2's `aws` node carrying Amazon-consolidated financials is this failure.)

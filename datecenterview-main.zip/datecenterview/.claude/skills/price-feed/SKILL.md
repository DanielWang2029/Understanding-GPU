---
name: price-feed
description: Onboard or refresh a GPU-rental price source (GetDeploying, AI-Multiple GPU Index, Cloud GPU Tracker, or a provider page) into the dcv pipeline as the L7 high-frequency price-feed loop. Use when adding a pricing aggregator, building the price_point time-series, wiring the Compute Price Board, or debugging price freshness/noise. Enforces deadband, cross-source agreement, and time-series discipline.
---

# Price-feed loop (L7)

GPU prices are the compute buyer's #1 signal and move daily + noisily, so they need their OWN controller — do not reuse the slow-fact loops (L1–L3). See `docs/TDD-compute-terminal.md` §2 (L7) and §4 (schema).

## The L7 contract
- **Setpoint:** on-demand price freshness < 24h; every existing (SKU × active-provider × region × term) cell covered; ≥2 aggregators agree within tolerance.
- **Measured:** age of latest `price_point`; grid fill %; cross-aggregator dispersion; per-cell volatility.
- **Error:** staleness / missing cells / dispersion > tolerance / anomalous jump.
- **Correction:** re-poll; rotate/add aggregator; on anomaly → flag + emit change event (never suppress); on feed degradation → circuit-break.
- **Mechanisms:** high sample rate · **deadband** · **anomaly detection** · **requisite variety** (multi-aggregator) · **circuit breaker**.

## Procedure to add a price source
1. **Adapter, not a bespoke script.** Implement `clients/price_aggregator.py`'s interface (one adapter per aggregator). Register the source in the `source` registry with a **trust weight** and a **circuit breaker** threshold — treat it exactly like a news feed.
2. **Normalize** each listing to a `price_point`: `{sku_id, provider_id, region, term(on_demand|reserved_1yr|spot), usd_per_gpu_hr, as_of, source_id, method}`. Resolve provider → `entity` and SKU → `sku` (alias tables); drop rows that don't resolve (log them, don't guess).
3. **Deadband before store.** Append a new `price_point` only if it differs from the last stored point for that cell by more than the per-SKU deadband (default ±2%, tune by observed volatility). This is both cost control (fewer writes) and alert quality (U4). `price_point` is **append-only, time-indexed, partitioned by month.**
4. **Anomaly = signal.** A jump beyond the anomaly band is NOT suppressed by the deadband — it's stored AND emits a change event (feeds alerts and the anomaly review, schema spec §4.5).
5. **Cross-source (L2 for price):** confidence is derived at rollup from **cross-aggregator agreement**, not per row. `n_sources < 2` → warn (mirrors the confirmed-but-single-source rule). Dispersion > tolerance → warn + review.
6. **Rollup in DuckDB → read-model:** compute `price_rollup` = `{low, median, high, n_sources, spark[90d], delta_30d, as_of}` per cell. **Ship the rollup + a downsampled 90-day sparkline to `data.json`, never raw hourly points.**
7. **Validate:** extend `data.schema.json` (`prices[]`, `term` enum, `usd_per_gpu_hr` range 0–200, `as_of` required, monotonic timestamps) and run `validate_data.py --max-stale-hours 24`.

## Forward curves — spot is only half the answer (add Kalshi)
Spot price tells a buyer today's cost; it does NOT tell them whether to **lock in or wait**. Pair the spot feed with a **forward curve**: **Kalshi GPU compute forward curves** (CFTC-regulated, launched 2026-07-14) publish market-implied future prices for H200 / B200 / A100 (referencing Ornn's spot index), derived from its prediction markets.
- Add `clients/kalshi.py` → a `price_forward` record `{sku, horizon(e.g. 3mo/6mo/12mo), usd_per_gpu_hr, as_of, source}`.
- Render a **forward column / curve** next to spot; the sign of `(forward − current_median)` is the buy-timing signal (▼ = market expects cheaper → wait; ▲ = tightening → lock a reservation).
- Coverage is partial (a few SKUs today) — mark SKUs without a live Kalshi curve as `modeled` (our own extrapolation), never as market-implied. This is the same disclosed-vs-estimated discipline applied to forwards.
- Keep SKUs current: as new accelerators ship, add them (e.g. Blackwell-Ultra **B300 / GB300**) — the SKU list is data, not code.

## Gotchas
- Spot vs on-demand vs reserved are different terms — never blend them into one median.
- Some aggregators quote per-instance (8× GPU) — normalize to **per-GPU-hr**.
- A provider absent from an aggregator ≠ price 0 — emit "no offering," not a blank/zero.
- Circuit-break a feed whose resolve-rate or freshness drops; degrade to last-known + a staleness badge, don't fail the whole board.

## Definition of done
Real prices for ≥6 SKUs × ≥10 providers in the read-model; freshness < 24h; deadband demonstrably suppresses sub-threshold noise while anomalies pass through; validator green.

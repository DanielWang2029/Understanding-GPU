---
name: evidence-extraction
description: Turn a document (SEC filing, press release, article) into a graph fact via an extractor + a different-vendor checker. Use whenever you build or change a stage that reads a source document and writes an entity, edge, or magnitude — chain_topology, chain_quant, chain_identity, phaseb/extract. Governs how the two models' outputs are joined, what a "miss" is allowed to claim, and whether the source can structurally reach the thing you are measuring. Complements loop-design, which mandates a cross-vendor checker but never says on what key the two verdicts are compared.
---

# Evidence extraction

`loop-design` requires a maker-checker with requisite variety: "a fact that must be trusted → different vendor + ≥2 independent sources." It stops there. It never specifies **how the maker's output and the checker's output are matched**, **what an empty result is allowed to assert**, or **whether the source can reach the counterparty at all**. Every bug in Band-1 #2/#3b lived in exactly that silence: the loop contract was fully satisfied while the stage silently produced nothing, or produced the same fact three times.

## The four rules

### 1. Join maker→checker on a resolved ID, never on a model-produced string
The extractor and the verifier return different surface forms of the same company — `"TSMC"` vs `"Taiwan Semiconductor Manufacturing Company Limited"`. An exact string join makes the two sets disjoint and **silently drops every fact** (Band-1 #2: 3 → 12 edges once fixed). So:

- Resolve **both** sides locally through the alias map (word-boundary matching, longest alias wins) and join on the **backbone id**.
- **Never let a model produce an id.** Extraction returns surface strings; resolution is deterministic, local, and testable. A model guessing `inferred_customer_id` is a different (weaker) claim than a model naming a company — treat it as such.
- Keep a raw-string fallback only for names that don't resolve, and **log those as backbone-expansion candidates** rather than dropping them (Band-1 #2 surfaced a whole missing equipment tier that way).
- **An all-empty cross-verify result is a bug signature, not a verdict.** If the intersection is zero across every input, suspect the join before you conclude the source is dry.

### 2. A miss must be auditable — say *why*, and show what you read
"The filing discloses nothing" and "we anchored on the wrong section" look identical from the outside, and **only the first is a fact about the world**. Reporting the second as coverage is how a dashboard starts lying about the market rather than about itself. So every non-result records a reason plus the head of the excerpt actually read. Use an explicit taxonomy:

| Reason | Kind of claim | May it be reported as coverage? |
|---|---|---|
| `no_disclosure` — we read the right section, it discloses nothing | about the **world** | yes |
| `wrong_anchor` — nothing matched, or we matched a same-shaped decoy | about **us** | **no** — it's a measurement gap |
| `source_out_of_reach` — the entity doesn't file with this source at all | about **reach** (rule 4) | **no** |
| `unresolved_name` — real counterparty, not in the backbone | about **our model** | **no** |

Empty-excerpt and found-but-nothing-in-it must stay distinguishable in code. Preserve evidence you can't attribute (e.g. `targeted_unattributed`) rather than deleting it — "TSMC discloses one customer at 19% but we can't say which" is a real, useful fact.

### 3. An unnamed aggregate disclosure is mutually exclusive
"One customer represented 19% of revenue" describes **exactly one** counterparty. Quantifying edge-by-edge lets that single figure land on several edges — TSMC's 19% attached to nvidia **and** broadcom **and** amd across runs — drawing one fact as three flows in the sankey.

- Group unnamed disclosures by `(source_entity, value, as_of)`; keep only the **best-attributed** claimant.
- **On a tie, drop them all.** A coin-flip between counterparties is not evidence for either.
- A verdict that **flips run-to-run** is itself proof the attribution is a coin flip — treat instability as a signal, not as noise to average away.
- Filings that **name** the counterparty beside the figure are exempt: two named customers can honestly sit at the same percentage.

### 4. Find-reach ≠ size-reach — state it before you build the sizing pass
The source that can **find** a relationship may be structurally unable to **size** it. Buyer 10-Ks name Foxconn, Samsung and SK Hynix as suppliers; none of them file a US annual report, so EDGAR can never quantify those edges — **5 of 12** named edges in Band-1 #3b. That is a permanent property of the source pairing, not a prompt problem, and no amount of retrying fixes it.

Before building a quantification pass, write down which discovered counterparties the sizing source can reach. Emit the reach gap as a **measured value** (a named, counted set), never as a low-confidence estimate that makes the column look full.

## Extraction mechanics (the ways an excerpt picker goes wrong)
- **Rank candidate windows; don't take the first pattern hit.** Taking the first match of the highest-priority pattern anchors on whichever same-shaped section appears earliest in a 900k-char filing (Amkor's end-market table beat its concentration note). Score candidates by the **density of the signal you actually want** and let the best window win.
- **Clamp the window at the document tail** so a match near the end still gets a full window — otherwise you return a header and miss the figures it introduces.
- **Re-run the whole known-good corpus after any extractor change and compare counts** (the `loop-design` conformance rule). An "improvement" validated only on inputs that previously yielded zero cannot detect that it took nvidia from 6 edges to 0.

## Persist the quote, not just the value — and the evidence, not just the verdict
Two ways evidence dies at a boundary, both of which this project shipped:

- **The extractor's supporting quote must reach the store.** Phase B always *required* a quote (an unquoted number is dropped as a hallucination) and then discarded it on write, so re-verification could only check our VALUES rather than values-plus-evidence — materially weaker — and a human reviewing the queue saw a number with nothing behind it. `"400 MW"` and *"earnings results suggest the site could host up to 400MW"* are the same number and very different claims; only the second shows the hedge. Store it (`Field<T>.quote`), and where the container is a plain dict rather than a `Field<T>`, carry it explicitly (`location.quote`).
- **A checker's corroborating sources must be persisted with its verdict.** Keeping `review_status` while dropping the sources that justified it left 23 rows asserting `approved` on a ≥2-source gate while the record showed one. If the verifier found independent corroboration, that URL is part of the finding — subject to `source-admissibility`, since the verifier's own web search can surface anything.

Record which basis a check ran on (`with_quote` vs `no_quote`) so a reader can distinguish a first-pass verdict from a full-strength re-check from a values-only one. Expect coverage to lag badly after the fix — only newly extracted rows carry quotes (3 of 338 the day after) — and report that split rather than implying the store is uniformly evidenced.

## Cross-vendor discipline (non-negotiable)
Assert `settings.extract_model` ≠ `settings.verify_model` **at import**, by vendor prefix — same-vendor agreement is correlated and certifies nothing. Vote both steps when the verdict is unstable (extraction: modal over N; verify: majority over N). Record the pair and the vote counts on the emitted fact (`verify: {extractor, verifier, extraction_votes, ...}`) so a reader can audit *how* it was agreed, not just that it was.

## Separate identity from attribution
"We know **who**" and "we can pin **this number** to them" are two verdicts with two gates. A relationship can be `named` (a filing names the supplier) while its magnitude stays `needs_review` (the disclosed % can't be attributed to that specific party). Emit them as separate fields — `link_basis` vs `rev_basis`/`review_status` — and never let confirming one silently confirm the other. Multi-customer suppliers stay unattributable from public data; only a dominant-customer edge reaches `confirmed`.

## Output
For any extraction stage, record in the module docstring: the **join key** (rule 1), the **miss taxonomy** it emits (rule 2), the **reach gap** for its source pairing (rule 4), and which fields carry identity vs magnitude. A stage that can't state its join key is not done.

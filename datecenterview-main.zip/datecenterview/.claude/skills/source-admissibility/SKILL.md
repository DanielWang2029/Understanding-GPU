---
name: source-admissibility
description: Decide whether a source may be used at all — licensing, ToS, robots — and enforce that decision as code on every ingest path plus the publish gate. Use whenever you add or change a connector, a discovery query, an enrichment step, or any code that fetches a URL, and whenever you find data already in the store that came from a source you are not entitled to use. Governs tiering, where enforcement must live, and how to remediate a value that has already shipped. Complements loop-design (which secures how a value is kept fresh, never whether we were allowed to take it) and evidence-extraction (which governs turning a permitted document into a fact).
---

# Source admissibility

Every other discipline in this project asks *is this value correct?* This one asks a prior question: **were we entitled to take it?** A figure can be perfectly extracted, cross-vendor verified, provenance-stamped and still be a liability — because the constraint that governs it is legal, not epistemic, and no amount of corroboration cures it.

Decision #1 has been in `CLAUDE.md` from the start: *don't scrape CleanView or other paid competitors' curated data.* It sat there as **prose for months**, and in that time `enrich.py` extracted **27 facility capacities straight out of competitor databases** and **104 tier-1 URLs reached the published read-model**. Nobody decided to violate it. The constraint simply had no representation in code, and prose does not execute.

## Rule 1 — A constraint that isn't code isn't enforced
Write the policy as a module (`source_policy.py`) that any fetch path can call, and make the publish gate depend on it. Until then you do not have a constraint, you have an intention. The test of whether a rule is real: **can it fail a build?**

## Rule 2 — Enforce on EVERY path, not the one that broke first
This is the rule that cost the most. After `enrich.py` was filtered, the next volume run **reintroduced tier-1 URLs through PhaseB discovery** — a path nobody had checked, because attention had gone to the path that failed. Before you call it fixed:

1. **Enumerate every code path that can introduce a URL.** Discovery queues, enrichment, verification (the verifier does its *own* web search and can surface anything), manual fixtures, seed files, backfill.
2. Filter at **each** of them.
3. Add the **publish gate** as the backstop that catches what you missed.

Defence in depth is not belt-and-braces here — the discovery path and the publish gate caught different escapes of the same rule, weeks apart.

**Refuse at the earliest possible point.** A denied candidate should be dropped *at the queue*, so it is never fetched at all. Filtering after retrieval means you already made the request, already have the content in memory, and are relying on discipline not to use it.

## Rule 3 — Tier the sources; record the ruling with a date and an owner
Admissibility is not binary. Three useful tiers:

| Tier | Meaning | Action |
|---|---|---|
| **Deny** | paid, curated, licensed competitor DB | refuse at ingest; block at publish |
| **Allowed-but-tracked** | free, operator-submitted directories | permitted; **counted** so drift is visible |
| **Free/primary** | gov APIs, filings, first-party press | unrestricted |

The middle tier is a **judgement call, and it is not yours to make.** Put the decision to the owner, and when it is ruled, write the ruling into the code with the date and a *do not re-litigate* note — otherwise every future session relitigates it from scratch and eventually decides differently. (Ruled 2026-07-20: tier 2 stays.)

Track the allowed tier as a **live measured value**, not a comment. "Allowed but tracked" with nothing tracking it is just "allowed."

## Rule 4 — Remediation withdraws the VALUE, not the URL
When inadmissible data is already in the store, the instinct is to swap the citation for a permitted one. **That is laundering, and it produces a number you cannot defend.**

The values genuinely differ: `aligned-iad02` carried **163 MW** from CleanView and **120 MW** once re-derived from a permitted source. Re-citing would have kept 163 MW under a clean URL — a figure whose only true provenance was the source you are not entitled to use.

So: drop the value, return the record to `needs_review`, and re-derive from scratch. Log every withdrawal with the **complete old value** so the action is auditable and reversible (`loop-design`'s exercise-the-UNDO rule applies — this is a write-path correction).

## Rule 5 — Report the honest cost
Re-derivation recovered 14 of 27 capacities. **13 stay sizeless** — no permitted source states their MW.

That is not a bug and not a backlog. It is the price of the constraint, and it must be visible in coverage rather than quietly filled from somewhere else. A constraint whose cost is hidden gets silently abandoned the next time someone wants the number.

## Checklist
- [ ] Is the policy **code**, and can it fail a build?
- [ ] Did you enumerate **every** path that introduces a URL — including the verifier's own search — and filter each?
- [ ] Does the publish gate check it independently, with a must-pass **and** must-fail test?
- [ ] Are denied candidates refused **before** fetch?
- [ ] Is the tier-2 ruling recorded in code with a date and an owner?
- [ ] Is allowed-tier exposure a **live measured value**?
- [ ] On remediation: did you withdraw the **value**, log the complete old one, and re-derive rather than re-cite?
- [ ] Is the unrecoverable residue reported as coverage loss?

## Output
For any connector or fetch path, state in the module docstring which tier its sources fall in and which policy call guards it. For any remediation, record what was withdrawn, what was recovered, and **what stays permanently missing** — that last number is the one that proves the constraint is real.

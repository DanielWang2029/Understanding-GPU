---
name: chain-financials
description: Quantify the GPU compute-chain graph — attach market cap / revenue / capex to companies and a magnitude (%COGS, %revenue) to each supplier/customer edge — as the L9 financial / market-graph loop. Use when building the Chain Analysis (SPLC) view, the capacity/revenue/market-cap weight toggle, or wiring a financial connector (SEC EDGAR XBRL first; FMP is ticker-gated to 8 mega-caps). Enforces disclosed-over-estimated precedence, per-metric coverage targets, the three-state edge model (seed / named / quantified), and honest provenance.
---

# Financial / market-graph loop (L9)

This is the core loop of the terminal pivot: it turns a bare `entities + edges` graph into a *quantified, decision-grade* one — the SPLC (who depends on whom, by how much) + WCAP (where market value concentrates) layers. See `docs/TDD-compute-terminal.md` §2 (L9), §4 (schema).

## The L9 contract
- **Setpoint:** every key chain company has `market_cap/revenue/capex` (freshness ≤ 1 quarter); every key edge has a `value` (%COGS / %revenue / $) + a `disclosed` flag.
- **Measured:** financial coverage %; edge-quantification rate; disclosed-vs-estimated ratio; reconciliation gap vs filings.
- **Error:** missing/stale financials; unquantified edges; an estimate that a new disclosure contradicts.
- **Correction:** pull FMP financials; extract relationship magnitudes from filings/earnings; cross-verify (L2); on a new disclosure, replace the estimate and log the delta (L4).
- **Mechanisms:** requisite variety (FMP + filings + press) · **disclosed > estimated precedence** · hysteresis · reconciliation vs authoritative anchors.

## Procedure
1. **Financials: lead with SEC EDGAR, not FMP.** `clients/edgar.py::company_financials()` reads free XBRL `companyfacts` (no key) for `revenue` + `capex`. FMP is a *supplement*: the connected plan gates **by ticker, not endpoint** — 8 mega-caps only (NVDA, TSM, INTC, AMD, MSFT, GOOGL, AMZN, META); every other symbol is access-denied, and there is no `FMP_API_KEY` in `.env`. Store per metric as a `money_field` (`value`, `as_of`, `basis`, `period`, `sources[]`, `unit`). Shipped guards, all load-bearing:
   - **`as_of` is the FILING date**, not the period end — freshness keys on when it was disclosed.
   - Annual only (`fp == "FY"`, form `10-K`/`20-F`); **refuse non-USD** rather than silently mixing currencies (blocks ASE/ASX).
   - EDGAR may **never overwrite a fixture-disclosed value**, and the builder targets **only currently-estimated** names — that is precisely what keeps consolidated parent revenue off a segment node like `aws` (see `entity-unit-of-analysis`).
   - **EDGAR carries no price**, so it can never widen `market_cap`. That needs a separate price source (Finnhub, or price × EDGAR shares-outstanding).
   - Foreign filers with no US CIK (Samsung, SK Hynix, Foxconn, Schneider) and privates stay `estimated` — **logged, never silently capped**.
2. **Assign each entity a `layer`** (foundry|packaging|hbm|gpu|server|networking|power|cloud|enduser) — drives the WCAP treemap coloring and the map layers.
3. **An edge has THREE states, not two.** Topology and magnitude are separate facts with separate sources — conflating them is how a graph starts inventing flows:
   - `topology_basis:"seed"` — **drawn**: we believe this relationship exists but nothing evidences it.
   - `topology_basis:"named"` + `link_basis:"named"` + `link_sources[]` — **evidenced**: a buyer's filing names the supplier. `pct_*` may be **absent**; the UI renders `— · not quantified` and the flow sankey skips it. A placeholder `0` would render "0%" — a confident claim of *no flow* where the truth is *unknown flow*.
   - `+ pct_revenue` / `pct_cogs` with `rev_basis`/`cogs_basis` — **quantified**.
   Topology comes from the **buyer's** 10-K (`chain_topology.py`); magnitude from the **supplier's** disclosed customer concentration (`chain_quant.py`). Suppliers sort by **%COGS** (cost exposure), customers by **%revenue** (revenue exposure) — the SPLC affordance. Direction is `supplies` **only**; an inverse `customer_of` double-counts in the sankey.
4. **Disclosed beats estimated — always.** If a value is disclosed in a filing, it overrides any estimate at the same (from,to,relation). The validator ENFORCES this (an estimate contradicting a disclosure at the same triple is an error, not a warning). Every estimated edge is confidence-scored and shown with an `estimated` badge in the UI.
5. **Cross-verify (L2):** a different-vendor pass confirms extracted magnitudes; disagreement lowers confidence and re-opens the edge.
6. **Emit** to the read-model: `entities[]` gain financials; `edges[]` gain `value` + `disclosed`; `meta.rollups.financials_coverage` + `edge_coverage` (the live L9 measured values; `market_cap_by_layer` was never built). The three views (map, SPLC chain, WCAP treemap) are pure functions of this.
7. **Validate:** extend `data.schema.json` — entity financial fields (≥0), `edge.value.basis` enum, `disclosed` bool, pct amounts 0–100, `as_of` required; the disclosed-overrides-estimate rule.

## Gotchas
- Market cap moves daily; revenue/capex quarterly — don't apply one freshness horizon to both.
- A relationship's *cost* share (to the buyer) ≠ its *revenue* share (to the seller) — store the basis, never blend.
- Most links are estimates; that's fine — the honesty (disclosed-vs-estimated + confidence) IS the product. Never present an estimate as disclosed.
- **Reconciliation vs the filing is DEFERRED** (fixture-based; no live re-pull or divergence check is wired). Per this project's own no-docstring-only-mechanisms rule, treat it as an open loop — do not describe it as if it runs.
- **The source that FINDS an edge may be unable to SIZE it.** Buyer filings name foreign suppliers that file no US annual report (Foxconn, Samsung, SK Hynix — **5 of 12** named edges). Record the un-sizeable set as a source-coverage fact; never fill it with an estimate to make the column look complete. See `evidence-extraction` rule 4.
- **%COGS is disclosed nowhere.** It stays estimated by decision, not by omission.

## Definition of done
State it **per metric** — a single conflated target hides which metric moved, and one of them is currently unreachable:

- **Revenue** — disclosed for every entity with a US CIK filing in USD (today **20/29**; the 9 remaining are foreign-no-CIK, private, or non-USD-blocked, and are individually logged).
- **Capex** — same reach as revenue (today **11/29**).
- **Market cap** — ⛔ **structurally capped at 8/29 until a price source is acquired.** EDGAR has no price. Do **not** set a market-cap coverage target against the current source set; a DoD the architecture cannot meet invites exactly the fake-completeness this skill exists to prevent.
- **Edges** — topology and magnitude reported separately (`edge_coverage.{topology_named, topology_seed, disclosed, estimated, named, confirmed}`), never as one "quantified %".
- Coverage is **emitted live** in `meta.rollups.financials_coverage` per metric and read by the UI — never hardcoded.
- Validator enforces disclosed-over-estimate; the SPLC + weight toggle render from the read-model. (The WCAP treemap was retired in v2.1 — market cap is a weight toggle, not a view.)

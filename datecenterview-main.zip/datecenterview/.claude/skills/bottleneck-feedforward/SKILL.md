---
name: bottleneck-feedforward
description: Model the upstream compute supply constraint (CoWoS → HBM → chip → server → power → cluster) as a FEEDFORWARD leading signal that predicts GPU availability/lead-time before the price moves. Use when building the Delivery-Constraint Funnel, the region power-headroom view, or any "can this cluster actually be delivered, and when?" feature. This is the terminal's edge over price aggregators, which only show *now*.
---

# Bottleneck feedforward (FF)

Current price is a **lagging** read of a supply squeeze. Feedforward (control-theory mechanism, `docs/loop-mechanisms-catalog.md` §1) turns the upstream constraint chain into a **disturbance model** that predicts availability/price *before* it hits — the single most differentiating mechanism for a compute-buyer terminal. See `docs/TDD-compute-terminal.md` §2 (FF).

## The disturbance model (two chains into one funnel)
```
 upstream:  CoWoS allocation → HBM supply → chip availability → provider capacity → price/lead-time
 downstream (ours, ~free):  ISO interconnect queue + BTM → energization date → cluster online
```
The **power stage is nearly free for us** — it's the ISO/EIA/BTM data we already have, finally load-bearing. That's where to start.

## The FF contract
- **Leading inputs:** TSMC/HBM earnings + TrendForce tightness (upstream, coarse in v1); our ISO/EIA interconnect queue + BTM (downstream power, real now).
- **Output:** per-stage `tightness ∈ {green,amber,red}` + `lead_time_days`, surfaced as the Delivery-Constraint Funnel (F4) and feeding a *predicted* availability signal into the Price Board.
- **Mechanisms:** **feedforward** (act before the news) · **PID-D** (rate-of-change of queue/allocation → scale attention early) · candidates verified downstream by L2.

## Procedure
1. **Start with the power stage (real).** From the existing ISO queue + EIA data, compute per-region **interconnect lead-time** and **power headroom** (available capacity vs pipeline compute demand). This alone answers "when can a cluster energize here?" — emit `bottleneck_stage(stage='power', region, tightness, lead_time_days, sources)`.
2. **Add coarse upstream stages** (`cowos`, `hbm`, `chip`, `server`) as manually-maintained tightness flags sourced from earnings/TrendForce notes (`sources/tightness.py`). Precision is low; that's fine — label them clearly and let them sharpen over phases.
3. **PID-D on the queue:** watch the *rate of change* of the interconnect queue / allocation, not just the level. A sudden spike in new large-load queue entries is a leading indicator of a coming squeeze — scale attention (and buyer warnings) up early.
4. **Every FF output is a CANDIDATE.** Show it as a leading signal (amber, lower-confidence), NOT as fact, until L2 confirms downstream (e.g., a price move or a capacity announcement validates the predicted squeeze). Calibrate the disturbance model against what actually happened (did the squeeze materialize?) and feed misses back via the flywheel (L4).
5. **Emit** `bottleneck[]` to the read-model: `{stage, region, sku_family, tightness, lead_time_days, as_of, sources}`. The funnel renders left→right with red/amber/green + lead-time per stage; each stage links to its evidence.
6. **Validate:** `data.schema.json` gains `bottleneck[]` (`stage`/`tightness` enums, `lead_time_days` range, `as_of` required, `sources` non-empty).

## Guardrails
- A bad disturbance model cries wolf — keep FF outputs low-confidence until verified, and track hit-rate as an SLO.
- Don't overfit the upstream flags to one earnings call; corroborate (requisite variety).

## Definition of done
Power lead-time per region derived from real ISO/EIA queue data; the funnel renders all six stages with sourced tightness; at least one squeeze surfaced as a leading signal before the corresponding price move (the feedforward win, TDD M5 exit).

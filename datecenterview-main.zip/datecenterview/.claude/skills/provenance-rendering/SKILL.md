---
name: provenance-rendering
description: Bind every provenance signal a user sees (a DISCLOSED/EST badge, a confidence dot, an as_of date, a source link) to the exact metric and source it actually describes. Use whenever you add or change how the read-model / UI shows the trustworthiness of a value — a badge, a flag, a tooltip, a color scale. Complements loop-design, which secures provenance in the STORE but says nothing about faithfully rendering it downstream.
---

# Provenance rendering

The product's core promise is **honest, inspectable, field-level provenance** — disclosed-vs-estimated, sourced, dated. That promise is kept in the store by the `Field<T>` discipline (`docs/data-schema-and-validation-spec.md`) and the loop-design gate. But provenance is only as honest as the pixel the analyst actually sees. A badge bound to the wrong signal doesn't degrade trust — it *inverts* it. This skill governs the last mile.

## The one rule
**A provenance signal must be driven by the provenance of the exact metric it sits next to — never a neighbouring or aggregate signal.**

If a card shows `$4.2T` (an entity's market cap) and a `DISCLOSED/EST` badge, that badge must read the *market cap's* `basis`, not the basis of some edge, relationship, or sibling metric that happens to be in scope.

### The cautionary example (why this skill exists)
P2's Chain Analysis rendered each supplier/customer card's badge from the seed **edge's** `disclosed` flag (`SUP[...][4]`) while the same card showed the **entity's real market cap**. Result: Alphabet's genuinely disclosed $4.2T rendered a red **"EST"** badge. The value was real; the badge called it a guess. On a trust-first terminal that is the worst-case failure — worse than showing no badge.

## Checklist (run when adding/altering any provenance UI)
1. **One metric, one badge, one source.** For each value with a visible trust signal, trace: value → which field's `basis`/`sources`/`as_of` drives the badge? They must be the same field. Write it down.
2. **Per-metric, not per-entity.** An entity can hold a disclosed market cap and an estimated revenue at once. A single entity-level `estimated` flag will mislabel one of them the moment the two metrics diverge (e.g. widening market_cap from a new source while revenue stays seed). Emit and read **per-metric** flags (`mc_estimated`, `rev_estimated`), and pick the one matching the **active weight / displayed metric**.
3. **Mixed-provenance views label each source distinctly.** When a single view fuses two provenance origins (e.g. entity financials + relationship-edge estimates), give them **separate, unambiguous** badges — never let one stand in for the other. If the edge % is estimated but the node value is disclosed, say both.
4. **Three absence states, three renderings.** `basis:"estimated"` ("we guessed the value"), `basis:"n/a"` ("this metric doesn't exist for this entity" — e.g. a private company's market cap), and **"not quantified"** ("we have filing evidence the relationship EXISTS, but no magnitude") are three different claims and must look different. The third is a first-class honest state, not a degenerate estimate: a discovered topology edge carries `topology_basis:"named"` + `link_sources[]` but **no** `pct_*`, so the UI renders `— · not quantified · named link` and the flow sankey **skips** it. Emitting a placeholder `0` would render as "0%" — a confident claim of *no flow* where the truth is *unknown flow*. Never collapse any of the three into another.
5. **Estimates carry their uncertainty.** A private-company estimate shown as a bare point value reads as fact. Surface a range / confidence / "internal estimate" qualifier so it can't be mistaken for a sourced figure.
6. **The measured provenance is live, not typed.** Coverage/freshness summaries in flags and footers ("8 disclosed + 21 estimated") must be computed from the data, not hardcoded — a hand-typed count silently lies the first time coverage changes. (This is the loop-design "measured value must be live" rule, applied to the UI.)

## Output
For any provenance-rendering change, add a one-line trace per signal — `<UI element> badge ← <data field>.basis` — to the component/module note, and confirm rules 1–4 hold. Ties into the **U2 (trust/dispute)** user-loop: a badge the user can't trust is the same open-loop failure as a dispute button that goes nowhere. That example is no longer hypothetical — it shipped as a stub that only relabelled itself, and was closed in Band-1 #3 (`POST /api/review` → `review_log` → the record re-opened for L2). The rendering lesson from that fix: **never report success you did not achieve.** On failure the control says "Could not file the dispute — nothing was queued" and re-enables retry, because a green confirmation for a write that never happened is the same inversion of trust as an "EST" badge on a disclosed value.

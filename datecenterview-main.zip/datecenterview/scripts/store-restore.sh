#!/usr/bin/env bash
# Load a local store snapshot into Postgres. The other half of store-dump.sh —
# a snapshot nobody can restore is a backup in the same sense that an untested undo is a
# reversal.
#
# DESTRUCTIVE, and says so. It drops and recreates the public schema, because a partial
# restore over an existing store silently merges two states and the primary-key collisions
# surface later as "why does this row have the wrong sources". Refuses to run without --force
# when the target already holds data.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="${1:-$ROOT/pipeline/snapshots/store.sql.gz}"
CONTAINER="${DCV_PG_CONTAINER:-dcv_postgres}"
DB="${POSTGRES_DB:-datacenterview}"
USER="${POSTGRES_USER:-dcv}"
FORCE="${FORCE:-0}"
[[ "${2:-}" == "--force" ]] && FORCE=1

[[ -f "$SRC" ]] || { echo "error: no snapshot at $SRC" >&2; exit 1; }
if ! docker ps --format '{{.Names}}' | grep -qx "$CONTAINER"; then
  echo "error: container '$CONTAINER' is not running — \`docker compose up -d postgres\`" >&2
  exit 1
fi

existing=$(docker exec "$CONTAINER" psql -U "$USER" -d "$DB" -tAc \
  "select coalesce(sum(c),0) from (select count(*) c from data_center
    union all select count(*) from power_project) t" 2>/dev/null || echo 0)

if [[ "$existing" -gt 0 && "$FORCE" != "1" ]]; then
  echo "refusing: '$DB' already holds $existing record(s)." >&2
  echo "This DROPS the public schema. Re-run with --force if that is what you want." >&2
  exit 1
fi

echo "→ dropping and recreating schema public in '$DB'…"
docker exec "$CONTAINER" psql -U "$USER" -d "$DB" -q \
  -c "drop schema public cascade;" -c "create schema public;"

echo "→ restoring $SRC …"
# stdout is the dump's own chatter; errors still surface. Counts below are the real check.
gzip -dc "$SRC" | docker exec -i "$CONTAINER" psql -U "$USER" -d "$DB" -q -v ON_ERROR_STOP=1 >/dev/null

echo "✓ restored. Row counts:"
docker exec "$CONTAINER" psql -U "$USER" -d "$DB" -tAc "
  select 'data_center', count(*) from data_center union all
  select 'power_project', count(*) from power_project union all
  select 'news', count(*) from news union all
  select 'entity', count(*) from entity union all
  select 'edge', count(*) from edge union all
  select 'change_log', count(*) from change_log union all
  select 'review_log', count(*) from review_log order by 1" | sed 's/^/    /'

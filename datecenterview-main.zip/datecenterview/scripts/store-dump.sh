#!/usr/bin/env bash
# Snapshot the Postgres system of record into an ignored local artifact.
#
# WHY THIS EXISTS. `data.json` is the published READ-MODEL and is committed, but it is not the
# whole truth: the store carries three
# things the read-model deliberately drops —
#
#   * the extraction QUOTE on every Field<T> ("earnings results suggest the site COULD host up
#     to 400MW" vs a bare 400) — store-side only; exposing it in the read-model is a schema
#     change nobody has taken;
#   * `change_log` — every withdrawal, re-verification and dedup batch, with the complete old
#     value, which is what makes corrections reversible;
#   * `review_log` — the human verdicts and disputes (the L4 training examples).
#
# Database snapshots can include source evidence and human review history. They stay local and
# must be shared through an approved private data channel, never through source control.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${1:-$ROOT/pipeline/snapshots/store.sql.gz}"
CONTAINER="${DCV_PG_CONTAINER:-dcv_postgres}"
DB="${POSTGRES_DB:-datacenterview}"
USER="${POSTGRES_USER:-dcv}"

if ! docker ps --format '{{.Names}}' | grep -qx "$CONTAINER"; then
  echo "error: container '$CONTAINER' is not running — start it with \`docker compose up -d postgres\`" >&2
  exit 1
fi

mkdir -p "$(dirname "$OUT")"
# --no-owner/--no-acl so it restores under whatever role the reader happens to have.
docker exec "$CONTAINER" pg_dump -U "$USER" -d "$DB" --no-owner --no-acl \
  | gzip -9 > "$OUT"

echo "✓ wrote $OUT ($(du -h "$OUT" | cut -f1))"
docker exec "$CONTAINER" psql -U "$USER" -d "$DB" -tAc "
  select 'data_center', count(*) from data_center union all
  select 'power_project', count(*) from power_project union all
  select 'news', count(*) from news union all
  select 'entity', count(*) from entity union all
  select 'edge', count(*) from edge union all
  select 'change_log', count(*) from change_log union all
  select 'review_log', count(*) from review_log order by 1" \
  | sed 's/^/    /'

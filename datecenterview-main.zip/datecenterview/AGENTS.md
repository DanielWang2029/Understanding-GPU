# Repository Guidelines

## Project Structure & Module Organization

- `pipeline/dcv/` contains the Python 3.12 ingestion, normalization, trust, and emit logic. Source adapters live in `sources/`, external-service clients in `clients/`, and Phase B workflow code in `phaseb/`.
- `pipeline/tests/` holds pytest coverage; `pipeline/seed/` contains committed, reviewable fixtures. Local Postgres snapshots belong in the gitignored `pipeline/snapshots/` directory.
- `web/` is the Next.js/React application. Routes are under `app/`, shared runtime code under `lib/`, and UI components under `components/`.
- `db/versions/` contains Alembic migrations. `data.json` is the published read model; `pipeline/data.schema.json` defines its contract.
- `docs/` contains product, architecture, research, handoff, and operational documentation. Keep only repository entry points and agent instruction files at the root.

## Build, Test, and Development Commands

- `uv venv --python 3.12 && uv pip install -e pipeline` installs the Python package. Set `PYTHONPATH="$PWD/pipeline"` if editable imports fail.
- `uv run pytest pipeline/tests -q` runs the pipeline test suite.
- `uv run ruff check pipeline` checks Python style; Ruff uses a 100-character line limit.
- `python pipeline/validate_data.py data.json --schema pipeline/data.schema.json --max-stale-days 45` runs the publish gate.
- `cd web && npm install && npm run dev` syncs `data.json` and starts the UI on port 3000.
- In `web/`, run `npm run typecheck` and `npm run build:check` before submitting. Use `build:check` while a dev server is active; a normal build shares `.next/` and can corrupt its artifacts.
- `docker compose up -d postgres` starts the local system of record.

## Coding Style & Naming Conventions

Match nearby code and keep changes surgical. Python uses four spaces, type hints, `snake_case` functions/modules, and `PascalCase` classes. TypeScript uses strict mode, two-space indentation, `PascalCase` React components, and the `@/` import alias. Do not hand-edit generated `web/public/data.json`; update the root read model through the pipeline or sync script.

## Testing Guidelines

Name Python tests `test_<behavior>.py` and functions `test_<expected_result>`. Add focused regression tests beside the affected domain. There is no configured coverage threshold, but changes must pass pytest, the data validator when the schema/read model changes, and web type/build checks for UI work.

## Commit & Pull Request Guidelines

Recent commits use concise, imperative, subsystem-prefixed subjects such as `pipeline: ...`, `docs: ...`, and `repo: ...`. Keep each commit scoped. Pull requests should explain the behavior change, list verification commands, link relevant issues/specs, and include screenshots for visible UI changes. Call out migrations, schema changes, generated-data updates, paid API usage, or new environment variables explicitly. Never commit secrets; copy `.env.example` to the gitignored `.env`.

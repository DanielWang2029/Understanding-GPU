# TDD — GPU Compute-Chain Terminal

> **Technical design** for the compute-chain terminal centered on **BMAP** (layered geospatial asset map) + **SPLC** (quantified, pivotable supplier/customer graph) + **WCAP** (market-cap analysis). Extends `docs/build-handoff-spec.md` (stack, three-layer arch) and `docs/data-schema-and-validation-spec.md` (v1.0 `Field<T>` store) — does not replace them. Implements `docs/PRD-compute-terminal.md` (v2 pivot). Loop theory from `docs/loop-mechanisms-catalog.md` + `docs/loop-engineering-value-chain-proposal.md`. July 2026 · v2.0-draft.

> **Revision note (v2 pivot).** v1 centered the design on a high-frequency price loop (L7) for a compute buyer. Review re-centered on the **navigable value-chain graph** (map + quantified chain + market-cap) for an analyst/investor. The core new loop is now **L9 — the financial / market-graph loop** (market cap + edge quantification via FMP + filings). L7 price-feed and L8 provider-rating survive but demote to the *docked* Clearing-price instrument; **FF becomes a map overlay**, not a standalone view.

---

## 1. Design thesis (the graph is the product)

The terminal is an instrument for the analyst's **OODA + chain-navigation** loops (U1 + U3); the pipeline is the control loops that keep every node fresh, cross-verified, quantified, and honestly labeled disclosed-vs-estimated.

```
  OUTER — analyst loop (U1 OODA + U3 chain navigation)      the product = the instrument
  ┌───────────────────────────────────────────────────────────────────────────┐
  │  OBSERVE map (BMAP) → ORIENT chain (SPLC) + value (WCAP) → DECIDE → ACT     │
  │     ▲   from ANY node, traverse both directions, every hop sourced/scored   │
  │  ┌──────────── INNER — data-quality + graph-quantification loops ────────┐  │
  │  │  L1 discover · L2 maker-checker · L3 freshness · L4 flywheel ·         │  │
  │  │  L5 cost/active-learning · L6 eval  +  NEW: L9 financial/market-graph  │  │
  │  │  (secondary: L7 price-feed · L8 provider-rating)  ·  FF = map overlay  │  │
  │  └────────────────────────────────────────────────────────────────────────┘ │
  └───────────────────────────────────────────────────────────────────────────┘
```

Two technical claims:
1. **The value is in the edges, quantified.** A graph of *who depends on whom* is only decision-grade when each edge carries a magnitude (% of COGS, % of revenue, $) and an honest **disclosed-vs-estimated** flag. That quantification — and keeping it fresh against filings — is the core new loop (**L9**).
2. **One graph, four altitudes, one weighting.** Aggregate flow (Overview sankeys), entity (SPLC Chain Analysis), project (role-flow drill), and geography (Explorer map) are four renderings of the same `entities + edges + assets`. Build the graph once; render it four ways, and let a single **weight toggle** (`Capacity · Revenue · Market cap`) re-scale flows/nodes across the flow + entity altitudes — so "market cap" is an *encoding on the chain*, not a separate view. `market_cap`/`revenue` come from L9.

---

## 2. Loop architecture — new & re-scoped controllers

Standard form: **setpoint → measured → error → correction → mechanism** (ref `docs/loop-mechanisms-catalog.md`).

### Carried over (now also cover assets + financials)
`L1` ingestion · `L2` maker-checker cross-verify · `L3` freshness · `L4` flywheel · `L5` cost/active-learning · `L6` eval gate.

### L9 — Financial / market-graph loop **(NEW — the core of the pivot)**
| Field | Value |
|---|---|
| **Setpoint** | Every key chain company carries `market_cap`, `revenue`, `capex` (freshness ≤ 1 quarter, event-updated); every key edge carries a quantified `value` + `basis` + a disclosed/estimated flag |
| **Measured** | Financial coverage %; edge-quantification rate; staleness; disclosed-vs-estimated ratio; reconciliation gap vs filings |
| **Error** | Missing/stale financials; unquantified edges; estimate diverges from a new disclosure |
| **Correction** | Pull FMP (market cap/revenue/capex); extract relationship magnitudes from filings/earnings; **cross-verify (L2)**; on a new disclosure, replace the estimate and log the delta (L4) |
| **Mechanisms** | requisite variety (FMP + filings + press) · **disclosed>estimated precedence** (a disclosed % always overrides an estimate) · hysteresis (don't churn an edge on one weak estimate) · reconciliation vs authoritative anchors (schema spec §4.6) |

### FF — Bottleneck feedforward **(re-scoped: now a map overlay/lens, not a tab)**
Same disturbance model as before (`CoWoS→HBM→chip→server→power`, power from ISO/EIA) but rendered as a **recolor lens** over the Supply-Chain Map + edges, giving the analyst a leading read of *which layer/region is the binding constraint*. Mechanisms unchanged: feedforward, PID-D on the queue rate-of-change, candidates verified downstream by L2. See the `bottleneck-feedforward` skill.

### L7 / L8 — demoted to the docked price instrument
`L7` price-feed (deadband/anomaly, GPU price aggregators) and `L8` provider-rating (ClusterMAX 10-dim, hysteresis) still power **Overview → Clearing price** and the provider page, but are no longer the centerpiece. Specs unchanged; see the `price-feed` and `provider-rating` skills. Until L7 lands, the Clearing price grid **measures its own provenance** — it reads `SEED — N of M price rows carry no source or as_of` off the data rather than asserting a literal, so the label corrects itself when the feed arrives.

### Loop → data-class map
| Data class | Owning loop(s) | Cadence |
|---|---|---|
| `entity.market_cap / revenue / capex` | **L9** | quarterly + event (FMP/8-K) |
| `edge.value` (%cogs / %rev / $) | **L9** + L2 | on filing + event |
| `asset` (fab/packaging/HBM/server/DC/power/cable) | L1 + L2 | event; DC/power from existing pipeline |
| bottleneck tightness (map lens) | **FF** + L1 | daily (power), weekly (upstream) |
| `price_point` / `provider_rating` | L7 / L8 | hourly / quarterly (secondary) |

### L9 realization — FMP plan limits + the P2 build steps (probed 2026-07-19)

**Plan constraint (live MCP probe).** The connected FMP plan gates endpoints individually. `statements/income-statement` works — `revenue`, `costOfRevenue`, `netIncome`, `filingDate`, `fiscalYear`, `weightedAverageShsOut` for every public ticker. But `company/market-cap`, `quote`, `statements/enterprise-values`, and the `company` batch endpoints return **ACCESS DENIED** (one `batch-market-cap` hit returned 8 mega-caps, then denied — treat as unavailable). So **revenue/COGS are the reliable spine; market cap is best-effort.** Consequences for L9:
- **Weight priority flips to Revenue-first.** The toggle's real default is Revenue; `market_cap` is populated only where the batch returns it, else `basis:"n/a (plan)"`. Market cap is a later upgrade (FMP tier, a free alt source, or `price × weightedAverageShsOut`) — additive, no rework.
- **Connector has two realizations.** The standalone pipeline can't reach FMP MCP and there's no `FMP_API_KEY` in `.env`, so `clients/fmp.py` ships as (a) a **keyed REST client** for automation + (b) an **in-session MCP pull** that writes `pipeline/seed/financials.json` (fixture) → `Entity.financials`, keeping `emit` reproducible without live FMP.
- **Backbone must be promoted.** The real graph is downstream-only; the ~29 upstream/midstream chain companies live only in `compute_seed`. P2.1 promotes them into the store as real `Entity` rows so the supply-sankey/SPLC render real-financial nodes. Private names (OpenAI/Anthropic/xAI/Crusoe) stay `basis:"estimated"`. And `Entity` has **no financial columns today → P2.0 is a real Alembic migration** (additive `financials` JSONB + `layer`), unlike the migration-free P1.

**L9 5-line contract — P2 instantiation (refined for the plan):**
- **Setpoint** — every backbone entity carries `revenue` ≤1-quarter fresh (disclosed); `market_cap` where FMP allows.
- **Measured** — revenue coverage %, staleness vs `filingDate`, market_cap availability %.
- **Error → correction** — missing/stale → re-pull `income-statement`, reconcile vs the filing anchor; a divergent estimate → replace + log the delta (L4).
- **Mechanisms** — reconciliation vs filing anchor · **deadband** on tiny market_cap moves · **circuit breaker** on FMP errors · **separate horizons** (market_cap daily vs revenue quarterly).
- **Guardrail** — disclosed-over-estimated; never let a private-co estimate masquerade as disclosed.

Full ordered **P2.0–P2.6** build steps + the two decisions (D-A market-cap source, D-B backbone promotion) live in `docs/data-collection-and-architecture-plan.md` §7 ("P2 — spec").

#### L9 conformance table — each contract line → code, or DEFERRED (post-review, 2026-07-19)

Per the `loop-design` conformance gate (a contract you don't implement is a lie), each L9 line maps to the code that realizes it, honest about what remains open-loop:

| Line | Implemented at | Status |
|---|---|---|
| **Setpoint** (freshness horizons, disclosed target) | `validate_data.FIN_HORIZON` (120/400d disclosed · 180/500d estimated) | ✅ real |
| **Measured** (coverage %, staleness, availability) | `emit._fin_coverage` → `meta.rollups.financials_coverage` (UI reads it live) | ✅ real (was a hardcoded string; fixed) |
| **Error** (missing/stale/incomplete) | `validate_data.financials_integrity` (disclosed must carry value+as_of+source) + freshness warns | ✅ real |
| **Correction** (re-pull → reconcile → replace + log delta) | fixture reload + **`ChangeLog` delta-log** (`financials.load_financials`) | 🟡 partial — delta-log real; **live re-pull + filing reconciliation DEFERRED** (needs the keyed REST path + a filing source), tracked as review C2 |
| **Mechanisms** | `material_move` deadband · **`CircuitBreaker`** (real) · `disclosed>estimated` (`financials.py`) · separate horizons (validator) | ✅ real |

**Guardrail** — disclosed-over-estimated enforced in the loader **and** the validator; a "disclosed" claim is structurally forced to be complete. The two failure classes the loop can't see are handled by the companion skills: the Chain-Analysis badge binds to the entity metric (`provenance-rendering`), and the `aws` node's parent-vs-segment unit is flagged `consolidated · incl. non-cloud` (`entity-unit-of-analysis`). Tests: `pipeline/tests/test_financials.py` (deadband, gate must-fail examples, breaker, delta-log).

**Still DEFERRED (honest open-loop):** live FMP re-pull + reconciliation vs a re-fetched filing (C2); widening real coverage past the 8 FMP mega-caps via EDGAR/Finnhub (feeds P3); `capex` (schema-ready, unpulled).

---

## 3. System architecture (extends build-handoff §2)

No new tiers — new **stages**, **tables**, **read-model arrays**, and **views**.

```
 PIPELINE (Python, scheduled)
  asset-ingest : company disclosures + press → asset (fab/packaging/HBM/server/cable); DC+power reused as two layers
  financials   : FMP connector → entity.market_cap/revenue/capex                              (L9)
  chain-quant  : extract relationship magnitudes from filings/earnings → edge.value + basis   (L9 + L2)
  bottleneck   : upstream tightness + ISO/EIA power → tightness lens                          (FF)
  (secondary)  : price-feed (L7) · rating (L8)
  (existing)   : phase-a power · phase-b discover/extract/verify · wire_edges · wire_news · emit
        │ upsert (field-level provenance; disclosed>estimated precedence)
        ▼
 DATA LAYER
  Postgres (SoR)  += asset;  entity += ticker/market_cap/revenue/capex/layer/hq;  edge += value{amount,basis,disclosed}
  DuckDB (compute) : market-cap-by-layer rollup, geo joins for the map, chain traversal aggregates
  emit step        : data.json += assets[]; entities[] += financials; edges[] += quantified value; meta.rollups += market_cap_by_layer
        │ REST/JSON (Next route handlers) — add /assets /chain/:id /marketcap
        ▼
 FRONTEND (Next.js)  — ONE graph at four altitudes, THREE tabs (instruments dock to what they explain)
  Overview        ALT1 supply-chain sankey · WEIGHT TOGGLE Capacity/Revenue/Market-cap
                       + Clearing price ($/GPU-hr grid — what the structure above clears at)
  Chain Analysis  ALT2 SPLC entity (drilled from Overview) → ALT3 Site dossier (deal shape · chain position)
                       + Newsfeed rail (relevance-ranked; scope = explicit All / site / company filter)
  Explorer        ALT4 map + table + drawer + supply-chain asset layers
  RETIRED: standalone Supply-Chain Map tab (→ Explorer layers) · standalone Market-Cap treemap (→ weight toggle) ·
           standalone Price Board tab (→ Overview "Clearing price") · standalone Newsfeed tab (→ Chain Analysis rail) ·
           project role-flow (→ Site dossier; it read usefully on 9 of 424 sites) ·
           Delivery funnel (→ Explorer/sankey constraint tint). Provider page returns at M5, off a provider node.
```

**Store choice unchanged** (Postgres SoR + DuckDB compute → Supabase at team rollout). `asset` is the one new sizeable table; DC/power rows project into it as two layers (a view, not a copy).

---

## 4. Schema deltas

> **Reconciliation with today's store (Tier B — cheap wins).** A pipeline audit (see `docs/data-collection-and-architecture-plan.md` §0–2) shows several deltas below are *already columns in the store, just unpopulated or unemitted*: the **`edge.value` JSONB column exists** (empty) — quantification is populate+emit, not a migration; **`entity.identifiers.ticker`** exists; **`data_center.operator_id/tenant_id`** exist (operator/tenant are extracted by PhaseB but not persisted); **`status_history`** exists (always `[]`); `sqft/acres/mwh/power_sources` are stored but not emitted; and the **`supply_chain` sankey is 100% seeded**. ~~and should be *derived* from the real `entities`+`edges`+financials~~ — ⛔ **this premise was measured and REFUTED by the P3.5 retro.** The 547 real edges are DC-centric (`operates 404 · develops 76 · serves 47 · powers 14 · provides_compute 4 · leases_to 2`) and contain **zero** supplier→customer relations, so the chain topology is not derivable — it had to be **built from buyer filings** (Band-1 #2, `pipeline/dcv/chain_topology.py`, 12 filing-evidenced `supplies` edges). The remaining Tier-B items shipped in **P1**.

### 4.1 New / extended store tables (v1.0 `Field<T>` discipline for claims)
- **`asset`** *(new — the map's physical nodes)* — `id, entity_id(→entity), layer(foundry|packaging|hbm|server|networking|datacenter|power|cable), name, location{country,region,lat,lng,geo_precision}, capacity:Field, capacity_unit, status(enum)+status_history[], sources[]`. Existing `data_center` and `power_project` **project into** `asset` as the `datacenter` and `power` layers (a view — no data copy).
- **`entity`** *(extend)* — `+ ticker, market_cap:Field, revenue:Field, capex:Field, layer, hq{country,region}`. Financials via L9.
- **`edge`** *(extend)* — `+ value:{amount, basis(pct_cogs|pct_revenue|usd|mw|gpus), disclosed(bool), as_of}`. `disclosed=true` always overrides an estimate at the same (from,to,relation).

### 4.2 New edge relations (extend the enum)
**As built: `supplies` ONLY was added.** `supplies` = supplier→buyer (fab→gpu-vendor, hbm→gpu, gpu→cloud). Existing `develops/operates/leases_to/serves/powers/provides_compute` unchanged.

> ⛔ **`customer_of` was deliberately REJECTED — do not add it.** The SPLC derives *both* sides from one directed edge list (`to == central` → suppliers, `from == central` → customers), so an inverse edge double-counts the same relationship in the sankey. See `pipeline/dcv/chain_topology.py` docstring. `funds` and `peer_of` were never built (peers come from `chain.entities[].peers`).

### 4.3 Time & honesty everywhere
`as_of` + history on `market_cap`, `capacity`, `edge.value`, and `status`. Every quantified edge carries **`disclosed`** — the single most important trust field for the SPLC layer.

### 4.4 Read-model (`data.json`) additions
```jsonc
{
  meta, datasets{data_center[],power_project[],news[]}, entities[], edges[], feeds[], supply_chain{},
  // NEW / EXTENDED:
  assets:   [ {id,entity_id,layer,name,country,region,lat,lng,capacity,capacity_unit,status,as_of,sources} ],
  entities: [ {id,name,category,layer,ticker,market_cap,revenue,capex,hq,as_of,sources} ],   // financials added
  edges:    [ {from,to,relation,value:{amount,basis,disclosed},confidence,as_of,sources} ],  // quantified
  // secondary (buyer instrument): skus[], prices[], ratings[]  (from v1)
  meta.rollups += { market_cap_by_layer, capacity_by_layer_region }
}
```
Bump `schema_version` to `1.2`. Every view is a **pure function** of these arrays.

---

## 5. Source connectors (extend `pipeline/dcv/`)

| New module | Source | Loop | Notes |
|---|---|---|---|
| `clients/fmp.py` | **FMP connector** (income-statement reliable; market-cap best-effort) | L9 | reachable via MCP but the plan **gates market-cap/quote/enterprise-values** (probed 2026-07-19) — `income-statement` (revenue/COGS) is the reliable spine, market cap best-effort; ~29–40 chain names; ships as keyed REST client + in-session MCP pull → `financials.json` fixture |
| `sources/assets.py` | company disclosures + press for fab/packaging/HBM/server/cable **locations** | L1 | finite set (dozens of fabs) — tractable; DC/power reused |
| `chain_quant/` (stage) | extract %COGS / %revenue / $ from 10-K/earnings; cross-verify | L9 + L2 | writes `edge.value` + `disclosed` flag; disclosed overrides estimate. **Built + run (2026-07-19):** Grok extract (voted) → Claude verify (voted) → `chain_edges_verified.json`. Finding: filings disclose **magnitudes not identities** → filing-inferred links cap at `needs_review` |
| `chain_identity/` (stage) | flip inferred LINKS to **named** from the **buyer's 10-K + first-party/trade press**; cross-verify | L2-identity | **Built + run (2026-07-20, $2.37):** spike killed the supplier-transcript route (names zero customers); the buyer's 10-K names its supplier + supplier press names its customer. `edgar.entity_mention` + Grok search → Grok extract → Claude verify (voted) → `chain_edges_identity_auto.json`. **Two separate gates:** relationship-named (3/3 on all 3 edges — source-flip works) vs %-attribution (only the dominant-customer edge confirms). Result: coreweave→microsoft **named/confirmed**; tsmc→nvidia + micron→nvidia **named/needs_review** (multi-customer suppliers — can't pin the specific 17% to Nvidia). Magnitude untouched; `named` requires typed `link_sources[]` (L6). `edge_coverage: named 3, confirmed 1` |
| `financials/` (stage) | FMP pull → `entity` financials | L9 | quarterly + 8-K events |
| `bottleneck/` (stage) | upstream tightness + ISO/EIA → tightness lens | FF | now feeds the map overlay |
| (secondary) `price_aggregator.py`, `clustermax.py` | price + rating | L7 / L8 | Overview → Clearing price + provider page |

Reuse existing `clients/spend.py` (L5), phase-b verify (L2), `wire_edges.py` (extend to write quantified edges).

---

## 6. Validation extensions (`validate_data.py` + `data.schema.json`)
Extend the green structural + referential + trust gate:
- **Schema:** `assets[]` (`layer` enum, lat/lng bounds, `capacity` range, `as_of`); `entity` financial fields (`market_cap`/`revenue` ≥ 0); `edge.value` (`basis` enum, `disclosed` bool, amount ranges per basis: pct 0–100).
- **Referential:** `assets.entity_id`→`entities`; new `edge` relations resolve; every quantified edge with `disclosed=false` warns if unsourced.
- **Semantic warnings:** an estimated edge that contradicts a disclosed one at the same triple → error (disclosed must win); market cap stale > 1 quarter → warn; reconciliation gap vs a filed figure beyond tolerance → warn (schema spec §4.6).
- **Time:** no future `as_of`; market-cap history monotonic timestamps.
Exit 1 still blocks publish (L6 balancing gate).

---

## 7. Demo → production path
The review demo is a **pure function of the extended contract** with clearly-labeled illustrative data. Path:
1. Approve the map + chain + market-cap views (this pivot's demo).
2. Wire **FMP** → real `market_cap` for ~40 tickers (smallest real slice; proves L9 + the WCAP treemap).
3. Project existing DC/power into `assets[]` as two map layers (near-free — data exists).
4. Quantify the highest-value edges from disclosures (Nvidia customer mix, TSMC customer mix) → SPLC with real disclosed values.
5. Fold the approved views into the Next.js app; retire the 3 weak v1 tabs.
6. FF power lens from existing ISO/EIA data — cheapest differentiator.

---

## 8. Roadmap & milestones (technical, gated)

> **The canonical, data-grounded build order is `docs/data-collection-and-architecture-plan.md` §7 (P0–P6)**, which sequences by the have / exists-but-unwired / net-new tiers (P1 = Tier-B cheap wins). The M0–M5 milestones below are the loop-instrumentation view of the same work and map onto P0–P6.

Aligns to PRD phases T1–T4. Each milestone names its **loop instrumentation** and an **exit gate**.

| Milestone | Build | Loops proven | Exit gate |
|---|---|---|---|
| **M0 — Contract + demo** | extend read-model (`assets[]`, entity financials, quantified `edges`); ship the map+chain+market-cap demo; extend `validate_data.py` | — | demo renders from the contract; validator green on new arrays |
| **M1 — Financials + weight toggle (T1)** *(= plan §7 P2)* | `fmp.py` + `financials/` stage → entity `revenue` (reliable) + `market_cap` (best-effort, plan-gated) → **weight toggle** (Capacity/**Revenue**-default/Market-cap) re-scaling the Overview sankeys | **L9** | **revenue** real for all public tickers + toggle re-scales real (relaxed from "≥30 tickers" — FMP plan gates market cap, see L9 realization §2); market_cap for the FMP-returned subset; freshness ≤ 1 quarter |
| **M2 — Chain drill + Explorer layers (T1/T2)** | render existing `edges[]` as **Chain Analysis** (SPLC), drilled from Overview nodes; project DC/power + upstream assets into `assets[]` as **Explorer layers** | L1, U3 | re-center works from any node; aggregate→entity drill works; ≥6 asset layers toggle in Explorer |
| **M3 — Quantify edges (T2)** | `chain_quant/` stage → `edge.value` + disclosed/estimated; SPLC sorts suppliers by %COGS, customers by %revenue | **L9 + L2** | top-N edges quantified & sourced; disclosed overrides estimate; validator enforces it |
| **M4 — Constraint lens (T2)** | `bottleneck/` → FF **map overlay**; power tightness from real ISO/EIA | **FF**, L1 PID-D | map recolors by tightness; power lead-time per region from real queue data |
| **M5 — Buyer instrument + intl (T3/T4)** | sourced price feed (L7) so Clearing price stops reading `SEED`; **provider page** (L8) off provider nodes; add non-US assets | L7, L8, L3 | provider page reachable from any provider node; one non-US region on the map |

**Build-order note:** M1 (market cap, FMP-only, ~40 tickers) is the smallest real proof and should ship first; M2 reuses existing DC/power data; M3 (edge quantification) is the hard, high-value data work. M4 (power lens) is the cheapest differentiator (reuses existing data).

---

## 9. Risks & mitigations (ref catalog §7)
- **Edge quantification is the hard data (L9):** most %COGS/%revenue links are estimated. **Mitigate:** disclosed-overrides-estimate precedence; confidence-score every estimate; show the disclosed/estimated flag in the UI; reconcile against each new filing.
- **FMP/feed fragility:** circuit breaker per source; degrade to last-known + staleness badge.
- **Asset coverage drift:** upstream is a finite set — enumerate the known fabs/packaging/HBM sites once, then event-update; log any coverage gaps (no silent truncation).
- **Reinforcing-without-balancing:** the estimation flywheel drifting on its own estimates → error cascade. **Mitigate:** L6 gold-set gate + HITL on the highest-value edges; disclosures always win.
- **Requisite variety costs money:** quantify the edges that move an analyst's decision (top suppliers/customers by value), not every link.

*Companions: `docs/build-handoff-spec.md` (stack) · `docs/data-schema-and-validation-spec.md` (`Field<T>`, validation) · `docs/loop-mechanisms-catalog.md` (mechanisms) · `docs/PRD-compute-terminal.md` (product) · `docs/compute-terminal-findings-and-options.md` (decisions). Skills: `.claude/skills/{loop-design,chain-financials,bottleneck-feedforward,price-feed,provider-rating}`.*

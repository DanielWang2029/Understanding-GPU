# dataCenterView — Agentic Ingestion Architecture Proposal

*How to build a comprehensive, up-to-date, verified data-center database that beats a hand-curated model like CleanView — using a multi-model agentic pipeline over free primary sources. US-first, worldwide-ready. Pricing current as of July 2026.*

---

## 1. Goal & design principles

The current dashboard has 24 hand-typed rows sourced from CleanView. This proposal replaces that with an automated pipeline that is **complete, fresh, and verified** — the three things the sample is not.

Five principles drive every decision below:

1. **Go to primary sources, not to CleanView.** Copying their licensed DB is a legal risk and keeps you permanently behind. Ingest the raw sources they use (EIA, ISO queues, trade press, permits) and you can be *fresher* than them.
2. **The database is the system of record — never an LLM.** Models discover, extract, and verify. A structured store (Postgres/DuckDB) holds truth. This prevents "hallucinated database" failure modes.
3. **Field-level provenance & confidence.** Every important value (capacity, status, location) carries its own source list, confidence score, and `last_verified` date — a stronger model than CleanView's record-level `source_1/2/3`.
4. **Model diversity for verification.** The agent that *checks* a fact uses a **different vendor** than the one that *extracted* it. Same-vendor models share blind spots; diversity is what makes an automated "audit-approved" flag trustworthy.
5. **Spend only on the delta.** Expensive search/LLM calls run on *new and conflicting* records, not the whole database. Cost then scales with how much is new, not with total size — so it stays cheap even at tens of thousands of records.

---

## 2. Data model (the core)

One record per data-center project. Key fields with **field-level provenance**:

```jsonc
{
  "id": "stargate-i-abilene-tx",          // stable slug/hash
  "project_name": "Stargate I (Abilene)",
  "aka": ["Lancium Abilene", "OpenAI Abilene"],
  "developer": "Crusoe Energy",
  "operator": "Oracle Cloud Infrastructure",
  "tenant": "Oracle",
  "end_user": "OpenAI",
  "status": "under_construction",          // proposed|permitted|under_construction|operating|cancelled|on_hold
  "capacity_mw": { "value": 1200, "sources": ["url1","url2"], "confidence": 0.86, "last_verified": "2026-07-10" },
  "capacity_mwh": null,
  "building_sqft": { "value": null, ... },
  "land_acres": { "value": 1150, ... },
  "cap_ex_usd": { "value": 11600000000, ... },
  "btm_generation": true,                  // behind-the-meter power on site
  "power_sources": ["natural_gas","grid"],
  "balancing_authority": "ERCO",
  "location": { "county": "Taylor", "state": "TX", "country": "US",
                "lat": 32.45, "lng": -99.73, "geo_precision": "county" },
  "announced_date": "2024-03-01",
  "operating_year": 2026,
  "overall_confidence": 0.82,
  "review_status": "approved",             // auto_approved|needs_review|approved|rejected
  "sources": [ {"url":"...","publisher":"DCD","retrieved":"2026-07-10","type":"trade_press"} ],
  "created_at": "...", "updated_at": "..."
}
```

Two design choices that matter: **status is a lifecycle enum** (so you can watch projects move stages and compute a change feed), and **geo_precision** is explicit (planned projects often only resolve to a county — don't pretend you have a rooftop).

> **Beyond the flat record:** the data model has since grown two graph layers, specified in `docs/loop-engineering-value-chain-proposal.md` and realized in the demo's `data.json` — `entities[]` + typed `edges[]` (the **value chain**: develops · operates · leases_to · serves · powers · provides_compute) and `supply_chain{nodes,links}` (the **supply chain**: foundry/HBM → accelerators → servers/networking → power/cooling → operators → end-users). The pipeline below produces the flat records; the graph layers are extraction add-ons (per-project relationships + supplier links).

---

## 3. Source map (tiered)

| Tier | Source | Covers | Access | Cost |
|---|---|---|---|---|
| **A. Free structured** | EIA-860M API | All US generators (power context, BTM gen) | REST + key | **Free** |
| | 7 ISO interconnection queues | Proposed power projects pipeline | CSV/portal | **Free** |
| | GDELT 2.0 | Global news event firehose (monitoring) | Query/BigQuery | **Free** |
| **B. DC inventories** | Data Center Map, PeeringDB, Cloudscene, Baxtel | Operating DC universe | Scrape / API (PeeringDB free) | Low |
| **C. Agentic discovery** | Perplexity Sonar / Exa / Tavily | New + planned projects, with citations | API | Usage |
| | Extraction LLM (Grok / Claude / GPT) | Article/permit → structured record | API | Usage |
| | Firecrawl | Turn any page/site → clean structured text | API | Usage |
| **D. Proprietary edge** | County/state permit & rezoning portals | Unannounced projects (CleanView's moat) | Scrape (Firecrawl) | Usage |
| | Satellite (Planet/Sentinel) | Construction-progress verification | API | Usage |
| **E. International** | ENTSO-E, National Grid ESO, regional regulators/permits | Non-US grid + projects | API/scrape | Mostly free |

Tier A is the free backbone. Tier C is the engine for the data-center layer that has **no** free feed. Tiers D–E are later stages.

---

## 4. Pipeline architecture — the multi-agent loop

```
  ┌───────────────┐   Tier A/B feeds (scheduled)        ┌──────────────────┐
  │  INGEST/POLL  │───────────────────────────────────▶│                  │
  └───────────────┘                                     │                  │
  ┌───────────────┐   GDELT + news RSS + X signal       │   CANDIDATE      │
  │  DISCOVERY    │──▶ "new/changed DC projects?" ──────▶│   QUEUE          │
  │  (search API) │    returns URLs + snippets           │                  │
  └───────────────┘                                      └────────┬─────────┘
                                                                   │
                                                    ┌──────────────▼─────────────┐
                                                    │  EXTRACTION AGENT (LLM #1)  │
                                                    │  page→JSON w/ schema+cites  │
                                                    └──────────────┬─────────────┘
                                                                   │
                                              ┌────────────────────▼───────────────────┐
                                              │  ENTITY RESOLUTION / DEDUP              │
                                              │  match to existing record by name+geo   │
                                              └────────────────────┬───────────────────┘
                                                                   │
                                     ┌─────────────────────────────▼──────────────────────────┐
                                     │  ADVERSARIAL VERIFIER (LLM #2, DIFFERENT VENDOR)         │
                                     │  independently re-search each key field; flag conflicts  │
                                     └─────────────────────────────┬──────────────────────────┘
                                                                   │
                                                 ┌─────────────────▼─────────────────┐
                                                 │  CONFIDENCE SCORING + GATE         │
                                                 │  ≥0.9 auto-approve · 0.6–0.9 review │
                                                 │  <0.6 hold as "reported"           │
                                                 └───────┬───────────────────┬────────┘
                                              approved   │                   │ needs_review
                                                 ┌───────▼──────┐     ┌──────▼───────┐
                                                 │ SYSTEM OF    │     │  HUMAN REVIEW │
                                                 │ RECORD (DB)  │◀────│  (approve/fix)│
                                                 └──────┬───────┘     └──────────────┘
                                                        │  change feed + API
                                                 ┌──────▼───────┐
                                                 │  DASHBOARD    │  (the HTML explorer, now live)
                                                 └──────────────┘
```

Each stage is a small, independently testable job. The queue between discovery and extraction lets you rate-limit and cost-control the expensive parts.

---

## 5. Model / provider assignment (why diversity)

| Role | First choice | Why | Alternate |
|---|---|---|---|
| **Discovery + freshness** | Exa (neural search, cheap) or Perplexity Sonar (cited synthesis) | Return candidate projects with source URLs | Tavily |
| **Early/unannounced signal** | Grok (live X access) | Local officials & construction accounts post before trade press | GDELT + local RSS |
| **Extraction (LLM #1)** | Grok 4.1 Fast or Claude Haiku | Cheap, structured JSON at volume | GPT-mini |
| **Adversarial verify (LLM #2)** | **Different vendor** than #1 (e.g. Claude if #1 was Grok) | Independent re-check avoids shared blind spots | rotate GPT/Gemini |
| **Scrape/normalize** | Firecrawl | Any page/permit portal → clean markdown/JSON | Playwright self-host |
| **Geocode** | US Census (free) / Mapbox | Validate & fill coordinates | Google |

The non-obvious point: **the verifier must be a different model family from the extractor.** If Grok extracts "1.2 GW" and Claude, searching independently, also lands on 1.2 GW from different sources, that agreement is real signal. If you use the same model for both, agreement means nothing.

---

## 6. Confidence scoring rubric

| Score | Meaning | Rule | DB status |
|---|---|---|---|
| **0.90–1.0** | Confirmed | ≥2 independent sources agree on capacity **and** status **and** location; coords validated | `auto_approved` |
| **0.60–0.89** | Probable | One strong primary source, or minor conflict on a secondary field | `needs_review` |
| **< 0.60** | Reported | Single weak/secondary source, rumor, or unresolved conflict on a key field | held as `reported`, not shown as fact |

Scoring is **per field**, then the record's `overall_confidence` is the weighted min across the three critical fields (capacity, status, location). The dashboard can filter/badge by confidence — so "confirmed" and "reported" are visibly different, which is more honest than a single audit flag.

---

## 7. Cost model (July 2026 prices)

**Fixed layer = $0.** EIA API (free, key required), ISO queues (free), GDELT (free), PeeringDB (free), US Census geocoder (free).

**Variable layer** — priced per current rates:

| API | Rate (July 2026) |
|---|---|
| Perplexity Sonar (base) | $1/$1 per 1M tok **+ $5–14 per 1,000 requests** by context depth |
| Perplexity Sonar Pro | $3/$15 per 1M tok + request fee |
| xAI Grok 4 | $3/$15 per 1M tok · **Grok 4.1 Fast $0.20/$0.50** · ~$175/mo free credits |
| Exa | ~$7 / 1,000 searches (contents incl.); extract $1/1,000 |
| Tavily | ~$8 / 1,000 basic · ~$16 / 1,000 advanced |
| Firecrawl | Free 1,000 cr/mo · Hobby $16 (5k) · Standard $83 (100k) · 1 cr/page |

**Worked steady-state estimate** — assume ~50 new/changed candidates/day (~1,500/mo), each costing 1 discovery + 1 extraction + 2 independent verify searches + ~3 page scrapes:

| Component | Monthly volume | Est. cost |
|---|---|---|
| Discovery (Exa) | 1,500 searches | ~$11 |
| Extraction (Grok 4.1 Fast) | 1,500 calls | ~$1 (free credits likely cover it) |
| Adversarial verify (Perplexity Sonar, medium ctx) | ~3,000 requests | ~$25–35 |
| Scraping (Firecrawl) | ~4,500 pages | $16–83 (Hobby→Standard) |
| Geocode | 1,500 | ~$0 (Census) |
| **Steady-state total** | | **≈ $55–130 / month** |

**One-time backfill** of the initial ~3,000-record US DB: ~$150–300.
**Worldwide scale** (20k+ records, higher news volume): ~$300–800/mo.

Headline: a disciplined delta-only pipeline runs **~$55–130/month** — versus CleanView's **$750/month** subscription — and **you own the data and the refresh cadence.**

---

## 8. Phased rollout

| Phase | Delivers | Sources/APIs | Effort | Run cost |
|---|---|---|---|---|
| **A. Free backbone** | Auto-ingest all US generators + ISO queues; power-grid context; nightly refresh | EIA, ISO, geocode | S | $0 |
| **B. Agentic DC layer** | Discovery→extract pipeline turns news into structured DC records with citations; 24 → hundreds | Exa/Perplexity + extraction LLM + Firecrawl | M | ~$30–60/mo |
| **C. Verify + freshness** | Adversarial cross-check, confidence scoring, dedup, scheduled refresh, change feed, human-review queue | 2nd-vendor LLM | M | +$25–70/mo |
| **D. Proprietary edge** | Permit/rezoning-portal scraping (unannounced projects) + satellite progress checks; Grok X-signal | Firecrawl, Planet/Sentinel, Grok | L | usage |
| **E. International** | ENTSO-E + regional permits + global news; unify schema | ENTSO-E, regional | L | mostly free |

Recommended start: **A + B together** — A is free and gives real coverage immediately; B stands up the agentic engine on a single state (e.g. Texas) so you can measure precision/recall before scaling.

---

## 9. Risks & mitigations

- **LLM hallucination / wrong numbers** → schema-validate every extraction; require ≥2 independent sources before "confirmed"; different-vendor verifier; keep source URLs for audit.
- **Legal / ToS** → source from primary/free data and licensed APIs; do **not** bulk-scrape CleanView's DB or other paid competitors' curated data; respect robots.txt and per-site ToS on permit portals.
- **Cost creep** → delta-only processing, aggressive caching, cheap models for extraction, cap the candidate queue, alert on daily spend.
- **Dedup errors** (same project, different names) → entity resolution on name + geo + developer; maintain an `aka[]` alias table; human review on ambiguous merges.
- **Source bias toward big projects** → deliberately include permit portals and local news (Phase D) to catch the long tail CleanView also has to hunt for.
- **Provider outage / price change** → the role/provider table is swappable by design; nothing is hard-wired to one vendor.

---

## 10. Success metrics

- **Coverage:** count vs a known benchmark (e.g. within X% of CleanView's public state totals).
- **Freshness:** median lag between public announcement and record appearing (target: < 48h for major projects).
- **Precision / recall:** measured against a hand-built gold set of ~100 verified projects.
- **Verification rate:** % of records at ≥0.9 confidence with ≥2 independent sources.
- **Cost per verified record:** total spend ÷ confirmed records (target: cents, not dollars).

---

## Appendix — why this beats the hand-curated model

CleanView's edge is human curation: analysts read press and permits and manually approve records. That's accurate but **slow, expensive, and headcount-bound**. This design keeps the *quality bar* (multi-source, verified, provenance) but replaces the *bottleneck* (human reading) with agentic discovery + cross-model verification, leaving humans only the conflicts. Same moat, a fraction of the cost, and a refresh cadence they can't match by hand.

---

*Sources for pricing/capability figures: Perplexity Sonar pricing (docs.perplexity.ai, aipricing.guru), xAI Grok pricing (aipricing.guru, pricepertoken.com), Exa vs Tavily pricing (buildmvpfast.com, exa.ai), Firecrawl pricing (firecrawl.dev), EIA Open Data API (eia.gov/opendata). All figures July 2026 and subject to change.*

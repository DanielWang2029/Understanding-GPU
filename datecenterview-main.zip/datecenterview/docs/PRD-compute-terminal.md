# PRD — GPU Compute-Chain Terminal

> **Product requirements** for pivoting dataCenterView into a **Bloomberg-style terminal for the GPU compute chain**. The product is **one value-chain graph viewed at four altitudes** (aggregate flow · entity · project · geography) with the two instruments (clearing price · news) **docked to the altitude they explain**. Primary user = **analyst / investor / strategist**. Pairs with `docs/TDD-compute-terminal.md` and `docs/compute-terminal-findings-and-options.md`. July 2026 · v2.2 (three tabs).

> **Revision history.** v1 = price-board-centric compute-buyer terminal. v2 = re-centered on the value-chain graph (BMAP map + SPLC chain + WCAP treemap) for an analyst. v2.1 = reunify with the original demo — one graph at four altitudes, market cap as a weight toggle, map folded into Explorer; retired the standalone BMAP and WCAP tabs. **v2.2 (this) = dock the instruments, five tabs → three.** Built and measured against the real read-model, three things were wrong. (a) The **Price Board** as its own tab was a grid with nothing to compare it to; it is now **Clearing price**, directly under the flow it prices. (b) The **Newsfeed** as its own tab was a global list with no selection to bind to, and only 24 of 258 items carry a date, so a reverse-chronological feed was mostly fabricated order; it is now a **relevance-ranked rail on Chain Analysis** with an explicit scope filter. (c) The **project role-flow** rendered usefully on **9 of 424** edge-bearing sites — it was designed against a 10-row seed with all four roles filled, and reported a structural fact (retail colo has no single tenant) as our own data gap; it is replaced by the **Site dossier**, and moved under Chain Analysis so entity → site is one scroll.

---

## 1. Vision

> **One terminal that shows the entire GPU compute chain and lets you fly through it at any altitude** — from the aggregate flow of the whole industry (silicon → systems → facility → operators → end-users), down to one company's quantified suppliers and customers, down to one project's participants, and across to where every asset physically sits. Weight the whole chain by **capacity, revenue, or market cap** with one switch. Every node sourced, dated, confidence-scored, pivotable.

We compete on the **connected, provenance-scored, self-correcting graph**, not facility count. The loops (see TDD) keep every link fresh, cross-verified, and honestly labeled disclosed-vs-estimated.

---

## 2. Users & jobs-to-be-done

### Primary — **Analyst / Investor / Strategist**
**Decision: understand where value, capacity, dependency, and risk sit along the GPU compute chain.**

| Job | Question | Altitude / view |
|---|---|---|
| See the whole chain | "How does compute flow from silicon to end-users, and where's the value?" | **Overview** (aggregate flow, weight toggle) |
| Price the output | "What does the chain's product actually clear at, and which way is it moving?" | **Overview → Clearing price** |
| Trace a dependency | "Who supplies Nvidia, at what % of its cost? Its biggest customers?" | **Chain Analysis** (entity / SPLC) |
| Drill a site | "What kind of deal is this campus, how rare is that shape, and what does it buy upstream?" | **Chain Analysis → Site dossier** (project) |
| Value vs bottleneck | "Which layer holds the value vs which gates the chain?" | Overview **weight = Market cap** |
| Where is it | "Where are the fabs, HBM, DCs, power geographically?" | **Explorer** (geography) |
| What changed | "What just moved around this company / this site?" | **Chain Analysis → Newsfeed rail** |

### Secondary
- **Compute buyer / AI builder** — **Clearing price** on Overview ($/GPU-hr by SKU · provider · term). The full v1 board — region filter, provider terminal page, ClusterMAX 10-dim — returns at T3, reached from a provider node rather than as its own tab.
- **DC developer** — Explorer power layer + forward pipeline.

---

## 3. The product: one graph, four altitudes, three tabs

This is the organizing principle. All four altitudes render the same `entities + edges + assets`; you move between them by clicking (U3 chain-navigation), and re-weight them with one toggle. **Altitudes are the model; tabs are the packaging** — an instrument gets a tab only if it answers a question on its own, and neither the price grid nor the news list did.

```
 ALT 1  AGGREGATE FLOW   sankey: silicon→systems→facility→operators→end-users + market flow   ┐
        + CLEARING PRICE $/GPU-hr by SKU × cloud — what the structure above clears at         ┘→ Overview
 ALT 2  ONE ENTITY       SPLC: a company's suppliers (%COGS) / customers (%revenue)           ┐
 ALT 3  ONE SITE         Site dossier: deal shape (vs the whole base) · position in the chain ├→ Chain Analysis
        + NEWSFEED RAIL  relevance-ranked, scoped All / this site / this company              ┘
 ALT 4  GEOGRAPHY        assets on a map, by layer                                             → Explorer
        ── WEIGHT TOGGLE across ALT 1–2:  Capacity (MW) · Revenue · Market cap ──
```

**Why the instruments dock rather than stand alone.** A price is only readable against the supply structure that sets it, so Clearing price sits under the flow. News is only actionable against a subject, so the rail sits beside the entity and the site — and its scope is an **explicit filter the user sets**, never inferred from the selection: a list that silently re-scopes itself when you click elsewhere is worse than one that doesn't move. The rail states its own date coverage (24/258 items dated) in its footer instead of implying a recency it can't support.

**OODA mapping:** Observe (Overview flow) → Orient (Chain Analysis, Explorer, weight=market-cap) → Decide (compare, follow the constraint) → Act (watch/alert/export; buyers → Clearing price, then the provider page). Click-to-drill (aggregate→entity→project) is the U3 loop; the dispute control is U2. **Each user loop (U1–U4) carries a filled 5-line controller contract in `docs/data-collection-and-architecture-plan.md` §7c** — **U2 is now CLOSED (Band-1 #3, 2026-07-20)**: the dispute control POSTs to `/api/review` → an append-only inbox → `dcv review-drain` writes `review_log` and **re-opens the record** for cross-vendor re-verification, with hysteresis (a dispute re-opens, never rejects), anti-windup (coalescing + rate limits), a `dismiss` undo, and an L6 gate that blocks publish if a dispute routed nowhere. A ranked **Review queue** is a persistent header surface. Still open: weighting disputes by user reliability. **U4 alerts remain unbuilt** (P3–P4).

---

## 4. Scope by phase (build schema for the end-state now)

> For the **data-side** build order (what to collect, from where, and in what priority), see `docs/data-collection-and-architecture-plan.md` §7 (P0–P6) — it grounds these product phases in the actual have / exists-but-unwired / net-new state of the pipeline.

| Phase | Theme | Deliverables | Data (mostly free / in-hand) |
|---|---|---|---|
| **T1 — Chain, weighted** *(MVP)* | "See the chain and where value sits" | Overview sankeys (reuse existing) + **weight toggle (Capacity/Revenue/Market cap)** + **Chain Analysis (SPLC)** drilled from Overview; project value-chain drill | existing `entities/edges/supply_chain` + **FMP** market cap/revenue |
| **T2 — Quantify & locate** | "How much, and where?" | edge **quantification** (%COGS / %revenue / $, disclosed/est); **Explorer gains supply-chain asset layers** + constraint tint | filings + earnings (FMP) + existing DC/power + ISO/EIA |
| **T3 — Buyer instrument** | "Transact + monitor" | **Provider page** (region filter, sparklines, ClusterMAX rating, inline news) reached from any provider node; a **sourced** price feed so Clearing price stops reading `SEED` | GPU price aggregators + ClusterMAX + existing feeds |
| **T4 — Edge & intl** | "Be first / go global" | permit + satellite into Explorer; ENTSO-E; non-US assets | Phase D/E sources |

> Existing DC (489) + power (3,557) stay as Explorer layers; the Overview sankey gains the weight toggle, and news is re-homed as the Chain Analysis rail.

---

## 5. Feature specs (T1 first)

### F1 — Overview: chain flow, weighted *(reuses the original Overview; the hero)*
**Story:** *As an analyst I see the whole chain as a flow and re-weight it by capacity, revenue, or market cap to see where value concentrates vs where it flows.*
- The **end-to-end supply-chain sankey** (silicon → systems → facility → operators → end-users) + the **Market-flow sankey** (value-chain aggregate), both retained from the original demo.
- **Weight toggle: `Capacity (MW) · Revenue · Market cap`** — re-scales flow-widths/node sizes. Flip to Market cap and the "packaging is a tiny sliver but gates the chain" mismatch shows **inside the flow**.
- **Clearing price** sits directly beneath: $/GPU-hr by SKU × cloud, cell tint vs the SKU-row median, 30-day sparkline, Kalshi 3-month forward. It carries a **measured** provenance badge — it reads `SEED — N of M price rows carry no source or as_of` off the data, so it stops calling itself seed by itself once P4 lands a sourced feed.
- **Click any node/flow → Chain Analysis** for that entity (the aggregate→entity drill).
- **AC:** the flow renders; the weight toggle re-scales without repainting identity; every node click drills to Chain Analysis; the price board's provenance badge is derived from the rows, never a literal.

### F2 — Chain Analysis (SPLC) *(new; the entity altitude)*
**Story:** *As an analyst I open any company and see suppliers by % of its COGS, customers by % of its revenue, and peers, then click through.*
- Central company; **suppliers sorted by %COGS**, **customers sorted by %revenue**, **peers**; each node **DISCLOSED / EST** + confidence; **market cap** shown; node size follows the **weight toggle**.
- **Click any node → re-center** (pivot). A breadcrumb / mini-sankey shows "you are here" relative to Overview.
- Reached primarily by drilling from Overview; also has its own company selector.
- **AC:** re-centering works from any node; disclosed overrides estimated; reuses `entities[]/edges[]`; shares the weight toggle with Overview.

### F2b — Site dossier *(ALT 3, directly under the SPLC)*
**Story:** *As an analyst I open one campus and learn what kind of deal it is, how unusual that shape is, and what it buys upstream.*
Replaces the role-flow, which worked on 9 of 424 edge-bearing sites because it assumed four filled roles against a graph averaging **1.11 edges per DC**. Two bands:
- **1 · Deal shape** — distinct counterparties across developer/operator/tenant/end-user, the participant chips, and a **distribution strip over the whole tracked base** so "3 parties" reads as "14 of 489 (2.9%)". Labeled horizontal bars, not one stacked strip: 90.6% sits in the first bucket, so proportional segments made the other three unreadable slivers.
- **2 · Position in the compute chain** — the site's participants that are in the financial backbone, and *their* disclosed suppliers by %COGS. **Clicking a supplier re-centers the SPLC above** — no navigation, the altitudes are on one page.
- **Absence has three distinct states, never one "—"**: *by construction* (multi-tenant colo, so a scalar `tenant` has nothing to hold — 291 of 489), *not extracted* (eligible but unresolved — 18 of 198 filled), and *out of scope* for band 2 (no backbone participant — 117 of 424 have one). Reporting the first as our own gap was the old panel's real defect.
- The role-flow survives as an **A/B toggle**, so the replacement can still be checked against what it replaced.
- **AC:** every edge-bearing site renders in both modes with no placeholder text; every coverage figure is read from the read-model or the gate-checked `dc_role_coverage` rollup, never hardcoded; a supplier click re-centers the SPLC.

### F2c — Newsfeed rail *(instrument, docked to Chain Analysis)*
**Story:** *As an analyst reading a company or a site, I see what just moved around it without leaving the page.*
- Scope is an **explicit filter**: `All` · `<this site>` · `<this company>`, each chip showing its live count. A chip the current selection cannot satisfy is **disabled, not hidden**, so the absence is legible (e.g. Nvidia holds no DC role → `Nvidia · 0`). A filter that becomes unsatisfiable resets to `All` rather than silently showing nothing.
- Ranked by relevance, **not recency** — only 24 of 258 items carry a `published_date`. Dated items sort first (newest) within a tier; undated ones sort by linked-site capacity and are **labeled `no date`** on their face.
- The footer states the coverage (`24 of 258 items carry a publish date`) as a live count.
- **AC:** the rail appears on Chain Analysis only; its height matches the main column exactly (bottom edges flush) and its list scrolls internally; it never claims an order the data can't support.

### F3 — Explorer *(kept from original; the geography altitude)*
**Story:** *As an analyst I see where the chain physically is and filter/inspect it.*
- The original map + table + filters + **detail drawer** (field values, typed/trust-weighted sources, freshness, dispute) — unchanged.
- **New: supply-chain asset layers** (fabs · packaging · HBM · systems … alongside the existing data-center + power layers), toggleable like the original provider-type filter.
- Detail drawer's compact value-chain **deep-links to the Site dossier** on Chain Analysis, and to the entity's Chain Analysis.
- **AC:** existing Explorer behavior preserved; new layers toggle; drawer deep-links land on Chain Analysis with the right site selected.

### F4 — Provider page *(T3; reached from a node, not a tab)*
**Story:** *As a buyer I open one provider and see its prices, its quality, and its position in the chain.*
- What the standalone Price Board was going to be, minus the tab: region filter, 90-day sparklines, **ClusterMAX 10-dim** rating, and that provider's headlines inline. Reached from any provider node in Clearing price / Chain Analysis / Explorer.
- **AC:** reachable from a provider node in all three places; prices, rating and news on one page; the Overview Clearing price grid stays the entry point, not a competitor.

---

## 6. Cross-cutting requirements
- **Weight toggle** (`Capacity · Revenue · Market cap`) is a first-class, shared control across Overview + Chain Analysis — color follows the entity/layer, size follows the weight; switching weight never repaints identity.
- **Pivot from anything** (U3): every node in every altitude links to the next altitude down.
- **Time on everything:** market cap, capacity, edge values carry `as_of` + history.
- **Provenance + disclosed/estimated** on every quantified value.
- **Pure function of the data contract** (`data.json` extended with financials + quantified edges + assets); no hardcoded arrays.

---

## 7. Success metrics
- **Time-to-trace** — clicks from the aggregate flow to a company's full supplier/customer chain (≤ 3).
- **Weight-flip insight** — a user can spot the value-vs-bottleneck mismatch in < 30s by flipping to Market cap.
- **Chain completeness** — % of key nodes with a quantified upstream **and** downstream link at ≥0.75 confidence.
- **Market-cap coverage** — % of chain revenue covered by tickers with live market cap.
- Loop health carries over: financial freshness < 1 quarter, edge-quantification rate, disclosed/estimated ratio, precision vs gold set, freshness < 48h, cost per verified fact ↓.

---

## 8. Non-goals (v1)
- No trading/price-prediction signals. No proprietary chip-shipment model. No racing on facility count. No public multi-tenant SaaS yet.
- **No standalone market-cap treemap, geographic-map, price-board or newsfeed tab** — all four dissolved into better homes (weight toggle / Explorer / under the flow / beside the entity). A tab is earned by answering a question alone.

---

## 9. Dependencies & risks
- **SPLC quantification is the hard data** — mostly estimated; ship confidence-scored + disclosed/estimated flags.
- **FMP dependency** for financials/market cap — treat as a source with a circuit breaker; reconcile vs filings.
- **Weight-toggle correctness** — market cap is entity-level, capacity is asset/edge-level, revenue is entity-level; the toggle must map each weight to the right measure per node type (see TDD §4).
- **Scope creep** — keep the graph the headline; the price and news instruments stay docked to what they explain.
- **Seed data flatters a panel into existence.** Three times now, a view looked finished against fabricated seed and collapsed on the real read-model: the 10-row `PROJECTS[]` behind the role-flow, the 8 perfectly-dated `NEWS[]` items behind the newsfeed, and the price rows with no provenance fields at all. **Design new panels against the live contract, not a seed** — and where a seed is unavoidable, have the UI *measure and state* what it is standing on.

*Companions: `docs/TDD-compute-terminal.md` (how) · `docs/compute-terminal-findings-and-options.md` (why/options) · `docs/demo-design-spec.md` (original Overview/Explorer contract) · `docs/loop-engineering-value-chain-proposal.md` (U1–U4).*

# Verifier selection — measured findings (2026-07-30/31)

**Status: DECIDED for now, OPEN for improvement.**
Production stays on **agentic `claude-sonnet-5`**. The retrieved-mode alternative is built,
measured, and parked — see §6 for exactly how to resume it.

This records what was measured so a future session extends the work instead of re-deriving it.
The harness is `dcv bakeoff` (`pipeline/dcv/bakeoff.py` + `clients/verifiers.py`); raw output is
`pipeline/seed/bakeoff_results_{agentic,retrieved}.json`.

---

## 1. The question

Architecture decision #4 fixes the *shape* of the trust gate — the verifier must be a
**different vendor** than the Grok extractor, because same-vendor agreement is not evidence. It
does **not** fix which vendor. `settings.verify_model` was `claude-opus-4-8` by default and had
never been competed, while being the single most expensive line in the pipeline.

Two sub-questions, answered separately:

1. **Which model** should hold the gate? (§3)
2. **Which architecture** — should the verifier search for itself, or should we retrieve and
   hand it evidence? (§4)

## 2. What phase 1 can and cannot measure

**It cannot measure who is CORRECT.** The `gold_set` table holds **7 rows, all
`verified_by="demo_seed_bootstrap"`**, which `goldset.certify()` refuses by construction. Scoring
candidates against the incumbent's own verdicts would be the same circularity one level up.

So phase 1 measures everything that does *not* require knowing the right answer:

| Metric | Why it decides something |
|---|---|
| structured-output validity | split into `schema_miss` / `malformed` / `truncated` / `refusal` / `error` — production collapses all five into "held as reported" |
| corroboration rate | `_AGREE_CORROBORATED` needs an independent domain and the approve gate needs ≥2 sources, so a verifier that can't corroborate **cannot promote a row however right it is** |
| queue impact | every verdict is pushed through the real `phaseb.verify.score()` — "swap to this and your queue resolves like THIS" |
| measured $/record | from each response's own usage block, **all-in** (tokens **+** server-side search) |

Everything below is **agreement, not accuracy.** That distinction is load-bearing and is the
reason this file says "for now".

## 3. Model bake-off — agentic mode

16 records × 5 backends, stratified by source class (14 directory / 2 news), same prompt, same
`max_tokens`, same gate. Total **$9.38**.

| backend | ok | refus | err | corrob | **$/rec all-in** | tok | srch | med s | agrees w/ incumbent |
|---|---|---|---|---|---|---|---|---|---|
| opus-4.8 *(then-incumbent)* | 16/16 | 0 | 0 | 0.50 | $0.2005 | 0.1762 | 0.0244 | 9.1 | — |
| opus-5 | 16/16 | 0 | 0 | 0.52 | $0.2034 | 0.1784 | 0.0250 | 14.2 | 0.896 |
| **sonnet-5** | 16/16 | 0 | 0 | 0.50 | **$0.1387** | 0.1143 | 0.0244 | 11.1 | **0.917** |
| haiku-4.5 | 16/16 | 0 | 0 | 0.50 | $0.0797 | 0.0422 | 0.0375 | 9.3 | 0.854 |
| grok-4.5 *(control)* | 15/16 | 0 | 0 | 0.31 | $0.0019 | 0.0019 | 0 | 3.5 | 0.711 |

**Queue impact** (what each would do to the 16 records):

| backend | review_status | verdict mix |
|---|---|---|
| opus-4.8 | needs_review 12 · reported 3 · approved 1 | agree 45 · disagree 2 · unverifiable 1 |
| opus-5 | needs_review 9 · reported 6 · approved 1 | agree 41 · disagree 5 · unverifiable 2 |
| **sonnet-5** | **needs_review 12 · reported 3 · approved 1** | agree 45 · disagree 3 |
| haiku-4.5 | needs_review 8 · reported 5 · approved 3 | agree 42 · disagree 5 · unverifiable 1 |
| grok-4.5 | needs_review 2 · reported 13 | agree 32 · unverifiable 13 |

### Findings

- **Reliability does not discriminate.** Zero refusals, zero malformed, zero truncations, zero
  errors across all four Anthropic models. *"The premium model is more dependable" is not
  supported.*
- **Corroboration does not discriminate either** — 0.50 / 0.52 / 0.50 / 0.50. Flat.
- **Cost is the only separating axis.** → **sonnet-5**: identical queue distribution to the
  incumbent, highest agreement of any candidate, **0.69×** the cost.
- **Haiku is 2.5× cheaper but behaves differently** — approves 3 rather than 1, reports 5 rather
  than 3. More decisive in both directions. Whether that is better judgement or worse **needs
  ground truth**.
- Haiku's 5× token-price advantage compresses to **2.5× all-in** because it *searches more*
  (search line $0.0375/rec, the highest of any backend).

### Decision

`settings.verify_model = "claude-sonnet-5"` (was `claude-opus-4-8`). Still a different vendor
than the Grok extractor, so decision #4 holds. Rationale is recorded inline at the setting.

## 4. Architecture bake-off — agentic vs retrieved

Same 16 records. `--mode retrieved` = **Exa retrieves** (5 results, 3k chars each, $0.005/record)
→ model judges **closed-book** over the supplied pages. Retrieved **once per record and shared by
every backend**, so judges differ and evidence does not. Every judge forced `search: none`.
Total **$1.21** (vs $9.38).

| backend | corrob agentic → retrieved | $/rec agentic → retrieved | off-script URLs | liveness |
|---|---|---|---|---|
| opus-4.8 | 0.50 → 0.40 | $0.2005 → $0.0259 | 0 | 19 live, 0 dead |
| opus-5 | 0.52 → 0.42 | $0.2034 → $0.0320 | 0 | 19 live, 0 dead |
| sonnet-5 | 0.50 → **0.33** | $0.1387 → **$0.0193** | 0 | 16 live, 0 dead |
| haiku-4.5 | 0.50 → 0.33 | $0.0797 → $0.0082 | 0 | 16 live, 0 dead |
| grok *(control)* | 0.31 → **0.38** | $0.0019 → $0.0102 | 0 | 18 live, 0 dead |

Retrieval: 40 pages over 16 records, **2 returned nothing**. Agreement with incumbent rose across
the board: sonnet-5 **0.938**, opus-5 0.889, grok **0.875**, haiku 0.854.

### What got better

- **Fabrication eliminated.** `cited_urls_not_supplied = 0` for every backend and **zero
  unreachable URLs**. URLs come from a search index, so they exist by construction.
- **Cost collapses ~7×.** Projected on the $55 line: sonnet-5 **$7.72** per 400 records,
  haiku **$3.28**.
- **The Grok control's confound is resolved.** Its agentic 0.711 was *tool access, not vendor* —
  handed evidence it jumps to **0.875** at $0.0102/record. This is the direct read on the
  Fireworks question: **supply the evidence and a cheap non-Anthropic model judges comparably.**

### What got worse

Corroboration fell **34%** for sonnet-5, and the verdict mix shifted hard:

| sonnet-5 | agree | disagree | unverifiable |
|---|---|---|---|
| agentic | 45 | 3 | **0** |
| retrieved | 29 | 8 | **11** |

`reported` went 3 → 10 of 16.

**Two readings, and phase 1 cannot separate them:**

- *Charitable* — agentic's 45/48 "agree" was partly rubber-stamping from prior knowledge, and
  closed-book forces honest abstention. Those 11 mean "the retrieved pages don't settle this",
  which is **true**.
- *Uncharitable* — one Exa call is too weak and real verification reach was traded away.

### The hybrid does not rescue it

Retrieved-as-first-pass with agentic escalation was checked and **rejected on the numbers**: 10 of
16 records would escalate → $0.106/rec against $0.139. A **24%** saving for two architectures to
maintain.

## 5. Cost model (per 400-record run)

| stage | model | cost |
|---|---|---|
| `phaseb/extract` | grok-4.20 | **$1.68** |
| chain layer (~54 calls) | sonnet-5 | ~$7.49 |
| **`phaseb/verify`** | **sonnet-5 agentic** | **$55.48** *(measured)* |
| `phaseb/verify` | sonnet-5 retrieved | $7.72 *(projected)* |
| `phaseb/verify` | haiku-4.5 retrieved | $3.28 *(projected)* |

**Verify is 33× extraction.** Moving the *extractor* to a cheap vendor optimises a rounding
error — that idea was raised and dropped for this reason. The only cost lever that matters is
the verify call.

## 6. Open threads — where to resume

1. **Retrieval quality is the lever with headroom.** 2 of 16 records returned zero pages, using a
   single naive query (`{name} data center {county} {state} capacity MW status`) at 5 results.
   Multi-query retrieval, more results, or a domain-targeted pass could close much of the
   0.50 → 0.33 gap while keeping the 7× cost advantage *and* zero fabrication. Cheapest
   experiment available; edit `bakeoff._retrieval_query` / `RETRIEVAL_RESULTS`.
2. **Ground truth is still the blocker** for every accuracy question here — the haiku
   decisiveness question, and the charitable-vs-uncharitable reading in §4. Needs ~30–40
   human-signed gold entries spanning both source classes. `gold_priority` in each results file
   already ranks records by how much the candidates split, so an adjudication hour goes to the
   rows that decide the gate rather than the biggest ones.
3. **Fireworks / open weights are unblocked but untested.** Three entries sit in `DEFAULT_SLATE`
   disabled pending `FIREWORKS_API_KEY`. ⚠ Their prices are **working figures**, flagged
   `price_confirmed: false` — the whole comparison is a $/record ranking, so confirm against the
   rate card before believing a row. Test them in **`--mode retrieved`**; in agentic mode they
   cannot retrieve and are structurally disqualified.
4. **Decision #4 remains untested.** The Grok control was meant to test "same-vendor agreement is
   meaningless" and did not — it ran without web search, so it measured tool access. Testing it
   properly needs Grok on Agent Tools search in agentic mode.
5. **Re-runs are one sample, not a fixed point.** `temperature` is deprecated on Opus 4.8 /
   Opus 5 / Sonnet 5 (a hard 400), so those models cannot be pinned. A narrow gap should be
   re-run before it is believed.

## 7. Changes shipped alongside

| Change | Why |
|---|---|
| `source_liveness.py` + gate wiring | a cited URL must **resolve** before earning the corroboration bonus — see the standing finding in `CLAUDE.md` |
| `phaseb.verify.score()` extracted | one gate implementation, shared by production and the bake-off, so a comparison cannot drift from what the pipeline does |
| `spend.register_price` + `unpriced` tracking | an unpriced model billed $0 and was invisible to the cap |
| `claude-sonnet-5` repriced $2/$10 → **$3/$15** | the $2/$10 intro rate expires 2026-08-31 and sonnet-5 is now the highest-volume paid call |
| `allow_web_search=False` on `chain_topology:153` + `chain_quant:338` | those two prompts are entirely excerpt-bound. **Only those two** — three sibling verifiers say "You MAY web-search" deliberately |
| `results_path(mode)` | each run used to overwrite the baseline it exists to be compared against |

Tests: **317 green** (259 before this work). Publish gate: 0 errors.

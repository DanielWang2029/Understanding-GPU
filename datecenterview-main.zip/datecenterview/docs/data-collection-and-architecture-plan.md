# Data Collection & Architecture Plan

> **Purpose.** Turn the approved demo (`compute-terminal-demo.html`) into a buildable data plan. It reconciles the demo's **target contract** with the **running pipeline** (the real `data.json` feeding the Next.js app at `localhost:3000`), and specifies — for every data point the terminal shows — where it comes from (API / scrape / DB / derive), how it's structured, how it's validated, and the **phased priority** to build it. The demo is the *UI* contract; this is the *data* contract behind it. Extends `docs/build-handoff-spec.md` §1–3 and `docs/data-schema-and-validation-spec.md`. July 2026.

---

## 0. The gap, in one line — and the three tiers that set priority

The demo needs a **superset** of what the pipeline emits today. The gap splits into three tiers, and the tiering *is* the prioritization logic:

| Tier | Meaning | Examples | Cost to close |
|---|---|---|---|
| **A · Have** | Collected **and** emitted today | power (3.5k rows), DC install base + news builds (407), value-chain edges (relation only), linked newsfeed | — |
| **B · Exists-but-unwired** | Column/data already in the store or extractor, but **not emitted or not populated** | `edge.value` (empty JSONB col) · `entity.identifiers.ticker` · `data_center.operator/tenant` (extracted, not persisted) · `status_history` (always `[]`) · `sqft/acres/mwh/power_sources` (stored, not emitted) · `supply_chain` sankey (100% **seeded**, should be derived) | **Cheap** — mostly emit/populate/derive |
| **C · Net-new** | Requires a real new source/collector | entity **financials** (market_cap/revenue/capex) · **quantified edges** (%COGS/%rev/disclosed) · physical **assets** (fabs/HBM/packaging) · **skus/prices/forwards/ratings/clusters/bottleneck** | New connectors |

**Key insight:** several headline demo features are Tier **B** — e.g. the Overview sankey is currently *seeded static* but can be **derived from the real `entities`+`edges`** we already collect, and `edge.value` is an *existing empty column*. So the first real milestone after wiring the contract is cheap. Financials (Tier C via FMP) are the highest analyst-value, lowest-effort net-new addition.

---

## 1. What the terminal shows → the data classes each view consumes

| View (altitude) | Data classes it needs | Today |
|---|---|---|
| **Overview** — flow sankey + project drill + weight toggle | `entities`(+**financials**) · `edges`(+**value**) · `supply_chain` topology · project role-chains | edges/entities real (unquantified); **sankey seeded**; no financials |
| **Chain Analysis** — SPLC | `entities`(+financials) · `edges`(+**%COGS/%rev/disclosed**) · peers | graph real; **no magnitudes** |
| **Explorer** — geography | `assets`(DC ✅ + power ✅ + **upstream 🔴**) · `data_center`(role chain) · `power_project` · filters | DC/power real; **upstream assets missing** |
| **Price Board** — buyer | `skus` · `prices`(spot) · `price_forward`(Kalshi) · `ratings`(ClusterMAX) · providers | **all net-new** |
| **Newsfeed** | `news`(+url) · `feeds` | real ✅ (published_date sparse) |

---

## 2. The complete data-point inventory

Legend — **Status:** ✅ A (have) · 🟡 B (exists-unwired) · 🔴 C (net-new). **Loop** ids per `docs/TDD-compute-terminal.md` (L1 ingest · L2 verify · L4 flywheel · L7 price · L8 rating · L9 financial · FF feedforward).

### 2.1 Entity (organization)
| Field | Status | Source · method | Cadence | Validation | Loop |
|---|---|---|---|---|---|
| id, name, category | ✅ A | wire_edges canonicalization | on build | referential; category enum | L1 |
| category quality (96/157 = `other`) | 🟡 B | rules + LLM classifier | on build | sampled edge/category precision | L4 |
| `layer` (**equipment**…enduser) | ✅ A | `models.py:78`; **8 layers** since Band 2 #1 added `equipment` | on build | enum | L1 |
| `ticker` | ✅ A | `identifiers` col → EDGAR ticker file | quarterly | `backbone_reach` | L9 |
| `revenue` **22/37**, `capex` **13/37** | ✅ A (partial) | **SEC EDGAR** XBRL companyfacts (free, no key) | Q + event | `financials_integrity`; `backbone_reach_integrity` | **L9** |
| `market_cap` **8/37** | 🟡 B | ⛔ **structurally capped** — EDGAR carries no price; FMP MCP gates by ticker (8 mega-caps). Needs a price source (Finnhub, or price × EDGAR shares-out) | Q + event | `financials_integrity` | **L9** |
| hq{country,region} | 🔴 C | company site / profile | rare | geo bounds | L9 |

### 2.2 Edge (typed relation)
| Field | Status | Source · method | Cadence | Validation | Loop |
|---|---|---|---|---|---|
| from, to, relation, confidence, sources | ✅ A | wire_edges | on build | relation enum; referential | L1/L2 |
| **`value`{amount, basis(pct_cogs\|pct_revenue\|usd\|mw\|gpus), disclosed}** | 🟡 B col / 🔴 C content | **col exists (unused)**; fill from **SEC EDGAR / earnings** extraction + cross-verify | on filing + event | **disclosed overrides estimate (error if violated)**; basis enum; pct 0–100 | **L9**/L2 |
| valid_from/to, status | 🟡 B | change_log | on change | dates monotonic | L3 |

### 2.3 Asset (physical node — the map layers)
| Field | Status | Source · method | Cadence | Validation | Loop |
|---|---|---|---|---|---|
| `datacenter` layer | ✅ A | project `data_center` rows into asset view | on build | — | L1 |
| `power` layer | ✅ A | project `power_project` rows | on build | — | L1 |
| `fab · packaging · hbm · server · cable` (id, entity_id, layer, geo, capacity, status) | 🔴 C | company disclosures / press / SemiAnalysis (finite set ~dozens) | event | geo bounds; entity ref | L1 |

### 2.4 Data_center (project record)
| Field | Status | Source · method | Cadence | Validation | Loop |
|---|---|---|---|---|---|
| project_name, developer, developer_category, status, sources, confidence, last_verified | ✅ A | PhaseB extract + PeeringDB | event | referential; conf 0–1 | L1/L2 |
| capacity_mw (76%), lat/lng (93%) | ✅ A | extract / enrich (Exa+Grok) / PeeringDB | event | range; bounds | L1 |
| county (14%) | 🟡 B | Census reverse-geocode from lat/lng | on build | — | L1 |
| **developer 98%, operator 94%, tenant/end_user** (see note) | ✅ A | PhaseB extract → `dc_roles.py` resolves name→entity id | event | entity ref; `dc_role_coverage_integrity` | L1/**L2-dcroles** |
| end_user (4%), cap_ex (9%), operating_year (8%) | ✅ A (sparse) | extract; sharpen via EDGAR/press | event | — | L1 |
| sqft, acres, capacity_mwh, power_sources | 🟡 B | **stored, not emitted** → emit | on build | ranges | emit |
| `status_history[]`, cod_date | 🟡 B | **col exists, always `[]`** → fill from change_log/news | on change | ordered transitions | L3 |

> **Correction (2026-07-21).** This table previously read "**operator, tenant** (extracted, **not persisted**)" and P1 below claimed both were persisted and entity-resolved. **Both were wrong, in opposite directions.** The measured pre-fix state (`dc_roles.py:6-10`): `developer` had 424 raw names and **0** resolved; `tenant` had 2 resolved and **no raw column at all** — `persist.py` computed a tenant and dropped it on write because no column existed. P1's `operator 0→94%` was real but came from `operates` **edges**, not from extraction. Fixed in Band 2 #2 (`e275e31`): `tenant_name`/`operator_name` columns added, `develops` mapped, and resolution moved into `dc_roles.py`.
>
> **`tenant` coverage is not a data-availability number — check the denominator.** 255 of 432 DCs are **retail colo** (Level(3), Equinix, Lumen): hundreds of customers, no single tenant, so a scalar column has nothing to hold. Coverage is reported against the **eligible** base (177) with `not_applicable` as a first-class count, and `tenant_distinct_party` separately — 24 of 49 extracted tenants merely restated the developer (a permit SPV occupying its own building carries no counterparty information). Driving the raw % up would mean inventing data.

### 2.5 Power_project
| Field | Status | Source · method | Cadence | Validation | Loop |
|---|---|---|---|---|---|
| name, technology, capacity_mw, status, geo, btm, confidence, sources | ✅ A | EIA-860M + 7 ISO queues (gridstatus) | EIA monthly · ISO daily | reconcile EIA totals / ISO counts | L1 |
| operating_year (58%), lat/lng (63%) | ✅ A | EIA / county centroid | monthly | bounds | L1 |
| **interconnect lead-time / queue position** | 🔴 C (derivable) | **derive** from ISO queue dates | daily | — | **FF** |

### 2.6–2.11 Compute & market layers (all 🔴 C unless noted)
| Class · key fields | Source · method | Cadence | Validation | Loop |
|---|---|---|---|---|
| **`sku`** name, vendor, gen, hbm_gb, tflops, power_w, cowos, launch | public datasheets (small static set) | event | enum; ranges | L1 |
| **`price_point`** sku, provider, region, term(on-demand/reserved/spot), $/gpu-hr, as_of, source | **GetDeploying · AI-Multiple · Cloud GPU Tracker** (API/scrape) | hourly–daily | deadband; **≥2 aggregators agree**; $ range; monotonic ts | **L7**/L2 |
| **`price_forward`** sku, horizon(3/6/12mo), $/gpu-hr, as_of | **Kalshi forward curves** (regulated API) | daily | mark `modeled` where no live curve | **L7** |
| **`provider_rating`** provider, source, tier, dims{10}, as_of | **ClusterMAX (SemiAnalysis)** — attribute; **ToS** | quarterly | single-source→warn; hysteresis on tier | **L8** |
| **`cluster`** operator, sku, gpu_count, status, cod_date, power_mw, region | press/announcements + **Epoch AI** | event | referential | L1 |
| **`bottleneck_stage`** stage, region, tightness(g/a/r), lead_time_days, as_of | power ← ISO/EIA (**derivable**); upstream ← earnings/TrendForce (coarse) | daily / weekly | candidate (low-conf) until confirmed | **FF** |

### 2.12 News / 2.13 Supply-chain topology
| Field | Status | Source · method | Cadence | Validation | Loop |
|---|---|---|---|---|---|
| news: title, publisher, **url**, source_feed, tag, projects | ✅ A | wire_news from source articles | continuous | url format; referential | L1 |
| news: published_date (often null), entity_refs | 🟡 B | improve extraction; `entity_refs` col exists | continuous | date format | L1 |
| **supply_chain nodes/links** | 🟡 B | **100% seeded today → derive from `entities`+`edges`+financials** (so the Overview sankey is real + weightable by cap/rev/mcap) | on build | acyclic; referential | L1/L9 |

---

## 3. Source-connector registry

| Source | Type | Access / cost | Feeds | Cadence | Loop | Status |
|---|---|---|---|---|---|---|
| EIA-860M | gov API | free (key) | power_project | monthly | L1/FF | ✅ |
| 7 ISO queues (`gridstatus`) | lib/scrape | free | power_project, interconnect lead-time | daily | L1/FF | ✅ |
| US Census Gazetteer/geocoder | file/API | free | lat/lng, county | on build | L1 | ✅ |
| PeeringDB | REST API | free | DC install base, `operates` edges | weekly | L1 | ✅ |
| GDELT 2.0 + trade-press RSS (DCD/DCF/DCK) | firehose/RSS | free | news, discovery | 15-min | L1 | ✅ |
| Exa / Grok Agent Tools | API | usage | discovery, capacity enrich | on-demand | L1 | ✅ |
| Firecrawl | scrape | low | article/permit extraction | event | L1 | ✅ |
| Extraction LLM (Grok) + Verify LLM (Claude, diff-vendor) | LLM | usage | DC fields, edges, roles, cross-verify | event | L1/L2 | ✅ |
| **FMP connector** | API (MCP) | free in-session | market cap only — **gated to 8 mega-caps**; superseded by EDGAR for revenue/capex | Q + event | **L9** | 🟡 partial |
| **SEC EDGAR** | API/parse | free, no key | entity revenue/capex, **customer-concentration %rev** (edge quant), chain topology from buyer 10-Ks | Q + event | **L9** | ✅ |
| **`source_policy`** (licensing guard) | local rules | free | **decision #1 as code** — tier-1 competitor DENY at discovery · enrichment · publish; tier-2 directories allowed + tracked | every ingest + publish | **L6** | ✅ |
| **GPU price aggregators** (GetDeploying, AI-Multiple, Cloud GPU Tracker) | API/scrape | free | prices (spot/reserved) | hourly–daily | **L7** | 🔴 |
| **Kalshi** | API | regulated | forward curves | daily | **L7** | 🔴 |
| **ClusterMAX (SemiAnalysis)** | scrape/ingest | partly free (**ToS**) | ratings | quarterly | **L8** | 🔴 |
| **Epoch AI** | CSV | free | clusters/models, `trains_on` | regular | L1 | 🔴 |
| **TrendForce / SemiAnalysis / earnings** | mixed | paid + free-via-earnings | bottleneck tightness, asset capacity | quarterly | **FF** | 🔴 |
| Company IR / disclosures | scrape/IR | free | **upstream asset locations**, edges, cap_ex | event | L1 | 🔴 |
| Permit/rezoning portals | scrape | low (ToS) | unannounced DCs, status | weekly | L1/FF | ⚠️ P6 |
| PitchBook connector | API | paid | private-co valuation/funding | event | L9 | ⚠️ opt |

---

## 3b. Connector loop contracts (5-line contract per connector)

Every connector is a controller, not a fetch step (`loop-design`). Below is the filled 5-line contract (setpoint · measured · error→correction · mechanism · guardrail) for each connector in §3. The four compute/financial connectors marked **†** are elaborated in their skills (`chain-financials`, `price-feed`, `provider-rating`, `bottleneck-feedforward`); this table is the single index. When a connector's module is built, copy its row into the module docstring.

### Existing connectors (harden in place)
| Connector · loop | Setpoint | Measured | Error → Correction | Mechanism · Guardrail |
|---|---|---|---|---|
| **`sources/eia.py`** · L1 | full US generator set, ≤35-day fresh, schema-valid, geocoded; matches EIA totals | last-pull age; row-count Δ vs prior month; % geocoded | stale / count-drop / total mismatch → re-pull, re-geocode, flag reconcile | scheduled poll · **reconciliation vs authoritative anchor** · delta-only. *Guardrail:* authoritative (conf 1.0, no cross-verify); monthly cadence = real change rate |
| **`sources/iso.py`** · L1/FF | 7 ISO queues ≤1-day fresh; MW/status/date current; feeds FF lead-time | per-ISO pull age; queue count; parse-fail rate/ISO | stale / parse-fail / anomaly → re-pull; repeated fail → **circuit-break that ISO** + alert | **circuit breaker per ISO** · **feedforward** (queue = leading power signal) · PID-D on queue rate. *Guardrail:* one ISO's format change can't fail the layer |
| **`geocode.py`** (Census) · L1 | every row lat/lng at best precision; gazetteer ≤1-yr | % geocoded; precision mix; cache age | ungeocoded / stale gazetteer → geocode addr→centroid; annual refresh | cache (stock) · deterministic · free. *Guardrail:* `geo_precision` flags county-level as coarse |
| **`clients/peeringdb.py`** · L1 | operating install base enumerated weekly; operator+geo current | facility count Δ; new/removed; API health | stale / API error → re-enumerate; degrade → circuit-break + last-known | weekly enumerate · **circuit breaker** · feeds `operates`. *Guardrail:* conf capped 0.75 (`needs_review`), capacity absent → downstream enrich |
| **`phaseb/discover.py`** (GDELT+RSS) · L1 | high **recall** of DC articles; new-source discovery; deduped | candidates/day; per-source relevance precision; dedup rate | recall/precision drop / spam → broaden queries; **circuit-break** low-precision source; promote high-signal domains | **requisite variety** (firehose+RSS+search) · **circuit breaker** per source · trust scoring. *Guardrail:* recall-then-classify; classifier gate before extract spend |
| **`clients/exa.py` + `clients/grok.py`** (discovery) · L1 | gap-fill/net-new for below-coverage cells; live-X signal | new candidates/query; cost/candidate; overlap | low yield / high cost → retarget to lowest-coverage cells; cap spend | **active learning** (query where coverage lowest) · **requisite variety** (2 decorrelated vendors). *Guardrail:* L5 spend cap; output = candidate |
| **`clients/firecrawl.py`** · L1 | candidate URLs → clean text in budget; paywalls flagged | fetch success %; cost; paywall/robots rate | failures / cost spike / robots → retry-backoff, **respect ToS** (skip+flag), backpressure | **anti-windup/backpressure** · governance. *Guardrail:* never bypass paywalls; keep url+retrieved-at |
| **`clients/grok.py`** (extract) · L1 | each article → schema-valid record, one quote/field | schema-pass %; field coverage; cost/record; gold-set field accuracy | schema-fail / low-coverage / accuracy regression → retry tighter prompt; regression → block + revise prompt | **schema-gated extraction** · **flywheel** (prompt improves) · cheap model. *Guardrail:* output = candidate until L2; gold set is the balancing gate |
| **`clients/claude.py`** (verify) · **L2** | key fields agree across ≥2 **different-vendor** sources | cross-vendor agreement; conflict rate; confidence dist. | disagreement / single-source → lower confidence + re-search; <2 → keep "reported" | **maker-checker / negative feedback** · **requisite variety** (verifier ≠ extractor vendor) · hysteresis on status. *Guardrail:* same-vendor agreement is meaningless — vendors MUST differ |
| **`clients/spend.py`** · **L5** | daily spend ≤ cap ($25/day); allocated to highest uncertainty×value | running daily spend; per-call cost; spend-by-stage | near/over cap / burst → throttle low-value; **anti-windup** (cap queue); alert | **anti-windup/backpressure** · **active learning** (budget→uncertainty×value) · overspend circuit-break. *Guardrail:* this IS the L5 actuator for all connectors |

### Trust & governance controllers (built in Band 1–2 — these are not source connectors, but they are controllers and belong in the index)
| Controller · loop | Setpoint | Measured | Error → Correction | Mechanism · Guardrail |
|---|---|---|---|---|
| **`source_policy.py`** · **L6** | **zero** tier-1 competitor URLs in the store or the published read-model; tier-2 directories allowed but *counted* | tier-1 URLs found by `scan()` at publish (gate 8) — **0** today; tier-2 exposure — **180** today | any tier-1 URL → **refused at the discovery queue** (so never fetched) and at enrichment; reaching publish → **blocks**; already published → `purge-denied-sources` withdraws the **value** | denylist/allowlist at **every** ingest path **+** the publish gate (defence in depth). *Guardrail:* enforce on EVERY path, not the one that broke first — `enrich.py` was filtered and PhaseB discovery then reintroduced tier-1 URLs through a path nobody had checked. **Withdrawing the URL alone launders the value** |
| **`dc_roles.py`** · **L2-dcroles** | every named role string (developer/operator/tenant/end_user) resolved to an entity id; coverage stated against the **eligible** base | `meta.rollups.dc_role_coverage` [live] — filled · resolved · eligible · `not_applicable` · `tenant_distinct_party` · conflicts | unresolved name → logged as a **backbone-expansion candidate**, not dropped; one name → many entities → surfaced as a conflict, never silently picked | deterministic **local** resolution (alias map, longest-match; **no model-produced ids**) · eligibility-aware denominator. *Guardrail:* **resolution runs BEFORE the lexical name guard** (`The Swig Company` is a real operator shaped like a descriptor); a role field holds an **identity**, never a description of one |
| **`goldset.py`** · **L6** (the balancing gate on the L4 flywheel) | ≥30 **human-signed** per-field entries (value + source + verbatim quote); field accuracy ≥ target | signed-entry count; per-field accuracy over **evidenced fields only** (unevidenced are skipped, not scored as correct) | below `min_signed` → `certify()` **refuses**, so no flywheel claim can be made | stratified sampling by **source class** (directory vs news), not confidence · refuse-by-default. *Guardrail:* **a gate derived from the system it gates is not a gate** — the old 7-row set was all `demo_seed_bootstrap`. Model transcription counts as `UNSIGNED`: the verifier of record is `claude-opus-4-8`, so Claude attesting to Claude certifies nothing |
| **`reverify.py`** · **L2** | zero rows sitting in `reported` that no second vendor ever checked; zero `approved` rows carrying <2 sources | considered / reverified / failed · status moves · sources added vs **refused by policy** · `with_quote` vs `without_quote` | unverified row → re-run **only** the verify stage (no discovery, no re-extraction); corroborated → persist the **source**; not corroborable → **demote** | maker-checker replay · fail-closed. *Guardrail:* **keep the EVIDENCE, not just the verdict** — the first build kept `review_status` and dropped the corroborating sources, leaving 23 rows asserting `approved` on evidence the record no longer contained. Every row records its basis (`reverify_with_quote` / `reverify_no_quote`) |
| **`backbone.py` reach** · **L9/L2** | every backbone entity classified `current` / `stale` / `no_us_listing` / `private` / `no_annual_report`; no out-of-reach entity ever carries a `disclosed` figure | `meta.rollups.backbone_reach` [live] — **24 / 8 / 4 / 1** today, against a **550-day** horizon | annual report older than the horizon → treated as `stale`, metric dropped; an out-of-reach entity holding `disclosed` → **gate 6 blocks publish** | reach classifier · freshness horizon. *Guardrail:* **find-reach ≠ size-reach** — a source that can find a relationship may be structurally unable to size it. **EDGAR reach is not binary**: Advantest is in the ticker file and returns a real 20-F that is 4,043 days old |

### New connectors (build with this contract)
| Connector · loop | Setpoint | Measured | Error → Correction | Mechanism · Guardrail |
|---|---|---|---|---|
| **`clients/fmp.py`** † · **L9** | every key entity market_cap/rev/capex/ticker ≤1-qtr fresh; reconciled to filing | coverage % of chain revenue; staleness; gap vs filing | missing/stale/divergent → pull FMP, reconcile vs EDGAR, review on divergence | **L9** · reconciliation vs anchor (earnings) · **circuit breaker** · **deadband** on tiny market_cap wiggle. *Guardrail:* market_cap daily vs rev/capex quarterly — separate horizons |
| **`clients/edgar.py`** † · **L9/L2** | %COGS/%rev + capex for top-N edges; `disclosed` flagged | disclosure coverage; extraction accuracy (gold set); disclosed/est ratio | missing/error/estimate-contradicts-disclosure → parse 10-K/8-K, **cross-verify**, disclosed wins, log delta | **maker-checker** · **disclosed-over-estimated** (validator-enforced) · **active learning** (top-N by value). *Guardrail:* gate the extraction flywheel on the gold set; disclosed always wins |
| **`clients/price_aggregator.py`** † · **L7** | on-demand <24h fresh; full SKU×provider×region×term grid; ≥2 aggregators agree | latest-price age; grid fill %; cross-aggregator dispersion; volatility | stale/missing/dispersion/anomaly → re-poll, rotate feed, **anomaly emits (not suppressed)**, degrade→circuit-break | **deadband + anomaly + requisite variety + anti-windup + circuit breaker**. *Guardrail:* confidence from cross-aggregator agreement, not per-row; deadband = cost AND alert quality |
| **`clients/kalshi.py`** † · **L7** | forward curves (3/6/12mo) for covered SKUs, daily | curve freshness; covered-SKU set; forward-vs-realized error | stale / uncovered SKU / poor calibration → re-pull, mark uncovered `modeled`, track realized error | daily poll · **disclosed(curve)-vs-estimated(modeled)** · calibration tracking. *Guardrail:* never present `modeled` as market-implied; a forward is a candidate |
| **`clients/clustermax.py`** † · **L8** | every active provider rated (10 dims) ≤quarterly; multi-source agreement | rating coverage; staleness; source agreement | missing/stale/disagreement → re-ingest, compute measurable dims, escalate | **requisite variety** (ClusterMax + our measured dims) · **hysteresis** on tier · **HITL**. *Guardrail:* **ToS** — attribute/link-out; don't flip tier on one weak signal |
| **`sources/tightness.py`** † · **FF** | per-stage tightness (CoWoS/HBM/chip/server) ≤quarterly; power from ISO real | flag freshness; **FF hit-rate** (did the squeeze materialize?) | stale / miscalibrated → update from earnings/TrendForce, recalibrate, **candidate until L2 confirms** | **feedforward** · PID-D (allocation rate) · candidate-then-verify. *Guardrail:* coarse+labeled; low-conf until a price move confirms; hit-rate SLO |
| **`sources/assets.py`** (company IR) · L1 | finite fab/packaging/HBM/server set enumerated+geo'd; capacity where disclosed | coverage vs known-site list; geo precision; last-verified age | gaps/stale → scrape IR/press, **log dropped sites (no silent cap)** | event-driven · requisite variety (IR+press+research) · geocode. *Guardrail:* finite set (dozens) → tractable; log coverage gaps explicitly |
| **`sources/epoch.py`** · L1 | notable/frontier clusters+models synced; `trains_on` resolved | sync age; new-model count; link-resolution rate | stale / unresolved → re-download, resolve to entities | scheduled download · free · deterministic. *Guardrail:* research dataset → attribute; resolve via alias table |
| **`clients/permits.py`** · L1/FF (P6) | active-DC-state portals crawled weekly; unannounced projects pre-news | new filings/week; **lead-time vs later news**; per-portal parse health | missed/portal-change/ToS → re-crawl, circuit-break changed portal, **respect robots/ToS** | **feedforward** (permit = leading indicator) · **circuit breaker** per portal · governance. *Guardrail:* ToS/robots compliance; output = candidate |
| **`clients/pitchbook.py`** · L9 (opt) | private-co (neocloud/AI-lab) valuation/funding current on events | private-name coverage; valuation freshness | missing/stale → pull on funding event, mark `estimated` | L9 · disclosed-vs-estimated (private = estimated) · circuit breaker. *Guardrail:* private valuation ≠ market cap — never rendered as such; paid → cost-gated |

---

## 4. Data structure — store (v1.2) + read-model

**New store tables:** `asset · sku · price_point · price_rollup · price_forward · provider_rating · cluster · bottleneck_stage`.
**Populate/extend existing (Tier B):** `entity` (+`ticker/market_cap/revenue/capex/layer/hq`) · `edge` (**populate the existing `value` JSONB** + emit it) · `data_center` (~~persist `operator_id/tenant_id`~~ ✅ done Band 2 #2 — `tenant_name`/`operator_name` columns + `dc_roles.py` resolution; fill `status_history`, emit `sqft/acres/mwh/power_sources`) · `news` (`entity_refs`) · `supply_node/supply_link` (**derive from graph instead of seed**).
Keep the **`Field<T>`** JSONB provenance wrapper on every claim value; **disclosed-over-estimated** precedence is a schema-enforced rule.

**Read-model (`data.json` → v1.2):** the demo's contract. Adds `assets[]`, `skus[]`, `prices[]`, `forwards[]`, `ratings[]`, `clusters[]`, `bottleneck[]`; extends `entities[]` (financials) and `edges[]` (`value`); consumes `meta.rollups`. `emit.py` projects each. Bump `schema_version` 1.0 → 1.2.

**Serving:** today the Next app fetches static `/public/data.json`. Add the noted **`/api/data` route handler** (already flagged in `next.config.mjs`) so the app can proxy the store + a change feed once multi-user.

---

## 5. Validation regime (existing + new)

Extend the shipped `data.schema.json` + `validate_data.py` gate (green today) across the new classes:

- **Structural** — types/enums/ranges for `assets/skus/prices/forwards/ratings/clusters/bottleneck`; `basis`/`tier`/`term`/`stage` enums; `$ /gpu-hr` 0–200; pct 0–100; `as_of`/`sources` required.
- **Referential** — edges→entities, assets→entities, prices→skus+providers, ratings→providers, clusters→skus, news→projects; **acyclic** derived supply-chain.
- **Cross-source (semantic)** — ≥2 independent sources before `confirmed`; **≥2 price aggregators agree** (dispersion→warn); **disclosed edge overrides an estimate at the same triple (error if violated)**; single-source rating→warn.
- **Freshness** — per-class horizons: price `<24h` (`--max-stale-hours`), market_cap `<1 quarter`, power monthly, DC status news-driven; **deadband** kills churn.
- **Reconciliation** — vs authoritative anchors: EIA generator totals, ISO queue counts, latest earnings for `market_cap/capex`, ClusterMAX tiers, cross-aggregator price median.
- **Admissibility (licensing/ToS)** — **decision #1 as code**: no value sourced from a tier-1 paid curated competitor may exist in the store or the read-model. Enforced at the discovery queue (refused before fetch), at enrichment, and at publish (gate 8) — see the `source-admissibility` skill. Tier-2 free directories are allowed and **counted** (`rollups.source_policy`, cross-checked by the gate). This class is invisible to every other line in this list: inadmissible data is fresh, corroborated and cross-vendor verified — the only thing wrong with it is that we were not entitled to it.
- **Evidence** — a published value should carry the verbatim quote supporting it (`Field<T>.quote`); coverage is reported live (`rollups.evidence_coverage`) rather than assumed, because quotes are persisted only from 2026-07-20 and most rows predate that.
- **Confidence & gates** — field-level → overall (weighted-min). CI: `validate_data.py` exit 1 blocks publish (the **nine** gates — see `docs/data-schema-and-validation-spec.md` §4.1).

> ⛔ **The ≥0.90 auto · 0.60–0.89 review · <0.60 "reported" threshold gate is measurably inoperative — do not re-specify it.** Measured 2026-07-20 across all 364 `needs_review` DCs: exactly **two** distinct confidence values, `0.72` (all news-extracted) and `0.75` (all PeeringDB). Confidence is a **per-ingest-path constant**, so every threshold approves all or none. The same defect degrades the active-learning priority `(1-conf)×log1p(mw)` referenced at §3b, §7b and §7c into a ranking by **capacity alone** — it is still a reasonable queue order, but it is not uncertainty sampling and must not be described as such. `goldset.sample()` stratifies by **source class** (directory vs news) instead. Making confidence load-bearing requires deriving it from something that varies per record (corroboration count, source-trust spread, extraction agreement); that is unbuilt.

---

## 6. Architecture (end-to-end)

```
 CONNECTORS ──────────────────────────────────────────────────────────────────────────
  free/have:  EIA · ISO(gridstatus) · PeeringDB · GDELT+RSS · Exa/Grok · Firecrawl · Census
  new:        FMP · EDGAR · GPU-price-aggregators · Kalshi · ClusterMAX · Epoch · earnings/IR
        │
 PIPELINE (Python, scheduled) ── existing: phase-a · phase-b(discover→extract→verify) · wire-edges · wire-news · enrich · emit
   NEW stages:  financials(L9) · chain-quant(L9) · assets(L1) · pricefeed(L7) · forwards(L7) · rating(L8) · bottleneck(FF)
   loops:  L1 ingest · L2 maker-checker · L3 freshness · L4 flywheel · L5 cost/active-learning · L6 eval · L7 price · L8 rating · L9 financial · FF feedforward
        │ upsert (Field<T> provenance; disclosed>estimated)
 STORE  Postgres (SoR, +8 tables, +populated cols)  ·  DuckDB (rollups: price, market-cap-by-layer, headroom, derived sankey)
        │ emit → data.json v1.2  (+/api/data route + change feed)
 FRONTEND  Next.js @ localhost:3000 — Overview · Chain Analysis · Explorer · Price Board · Newsfeed
           (the approved demo's runtime, ported; pure function of the contract)
        │ docker-compose: postgres · pipeline · api · web  →  Supabase at team rollout
```

**Demo → production:** the demo's runtime is the reference implementation of the v1.2 read-model UI; porting it into `web/lib/runtime.ts` preserves the "pure function of `data.json`" architecture the app already uses.

---

## 7. Phased implementation plan (by priority)

Priority = **analyst value × cheapness**, exploiting the Tier-A/B/C split. Each phase names its data classes, connectors, the UI it unlocks, validation added, and an exit gate. **Each phase is also a closed-loop controller — its 5-line loop contract, cross-cutting loops, and guardrails are certified in §7b** (the exit gate below is the loop's *setpoint*).

| Phase | Goal | Data / connectors | UI unlocked | Exit gate | Effort |
|---|---|---|---|---|---|
| **P0 · Contract v1.2 + port demo** ✅ **SHIPPED** | one contract, real app | extend `data.schema.json` + `emit.py` to v1.2 (arrays present, illustrative where absent); port the 5 demo views into `web/`; add `/api/data` route | the 5-tab terminal live at `:3000` | Next renders v1.2 contract; validator green | S–M |
| **P1 · Tier-B cheap wins** ✅ **~DONE** (seed-kill → P2/P3) | make the real graph load-bearing | **emit `edge.value` shape + DC `sqft/acres/mwh`; persist operator/tenant + entity-resolve; fill `status_history`; DERIVE supply_chain from entities+edges (kill the seed); reverse-geocode county; published_date** | Overview/Chain/Explorer on **real** graph (no seed); status timeline; role chains | seed removed; sankey derived; ≥90% status_history coverage on tracked rows | **S–M (cheap)** |
| **P2 · Financial spine** ✅ **SHIPPED** (8 real / 21 est) | value everywhere | **FMP** → entity `market_cap/revenue/ticker/layer` (plan serves **8 mega-caps only**; 21 backbone names flagged estimate) | **weight toggle (cap/rev/mcap)** on real financials; market-cap in Chain Analysis | ~~≥30 tickers~~ → 8 disclosed + toggle re-scales real (FMP-plan-limited) | **S (high value)** |
| **P3 · Edge quantification** 🟡 **shipped + L2 built** | the SPLC magnitudes | **EDGAR** → disclosed `%revenue` into `edge.value` (3 edges) + inferred link; `%COGS` estimated (not disclosed in filings); **cross-vendor L2 (`chain_quant`) built + proven** | suppliers-by-%COGS / customers-by-%revenue with disclosed/est + inferred-link badges + `src↗` | top-N edges quantified+sourced; disclosed-over-estimate enforced | **M (hard data)** |
| **P4 · Compute & price layer** | the buyer instrument | **datasheets**→skus; **aggregators**→prices; **Kalshi**→forwards; **ClusterMAX**→ratings | real Price Board (spot + Kalshi forward + provider quality) | ≥6 SKUs × ≥10 providers, freshness <24h; forwards live | M |
| **P5 · Upstream assets + bottleneck** | the "where + when" | company/press → fab/HBM/packaging **assets**; ISO/EIA (real) + earnings (coarse) → **bottleneck** | Explorer upstream layers; constraint/leading signal | ≥6 asset layers; power lead-time per region from real queue | M |
| **P6 · Proprietary edge + intl** | be first / global | permits · satellite · **Epoch** clusters · **PitchBook** private valuations · ENTSO-E/non-US | pre-news discovery; private-co market-cap; non-US | unannounced project surfaced pre-news; one non-US region | L |

**Build-order rationale:** P0 unifies the contract so the real app shows the terminal; **P1 (Tier B) is the cheapest high-value step** — it makes the graph the app already has *real and navigable* (killing the seeded sankey, wiring the empty `edge.value`); **P2 (FMP financials)** is the single highest analyst-value net-new addition and is nearly free; P3 is the hard-data core (edge magnitudes); P4 restores the buyer instrument; P5/P6 are differentiation.

### P0 — shipped (2026-07-17)

The 5-tab Compute Terminal now runs in the real Next app at `localhost:3000` as a pure function of `data.json` **v1.2**. What landed:
- **Contract v1.2** — `schema_version` `1.0→1.2`; new top-level keys added that don't collide with the preserved real arrays: `layers · chain{entities,edges} · projects · power · assets · skus · providers · prices · price_terms · forwards`. `data.schema.json` + `validate_data.py` extended (structural + referential + semantic for every new class); **validator green** (0 errors on the real+seed file). `emit.py` bumped to 1.2 and merges the seed (`SCHEMA_VERSION="1.2"`, `from .compute_seed import build_seed`).
- **Illustrative-vs-real split (the P0/P1 seam).** The four chain views (Overview flow, Chain Analysis SPLC, Explorer, Price Board) render from an **illustrative compute-chain seed** (`pipeline/dcv/compute_seed.py` — the demo's data promoted into the contract). The **Newsfeed + Explorer datasets are live pipeline output** (real `datasets.news`/`feeds`, 272 items). The real `entities`(157)/`edges`(547)/`datasets`/`supply_chain` are preserved untouched in the file so **P1 is a clean source-flip** (derive `chain` from the real graph) rather than a rewrite. UI carries an honest "◆ ILLUSTRATIVE compute-chain data — Newsfeed is live" flag.
- **UI port** — `web/lib/skeleton.ts` (5-tab body), `web/lib/runtime.ts` (`initApp(D,deps)` reads the v1.2 contract), `web/app/globals.css` (compute-terminal styles + the `--L-<layer>` vars the sankey reads via `getComputedStyle`). Same "skeleton + runtime + injected d3/maplibre deps" pattern the app already used — architecture unchanged.
- **`/api/data`** route handler (`web/app/api/data/route.ts`) — proxies the static contract today; the seam to Postgres + change feed later.
- **Reproducible build** — `python3 pipeline/build_p0_data.py` regenerates the v1.2 `data.json` (real emit + seed merge) without needing Postgres up. `next build` clean; all 5 tabs verified in-browser, pivots (`goChain`) work, 0 console errors.

### P1 — shipped, partial (2026-07-18)

The **real graph is now load-bearing** for the geography + role altitudes; the remaining P1 item (killing the *company supply-sankey/SPLC* seed) is genuinely coupled to P2/P3 (it needs financials + supplier %COGS edges the role-graph doesn't carry), so it moves there.

- **Explorer → real** (slice 1): real `datasets.data_center` (428) + `power_project` (3.5k) on the geojson map, real filters, and a real detail drawer (field-level provenance + the real role chain from `edges`). Upstream fab/HBM/packaging asset **layers** stay illustrative (P5). The **project value-chain drill** also runs on real `edges` (427 sites).
- **Backfill existing columns → emit** (slice 2, `pipeline/dcv/backfill.py`, no migration — all columns already in `models.py`): `operator` 0→**94%** (from `operates` edges), `status_history` 0→**100%** (as-observed entry), entity `category` `other` **96→65** (keyword rules), `county` 14→**94%** (FCC reverse-geocode). Surfaced in the drawer (Operator field + real status timeline) + table (county). Validator green.
- **Still on the seed (→ P2/P3):** the Overview *company supply-sankey* and *Chain Analysis SPLC* need real `market_cap`/`revenue` (P2 FMP) + supplier→buyer `%COGS`/`%rev` edges (P3 EDGAR) before the seed can be killed. **U2 dispute** (§7c) still a stub — wire alongside a `review_log` write.

> ⚠️ **P1's exit gate was reported met when half of it was not** (corrected 2026-07-21). The scope cell above says "persist operator/tenant + entity-resolve." `operator` reached 94% **from `operates` edges**, which is a different mechanism than the one specified — and `tenant` was never persisted at all, because no column existed to hold it. Nothing in P1 measured whether extraction→persist actually worked for either role, so a partial win closed the gate for both. This is the concrete case behind the `loop-design` rule *"the measured value must be live"*: an exit gate that isn't computed from the store is a claim, not a gate. Genuinely fixed in Band 2 #2.

**Next: P2 (Financial spine)** — FMP → entity `market_cap/revenue/ticker/layer`, then flip the Overview supply-sankey + Chain Analysis from seed to the real `entities` with a real weight toggle.

### P2 — spec (elaborated 2026-07-19; FMP-plan-grounded, not yet built)

**Governing constraint (probed live via FMP MCP, 2026-07-19).** The connected FMP plan is **granularly gated**. `statements/income-statement` returns full data for every public ticker probed — `revenue`, `costOfRevenue` (COGS, → P3), `netIncome`, `filingDate`/`fiscalYear` (provenance), `weightedAverageShsOut`. But `company/market-cap` (single), `quote`, `statements/enterprise-values`, and the `company` batch endpoints return **ACCESS DENIED** (one `batch-market-cap` call returned 8 mega-caps, then denied — treat market cap as *unavailable*). **Implication: revenue is reliably free; market cap is not.** Two more facts shape P2: the real entity graph is **downstream-only** (colos/operators/clouds) — upstream TSMC/Nvidia/HBM/systems live only in `compute_seed` — and `Entity` has **no financial columns** (unlike P1, this needs a real migration).

**Two decisions (resolve at build start):**
- **D-A · market-cap source** — recommend **"revenue now, market-cap where FMP returns it free"**: the weight toggle ships with **Revenue** as the real default; `market_cap` populated only where the batch returns it, else `basis:"n/a (plan)"`. Revisit via FMP upgrade or a free alt source (Finnhub / Alpha Vantage / `price × weightedAverageShsOut`) later — additive field, no rework.
- **D-B · backbone promotion** — promote the ~29 curated `compute_seed` chain companies into the **real** store as first-class `Entity` rows (public → real FMP financials; private OpenAI/Anthropic/xAI/Crusoe → `basis:"estimated"`, flagged), entity-resolving against existing real names.

**Steps (each a P2.n; L9 `chain-financials`):**
| # | Step | What lands |
|---|---|---|
| **P2.0** | **Store migration** (first Alembic — additive, low-risk) | `Entity.financials` JSONB (`Field<T>`: `{market_cap, revenue, capex, currency, as_of, sources, basis: disclosed\|estimated\|n/a}`) + `Entity.layer` + ensure `identifiers.ticker`. Extend `data.schema.json`. |
| **P2.1** | **Promote the backbone** | Seed the ~29 chain companies as real `Entity` rows (id/name/category/**layer**/ticker); resolve vs existing real entities; flag private names. Gives the store a real upstream→downstream backbone. |
| **P2.2** | **`clients/fmp.py` (L9) + in-session pull** | Per ticker: `income-statement` → `revenue`, `costOfRevenue` (→P3), `netIncome`, `filingDate`→`as_of`; `batch-market-cap` where allowed, else null. Two realizations: keyed FMP **REST client** for automation (needs `FMP_API_KEY` in `.env`) + the **in-session MCP pull** → `pipeline/seed/financials.json` fixture → persist to `Entity.financials` (keeps `emit` reproducible without live FMP). Guardrails: **deadband** (tiny mcap wiggle), **circuit breaker** (FMP errors), **separate horizons** (mcap daily vs revenue quarterly), revenue-vs-filing = `disclosed`. |
| **P2.3** | **Derive `layer` + reconcile** | category→layer map (foundry…enduser); assert acyclic stage order; log FMP-real vs seed-illustrative deltas (e.g. NVDA ~$4.9T real vs $3.6T seed) as a sanity check. |
| **P2.4** | **Emit + validate** | entities emit `financials` (+`basis`) + `layer` (still v1.2 — additive). Validator: ranges ≥0, `as_of` <1qtr → warn, `estimated` required where no ticker, disclosed-over-estimated enforced. |
| **P2.5** | **Flip the UI seed→real** *(the payoff)* | `runtime.ts`: Overview company supply-sankey + Chain Analysis SPLC read **real** `entities.financials`; weight toggle re-scales by real revenue (always) / market_cap (where present) / capacity; missing mcap → gray or fall back to revenue with a note. Chain-Analysis central card shows real market cap + `as_of` + DISCLOSED/EST. Kill seed `chain.entities` financials (keep seed supply **edges** until P3). Flag → "financials real (FMP); %COGS/%rev edges illustrative → P3". |
| **P2.6** | **Verify + commit** | toggle re-scales on real financials; validator green; 0 console errors. |

**Exit gate (adjusted for the FMP plan):** revenue real for all public tickers **and** toggle re-scales on real data (relaxed from "≥30 tickers ≤1-qtr fresh"); market_cap for the FMP-returned subset only. **P2 unlocks P3** — the `costOfRevenue` pulled here is a head-start on the EDGAR edge-%COGS work.

### P2 — shipped (2026-07-19)

The chain graph now carries **real financials**; the 5 steps landed as specced, with one build-time discovery that reshaped coverage.

- **The FMP constraint, sharpened.** The connected FMP plan gates by **ticker, not endpoint**: it serves a **fixed set of 8 mega-caps** (NVDA, TSM, INTC, AMD, MSFT, GOOGL, AMZN, META) — income-statement **and** market-cap both denied for every other symbol (the earlier "income-statement works reliably" read was NVDA-only luck). So real coverage is **8/29**; the other 21 backbone names carry `compute_seed` estimates, flagged. Decision (with the user): **ship 8 real + 21 estimated now**; widen later via **EDGAR** (free, US disclosed revenue, no market-cap/foreign — and the P3 connector) or **Finnhub** (free key, market-cap + foreign) or an FMP upgrade. `yfinance`/`Alpha Vantage`/`Twelve Data`/derive-from-`price×shares` are the other free options.
- **P2.0 migration** (`c1d2e3f4a5b6`) — `entity.financials` JSONB (per-metric `Field<T>`) + `entity.layer`; `data.schema.json` `money_field`/`entity_financials` $defs; reversible, validator green.
- **P2.1 backbone promotion** (`dcv promote-backbone`) — 29 curated chain companies into `entity`: 12 enriched, 17 net-new inserted (16 upstream + anthropic); merge-not-duplicate with `amazon→aws`, `digitalrealty→digital-realty` id-mapping; upstream category `other` + `layer`.
- **P2.2 FMP spine** (`build_financials_fixture.py` → `pipeline/seed/financials.json` → `dcv load-financials`) — 8 disclosed values pulled in-session via FMP MCP (market_cap from batch, revenue/COGS/NI from income-statement, filing-dated; TSM TWD→USD; `aws`=Amazon parent) baked into the committed fixture; loader with L9 guardrails (disclosed>estimated, market_cap deadband — idempotent). `clients/fmp.py` = the keyed REST automation path (needs `FMP_API_KEY`).
- **P2.4 emit + validate** — `entities[]` project `layer`/`ticker`/`financials`; validator `financials_integrity` (negative or no-ticker-disclosed → block) + freshness warns (market_cap 120d / revenue 400d).
- **P2.5 UI flip** — emit `_canonicalize_and_enrich` remaps the seed chain id-space to the real entities' + injects real financials ($B) + honest `estimated` flag. **Verified in-browser:** Chain Analysis shows Nvidia **$4.9T** (was $3.6T seed), TSMC $2.1T DISCLOSED, estimated names EST-badged; the **weight toggle re-scales the sankey on real data** (Revenue → Amazon $717B dominates, TSMC shrinks); 0 console errors.

**Still seed (→ P3):** chain **topology** + edge **%COGS/%revenue** + the Price Board. **Next: P3 (edge quantification)** — EDGAR/earnings → real `%COGS`/`%revenue` into `edge.value` (the fixture's `_cost_of_revenue` is a head-start), and widen financial coverage past the 8 mega-caps via EDGAR/Finnhub.

### P2 — hardened (adversarial-review follow-up, 2026-07-19)

A 3-agent adversarial review of the branch (the double-loop applied to our own build) found the misses split into two buckets — **execution failures against a theory that already forbade them** (loop mechanisms shipped as docstrings; a validator gate with holes) and **blind spots the loop theory never covered** (a UI badge bound to the wrong metric; a parent's financials on a segment node). Both were operationalized into the skills **and** fixed in code:

- **Process teeth** (`.claude/skills/`): `loop-design` gained a **conformance gate** (map each of the 5 lines to code or mark DEFERRED; measured value must be live; adversarially test the L6 gate; no unexercised code). Two new companion skills: **`provenance-rendering`** (a trust badge binds to the metric it describes) and **`entity-unit-of-analysis`** (a metric's reporting unit must match the node's).
- **Gate holes closed** (B1/B2/B3): `additionalProperties:false` (a `markt_cap` typo now rejects); `disclosed` must structurally carry value+as_of+source; freshness now covers estimates (180/500d) not just disclosed. Shipped with must-fail tests.
- **Badge fix** (C1/C3): the Chain-Analysis DISCLOSED/EST badge now binds to the **entity** metric for the active weight (Alphabet's real $4.2T no longer shows "EST") via **per-metric** `mc_estimated`/`rev_estimated`; seed edge % marked "· illustrative". Coverage count is now **live** from `meta.rollups.financials_coverage`, not hardcoded.
- **Unit-of-analysis** (C9): the `aws` node carries Amazon **consolidated** financials; now flagged `consolidated · incl. non-cloud` end-to-end (`money_field.unit` → chain `unit_note` → UI).
- **Loop claims made real or honest** (A1/C2): a real `CircuitBreaker` + HTTP-200-error-body detection in `clients/fmp.py`; a real **`ChangeLog` delta-log** in `load_financials`; the L9 **conformance table** in the TDD marks reconciliation-vs-filing **DEFERRED** rather than claiming it.
- **Tests**: `pipeline/tests/test_financials.py` (20) — deadband, gate must-fail, breaker, delta-log; full suite 46 green.

Standing rule going forward: **run the adversarial review as a per-phase gate**, not a one-off.

### P3 — edge quantification, vertical slice shipped (2026-07-19)

Made real, disclosed edge magnitudes flow from SEC filings into the SPLC — built under the new discipline (loop-design conformance gate + the two companion skills), grounded in an EDGAR probe first.

- **Grounding (P3.0):** filings **disclose customer-concentration %s** (TSMC 20-F FY25: 2nd customer 17%; Micron 10-K FY25: one customer 17%, CMBU) **but leave the counterparty unnamed**; supplier **%COGS is not disclosed** as a number. Decision (with the user): **disclosed magnitude + inferred counterparty, both flagged**.
- **What shipped:** `clients/edgar.py` (free, no key, UA-compliant; exercised live) → `seed/chain_edges.json` (2 disclosed edges, in-session-extracted, EDGAR-sourced) → `emit._quantify_edges` (every seed edge defaults to estimated + inferred link; disclosed magnitudes overridden) → UI shows the edge % with its **own** provenance (disclosed/est badge + inferred-link + `src↗`), distinct from the entity value badge. Live `meta.rollups.edge_coverage`. Contract: `chain_edge.value` gains `cogs_basis/rev_basis/link_basis/as_of/sources` + `additionalProperties:false`; `edge_integrity` gate (disclosed ⇒ source+as_of) with must-fail tests. **Verified in-browser** (central=TSMC → Nvidia 17% disclosed · inferred link · src↗); 55 tests green.

**L9+L2 conformance (P3):** Setpoint→`edge_integrity`+coverage · Measured→`meta.rollups.edge_coverage` [live] + `chain_quant.run` agreement stats · Error→`edge_integrity` + verifier `pct_confirmed`/`link_verdict` · Correction→EDGAR fixture override + **cross-vendor maker-checker** (`chain_quant`: Grok extract → Claude verify → confirmed/needs_review/drop) · Mechanisms→**maker-checker + requisite variety (Grok≠Claude)** · disclosed>estimated · per-metric bases · active-learning order · spend governor (L5) · CircuitBreaker (shared). **The Correction/L2 line is now implemented, not deferred.**

### P3 — chain_quant L2 automation built (2026-07-19)

The DEFERRED cross-vendor line is now real. `dcv/chain_quant.py`: `quantify()` runs the EDGAR excerpt through **Grok (extract customer-concentration + infer counterparty) → Claude (different vendor, web-search allowed; confirm the % is in the filing, assess the inference)**; a disclosed magnitude is accepted only if the verifier confirms it, `refute`→drop, `agree`→`confirmed`, `uncertain`→`needs_review` (HITL). `run()` = active-learning order + L5 spend cap → `seed/chain_edges_verified.json`, which `emit._load_chain_edges` merges **over** the manual `chain_edges.json` (verified wins). Import-time assert enforces extract≠verify vendor. Tests: 5 gating (mocked) + run-writes-fixture + emit-merge (62 total green).

**Proven live** (Micron): Grok extracted "one customer 17% CMBU"→Nvidia; Claude confirmed the 17% verbatim but marked the link **uncertain** ("filing never names the customer") → `needs_review` — **more rigorous than the single-analyst manual fixture** (which asserted Nvidia). Cost ≈ $0.33/supplier (Claude verify + one web search). **Not yet run into production data** — that's an operational step (`dcv chain-quant --limit N`); emit still serves the manual baseline until then.

**Run into production (2026-07-19):** ran `chain_quant` over 25 backbone names (2 runs, $1.28 + $0.68). Inspecting the first run **caught a real data-quality bug before merge** — the extractor pulled prior-year comparatives (TSMC 11%/12%, Micron 10%) as duplicate edges that would have *regressed* the clean current-year figures. Fixed (latest-fiscal-year prompt + per-`(from,to)` dedup). The fixed run cross-verified **micron→nvidia 17% [confirmed] conf 0.82**, which merges as an **upgrade** over the manual baseline (TSMC/CoreWeave stay manual). The verdict is surfaced end-to-end: `edge.value.review_status`/`link_confidence` → UI **"✓ verified"** / **"⚠ review"**. **Honest finding: the LLM extraction is NON-DETERMINISTIC** — run 1 covered TSMC+Micron+Dell (with year bugs), run 2 only Micron (clean); one run doesn't reliably cover all edges. So the automation is a **cross-verification overlay** on the curated baseline, not a wholesale replacement.

**Voting pass built + run (2026-07-19).** `chain_quant.quantify_voted` votes BOTH steps: extraction ×N (keep a customer only if proposed in ≥`min_votes` rounds; pct = modal value → drops prior-year comparatives) + verify ×N (majority-vote the verdict; strict-majority-AGREE → confirmed, majority-refute → drop, else needs_review). `dcv chain-quant --rounds N`. Cost ≈ N×(cheap Grok) + N×(Claude/consensus edge).

**THE finding (why this matters):** with full voting the verdict STABILIZED — and the stable answer is that **filing-inferred supplier→buyer links are `needs_review`, not confirmable.** micron→nvidia: extraction **3/3** (magnitude 17% rock-solid) but verify **agree 1/3** → `needs_review`, conf 0.24 ("the filing does NOT name the customer, only 'one customer'"). Filings disclose customer-concentration **MAGNITUDES but not IDENTITIES**, so a rigorous voted cross-vendor verifier correctly **refuses to confirm the counterparty** — the earlier single-verify "confirmed" was optimistic; voting corrects it. The UI now shows micron→nvidia as **⚠ review** (disclosed magnitude · inferred link · ⚠ review). This is the system calibrating trust honestly, not a failure.

**Implication:** **confirmed** edges need a **NAMED-customer source** — earnings-call transcripts (execs name customers), press/analyst reports, or the minority of filings that name customers. Filing concentration tables alone cap out at `needs_review`.

**Still open (P3 → full):** add an earnings-call / press **named-customer** source to lift links from needs_review → confirmed; wire a `needs_review` HITL queue; `%COGS` remains estimated (no disclosure source). **Next: P4 (compute & price layer)** or the named-customer source.

### P3 — named-customer identity resolver built (2026-07-20)

**Spike first (cost ≈ $0).** Before building the "named-customer source", a spike tested the assumption on our real edges. Finding — **the assumption was wrong, and the spike redirected the build**:
- FMP earnings-**transcript content is plan-gated** (metadata only); FMP `news` is accessible but market-noise, no supply-chain relationships.
- **The supplier's own transcript names ZERO customers** — Micron FY26-Q3 and TSMC FY26-Q2 both use only generic terms ("four very large customers", "leading AI customer", "our customers' customer"). Upstream suppliers are as tight-lipped on the *call* as in the *10-K*. **Mining the supplier's transcript is a dead end.**
- **But the identity is disclosed by the OTHER end of the edge, attributably and free:** the **buyer's 10-K** names the supplier in risk factors (*"NVIDIA utilizes foundries such as TSMC … to produce its semiconductor wafers"*), and the supplier's **first-party press** names the customer (Micron's own newsroom: *"HBM4 designed for NVIDIA Vera Rubin"*). Both our real edges clear the bar with these.

**The build — `dcv/chain_identity.py` (L2-identity), a source-flip, not a new connector.** For each disclosed-magnitude edge whose link is still inferred, it gathers identity evidence from the **buyer's 10-K** (`edgar.entity_mention` — the buyer naming its supplier near dependency language) + **first-party/trade press** (Grok Agent-Tools web search), then a **different-vendor maker-checker** (Grok extracts the namings → **Claude verifies, voted ×`rounds`**) decides: majority-confirm a real naming → `link_basis: named`; majority also confident on the **%-attribution** → `review_status: confirmed`; else `needs_review` (a named link we can't pin to the disclosed %). **The disclosed magnitude is never touched** — `pct_revenue`/`rev_basis` stay pinned to the supplier's filing; each source carries only the half it discloses (requisite-variety split). `link_basis: named` **requires** typed `link_sources[]` with a url (`validate_data.edge_integrity`, L6). Reuses infra we already run (EDGAR + discovery + cross-vendor pair) — near-zero new connector cost. `dcv chain-identity --limit N --budget $ --rounds N`.

**Fixtures/merge:** manual identity baseline `seed/chain_edges_identity.json` (hand-curated from the spike evidence) + automation output `seed/chain_edges_identity_auto.json`. `emit._load_chain_edges` now **field-merges** all four fixtures in precedence order (magnitude → identity), so the LINK half lands on the disclosed magnitude without either clobbering the other. `meta.rollups.edge_coverage` gains live `named`/`confirmed` counts; UI renders **"named link · who↗"** (the identity citation, distinct from the magnitude `src↗`). Tests: 7 resolver (mocked) + 4 validator named-rule + identity-merge (**80 total green**).

**Run into production (2026-07-20):** `dcv chain-identity --limit 8 --budget 3 --rounds 3` over the 3 disclosed edges, $2.37. The automation is **more rigorous than the hand baseline and split two distinct judgements** the baseline had conflated:
- **RELATIONSHIP named: 3/3 on all edges** — the source-flip works end-to-end. Nvidia's own FY2026 10-K names its suppliers verbatim (*"We utilize foundries, such as … TSMC … We purchase memory from SK Hynix …, Micron …, and Samsung"*); TSMC's + Micron's first-party press name Nvidia (TSMC's "500 millionth processor … manufactured by TSMC"; Micron's "24GB 8H HBM3E … part of NVIDIA H200"). CoreWeave↔Microsoft named in press + CoreWeave's S-1.
- **%-ATTRIBUTION** (is this named party THE disclosed-% customer?) is a *separate* gate: **coreweave→microsoft confirmed 3/3** (Microsoft is CoreWeave's dominant/anchor customer, tied to the 67% in its own S-1) → `confirmed`; **tsmc→nvidia and micron→nvidia attribution 0/3** → `needs_review` — TSMC (Apple, Nvidia, …) and Micron (Nvidia, AMD, …) each have several large customers, so the specific "one customer 17%" can't be pinned to Nvidia from public data even though the relationship is unambiguously named.

**Merged result:** `edge_coverage: {disclosed 3, estimated 36, named 3, confirmed 1}`. The auto fixture (richer real link_sources) supersedes the hand baseline per-field; the hand baseline was **reconciled to the rigorous verdicts** so a keyless checkout serves the honest answer, not the optimistic one. UI renders per edge: **"disclosed · named link · who↗ · src↗ · ✓ verified"** (CoreWeave→Microsoft) vs **"named link · who↗ · ⚠ review"** (TSMC/Micron→Nvidia) — `who↗` (identity) and `src↗` (magnitude) cited distinctly. Browser-verified, 0 console errors, 80 tests green.

**The refined finding:** the named-customer source is the **buyer's filing + supplier's first-party press** (NOT the supplier's transcript — that dead end was killed in the spike). It reliably **confirms the counterparty IDENTITY** for every edge, but **%-attribution to a specific counterparty only confirms for dominant-customer edges** (one anchor customer ≈ the disclosed %); multi-customer suppliers stay `needs_review` on the specific number. That is the honest ceiling of public disclosure, and the loop now reports it correctly.

**Still open:** run coverage wider (more buyer filings / press); a `needs_review` HITL queue to adjudicate the attribution cases; `%COGS` still estimated. **Next: P4 (compute & price layer).**

### P3.5 — retro & re-sequencing (2026-07-20)

A retro across P0–P3 (evidence: live `data.json` coverage audit + plan/code gap scan). **Thesis: we built world-class loop DEPTH on a graph that is still ~90% illustrative BREADTH** — 3 edges cross-vendor-verified while 36 are estimated; the whole chain topology / assets / prices / forwards are a 29-node seed sitting next to **174 real entities + 547 real edges the chain view doesn't use**. Close that breadth gap on the centerpiece *before* adding a new seed layer (P4 prices).

**A non-obvious finding that corrects P1's plan:** the 547 real edges are **DC-centric** (`operates 404 · develops 76 · serves 47 · powers 14 · provides_compute 4 · leases_to 2`) — they do NOT contain supplier→customer relationships. So "derive the chain graph from real entities+edges" (the deferred P1 item) is a misconception: the compute-chain topology (`supplies`/`customer_of` edges) must be **built** via `chain_quant`/`chain_identity` at scale, not flipped from what exists.

**Ranked gaps:**
- **Band 1 — credibility of the centerpiece (do before P4):** (1) financial spine capped at **8/29 mega-caps** (FMP ticker-gate) → widen via EDGAR + Finnhub, pull `capex`; (2) chain topology is seed & not derivable → build `supplies`/`customer_of` edges via the P3 automation at scale; (3) edges 3-deep + trust loop has no drain (`review_log` unconsumed, **U2 dispute is a pure stub**, 363/428 DCs `needs_review`) → coverage run + HITL queue + wire `disputeRecord→review_log→L2`.
- **Band 2 — real-data coverage holes:** (4) value-chain-critical DC fields near-empty (`tenant 0.5%`, `end_user 11%`, `operating_year 8%`, `cap_ex 9%`); (5) verify/approve loop unrun at scale (37/428 approved).
- **Band 3 — layers still 100% seed / not built:** (6) **P4** price/forwards/ratings (no aggregator/Kalshi/ClusterMAX modules exist); (7) **P5** assets + the bottleneck/FF lens (code absent, skills only); (8) **P6** permits/satellite/intl + **U4 alerts**.
- **Loop debt:** L9 reconciliation DEFERRED (fixture, no live re-pull); `supply_chain` sankey hand-figured; **`%COGS` has no disclosure source** (decision needed: earnings-mine vs explicit estimation method).

**Re-sequencing decision:** **Band 1 → Band 2 → then P4** (diverges from the earlier "Next: P4"). Convert the shipped centerpiece from *illustrative* to *defensible* before investing in a new seed layer.

### Band-1 #1 — financial spine widened via free SEC EDGAR ✅ SHIPPED (2026-07-20)

**The approach changed on contact with the facts:** there is **no Finnhub key** (`.env` carries only EIA/EXA/XAI/Anthropic, and no `FMP_API_KEY`), so the planned "EDGAR + Finnhub" became **EDGAR-only** — its free XBRL **companyfacts** API (no key) discloses annual **revenue + capex** for any US filer.

**Result: revenue disclosed 8 → 20 of 29; capex 0 → 11** (capex was schema-ready but unpulled). Micron $37.4B · Broadcom $63.9B · Dell $113.5B · Oracle $67.4B · Eaton $27.4B · SMCI $22.0B · Vertiv $10.2B · Equinix $9.2B · Amkor $6.7B · Digital Realty $6.1B · CoreWeave $5.1B · Nebius $1.3B — each with filing date, fiscal period and SEC source.

**What stays estimated (logged, not silently capped):** `market_cap` outside the FMP 8 — EDGAR carries **no price**, so market cap is honestly still 8/29 (widening it needs a price source: a Finnhub key, or price × EDGAR shares-outstanding, which we now fetch). Plus 4 foreign with no US CIK (Samsung, SK Hynix, Foxconn, Schneider), 4 private (Crusoe, OpenAI, Anthropic, xAI), and ASE/ASX where the **non-USD guard** refused a TWD-tagged figure.

**Build:** `clients/edgar.py::company_financials()` (priority concept lists — filers tag revenue differently across eras; annual-only FY+10-K/20-F filter; non-USD guard; `as_of` = FILING date; filing-folder source) · `build_edgar_financials.py` (targets **only currently-estimated** names, which structurally excludes the disclosed mega-caps — critically the `aws` node = Amazon **parent/segment** unit, where overlaying consolidated revenue would be the entity-unit-of-analysis bug) · `financials.py` (EDGAR overlay, disclosed-over-estimated, capex carried, delta-log extended, hardened so EDGAR can never overwrite **any** fixture-disclosed value).

**A measured-value fix this exposed:** `_fin_coverage` counted an entity disclosed only when **both** market_cap AND revenue were — so it still read `8` after the widening. Now reported **per metric** (market_cap / revenue / capex), because they have different sources and different coverage; a conflated count hid the correction and would mislabel whichever metric the weight toggle is showing (`provenance-rendering`). The UI banner reports per-metric too.

**Verified:** 87 tests green (+7); emit 0 errors; in-browser the badge binds per-metric — **Micron `DISCLOSED` under Revenue, `EST` under Market cap**, while Samsung/SK Hynix stay `EST` under both; 0 console errors. Commit `33af122`.

### Band-1 #2 — real chain topology discovered from buyer filings ✅ SHIPPED (2026-07-20)

`dcv/chain_topology.py` sweeps each SEC-filing chain company, extracts every **named supplier** from its own 10-K/20-F (Grok, voted), **cross-vendor confirms** the list (Claude), resolves names to backbone ids **locally** via the alias map (never an LLM's id guess), and emits `supplies` edges with `link_basis: named` + `link_sources`. `dcv chain-topology`.

**Direction:** `supplies` only — **no inverse `customer_of`**. The SPLC derives both views from one directed edge list (`to == central` → suppliers, `from == central` → customers), so an inverse edge would double-count the same relationship in the sankey.

**Result — 12 filing-evidenced edges across three tiers:** `nvidia ← tsmc, samsung, skhynix, micron, foxconn` · `broadcom ← tsmc, ase, foxconn, amkor` (**the packaging tier, entirely new**) · `amd ← tsmc, samsung` · `coreweave ← nvidia`. Chain graph **39 → 44 edges**: 7 seed edges **upgraded in place** (magnitudes preserved), 5 genuinely new relationships appended. `edge_coverage` gains **`topology_named` 12 / `topology_seed` 32** — the read-model now states which topology is *evidenced* vs *drawn*.

**Honest limits (logged, not silently capped):**
- Only **fabless semiconductor filers** name suppliers concretely. Cloud/software/systems filers (MSFT, GOOGL, AMZN, META, ORCL, DELL, EQIX, VRT…) use generic language → **0 edges**. Buyer-filing discovery lights up the upstream silicon tier and goes dark at the cloud tier.
- **8 discovered names are real chain participants missing from the 29-node backbone** — all semiconductor **equipment** (ASML, Tokyo Electron, Lam Research, Teradyne, Advantest) plus Taiwanese suppliers (All Ring Tech, Marketech, Grand Process). A concrete **backbone-expansion** candidate list, and a whole tier upstream of foundry we don't model.
- A discovered edge carries **no magnitude** — a fake `0` would render as "0%", so `pct_*` is simply absent (schema now allows it), the UI renders **"not quantified"**, and the flow sankey skips it (you can't size a flow you haven't quantified). It still appears in the SPLC: we know *who supplies whom*, not yet *how much*.

**Two real bugs, both caught by re-checking a filer that previously worked** (and both now locked by regression tests): (1) `supplier_excerpt` took N hits of the *first* pattern, so an incidental early "we purchase certain components" crowded out the real roll-call — **nvidia 6 → 0 edges**; now gathers candidates from all patterns and **ranks by company-name density**. (2) `discover()` joined extractor→verifier on the **raw string**, but the two models return different surface forms ("TSMC" vs "Taiwan Semiconductor Manufacturing Company Limited"), so the sets never intersected and every edge was dropped — **3 → 12 edges** once joined on the resolved backbone id.

**Verified:** 105 tests green (+18); emit 0 errors; browser-verified on Nvidia and Broadcom (`— · not quantified · named link who↗` for the new edges, sankey intact); 0 console errors. Commit `51852c9`.

### Band-1 #3 — the HITL queue + the U2 dispute drain ✅ SHIPPED (2026-07-20)

The retro's flagged open loop, confirmed live before the fix: **363/428 data centers in `needs_review`, `review_log` 0 rows**, and `runtime.ts::disputeRecord` only relabelling its own button. The reader was a sensor whose signal was thrown away.

**The wire.** `POST /api/review` (Next) appends the dispute to an append-only inbox → `dcv review-drain` writes a `review_log` row **and re-opens the record** (`approved → needs_review`, confidence de-rated, `last_verified` **voided**) so the next verify pass re-checks it → `dcv review` prints the queue → `dcv review-decide` records a human verdict. New module `dcv/review.py`; live measured value emitted at `meta.rollups.review_queue`.

**Deliberate boundary:** the web tier holds **no DB credentials** and cannot write a verdict — it appends a fact ("a reader disputed X"). That is also the **hysteresis** rule: a dispute can only *re-open* a record, never reject it, so one bad-faith dispute cannot destroy a verified value. Approve/reject live only at the CLI, where a verdict always carries a named reviewer into `review_log`. **Anti-windup:** repeats coalesce per `(record, field)`, a per-drain re-open cap, and a per-record/per-client rate limit on the endpoint — all **logged, never silent**. **Active learning:** queue ranked by *uncertainty × value* (`log1p`-damped so one 2 GW campus can't monopolise it), disputed records jumping the queue — but see the §5 correction: with only two distinct confidence values in the store the uncertainty term is constant, so today this ranks by **capacity**, and the dispute jump is the only part doing real prioritisation work.

**The L6 gate (`validate_data.py::review_queue_integrity`) — three ways the loop can silently go open, each with a must-pass and must-fail test:** (1) the emitted depth must equal the real `needs_review` count — a hardcoded number is the exact failure the conformance rule targets; (2) every `disputed_id` must resolve **and no longer read `approved`** — a dispute that leaves the record approved never re-opened it, i.e. the stub's behaviour dressed as a number; (3) `inbox_pending` must be 0 at publish. All three verified firing against real `data.json`.

**A freshness blind spot this exposed:** voiding `last_verified` was schema-invalid *and* revealed that `semantic()` treated a missing date as **exempt** — so the least-verified records were the only ones the staleness rule ignored. Absent now reads as maximally stale (`candidate` excepted).

**Three follow-on defects found by cleaning up the smoke-test data** (the cleanup was the test the loop needed):
1. **The de-rate compounded across drains.** Coalescing only dedupes *within* one drain, so repeat disputes ground a record 0.95 → 0.81 → 0.69 → … → the 0.2 floor and pinned it out of `approved` permanently. That defeats the hysteresis guarantee: one dispute couldn't destroy a value, but a persistent disputer could. Now a record with an **already-open** dispute logs the signal without moving the state again — proper hysteresis (the first input moves it; more of the same doesn't).
2. **An unfounded dispute was irreversible.** `DECISIONS` had no way to say "this dispute was wrong": `reject` rejects the *record* and `approve` asserts a verification nobody performed, so both exits were lies. Added **`dismiss`**, which restores `review_status`/`confidence`/`last_verified` from the audit trail (`review_log.before` of the *earliest* dispute in the open run — restoring from the latest would restore an already-de-rated value).
3. **`edit` wrongly resolved a dispute.** Last-decision-wins meant an edit cleared the disputed flag and stranded the de-rate with no undo. Only `approve`/`reject`/`dismiss` are terminal now; an edit leaves the dispute open.

**Cleanup verified:** all 3 smoke-tested records restored **exactly** (`aws-salem` → approved / 0.85 / 2026-07-13), 0 open disputes, queue back to 363. The `review_log` keeps all 7 rows — 3 disputes, 1 edit, 3 dismissals with notes saying they were wiring tests. The events happened; the trail records the action *and* its reversal rather than rewriting history.

### Band-1 #3b — targeted magnitudes on the named topology edges

Because chain_topology **named** the counterparty, quantification no longer has to guess it: `dcv chain-quant-named` asks the supplier's filing a *closed* question ("what share of your revenue is this named buyer?"). **Net new published magnitudes: zero** — and that is the finding, not a failure:

- **5 of 12 named edges are structurally out of EDGAR's reach** — Foxconn, Samsung, SK Hynix are foreign-listed and file no US annual report. Buyer-filing discovery found them; supplier-filing quantification cannot size them. A different source is required, not a better prompt.
- **A real double-count caught before it shipped:** TSMC's single unnamed *"one customer represented 19% of revenue"* attached to **nvidia, broadcom AND amd** on successive runs — one fact drawn as three flows. `_resolve_unnamed_conflicts` now enforces mutual exclusion: one unnamed disclosure describes one customer, so only the best-attributed edge survives, and **on a tie all claimants are dropped**. All three tied at zero confidence → none published. The run-to-run flip (Broadcom accepted one run, refuted the next) is itself the evidence that the attribution is a coin flip.
- **Misses are now auditable.** "The filing discloses nothing" and "we anchored on the wrong section" look identical from outside, and only the first is a fact about the company — Amkor's 10-K anchors on its **end-market distribution table**, so its miss is a *measurement gap*. Each miss records the reason plus the head of the excerpt actually read; the unattributed 19% is preserved in `targeted_unattributed` rather than deleted.

**Verified:** 138 tests green (+33); emit 0 errors; the L6 gate confirmed rejecting all three bad shapes on real data; end-to-end in-browser — filed a dispute from the drawer, drained it, saw the record re-open and jump the queue (priority 2.03 → 2.81); the failure path reports honestly (**"Nothing was queued"**, red, retry enabled) rather than the stub's green lie; 0 console errors across all 5 tabs.

**Next in Band 1:** Band 1 is closed. Band 2 = fill the sparse DC fields (tenant 0.5%, end_user 11%, operating_year 8%, cap_ex 9%) and work the 364-deep queue at scale; the **backbone expansion** to the discovered equipment tier is the highest-leverage prerequisite for both.

> ⛔ **Correction (2026-08-07) — "work the 364-deep queue at scale" is the wrong instruction, measured.** It reads the queue as one backlog wanting one scarce input (human hours), which is the same mistake as `tenant 0.5%` one line earlier in the same sentence. `dcv review --segments` classifies by *what would actually move each row*; over 401 data centers:
>
> | segment | rows | moved by |
> |---|---:|---|
> | `reverifiable` | 262 (65%) | **verify** spend — ≥2 domains, below auto-approve; 236 sized (19,579 MW) but only **4 carry a quote**, so it re-checks values, not values-plus-evidence |
> | `evidence_blocked` | 129 (32%) | **discovery** spend — <2 distinct domains, so `_gate` can *never* approve them however many humans look. **Zero carry a capacity value**: a PeeringDB listing with no number and no quote gives a reviewer nothing to decide |
> | `gate_satisfied` | 5 | a **decision** — already meets the gate, re-opened by a source-policy citation strip |
> | `below_floor` | 5 | investigate |
>
> **Human review is the right input for ~1% of the queue.** "At scale" would have bought throughput for the population that needs it least. `reverify --segment` spends against the same classifier so the money targets the population the report describes.
>
> A second trap sat under any threshold-based drain: **10 rows carried 0.93 confidence for a capacity the source policy had already withdrawn** (2,003 MW), which `_gate` reads as `approved`. Draining on confidence would have re-published exactly what decision #1 removed. `purge_sources` now surrenders the confidence with the value; `--cap-confidence` repaired the existing rows.

### Band-2 #1 — backbone expanded to the semiconductor-equipment tier ✅ SHIPPED (2026-07-20, `d800d5b`)

The 8 names Band-1 #2 logged as unresolved were promoted into a new **`equipment`** layer, taking the backbone **29 → 37** entities. The re-sweep then resolved **all 8** and grew named topology **12 → 21** edges with **zero lost** — the `loop-design` regression rule (compare counts, not just green tests) is what made "zero lost" a measured claim rather than a hope.

- **ASE's 20-F — not TSMC's — turned out to be the source of the equipment tier.** The assumption that the foundry names its own tool vendors was wrong; the OSAT does.
- **Deliberately absent:** Applied Materials and KLA. No swept filing named them, so adding them would be a **prior, not evidence** (`backbone.py`). The backbone only grows from something a filing said.
- The loop then surfaced **11 new** expansion candidates (Carl Zeiss SMT, GlobalFoundries, UMC, SPIL, King Yuan, Ablecom, Compuware, Flex, Plexus). That is the next iteration of a working loop, **not a gap**.
- Shipped alongside: `dcv backbone-reach` + `meta.rollups.backbone_reach` + gate 6, and the **550-day** staleness horizon (see §3b).

### Band-2 #2 — the value-chain role fields, repaired ⚠️ PARTLY DONE (2026-07-20, `e275e31` · `8a5f58f` · `494462c`)

**The framing in the line above was wrong.** "`tenant 0.5%`" was three different problems wearing one number:

1. **A denominator.** 255 of 432 DCs are **retail colo** — hundreds of customers, no single tenant. A scalar `tenant` column has nothing to hold, so the field's unit of analysis simply does not fit. Coverage now reports against the **eligible** base (177) with `not_applicable` first-class.
2. **Plumbing.** The extractor had always returned `tenant`; there was **no column**, so `persist` dropped it on write. `develops` was never mapped to `developer_id` either.
3. **A prompt gap.** The only mention of tenants in the extraction schema was a *prohibition*. Rule 8 now defines each role positively — while still saying where to **look**, never to guess: an unstated tenant is still null.

All three fixed; `developer` went **0% → 98%** resolved. What genuinely remains is **extraction volume** over the 177 eligible records — most carry only a PeeringDB source, so it needs discovery spend, not a bug fix. `operating_year` and `cap_ex` are untouched.

Two findings worth not re-learning: **a `tenant` that restates the developer is not a lease fact** (the TDLR permit feed names the applicant SPV, so 24 of 49 extracted tenants were this shape — hence `tenant_distinct_party` is reported separately), and **a role field holds an identity, never a description of one** (Hut 8 announced a 352 MW / $9.8bn lease to *"a high-investment-grade company"* — kept out of the column, retained in the store for audit).

### Band-2 #3 — the balancing gate, and a licensing violation found while building it 🟡 HARNESS SHIPPED (2026-07-20, `ba6ef03` · `24204d3`)

Building the gold set surfaced two things that outrank the queue drain itself:

- ⛔ **Confidence cannot gate the review queue** — see the §5 correction. Two distinct values across 364 records.
- ⛔ **The old gold set could not certify anything** — all 7 rows were `verified_by="demo_seed_bootstrap"`, the project's own demo seed. The new format requires per-field evidence (value + source + **verbatim quote**) and `certify()` refuses by default.
- 🚨 **Decision #1 was prose only, and had been violated.** `enrich.py` had extracted **27** facility capacities out of competitor databases; **104** tier-1 URLs had reached the published read-model. Now enforced as code at three points (`source_policy.py`, §3b). Remediation withdrew the **values**, not just the URLs — re-enrichment recovered 14 from permitted sources and **13 stay sizeless**, which is the honest cost of the constraint. Live proof the figures genuinely differ: `aligned-iad02` read **163 MW** from CleanView and **120 MW** re-derived from a permitted source.
- **Tier 2 ruled ALLOWED by the owner, 2026-07-20** (datacenters.com · cloudscene · baxtel · datacentermap — free, operator-submitted, closer in kind to PeeringDB). Recorded in code with the date. **Do not re-litigate.**

**Still open:** the gold set is a harness with no signed content, so the L6 balancing gate on the L4 flywheel is **open** — and only a human can close it. The queue stands at **399** `needs_review` vs 46 approved.

**Verified across Band 2:** 200 tests green; validator 0 errors (nine gates); `reverify` cleared the outage backlog (68 rows) and then a second pass over 31 single-sourced approvals persisted **+56** corroborating sources, **demoted 11**, and refused **3** competitor URLs the verifier's own web search surfaced — approved-rows-with-<2-sources went **31 → 0**.

**Next: Band 2 residue then Band 3** — extraction volume over the 177 eligible DCs, `operating_year`/`cap_ex`, the queue drain (blocked on a signed gold set), then P4 price/forward/rating · P5 upstream assets + bottleneck feedforward · P6 permits + international.

#### Band 2 residue — `news.published_date` is missing on 91% of items (found 2026-07-21, UI work)

**Measured:** of **258** real news items, only **24 (9.3%)** carry a `published_date`; **234** carry none. The dated ones span **2023-07 → 2026-07**, so the field is not merely stale — it is absent, and where present it is not bounded to recent coverage. By contrast **254 of 258 (98.4%)** link to at least one data center, so *linkage* is well populated and *time* is not.

**Why it matters beyond cosmetics:**
- **It silently blocks a whole class of UI.** Any chronological surface — a newsfeed ticker, "what changed this week", a freshness sort — cannot be built honestly. The Overview coverage rail added on 2026-07-21 had to be ordered by **relevance (project linkage)** instead of recency for exactly this reason, and it discloses the 24/258 split in its own footer rather than implying an ordering the data cannot support.
- **It undercuts a validation rule we already claim to enforce.** The regime lists a **freshness** check; for news, the field that check would read is null 91% of the time, so freshness is unenforceable on this dataset. That is the same failure shape as the pre-fix `tenant` column: a stated gate with nothing behind it.
- **The demo hid it.** `compute-terminal-demo.html` rendered a hardcoded 8-item `NEWS[]` seed where every item had a perfect date, so the feed *looked* complete. Same seed-masks-reality pattern as `PROJECTS[]`. Both seeds are now removed from that page.

**Fix:** capture the publish date at ingest in Phase B / the feed connectors — it is almost always present in source page metadata (`<meta property="article:published_time">`, JSON-LD `datePublished`, or the feed item's own `pubDate`). Backfill existing rows from the stored source URL. Then: report `news_date_coverage` in `meta.rollups` as a **live measured value** (not a claim), and only once it is high enough to be meaningful, allow a recency-ordered surface. Per `loop-design`, the rollup comes first — a chronological view built before the measurement is the thing that just went wrong.

**Guardrail:** do **not** default a missing date to ingest date or today. That manufactures recency and would make a 2023 article read as this week's news — worse than admitting the absence.

---

## 7b. Loop-engineering conformance — every phase is a controller, not ETL

Each phase must satisfy the `loop-design` **5-line contract** (setpoint · measured · error · correction · mechanism) and carry the guardrails from `docs/loop-mechanisms-catalog.md` §7. The inventory (§2) already assigns an *owning* loop per data class; this section certifies the **phases** as controllers and makes the **cross-cutting loops** explicit.

### Cross-cutting loops — these run in EVERY phase (the outer/double loop)
No phase is "done and forgotten"; each keeps running under three loops that span all of P0–P6:
- **L6 · eval / balancing gate** — every phase extends `validate_data.py` + the gold set; nothing ships without its validation. This is the balancing loop that protects every reinforcing flywheel from error cascade. **P0 stands this gate up before any data phase.**
- **L5 · cost governor + active learning + anti-windup** — every phase honors the daily spend cap (`clients/spend.py`, $25/day), routes expensive work (LLM extract/verify, price polling) to **highest uncertainty × value**, runs **delta-only**, and backpressures under bursts.
- **L4 · flywheel / double-loop** — every phase's human corrections + resolved conflicts feed back to improve the *rules* (prompts, source-trust weights, classifiers, disturbance models), so accuracy rises while cost/verified-fact falls.
- **U1/U2/U3 · user loops** — the shipped UI wires the reader into L2: a dispute is a verification trigger + a training example, not a support ticket.

### Per-phase loop contract
| Phase | Setpoint | Measured | Error → Correction | Mechanism(s) | Guardrail (§7 caveat) |
|---|---|---|---|---|---|
| **P0 · Contract** | validator green on full v1.2; 0 render errors | validator pass/fail; schema/referential error count | any violation → fix schema/emit/port, re-gate | **L6 balancing gate** (the reference gate all later phases publish through) | gate wired in CI *before* P1 — it protects every later reinforcing loop |
| **P1 · Tier-B** | 0 seeded sankey rows (fully derived); operator/tenant persisted; status_history on tracked rows | % derived vs seed; **entity-resolution merge precision** (sampled); status coverage | residual seed / low-conf merge → derive from graph; uncertain merge → **HITL** | L1 derive · **requisite variety** (alias+LLM entity res) · **deadband/hysteresis** (status) | entity resolution is a self-improving rule → **balancing gate + HITL on uncertain merges** (don't let auto-merge drift) |
| **P2 · Financials (L9)** | every key entity market_cap/rev/capex ≤1-qtr fresh; reconciliation gap < tol | coverage %; staleness; **gap vs filing** | missing/stale/divergent → re-pull FMP, **reconcile vs EDGAR**, review | **L9** · reconciliation vs authoritative anchor · deadband · **circuit breaker** (FMP) | **delays**: market_cap daily vs revenue/capex quarterly — separate horizons |
| **P3 · Edge quant (L9+L2)** | top-N edges (by value) have {amount, basis, disclosed}; disclosed-over-estimate holds | quant rate; disclosed/est ratio; cross-verify agreement; gold-set edge precision | unquantified/conflict → extract, **cross-verify (diff-vendor)**, disclosed wins; low-conf → HITL | **maker-checker + requisite variety (L2)** · **active learning** (highest market_cap edges first) · **balancing gate** (disclosed-wins enforced) | **reinforcing-without-balancing**: gate the extraction flywheel on the gold set; never train on unverified extractions |
| **P4 · Price/forward/rating (L7/L8)** | price freshness <24h + ≥2-aggregator agreement; every priced provider rated ≤qtr | price age; grid fill %; **cross-aggregator dispersion**; rating coverage | stale/missing/anomaly → re-poll, rotate feed, **anomaly emits (not suppressed)**, degrade→circuit-break | **deadband + anomaly + requisite variety + anti-windup** (L7) · **hysteresis** on tier (L8) · `modeled` vs `curve` (Kalshi) | **delays**: price fast vs rating slow — separate horizons; deadband = cost *and* alert quality |
| **P5 · Assets + bottleneck (FF)** | fab/HBM asset set enumerated; per-region power lead-time from real ISO/EIA; **FF hit-rate SLO** | coverage; lead-time vs actual; **did predicted squeezes materialize** | gaps/false-squeeze → add sources, recalibrate; **FF output = candidate (amber) until L2 confirms** | **feedforward** (leading signal) · **PID-D** (queue rate-of-change) · candidate-then-verify | **feedforward needs a calibrated disturbance model** — low-conf until confirmed; **no silent coverage caps** (log dropped) |
| **P6 · Edge + intl** | unannounced projects pre-news; 1 non-US region; permits→funnel | lead-time vs news; intl coverage | missed signal/gap → add permit/satellite/Epoch/PitchBook; **feedforward from permits** | **feedforward** (permits/satellite) · **requisite variety** (higher-variety intl → more source types + HITL) · circuit breaker | requisite variety **proportional to uncertainty** (don't over-source); permit **ToS/robots** compliance |

### The "build-first seven" (catalog §5) — all present, mapped to phases
1. **MAPE-K + flywheel** → L1/L4, the spine of every phase. 2. **Maker-checker + requisite variety** → P3 (edges), P4 (price cross-aggregator), P2 (FMP+filing), P1 (entity res). 3. **Active learning** → P3 (top-N first) + L5 everywhere. 4. **Deadband + hysteresis** → P1 (status), P2 (market_cap), P4 (price). 5. **Feedforward** → P5 (power/bottleneck), P6 (permits). 6. **Balancing gate on the reinforcing flywheel** → P0 stands it up; every self-improving-rule phase (P1/P3/P4/P5) is gated by it. 7. **Anti-windup / backpressure** → L5, esp. P4 (price bursts), P3 (news bursts).

**Conformance rule for the build:** before implementing any phase, run the `loop-design` skill on it and record the filled 5-line contract in the stage's module docstring + the TDD. A phase whose PR adds a source without a setpoint/error/correction and a validator extension does not merge.

### 7c. User/UI-loop contracts (U1–U4) — the outer loop closes here

The front-end isn't a passive renderer; it runs the analyst's decision loop **and** feeds the machine loops (the *double loop*, `docs/loop-engineering-value-chain-proposal.md` §6). Same 5-line discipline applies — and a UX "correction" that goes nowhere (a dispute button that only changes its own label) is **open-loop**, the exact failure `loop-design` forbids for connectors.

| User loop · feeds | Setpoint | Measured | Error → Correction | Mechanism · Guardrail | In demo |
|---|---|---|---|---|---|
| **U1 · OODA comprehension** → drives all | analyst reaches decision-grade understanding of their JTBD with minimal friction | time-to-insight; decision-coverage (% JTBD answered in-app); altitude transitions | dead-end / missing view / too-slow → progressive disclosure, surface the next-altitude affordance, weight toggle reframes in place | **OODA** (Observe flow → Orient chain/geo/market-cap → Decide → Act) + progressive disclosure. *Guardrail:* don't overload the front door; every view must advance a stage ("does it move the decision?") | ✅ nav + weight toggle; ⚠️ explicit **Decide (compare tray)** + **Act (export)** still thin |
| **U2 · trust / dispute** → **L2 + L4** | every value inspectable (source·confidence·as_of·disclosed) **and** disputable; trust calibrated to real confidence | dispute rate/field; resolution latency; **do user disputes agree with cross-verify?** | unsourced/undisputable value, or a dispute that routes nowhere → provenance on every value; a dispute **triggers L2 re-verify + a `review_log` training example** | **human-in-the-loop / negative feedback** (user = sensor into L2). *Guardrail:* the dispute MUST be wired — a stub is open-loop; weight by user reliability + **hysteresis** (one bad-faith dispute can't flip a confirmed value); rate-limit (anti-windup) | ✅ **CLOSED (Band-1 #3)** — provenance shown; dispute POSTs to `/api/review` → `review_log` + record re-opened for L2; hysteresis (dispute re-opens, never rejects), coalescing + rate-limit (anti-windup), queue ranked by uncertainty × value; L6 gate blocks publish if a dispute routed nowhere. *Still open:* weighting by user reliability (needs a track record) |
| **U3 · chain navigation** → graph quality | from ANY node (org/asset/SKU/region/project/price/news) traverse to the adjacent altitude ≤1 click, both directions, every hop sourced; **no dead ends** | pivot coverage (% nodes that link); time-to-trace (chip→power / project→end-user); dead-end rate | dead-end / broken pivot / unsourced hop → make every node a link; drawer deep-links; breadcrumb "you are here" | **chain navigation** (aggregate→entity→project→geography, both ways). *Guardrail:* no dead ends; a pivot to an unsourced claim is worse than none; keep context on pivot | ✅ **best-realized loop** (click-to-drill everywhere) |
| **U4 · alert / personalization** → **change feed (L3) + L4** | user watches ("H200 spot < $X in ERCOT", ">500MW DC w/ neocloud tenant", "CoWoS→red") fire within one refresh of a real crossing, zero noise | **alert precision** (% acted on); event→alert latency; noise rate; which watches kept/muted | missed crossing / noise / stale → fire off the **change feed** on material crossings; **deadband** suppresses sub-threshold; learn from mutes/acts (personalization→L4) | **deadband** + change feed + **active-learning personalization** (what users watch informs what to verify/refresh first). *Guardrail:* deadband is mandatory (alert fatigue kills the loop); personalize without filter-bubbling (still surface material out-of-watch changes) | 🔴 **not in current demo** (v1 had an alert bar, dropped in reunify) — build with the price/change-feed layer (P3–P4) |

**The double loop (why this matters):** U2 and U4 are the wires that make the system a *double* loop — the reader's disputes become verification triggers (U2→L2) and training examples (U2/U4→L4), and what users watch prioritizes what the machine refreshes first (U4→L3/L4). Without them the terminal is a read-only dashboard; with them it self-corrects and personalizes as it's used. **U2 is now real (Band-1 #3):** the `disputeRecord` stub became a `/api/review` POST → `review_log` write → record re-opened for L2 re-verification, with a visible HITL queue to drain it. **U4 alerts remain the load-bearing gap** (P3–P4, needs the change feed + price layer). U1 and U3 are implemented (U3 is the best-realized loop); U1's explicit *Decide/Act* affordances (compare tray, export) are the thin spot.

---

## 8. Open decisions (resolve during P0–P2)
1. **ClusterMAX ToS** — mirror tiers with attribution vs link-out only.
2. **Paid upstream data** (TrendForce/SemiAnalysis) vs coarse manually-maintained bottleneck flags in v1.
3. **Kalshi API** access + which SKUs have live curves vs `modeled`.
4. ~~**Entity resolution** for operator/tenant — alias table now, embedding match later.~~ ✅ **RESOLVED Band 2 #2** — deterministic local alias table (`dc_roles.py`), word-boundary longest-match, ties resolve to NEITHER and are logged. Embedding match is not needed and would be worse here: resolution must be **deterministic and testable**, because a model guessing an id is a weaker claim than a filing naming a company.
5. **Confidence formula** — fixed weights vs learned calibration on the gold set. ⚠️ **No longer merely open — the current formula is known not to discriminate.** It emits exactly two values across the whole queue (0.72 news / 0.75 PeeringDB), so it is a per-ingest-path constant, not a signal. Any fix must derive confidence from something that varies per record (corroboration count, source-trust spread, extraction agreement). Note the dependency: calibrating on the gold set is blocked until the gold set has **human-signed** content.
7. **Tier-2 source admissibility** (free operator-submitted directories) — ✅ **RULED 2026-07-20 by the owner: allowed**, extended 2026-07-21 (seven domains the fail-closed check surfaced) and **2026-08-07 (`aterio.io`)**. Recorded in `source_policy.py` with dates. Do not re-litigate. Exposure is tracked live at `rollups.source_policy`. ⚠️ Still open: the fail-closed guard matches directory-shaped **hostnames**, so a directory whose tell is in the URL *path* (`aterio.io/us-data-centers/`) passes silently. Widening it to read paths would also catch trade press and operators' own sites, so it is pinned by a test and left deliberately open.
6. **Serving** — static `/public/data.json` (now) vs `/api/data` route + change feed (P0/P3, when writes/history matter).

*Companions: `docs/PRD-compute-terminal.md` (product) · `docs/TDD-compute-terminal.md` (loops/schema) · `docs/compute-terminal-findings-and-options.md` (decisions) · `docs/data-schema-and-validation-spec.md` (`Field<T>`/validation) · `docs/build-handoff-spec.md` (stack) · `compute-terminal-demo.html` (the UI contract this data plan serves).*

# CleanView (cleanview.co) — Reverse-Engineering Teardown

*Prepared for the "dataCenterView" project — how CleanView is built, what data it uses, and where it comes from. Based on a full walkthrough of the live site and its public API documentation (July 2026).*

---

## 1. What CleanView actually is

A **U.S.-only market-intelligence product** that tracks power infrastructure and data-center development "from the first permit to final completion." It is a small, bootstrapped team in Colorado, founded by Michael Thomas (of the *Distilled* clean-energy newsletter). Its data has been cited by NYT, WSJ, FT, Washington Post, Reuters, and Canary Media.

Three things it sells:
1. **A web platform** (map + tables + filters) covering data centers and power projects (solar, wind, battery, natural gas, nuclear, coal, hydro, geothermal).
2. **Data downloads + an API** for teams that want the raw records.
3. **Original research reports** and a **newsletter** as top-of-funnel marketing.

> **Key constraint for us:** CleanView is **United States only** (all 50 states, ISO/RTO regions). Your goal is *worldwide* data centers — CleanView is an excellent blueprint for the U.S. layer but does **not** solve international coverage. See §7.

---

## 2. Site map (every page reviewed)

**Marketing**
- `/` — homepage (live map of data centers / planned solar / planned batteries)
- `/pricing` · `/about` · `/contact` · `/demo`
- `/login` · `/signup` (gated app)

**Free trackers** (public, SEO + lead-gen — these are the scrapeable pages)
- `/data-centers` → `/data-centers/us` → `/data-centers/{state}` (e.g. `/data-centers/virginia`)
- `/power-projects/solar-farms`
- `/power-projects/wind-farms`
- `/power-projects/battery-storage-projects`
- `/power-projects/natural-gas-power-plants`
- `/power-projects/nuclear-power-plants`
- `/power-projects/coal-power-plants`
- `/power-projects/hydro-power-plants`
- `/power-projects/geothermal-power-plants`
- `/power-projects/developers`

**Research**
- `/reports/{slug}` — e.g. `/reports/fermi`, `/reports/google-power-strategy`, `/reports/behind-the-meter-data-centers`

**Off-domain**
- `newsletter.cleanview.co` — email newsletter
- `docs.cleanview.co` — API docs (Mintlify)
- `api.cleanview.co/api/v1` — the API itself

Each free-tracker state page shows summary stats (total / operating / planned counts, operating + planned MW, unique developers, unique counties), a MapTiler map, and "Largest Operating / Largest Planned" project cards. Every project card links to an individual project detail page.

---

## 3. Technology stack (from network + page inspection)

| Layer | What they use | Evidence |
|---|---|---|
| Framework | **Next.js** (App Router, React Server Components, Turbopack) | `_next/static`, `?_rsc=` request params |
| Hosting | **Vercel** | `dpl_…` deployment IDs on assets |
| Maps | **MapTiler** (streets-v2 style + v3 vector tiles) over **OpenStreetMap** | `api.maptiler.com`, "© MapTiler © OpenStreetMap" |
| CRM / forms / tracking | **HubSpot** (portal `46648266`) | `track.hubspot.com`, `hscollectedforms`, `hs-scripts` |
| Product analytics | **Mixpanel** | `api-js.mixpanel.com/track` |
| API docs | **Mintlify** | footer "built and hosted on Mintlify" |
| Newsletter | Separate subdomain (hosted newsletter platform) | `newsletter.cleanview.co` |

Design implication: the project data is **server-rendered into the page** (RSC), so there is no obvious open `/api/…` JSON call on the public site — the data is baked into the HTML/RSC payload. The real programmatic surface is the **paid, API-key-gated** `api.cleanview.co`.

---

## 4. The data sources — what CleanView aggregates (the important part)

CleanView's own API docs and About page name their upstream sources explicitly. **Almost all of it is public, free government / grid-operator data**, plus a manually-curated data-center layer.

### A. EIA-860M — operating & planned generators
- Source: **U.S. Energy Information Administration**, *Preliminary Monthly Electric Generator Inventory (Form EIA-860M)* — free, public, updated **monthly**.
- Covers every utility-scale generator: solar, wind, batteries, natural gas, coal, hydro, geothermal, nuclear.
- CleanView's dataset counts by energy source: NG 9,742 · SUN 9,000 · DFO 5,517 · WAT (hydro) 4,598 · LFG 1,983 · WND 1,955 · MWH (battery) 1,435 · coal ~1,300 · GEO 341.
- Fields exposed: `plant_id, plant_name, state, county, latitude, longitude, entity_name, nameplate_capacity_mw, nameplate_energy_capacity_mwh, energy_source_code, technology, prime_mover_code, status, operating_date, retirement_date, balancing_authority_code, sector, developer`.

### B. Interconnection queues — the pipeline of *proposed* projects
- Source: the **7 major grid operators (ISOs/RTOs)**, each of which publishes its interconnection queue:

| ISO/RTO | Region | Projects | Top tech |
|---|---|---|---|
| CAISO | CA, NV, AZ | 3,000+ | Solar, Battery, Wind |
| ERCOT | TX | 2,200+ | Solar, Wind, Hybrid |
| PJM | 13 Mid-Atlantic states | 1,800+ | Solar, Gas, Wind |
| MISO | 15 Midwest/South states | 1,500+ | Wind, Solar, Gas |
| SPP | 8 Central states | 800+ | Wind, Solar, Battery |
| NYISO | NY | 400+ | Solar, Wind, Battery |
| ISO-NE | 6 New England states | 300+ | Solar, Wind, Battery |

- Fields exposed: `iso, queue_id, project_name, capacity_mw, technology, status, state, county` (+ IA-signed flag, operating date on some).

### C. Data centers — the manually-curated layer
This is CleanView's real proprietary work. **There is no single public feed for data centers** — they build it themselves:
- **Method (stated on /about):** "we use everything from **permit documents** to **satellite imagery**" to find projects, "including projects that haven't been publicly announced."
- **Sourcing revealed by the API schema:** each record carries `source_1`, `source_2`, `source_3` **URLs** — the example records cite `datacenterdynamics.com` and company sites (`corescientific.com`). So the pipeline is: monitor trade press + press releases + company sites + local permit filings → extract project → cross-verify with 2–3 sources → **manual "audit-approved" flag** → publish.
- Fields per data center: `project_name, developer, tenant, end_user, status (Planned/Operating/Cancelled), operating_year, capacity_mw, land_acres, building_square_footage, cap_ex (USD), county, state, latitude, longitude, btm_generation (behind-the-meter flag), source_1..3`.
- Current size: ~**1,176–2,950 records** (docs example says 1,176 audit-approved; the live free tracker showed 2,950 total / 1,208 operating / 1,703 planned / 434,568 MW). Concentrated in VA, TX, GA, AZ, CA.

### D. Developers & Contacts — enrichment layers
- **Developers** (~580 power + ~500 data-center, 1,000+ total): derived by mapping every project to its developer company, then ranking by project count / pipeline.
- **Contacts** (~25,000): decision-makers with name, title, company, city/state, **email + LinkedIn** — a sales/BD enrichment layer (title + company + LinkedIn pattern suggests LinkedIn / company-site scraping + email pattern inference).

### E. Satellite imagery — verification, not a feed
Used editorially (e.g., the Fermi report: "using satellite imagery, we found the data center is at least a year behind schedule"). It's how they verify construction progress, not a bulk dataset.

---

## 5. The public API surface (for reference)

- **Base URL:** `https://api.cleanview.co/api/v1`
- **Auth:** API key in `x-api-key` header. Beta, manual approval, paid ("Custom" tier).
- **OpenAPI spec:** `https://docs.cleanview.co/api-reference/openapi.json`
- **LLM index:** `https://docs.cleanview.co/llms.txt`

| Endpoint | Returns |
|---|---|
| `GET /data-centers` | All audit-approved data centers (single JSON blob, no pagination, ~500KB+) |
| `GET /eia-860m` | EIA generator records — filters: `state, energy_source, balancing_authority, status, start_year, end_year, limit, offset` |
| `GET /interconnection/{iso}` | Queue for `caiso/ercot/pjm/miso/spp/nyiso/iso-ne` — filters: `state, technology, status, min_capacity, max_capacity, limit(50–5000), offset` |
| `GET /projects` | "Unified" view merging EIA-860M + queue sources |

---

## 6. How CleanView is built, in one sentence

> Take **free public data** (EIA-860M + 7 ISO interconnection queues), **merge/de-dupe** it into a unified project database, **enrich** it with developer/contact mappings, add a **hand-curated data-center layer** sourced from trade press + permits + satellite + company sites (each record human-verified), and wrap it in a **Next.js map/table UI** with **free SEO tracker pages** as the funnel and a **paid platform/API** as the product.

---

## 7. Implications for *your* worldwide data-center dashboard

The reusable playbook (U.S.):
- **Generators / power context:** EIA-860M (free) + ISO queues (free) — directly replicable.
- **Data centers:** no free feed exists; you must build a curated pipeline from news + press releases + permits + company sites, exactly like CleanView. The `source_1/2/3` pattern is the model.

The gap CleanView does **not** cover — **worldwide** — needs different sources:
- **Global inventories:** Data Center Map (datacentermap.com), Baxtel, Cloudscene, PeeringDB (interconnection facilities), Open Data Center map projects, Uptime Institute.
- **Regional grid/permit data:** EU (ENTSO-E transparency platform), UK (National Grid ESO), and per-country regulators — the international equivalent of EIA + ISO queues.
- **News/reports layer (global):** DataCenterDynamics, Data Center Frontier, trade press, hyperscaler press releases, planning-permission portals per jurisdiction.
- **Satellite / construction verification:** same approach, global providers.

**Recommendation:** treat CleanView as the reference architecture for a *U.S.* layer you can largely automate from free APIs, and plan a separate *international* ingestion layer (inventory sites + regional grid data + a global news scraper) since no single worldwide "EIA for data centers" exists.

---

*Sources: live inspection of cleanview.co (home, /data-centers, /data-centers/virginia, /about, /pricing) and docs.cleanview.co (API reference, llms.txt, endpoint schemas for data-centers, eia-860m, interconnection).*

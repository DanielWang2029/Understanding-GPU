# Loop Mechanisms Catalog

*The specific feedback/control mechanisms inside "loop engineering," defined and mapped to dataCenterView. Companion to `docs/loop-engineering-value-chain-proposal.md` (which is the "why/what"; this is the "which mechanisms, precisely"). Research-backed, July 2026.*

---

## 0. Framing

"Loop engineering" isn't one theory — it's a toolkit of feedback/control **mechanisms** drawn from five fields:

1. **Control theory** — PID, feedforward, deadband, hysteresis, anti-windup.
2. **Cybernetics** (Wiener, Ashby) — negative/positive feedback, homeostasis, requisite variety.
3. **System dynamics** (Forrester, Senge) — reinforcing/balancing loops, stocks & flows, delays.
4. **Autonomic computing** — MAPE-K self-management.
5. **ML-ops** — data flywheels, active learning, human-in-the-loop.

These are now explicitly combined in current work — e.g., *Adaptive Data Flywheel: Applying MAPE Control Loops to AI Agent Improvement* (arXiv 2510.27051, 2025) and *Agent-in-the-Loop* (arXiv 2510.06674). The sections below catalog each mechanism and map it to a concrete job in this project; §5 is the shortlist to build first.

Reference frame: **L1–L6** = the technical loops and **U1–U4** = the user loops defined in the proposal.

---

## 1. Control-theory mechanisms

| Mechanism | What it is | Use in dataCenterView |
|---|---|---|
| **Setpoint / reference** | The target value the loop drives toward | Per-state coverage & precision targets (e.g. TX ≥0.90 precision); the freshness horizon |
| **Error signal** | setpoint − measured | Gap between target coverage and measured coverage; conflict rate vs tolerance |
| **Negative feedback** | Suppresses deviation → stability | Cross-vendor disagreement *lowers* confidence and triggers re-search (L2) |
| **Positive feedback** | Amplifies deviation → growth | The flywheel: good data → better prompts → more good data (must be gated — §7) |
| **Gain** | How aggressively to correct per unit error | How many extra sources/searches to spawn when a field is contested |
| **Feedforward** | Correct for a *measurable disturbance before* it hits output | Permit filings + ISO-queue entries are leading indicators — pre-verify a project *before* the news breaks (Phase A BTM signal → Phase B). A freshness edge over reactive scraping |
| **PID (P/I/D)** | Correct on present error (P), accumulated error (I), rate of change (D) | P: current coverage gap; I: persistent backlog of unverified records; D: a sudden spike in new announcements → scale discovery up early |
| **Deadband** | A band around setpoint where **no** correction fires | Don't re-verify or emit a "change" for immaterial edits (capacity 900→905 MW). Kills wasted spend + alert fatigue (L3, U4) |
| **Hysteresis** | Different up vs down thresholds | A project flips to "operating" only on strong evidence, and won't flip back on one weak contrary source → stops status flapping |
| **Anti-windup / saturation clamp** | Stop the integral (backlog) exploding when the actuator is maxed | Cap the candidate queue during a news burst or source outage so catch-up doesn't cause a runaway spend spike (L5) |
| **Damping** | Tuning to avoid overshoot/oscillation | Rate-limit re-verification so the DB doesn't thrash between conflicting sources |

---

## 2. Cybernetics mechanisms

| Mechanism | What it is | Use in dataCenterView |
|---|---|---|
| **Requisite variety (Ashby)** ★ | "Only variety can absorb variety" — a controller needs at least as many responses as the disturbances it faces | The environment is high-variety (7 ISO formats, thousands of publishers, rebrands, paywalls, tangled ownership). So the *controller* must match it: **diverse models** (extractor ≠ verifier), **multiple source types**, and **human escalation** for the residual. This is the theoretical justification for model diversity + multi-source + HITL |
| **Homeostasis** | Maintain an internal equilibrium despite external shocks | The DB holds a stable "verified truth" state even as sources churn, go down, or contradict |
| **Ultrastability** | Higher-order adaptation when first-order regulation fails | When simple re-query can't resolve a conflict, escalate to a structural change (add a source, change the prompt) — i.e., double-loop learning |

★ Requisite variety is the most under-used idea and the strongest argument for the architecture: don't fight source chaos with one bigger model — match its variety with a *portfolio* of models, sources, and human review.

---

## 3. System-dynamics mechanisms

| Mechanism | What it is | Use in dataCenterView |
|---|---|---|
| **Balancing (goal-seeking) loop** | Self-corrects toward a target | Every quality gate: coverage/precision loops that pull the system back to setpoint |
| **Reinforcing loop** | Compounding growth (or collapse) | The data flywheel (good) — but unchecked it can also compound *errors* (§7) |
| **Stocks & flows** | Accumulations vs rates | Stock = verified records; flows = discovery-in, verification-through, decay-to-stale. Manage the *rates*, not just the stock |
| **Delays** | Lags that cause overshoot/oscillation | Freshness lag: if re-verification is slower than a project's real-world change rate, the DB oscillates stale↔wrong. Fix with volatility-adaptive polling |

---

## 4. Autonomic & ML-ops mechanisms

| Mechanism | What it is | Use in dataCenterView |
|---|---|---|
| **MAPE-K** | Monitor → Analyze → Plan → Execute over shared Knowledge | The ingestion controller's skeleton (L1) |
| **Data flywheel** | Self-reinforcing loop where errors/interactions fuel improvement | L4: human corrections + resolved conflicts improve prompts, source-trust weights, provider classification |
| **Active learning (uncertainty sampling)** ★ | The model picks the *highest-uncertainty* items for a human/verifier to label | The precise mechanism for L5: spend expensive verification on the **lowest-confidence, highest-value** records — not uniformly. Cost down, quality up |
| **Human-in-the-loop / weak supervision** | Embed expert judgment at monitor/annotate/evaluate | U2 dispute control feeds review; reviewer decisions become training/eval data |
| **OODA (Boyd)** | Observe–Orient–Decide–Act decision loop | The user's comprehension loop (U1) |
| **Single vs double vs triple-loop learning (Argyris)** | Fix the action / fix the assumptions / fix the goals | Single: correct a value. Double: change the source list or prompt. Triple: revisit what "verified" should even mean |
| **SRE control patterns** | Circuit breaker · backpressure · rate limit · error budget | Circuit-break a source that starts returning garbage; backpressure the queue; an "error budget" for how many auto-approved records may later be corrected before the gate tightens |

★ Active learning is the highest-ROI mechanism you're not yet using explicitly: it turns "verify everything" into "verify what we're least sure about," which is both cheaper and more accurate.

---

## 5. The highest-leverage seven (build these first)

1. **MAPE-K + data flywheel** — the spine; makes the pipeline self-managing and self-improving.
2. **Negative-feedback maker-checker + requisite variety** — diverse extractor/verifier + multi-source; the trust engine.
3. **Active learning (uncertainty sampling)** — route verification budget to lowest-confidence records; biggest cost×quality win.
4. **Deadband + hysteresis** — re-verify / emit change events only on *material* change; kills alert fatigue and wasted spend.
5. **Feedforward from permits & ISO queues** — act on leading indicators before news breaks; the freshness edge.
6. **Balancing gate on the reinforcing flywheel** — prevent the error cascade (§7).
7. **Anti-windup / backpressure** — bound queue & spend under bursts; keeps the system stable and predictable.

---

## 6. Mechanism → loop map

| Loop (from proposal) | Primary mechanisms |
|---|---|
| L1 Ingestion | MAPE-K, setpoint/error, PID, feedforward |
| L2 Verification | negative feedback, requisite variety, hysteresis |
| L3 Freshness | deadband, delays→adaptive polling, stocks & flows |
| L4 Flywheel | reinforcing loop, double-loop learning, data flywheel |
| L5 Cost governor | active learning, anti-windup, backpressure |
| L6 Eval | balancing loop, error budget |
| U1–U4 User | OODA, human-in-the-loop, active learning (dispute prioritization) |

---

## 7. Caveats (where loops bite back)

- **Reinforcing without balancing = runaway error.** A flywheel that trains on its own unverified output drifts into an error cascade / model collapse. *Always* pair the reinforcing flywheel (L4) with a balancing quality gate (L6) and keep humans in the highest-uncertainty path.
- **Delays cause oscillation.** Re-verification slower than real-world change makes the DB swing stale↔wrong. Tune polling to project volatility, not a fixed cadence.
- **Requisite variety costs money.** Match the environment's variety, don't exceed it — more models/sources than the problem needs is just spend. The active-learning + cost-governor loops keep variety proportional to uncertainty.
- **Feedforward needs a good disturbance model.** Leading indicators (permits/queues) only help if the mapping "this filing → likely this data center" is calibrated; treat its output as a *candidate*, verified downstream.

---

*Sources: [Åström & Murray, *Feedback Systems* (Caltech)](https://www.cds.caltech.edu/~murray/books/AM08/pdf/fbs-pid_17Aug2019.pdf) · [Control Engineering — PID/deadband/feedforward/anti-windup](https://www.controleng.com/advanced-pid-loop-tuning-methods/) · [System dynamics (Wikipedia)](https://en.wikipedia.org/wiki/System_dynamics) & Senge, *The Fifth Discipline* · [Ashby's Law of Requisite Variety](https://taodynamics.org/cybernetics/ashby-requisite-variety.html) · [Adaptive Data Flywheel: MAPE Control Loops for AI Agents (arXiv 2510.27051)](https://arxiv.org/abs/2510.27051) · [Human-in-the-loop active learning](https://humansintheloop.org/how-do-you-build-human-in-the-loop-ai-pipelines-using-active-learning/). Frameworks: Wiener (cybernetics), Ashby (requisite variety/ultrastability), Boyd (OODA), Argyris (double-loop learning).*

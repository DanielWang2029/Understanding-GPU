We're building **dataCenterView** — a dashboard that tracks US (then worldwide) data centers plus the power, news, supply chain, and players around them: comprehensive, up-to-date, and verified. This folder is an investigation/R&D knowledge base (finalized specs + a working HTML demo) produced to de-risk this build. Your job is to turn it into a real, running application.

**Before writing any code, read these in order and reply with a short plan (no code yet):**
1. `docs/build-handoff-spec.md` — finalized architecture, stack, datastore decision, roadmap, skills. **Primary spec.**
2. `CLAUDE.md` — project brief, doc index, non-negotiable constraints.
3. `docs/data-schema-and-validation-spec.md` — production data model + validation regime.
4. `docs/phase-a-spec.md`, `docs/phase-b-spec.md` — the ingest specs.
5. `docs/demo-design-spec.md` + `datacenterview-explorer.html` + `data.json` — the UI to port and the data contract it consumes.

**Confirmed stack (do not re-litigate):**
- Deployment: local-first → small team; **Dockerized** (docker-compose).
- Pipeline: **Python 3.12** (uv). API + UI: **TypeScript / Next.js 15 + React + Tailwind**.
- Datastore: **Postgres = system of record**, **DuckDB = in-pipeline analytics**, emit the **`data.json` read-model**. (Supabase later for team auth — same Postgres, so no migration.)
- Ingest: `gridstatus` + EIA API (power); GDELT + publisher RSS + a search API (discovery); Firecrawl (scrape); a cheap LLM for extraction and a **different-vendor** LLM for verification.

**This session — scope = P0 + start of P1, in order:**
1. Scaffold a monorepo: `pipeline/` (Python), `api/` + `web/` (Next.js), `db/` (Alembic), `docker-compose.yml` (postgres · pipeline · api · web). `docker compose up` must bring it up.
2. Postgres schema + Alembic migrations from `docs/data-schema-and-validation-spec.md` (field-level provenance: records, entities, edges, sources, review_log, change_log, gold_set).
3. Move `data.schema.json` + `validate_data.py` into the repo; wire them into CI (GitHub Actions) as a publish gate.
4. Implement `phase-a-ingest`: EIA-860M + the 7 ISO queues via `gridstatus` → normalized `power_project` rows (`docs/phase-a-spec.md`) → upsert into Postgres → geocode via US Census.
5. Build step: read Postgres via DuckDB and **emit `data.json`** in the exact demo contract — `{ meta, datasets{data_center,power_project,news}, entities[], edges[], feeds[], supply_chain{} }`.
6. Port the demo UI (`datacenterview-explorer.html`) into the Next.js app — **Overview · Explorer · Newsfeed** — consuming the emitted `data.json`. Keep the charts (MapLibre, d3-sankey market + supply flows, the role-column project value chain) and the detail drawer.

**Non-negotiable constraints:**
- Never scrape CleanView or other paid competitors' curated data. Source only primary/free data + licensed APIs. Respect robots.txt / per-site ToS; never bypass paywalls.
- Keep a source URL for every extracted field; validate all LLM output against the schema.
- The UI is a **pure function of `data.json`** — no hardcoded data in the frontend.
- Delta-only processing; cache; cheap models for extraction; alert on daily spend.
- Field-level provenance + confidence are first-class; "confirmed" requires ≥2 independent sources (enforced in verify later; the validator warns on it now).

**Working style:**
- Propose a step-by-step plan + task list first; get my ok before large changes.
- Work incrementally; after each step run the validator/tests and show me the diff.
- Keep the `data.json` contract stable; version it with `schema_version`.
- Ask me (don't guess) when you hit these open decisions: (a) search vendor **Exa vs Perplexity**; (b) the **2nd LLM vendor** for cross-verify; (c) orchestrator **GitHub Actions vs Prefect**; (d) API host — **Next.js route handlers vs a separate FastAPI**.

Start by reading the docs and giving me the plan.

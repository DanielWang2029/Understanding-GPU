# Compute-Chain Terminal — Findings & Solution Options

> **What this is.** The investigation output behind the pivot from *"data-center tracker (à la CleanView)"* to a **Bloomberg-style terminal for the GPU compute chain**, aimed at a **compute buyer / AI builder**. It records (1) what the current demo/data actually is, (2) the gap to a decision-grade terminal, (3) all candidate data sources and the connections between them, and (4) the design decisions with options + a recommendation each. Feeds `docs/PRD-compute-terminal.md` (product) and `docs/TDD-compute-terminal.md` (technical + loop architecture). July 2026.

---

## Revision — v2 pivot (BMAP/SPLC/WCAP)

Design review of the v1 demo re-centered the product. The **Price Board** was validated as useful, but the other v1 tabs (Provider page, Delivery funnel, How-it-maps) read as flat, isolated instruments. The target is now a fusion of three Bloomberg functions applied to GPU compute:
- **BMAP** — a layered geospatial map of the chain's *physical assets* (fabs · CoWoS/OSAT · HBM · servers · **data centers** · **power** · cables).
- **SPLC** — a *quantified* supplier/customer/peer graph you pivot through (suppliers by %COGS, customers by %revenue), built on the existing `entities[]/edges[]`.
- **WCAP** — market-cap analysis of the chain (a treemap by layer), via the **FMP connector**.

This **updates D1 and D2**: primary user is now **analyst / investor / strategist** (understand where value/capacity/dependency/risk sit), and the centerpiece is the **navigable value-chain graph**, not the price board (which demotes to a secondary buyer instrument). This re-aligns with the project's original thesis (`docs/loop-engineering-value-chain-proposal.md` §4, **U3 chain navigation**). Retired: standalone Provider page (→ entity drawer), Delivery funnel (→ FF map overlay), How-it-maps (→ docs). New core loop: **L9 financial/market-graph** (`chain-financials` skill).

**v2.1 refinement (after review of the v2 demo).** The graph should not *replace* the original demo tabs but *nest into* them: the product is **one graph at four altitudes** (aggregate flow · entity · project · geography) + two instruments (Price Board · Newsfeed). Concretely: (1) supply-chain = the original **Overview sankeys + project drill**, not a geographic tab; (2) **Market flow + Chain Analysis** = aggregate→entity drill of one graph (click a sankey node → SPLC); (3) **market cap is a weight toggle** (`Capacity · Revenue · Market cap`) that re-sizes the flows/nodes in place — the standalone WCAP treemap is retired; (4) **Price Board** restored to the full v1, with contextual news; (5) **Explorer kept**, and it absorbs the geographic supply-chain map as extra **asset layers**. Standalone BMAP-map tab and WCAP-treemap tab are both retired into better homes. See the refreshed `docs/PRD-compute-terminal.md` (v2.1) / `docs/TDD-compute-terminal.md`.

---

## 0. TL;DR

- The demo today is a **coverage/inventory map** (data centers + power projects, one 2026-07-16 snapshot). That is the *crowded* half of the market (Baxtel, DC Byte, datacenterHawk, SemiAnalysis) and **not what a compute buyer needs**.
- The buyer's decision — *"where do I get GPUs, what do they cost, are they any good, can the cluster actually be delivered and when?"* — is answered by **price, provider-quality, and the upstream delivery constraint**. We have **~zero data** on all three, and they are the sparsest edges in the graph.
- The good news: the highest-value buyer layer (**GPU rental price time-series**) is **free and already time-series-rich**, and the financial layer is reachable through the **FMP connector** without building scrapers.
- The moat is **not coverage** (unwinnable vs SemiAnalysis) — it's the **connected, provenance-scored, self-correcting graph** that the loops produce. Keep that; re-center it on compute.

---

## 1. What the current demo actually is (verified inventory)

| Layer | Records / signal in `data.json` | Verdict for a compute buyer |
|---|---|---|
| Data centers | 428 (`capacity_mw`, status, county/state, confidence, sources) | Context only — "does a building exist here" |
| Power projects | 3,558 (tech split, 1,031 BTM-flagged) | Context only — matters *only* as a delivery constraint |
| News | 272 (project-linked, source_feed) | Useful, keep |
| Entities | 157 — but **96 (61%) are `other`** (untyped) | Graph is mostly unclassified → can't screen/rank |
| Edges | 547 — but **404 are `operates`** (PeeringDB plumbing) | The insightful edges are nearly empty (see §3) |
| Supply-chain sankey | 24 nodes / 47 links, **static aggregate, disconnected from the 428 records** | Names the compute chain but carries no live data |
| **Price** | **0** | 🔴 The #1 buyer need — absent |
| **Provider quality** | **0** | 🔴 Absent |
| **Chip / cluster inventory (SKU, GPU count, FLOPS)** | **0** | 🔴 Absent |
| **Delivery constraint (CoWoS/HBM/power lead-time)** | Power queue exists but **unlinked**; upstream absent | 🔴 Effectively absent |
| **Time series** | Snapshot only; `published_date` null, `operating_year` on 35/428 | 🔴 No history = not a terminal |

**Structural strengths to keep:** field-typed, trust-weighted provenance; freshness (`last_verified`); the graph skeleton (`entities[]`/`edges[]`); the pure-`data.json` read-model; the loop-driven pipeline. These are rare and hard to copy.

**Housekeeping found:** `docs/demo-design-spec.md` counts are stale (says 21 DCs / v0.1; reality 428 / v1.0). The **"How it works"** view is fully built but its nav tab is removed (unreachable). `meta.rollups` is emitted but **never consumed** by the UI (free KPIs unused).

---

## 2. The reference landscape (who we're really up against)

| Product | What it is | Access | Takeaway for us |
|---|---|---|---|
| **SemiAnalysis Datacenter Model** | 5,000+ facilities, IT power, PUE, hyperscaler capex forecast | Paid PDF/xlsx | Can't out-cover them; they sell files, not a graph |
| **SemiAnalysis Accelerator & HBM Model** | Shipments + ASP by SKU (every Nvidia/TPU gen), installed base, FLOPS/MFU | Paid | The chip layer, if we ever license/estimate it |
| **ClusterMAX (SemiAnalysis)** | GPU-cloud rating, **10 dimensions**, 5 tiers, 84 clouds, 140+ user interviews | Partly free | The provider-quality standard to ingest/mirror |
| **GetDeploying / AI-Multiple GPU Index / Cloud GPU Tracker** | **$/hr by SKU · provider · region · term**, 68 providers / 90 SKUs, hourly–monthly | **Free** | **Our flagship free feed** — the quote layer |
| **Epoch AI models dataset** | 2,000+ models: training FLOP, params, cost, power, time | **Free CSV** | The demand/end-user proof layer |
| **Baxtel / DC Byte / datacenterHawk** | DC inventory + real-estate comps (8,000+ sites) | Free-ish / paid | Coverage competitors — don't race them |

**Market facts worth pinning (mid-2026):** H100 rental median ≈ **$3.15/GPU-hr** (down from ~$7 early 2024), H200 ≈ **$4.11**, range $1.49–$6.98; CoWoS capacity ≈ **120–130k wpm** by end-2026 (from ~75k in 2025), **Nvidia ~70% of CoWoS-L**, HBM3E sold out; hyperscaler capex ≈ **$725B in 2026** (60%+ on *power*). These are the numbers a buyer's decisions actually turn on — and none are in our data.

---

## 3. The connections gap ("insight lives in the sparse edges")

Insight density is **inversely** correlated with edge count today:

| Edge | Count now | Buyer value | Source to build it |
|---|---|---|---|
| `operates` | 404 | Low (plumbing) | PeeringDB ✅ |
| `develops` | 76 | Low–med | Press/permits |
| `serves` | 47 | Med | Press |
| `powers` / BTM | **14** | **High** — can this cluster be energized & when | ISO/EIA (we have 1,031 BTM, mostly unlinked) |
| `provides_compute` | **4** | **High** — who actually has which GPUs | Provider pages, ClusterMax |
| `leases_to` | **2** | Med | Deals/filings |
| `prices_at` (SKU×provider→$/hr, dated) | **0 (new)** | **Critical** — the quote | Pricing aggregators (free) |
| `rated` (provider→ClusterMax tier) | **0 (new)** | **High** — is it any good | ClusterMax |
| `supplied_by` / `allocates` (CoWoS→chip→provider) | **0 (new)** | **High** — who can even get chips | TrendForce / earnings |
| `off_takes` / `funds` (lab/investor→provider) | 2 / 0 | Med — is capacity spoken for | Deals, filings, PitchBook |
| `trains_on` (model→cluster) | 0 (new) | Med — proof of real capacity | Epoch AI |

**Rule of thumb for the build:** a new edge type earns its place only if it changes a buyer's decision. `prices_at`, `rated`, `powers`, `provides_compute`, `supplied_by` do; a fifth flavor of `operates` does not.

---

## 4. All candidate data sources, by chain layer

| Layer | Source(s) | Cost | Cadence | Gives | Have? |
|---|---|---|---|---|---|
| 0 · Capital/demand | Hyperscaler capex (earnings/SEC); **FMP connector**; PitchBook (raises) | Free/paid | Q / event | $725B capex, funding, backers | ❌ |
| 1 · Silicon & packaging | TrendForce; TSMC/SK Hynix earnings; SemiAnalysis Accel/HBM | Paid + free-via-earnings | Q/monthly | CoWoS/HBM capacity & allocation | ❌ |
| 2 · Accelerators | SemiAnalysis Accel model; Nvidia/AMD earnings; datasheets | Paid + free | Q | Shipments/ASP, installed base, FLOPS | ❌ |
| 3 · Systems/networking | Dell/SMCI/Foxconn/Arista/Broadcom earnings; specs | **Free** | Q | ODM share, rack designs, fabric | ❌ |
| 4 · DC facilities | EIA-860M; PeeringDB; permits; Baxtel/DC Byte | Free + paid | Monthly/event | Facility inventory, comps | ✅ base |
| 5 · Power & grid | `gridstatus` (7 ISOs); EIA; ENTSO-E; FERC; utility IRPs | **Free** | Monthly/daily | Queues, interconnect lead-time, BTM | ✅ |
| 6 · **Providers / clouds** | **GetDeploying · AI-Multiple · Cloud GPU Tracker** (price); **ClusterMax** (quality) | **Mostly free** | **Hourly/monthly** | **$/hr, availability, provider ratings** | ❌ **← top gap** |
| 7 · End users / models | **Epoch AI** (open CSV); press | **Free** | Regular | Training FLOP, cost, power | ❌ |
| Cross-cut | GDELT, trade-press RSS; **FMP** (quotes/statements/13F/insider) | Free | Live | News + market data on ~30 chain names | ✅ news / ❌ market |

**Punchline:** the three things the buyer cares most about (price, quality, delivery constraint) are all **free or already in hand**, and we've wired almost none of them. We are sitting on the crowded/hard layer and missing the cheap/decisive one.

---

## 5. Design decisions — options & recommendations

Each decision, the options, and the pick. These become the locked assumptions in the PRD/TDD.

### D1 — Product center of gravity
- **A. Re-center on compute** (chips→clusters→clouds→users; DC/power become "deliverability" context).
- **B. Keep DC/power as headline** (current).
- **C. Both, phased** — ship DC/power coverage, layer the compute terminal on top.
- **✅ Recommend C, but build the schema for the compute end-state now** *(your call)*. Caveat carried into the PRD: for the *primary user*, the compute layer is the real Phase 1 — see D3.

### D2 — Primary user & the decision
- **A. Investor / capital allocator** · **B. Compute buyer / AI builder** · **C. DC developer** · **D. Analyst/policy**.
- **✅ B — Compute buyer** *(your call)*. Decision = *choose provider · SKU · region · timing*. Every view must move that decision or it's deferred. Investor/analyst become **secondary** and get read-only reuse of the same data.

### D3 — Sequencing (the tension in C)
- **A. Literal:** DC/power coverage first (data exists), compute later.
- **B. Buyer-first:** ship the **Price Board + Provider pages + Delivery-Constraint** first (free data, serves the #1 user), let DC/power ride along as the constraint layer.
- **✅ Recommend B.** The free pricing feed is cheaper *and* more decision-relevant than more DC coverage. DC/power is demoted from headline to the *"can it be delivered"* gate. (This is the one place I'd push back on a literal reading of "coverage first.")

### D4 — Pricing data source
- **A. GetDeploying** (breadth: 68 providers, 90 SKUs) · **B. AI-Multiple Index** (monthly, clean) · **C. Cloud GPU Tracker** (hourly) · **D. scrape providers directly**.
- **✅ Recommend A primary + B as cross-check** (requisite variety on price), D only for tier-1 providers where we want first-party confirmation. Treat each aggregator as a *source* with a trust weight, exactly like news.

### D5 — Provider quality
- **A. Mirror ClusterMAX** tiers/dimensions (fast, credible, attributed) · **B. Build our own rubric** · **C. Aggregate user reviews only**.
- **✅ Recommend A now** (ingest + attribute ClusterMAX's 10 dims + tier), **B later** as a differentiator once we can measure a few dimensions ourselves (price transparency, availability, power headroom — which we can compute). Never present others' ratings as ours.

### D6 — Financial / capex layer
- **A. FMP connector** (quotes, statements, analyst, 13F, insider — ~30 public chain names) · **B. SEC EDGAR parse** · **C. skip for v1**.
- **✅ Recommend A** — it's already available and removes a whole scraper class. Use it for capex, guidance, and the market-data column on entity pages.

### D7 — Time series (snapshot → history)
- **A. Add `as_of`/`status_history` everywhere now** · **B. defer**.
- **✅ Recommend A, non-negotiable.** Without dated records + price history there is no terminal. The drawer already has the placeholder (*"status_history arrives with v1.0"*) — make it real. This is the single highest-leverage schema change.

### D8 — Bottleneck / delivery constraint
- **A. Model it as a feedforward funnel** (CoWoS→HBM→chip→server→power→cluster), red/amber/green tightness · **B. just show power queue** · **C. skip**.
- **✅ Recommend A** — it's where our *existing* ISO/BTM data finally pays off (it's the last gate of the funnel) and it's the buyer's "when can I actually get it" answer. Upstream stages start coarse (manually-maintained tightness flags from earnings/TrendForce) and sharpen over phases.

### D9 — Demo scope for review
- **A. New standalone `compute-terminal-demo.html`** with representative data for the new layers · **B. surgically edit the 617-line demo + Next port**.
- **✅ Recommend A** for the review artifact (clean, self-contained, clearly-labeled illustrative data), then fold the winning views into the Next app once approved. Keeps the current demo intact as the "coverage" reference.

---

## 6. What we are explicitly NOT doing (scope discipline)
- **Not** racing SemiAnalysis/Baxtel on raw facility count.
- **Not** modeling chip shipments/ASP ourselves in v1 (license or estimate later; start with the *free* buyer-facing layers).
- **Not** surfacing the full clean-energy queue detail to the buyer (solar/wind noise) — only the BTM/large-load/interconnect slice that gates delivery.
- **Not** building trading/price-prediction features — this is a *decision-support* terminal, not a trading tool.

---

## 7. Open questions to resolve during the build
1. Do we license any SemiAnalysis/TrendForce data for the upstream funnel, or keep it as coarse manually-maintained tightness flags in v1? (Cost vs precision.)
2. Provider "availability/lead-time" has no clean free feed — do we infer it (price volatility + capacity announcements) or partner?
3. ClusterMAX attribution/ToS for mirroring tiers — confirm we can display with credit vs. link-out only.
4. How much of the DC/power coverage do we keep visible to the buyer vs collapse into a single "deliverability" score?

*Companions: `docs/PRD-compute-terminal.md` · `docs/TDD-compute-terminal.md` · `docs/loop-mechanisms-catalog.md` · `docs/build-handoff-spec.md` · `docs/data-schema-and-validation-spec.md`.*

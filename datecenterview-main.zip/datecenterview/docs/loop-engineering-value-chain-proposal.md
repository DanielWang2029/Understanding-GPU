# Loop Engineering & the Value Chain — Proposal

*How to make dataCenterView outstanding — technically and in content — by (1) running the pipeline as a set of closed feedback loops and (2) exposing the navigable value chain from **project → developer → operator → tenant → end-user → compute provider**. Investigation output for the future Claude Code build. Taxonomy current as of July 2026.*

---

## 1. Thesis

Two moves make this outstanding, and they compound each other:

1. **Technical — run ingestion as closed feedback loops, not one-shot ETL.** A pipeline without feedback drifts (stale, unverified, drifting cost). A pipeline *with* feedback self-corrects toward quality and freshness setpoints and gets better *and cheaper* every cycle.
2. **User — design the UX as loops too.** Sense-making (observe→act), a trust loop where a user's dispute flows back into machine verification, and above all **chain navigation**: let an end-user start at a data center and traverse the whole commercial/physical chain, each hop provenance-backed and confidence-scored.

The content payoff is the **value-chain graph** — the answer to *"who actually runs the compute here, who leases it, who's the end user, who powers it, and how sure are we?"* That is the question investors and BD teams actually ask, and it's precisely what CleanView's record-centric model can't answer. Data anyone can copy; a **self-correcting, navigable, provenance-backed chain** is hard to copy and compounds.

---

## 2. Why loops (theory, briefly)

- **Closed-loop control:** setpoint → measure → error → correct. The organizing metaphor for the whole system.
- **MAPE-K** (autonomic computing): *Monitor–Analyze–Plan–Execute over shared Knowledge* — the template for a self-managing ingestion system.
- **Maker–checker / adversarial verification:** a checker from a *different vendor* gives **decorrelated** feedback — the only kind that's a real error signal.
- **Double-loop learning** (Argyris): single-loop fixes a wrong value; **double-loop fixes the governing assumptions** (the source list, prompts, heuristics). The data flywheel is double-loop learning.
- **OODA + human-in-the-loop / active learning:** the user is a sensor whose corrections train the machine loops.

---

## 3. Technical loops (inner — data quality)

Each is a controller: a **setpoint**, a **measured value**, an **error signal**, and a **correction**.

| Loop | Setpoint | Measured | Correction |
|---|---|---|---|
| **L1 Ingestion (MAPE-K)** | coverage & precision targets per state | eval metrics, conflict rate | re-query sources, tighten prompt, escalate to human |
| **L2 Verification (maker–checker)** | fields agree across ≥2 independent sources | cross-vendor agreement | disagreement → lower confidence + re-search |
| **L3 Freshness (adaptive polling)** | staleness < horizon | `last_verified` age, volatility | poll high-velocity projects more often; auto-re-verify stale records; emit change feed |
| **L4 Flywheel (double-loop)** | rising precision at falling cost | human corrections, resolved conflicts | update source-trust weights, prompts, BTM & provider heuristics |
| **L5 Cost governor** | spend ≤ budget | daily spend, uncertainty | allocate budget to highest **uncertainty × value**; delta-only is the actuator |
| **L6 Eval (eval-driven dev)** | no regression vs gold set | precision/recall on gold set | block deploy on regression |

The important one is **L4**: every human decision and resolved conflict feeds back to improve the *rules themselves*, so the system's accuracy rises while cost per verified fact falls. That compounding is the moat — CleanView's human curation doesn't compound this way.

---

## 4. User loops (outer — sense-making & trust)

| Loop | Turn |
|---|---|
| **U1 Comprehension (OODA)** | overview (map/table) → orient (filter/compare) → decide (open a project) → act (trace / export / alert) → repeat. Progressive disclosure. |
| **U2 Trust (human-in-the-loop)** | every field shows source + confidence → user clicks through → **agrees / disputes** → the dispute becomes a signal into **L2**. Users as sensors. |
| **U3 Chain navigation** | from any node, traverse the value graph both directions (the headline feature — §5). |
| **U4 Alert / personalization** | user sets a watch ("new >500 MW in ERCOT with a neocloud tenant") → change feed fires → user acts → app learns what they care about. |

U2 is the quiet superpower: it wires the *reader* into the *data-quality* loop. A user-reported error isn't a support ticket — it's a verification trigger and a training example.

---

## 5. The content upgrade — the Value-Chain Graph

This is what realizes the end goal. Move from **record-centric** ("here are the data centers") to **graph-centric** ("here is who does what to whom, and how sure we are").

### Entities (nodes)
Project (data center) · Developer · Operator · Tenant · End-user · Power supplier · **Compute provider**.

### Compute-provider taxonomy (2026)
- **Hyperscaler self-build** — Microsoft, AWS, Google, Meta, Oracle, Apple. Own + operate for their own cloud (~$700B combined capex in 2026).
- **Neocloud / GPU-as-a-Service** — CoreWeave, Crusoe, Lambda, Nebius, Nscale, Fluidstack, Together (~$20B revenue in 2026 → ~$180B by 2030). AI-first; frequently behind-the-meter or leasing colo to move fast.
- **Wholesale / hyperscale colocation** — Digital Realty, QTS, Vantage, Stack, CyrusOne, Aligned, Switch, CoreSite. Increasingly **build-to-suit whole buildings/campuses** for hyperscalers and neoclouds.
- **Retail colocation / interconnection** — Equinix, Cologix, CoreSite. Smaller footprints, peering, network density.
- **Enterprise / sovereign / crypto-to-AI** — enterprise self-operated, government/sovereign clouds, and pivots (Hut 8, Core Scientific, IREN).

> Reality is tangled — which is the whole point. A campus can be **developed by** a colo (Vantage), **leased to** a neocloud (CoreWeave), **serving** a hyperscaler's customer (Microsoft/OpenAI), and **powered by** on-site gas. The categories cross; only a graph captures it.

### Edges (typed, provenance-backed, confidence-scored)
`develops` · `operates` · `leases-to` (tenant) · `serves` (end-user) · `powers` (BTM/PPA) · `provides-compute` (with type). **Each edge is `{value, sources[], confidence, last_verified}`** — same provenance discipline as fields, so every link in the chain is clickable and disputable.

### Worked example — trace *Stargate Abilene*
```
Stargate I  ──develops──▶  Crusoe (neocloud)
            ──operates──▶  Oracle (hyperscaler cloud)
            ──serves────▶  OpenAI (AI lab / end-user)
            ──powered-by▶  on-site natural gas (BTM)      [confidence per hop]
```
One project touches four provider categories. A user clicking through sees *who runs the compute, who consumes it, and who powers it* — with a confidence badge and sources on every arrow.

### Upstream: the supply chain
The value chain runs *downstream* (project → operator → tenant → end-user). It extends *upstream* into a **supply-chain graph** — **foundry/HBM → accelerators → servers/networking → power/cooling → operators** — populated with the real vendors behind each project (chips: Nvidia/AMD/Broadcom; servers: Dell/Supermicro/Foxconn; networking: Arista; power/cooling: Vertiv/Eaton/CoolIT), node figures drawn from earnings. Together the two directions give the **end-to-end** picture: from the silicon a data center runs on, through who builds/operates/leases it, to who consumes the compute. Both are modeled in `data.json` (`supply_chain{}` + `edges[]`) and rendered as the demo's three Overview flow charts.

### Why it's differentiating
CleanView answers *where*. The chain answers *who / for whom / how sure* — and the loops guarantee each link is fresh, cross-verified, and disputable. That's the answer an investor or BD lead is actually paying for.

---

## 6. How the loops and the graph fuse (the double loop)

```
        OUTER LOOP — user + learning (double-loop)
  ┌──────────────────────────────────────────────────────────────┐
  │  user: OBSERVE → ORIENT → DECIDE → ACT (trace / dispute)      │
  │      ▲                                        │ dispute        │
  │      │  navigable, confidence-scored CHAIN    ▼                │
  │  ┌────────────── INNER LOOP — data quality ──────────────┐    │
  │  │  discover → extract → VERIFY (diff-vendor) → score →   │    │
  │  │      ▲                                        │ gate    │    │
  │  │      └──────── re-query / re-prompt ◀──────────┘        │    │
  │  └───────────────────────────┬───────────────────────────┘    │
  │      corrections + disputes   ▼   (flywheel / double-loop)     │
  │   update source-trust · prompts · provider-classification      │
  └──────────────────────────────────────────────────────────────┘
```

Each **edge** in the chain is produced by L1, disputed by L2, scored, made navigable in U3, and disputable in U2 — and every dispute or resolved conflict feeds L4, so the graph gets **denser and more trusted every cycle**. The graph is the artifact; the loops are what make it trustworthy and self-improving.

---

## 7. Where it slots into the roadmap

- **Schema:** extend the `data.json` contract with `entities[]` and `edges[]` alongside `datasets[]`. Extraction already captures developer / tenant / end-user; add `operator` and a `compute_provider` classification, plus per-edge provenance.
- **Provider classifier:** a small step tagging each org with its provider type (rules + LLM), living inside **L4** so it improves via corrections.
- **App:** a **Chain view** (relationship panel per project), the **dispute control** (U2), and **watch/alerts** (U4).
- **Evals:** add **chain-completeness** and **edge-precision** to the gold set.

Sits mostly in Phases B–C; the taxonomy + graph is a *cross-cutting* content layer, not a new phase.

---

## 8. Success metrics

- **Chain completeness** — % of projects with tenant **and** compute-provider resolved at ≥0.75 confidence.
- **Edge precision** — sampled correctness of `leases-to` / `provides-compute`.
- **Time-to-trace** — clicks/seconds for a user to go project → end-user.
- **Loop health** — dispute-resolution latency, freshness lag, and **cost per verified edge trending down** (the flywheel, proven).

---

## 9. Bottom line

The loops make the data **trustworthy and cheap to keep fresh**; the value-chain graph makes it **understandable and actionable** — an end-user can trace a project all the way to its tenant and compute-provider category, and trust each link because it's sourced, scored, and disputable. Anyone can scrape rows. A self-correcting, navigable chain is the version that's hard to copy and gets better the more it's used.

---

*Sources for the 2026 taxonomy: [ABI Research — leading neocloud companies](https://www.abiresearch.com/blog/leading-neocloud-companies) · [Network World — neoclouds vs hyperscalers](https://www.networkworld.com/article/4011187/neoclouds-roll-in-challenge-hyperscalers-for-ai-workloads.html) · [Umbrex — data-center types taxonomy](https://umbrex.com/resources/data-center-primer/types-of-data-centers-industry-taxonomy/) · [DCK — colocation battleground 2026](https://www.datacenterknowledge.com/colocation/power-not-space-the-colocation-battleground-in-2026). Loop frameworks: MAPE-K (autonomic computing), Argyris double-loop learning, Boyd's OODA, maker-checker control.*

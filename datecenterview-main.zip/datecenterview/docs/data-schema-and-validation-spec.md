# Data Schema, Sources & Ongoing Validation

*How the data model should be re-designed for production, what feeds every field, and how to keep it correct continuously. Ships with a runnable structural gate (`data.schema.json` + `validate_data.py`). Supersedes the loose demo shape (`schema_version 0.1`) with a `1.0` target.*

---

## 0. The two schemas (this is the key reframe)

The demo's `data.json` is a **read-model**: flat, record-level provenance, illustrative. Production needs **two** schemas, kept in sync by a build step:

1. **Store schema (system of record)** — normalized tables in Postgres/DuckDB with **field-level provenance**, IDs, history, and a source registry. This is truth.
2. **Read-model (`data.json`)** — a denormalized projection the UI loads (what the demo already consumes). Generated from the store, **validated before publish** by `data.schema.json`.

The store carries full provenance; the read-model flattens each field to `value + confidence + sources` for rendering. Never let the UI write truth; it only reads the projection.

---

## 1. What changes from v0.1

| v0.1 (demo) | v1.0 (production) |
|---|---|
| Record-level `confidence` + `sources[]` | **Field-level provenance** — every key value carries its own sources/confidence/last_verified |
| Free-text `developer`, `end_user` | **Entity references** (`*_id` → `entity` table) with alias resolution |
| `status` string | `status` enum **+ status_history** (drives the change feed) |
| Flat records only | `entity` / `edge` / `supply_chain` as first-class graph tables |
| Sources = bare URLs | **Source registry** with type, trust weight, license, retrieved_at |
| Implicit | `review_log`, `change_log`, `gold_set` for validation |

---

## 2. v1.0 store schema

### 2.1 The reusable provenance wrapper — `Field<T>`
Every important value is not a scalar but:
```jsonc
Field<T> = {
  "value": T,
  "unit": "MW|sqft|acres|USD|null",
  "sources": ["src_id", ...],        // → source registry
  "confidence": 0.0–1.0,
  "method": "gov_api|iso|extracted|cross_verified|human|geocoded",
  "last_verified": "YYYY-MM-DD",
  "as_of": "YYYY-MM-DD",             // the date the value is true for
  "quote": "…verbatim sentence…"     // OPTIONAL — key omitted entirely when absent
}
```

**`quote` (added 2026-07-20, `19673ac`).** The verbatim sentence from the source that supports this value, capped at 500 chars. Phase B's extractor has *always* required one — an unquoted number is dropped as a hallucination — but nothing persisted it, so the evidence died at the store boundary. That is the difference between reviewing "400 MW" and reviewing *"earnings results suggest the site could host up to 400MW"*: same number, very different weight, and only the second lets a reviewer see that the claim is hedged.

Three rules:
- **Omitted, never null.** A `gov_api`/ISO field has a feed, not a quote; padding it with `"quote": null` would imply a missing quote rather than an inapplicable one.
- **Store-side only.** Quotes are not in the read-model — exposing them would be a schema change and a separate decision.
- **Coverage is low and that is expected.** Only rows extracted *after* the change carry one (**3 of 338** capacities today). `dcv reverify` reconstructs the quote where present and records per row whether the check was `reverify_with_quote` (values-plus-evidence, full strength) or `reverify_no_quote` (values-only, weaker). Read `field.py::field_quote()` rather than reaching into the dict.

`location` is a plain dict, not a `Field<T>`, so its quote is carried inline as `location.quote` — it is the evidence for the siting claim.

### 2.2 Tables

- **`source`** — `id, url, publisher, type(gov_api|iso|trade_press|permit|earnings|company|satellite|social|research), trust_weight(0–1), license, retrieved_at`.
- **`entity`** — `id, name, aka[], category(provider taxonomy), category_confidence, identifiers{ticker,LEI,domain}, sources[]`, **`layer`** (equipment|foundry|memory|gpu|asic|server|networking|…|enduser — 8 layers since Band 2 #1 added `equipment`), **`financials`** (JSONB, **per-metric** `Field<T>` for `market_cap`/`revenue`/`capex`; migration `c1d2e3f4a5b6`). Per-metric matters: an entity can hold a *disclosed* revenue and an *estimated* market cap at once, and a single entity-level flag would mislabel one of them — see the `provenance-rendering` skill. `financials_integrity` (gate 3) attaches here.
- **`data_center`** — `id, natural_key, project_name, aka[], developer_id, operator_id, tenant_id, end_user_id (→entity)`, **`developer_name, operator_name, tenant_name, end_user_name`** (the raw extracted strings), `developer_category, status(enum), status_history[], capacity_mw:Field, building_sqft:Field, land_acres:Field, cap_ex:Field, btm_generation:Field, power_sources[], location{county,state,country,lat,lng,geo_precision,quote?}, announced_date, operating_year, overall_confidence, review_status, last_verified, sources[], created_at, updated_at`.

  **Every role carries a raw-name / resolved-id pair.** `tenant_name` and `operator_name` were missing until Band 2 #2 (`d4e5f6a7b8c9`), and their absence was the bug: the extractor produced a tenant on every candidate and `persist` dropped it on write because there was no column. Keep both halves — the raw string is what a human audits and what `dc_roles.py` re-resolves as the backbone grows, and it is also where an *unusable* value is retained honestly (Hut 8's tenant *"a high-investment-grade company"* stays in `tenant_name` while `tenant_id` is correctly null, reason `undisclosed_counterparty`).
- **`power_project`** — `id, natural_key(plant_id+generator_id | iso+queue_id), project_name, developer_id, technology(enum), capacity_mw:Field, capacity_mwh:Field, status(enum), balancing_authority, location{…}, btm_datacenter_signal:Field, operating_date, source_id, last_verified`.
- **`edge`** — `id, from_id, to_id, relation(develops|operates|leases_to|serves|powers|provides_compute|supplies), value:Field?(MW/GPUs/$), confidence, sources[], valid_from, valid_to, status(active|expired)`.
- **`supply_node` / `supply_link`** — provider `entity_id`, `layer(foundry|memory|gpu|asic|server|networking|power|cooling|operator|enduser)`, `supplies` links with `value` + `$ metadata (as_of)` from earnings.
- **`news`** — `id, title, publisher, published_date, url, source_feed, entity_refs[], project_refs[], summary, provenance`.
- **`review_log`** — every human decision (approve/reject/edit) with reviewer, timestamp, before/after → trains the flywheel.
- **`change_log`** — every field change with old/new/source → powers the change feed + drift detection.
- **`gold_set`** — hand-verified records used to measure precision/recall.

### 2.3 Read-model (`data.json`)
Emitted by a build step; shape validated by `data.schema.json`:
`{ meta, datasets{ data_center[], power_project[], news[] }, entities[], edges[], feeds[], supply_chain{nodes,links} }`. Field objects are flattened to `value` (+ top-level `confidence`, `sources`, `last_verified`) for the UI. Bump `schema_version`; keep migration notes.

---

## 3. Data-source map (what feeds each field)

| Data | Primary source(s) | Type | Cadence | Access / cost |
|---|---|---|---|---|
| **Power projects** (all fields) | EIA-860M; 7 ISO interconnection queues (via `gridstatus`) | gov_api / iso | EIA monthly · ISO daily | Free |
| **BTM signal** | EIA + ISO + heuristic, confirmed by news | derived | daily | Free |
| **DC existence / name / developer** | Trade press (DCD, DCF, DCK), company press/IR, **permit & rezoning filings**, local business journals | trade_press / company / permit | continuous | Low (scrape/API) |
| **DC capacity_mw** | Press announcements, permit/utility filings, interconnection MW | trade_press / permit / iso | event | Low |
| **DC cap_ex** | Earnings, press releases, state incentive filings | earnings / company | event / quarterly | Low |
| **DC status (lifecycle)** | News, permits, **satellite progress** | news / permit / satellite | event | Low–med |
| **DC location / coords** | Permit address; US Census geocoder | permit / gov_api | event | Free |
| **Entities / category** | Company sites, earnings, analyst taxonomies (ABI, DCK) | company / earnings / research | quarterly | Low |
| **Edges** (develops/operates/leases_to/serves/powers/provides_compute) | Press releases, **PPAs & utility filings**, earnings calls, company announcements | company / permit / earnings | event | Low |
| **Supply chain** (suppliers + $) | **Earnings reports / 10-K / 8-K**, investor decks, analyst research, chip-deal announcements | earnings / research | quarterly + event | Low |
| **News / feeds** | GDELT 2.0, publisher RSS, Exa/Perplexity search | firehose / rss / api | continuous (15-min) | Free–usage |

**Trust weights (source registry):** gov_api/iso ≈ 1.0 · earnings/SEC ≈ 0.95 · permit filings ≈ 0.9 · reputable trade press ≈ 0.8 · company PR ≈ 0.7 (aspirational) · social/rumor ≈ 0.4. Confidence is a function of source trust × corroboration count.

---

## 4. Ongoing validation regime (the heart)

Validation is **continuous and layered**, not a one-time load check. **Nine automated gates ship today** — eight of them blocking (they land in `errs`, exit 1) plus `semantic`, which warns; verification, human review, and the control loops complete it. Run with `python -m dcv validate`.

### 4.1 The nine gates — `data.schema.json` + `validate_data.py` *(shipped, runs in CI)*

| # | Gate | `validate_data.py` | Blocks? | What it enforces |
|---|---|---|---|---|
| 1 | `structural` | `:36` | ✅ | JSON Schema: types, enums, ranges (capacity 0–20 000 MW, lat/lng, confidence 0–1), URL/date formats, required fields, unique ids |
| 2 | `referential` | `:51` | ✅ | edges→entities/projects, news→projects, supply links→nodes |
| 3 | `financials_integrity` | `:206` | ✅ | a `disclosed` metric must structurally carry value + `as_of` + source |
| 4 | `edge_integrity` | `:238` | ✅ | the three-state edge model — `seed` / `named` / quantified — stays consistent; no placeholder magnitudes |
| 5 | `review_queue_integrity` | `:263` | ✅ | `meta.rollups.review_queue` matches the emitted read-model, not the store |
| 6 | `backbone_reach_integrity` | `:307` | ✅ | an entity EDGAR cannot reach may never carry a `disclosed` figure |
| 7 | `dc_role_coverage_integrity` | `:352` | ✅ | role coverage is reported against the **eligible** base, with `not_applicable` counted |
| 8 | `source_policy_integrity` | `:394` | ✅ | **decision #1** — no tier-1 competitor URL reaches the published read-model |
| 9 | `semantic` | `:140` | ⚠️ warn | trust (≥2 sources for `confirmed`) · freshness · acyclic supply chain |

Gate 8 is the one that carries legal risk: decision #1 was prose only until 2026-07-20, and in that window 104 tier-1 URLs reached the published read-model. It is now enforced at discovery, at enrichment, **and** here.

Every gate ships with a must-pass **and** a must-fail test (the `loop-design` adversarial rule) — a green validator with holes is worse than none.

### 4.2 Cross-source verification — semantic
Require **≥2 independent sources** before a field is `confirmed`; a **different-vendor LLM** re-searches each key field (capacity/status/location); conflicts lower confidence and re-open the record. The shipped validator **warns on every confirmed-but-single-source record** — ~3.6k today, and the shape matters: they are almost entirely ISO-queue `power_project` rows, which come from exactly one authority by nature. Treating that as a backlog to burn down would be a category error; the DC side is where corroboration is real work.

`dcv reverify` re-runs **only** this stage, for rows the verifier never checked (e.g. after an API outage, where `phaseb.verify` correctly fails closed). It persists any corroborating source it finds — keeping the verdict while discarding the evidence is how a row ends up asserting `approved` on two sources while showing one.

### 4.3 Confidence & gates
Per-field then overall (weighted min across capacity/status/location). The original design was **≥0.90 auto-approve · 0.60–0.89 human review · <0.60 "reported."**

> ⛔ **Measured 2026-07-20: that threshold gate is inoperative, and must not be re-specified.** Across all 364 `needs_review` data centers there are exactly **two** distinct confidence values — `0.72` (all news-extracted) and `0.75` (all PeeringDB). Confidence is a per-ingest-path constant, so no threshold discriminates: every cut approves all or none. The active-learning priority `(1-conf)×log1p(mw)` degenerates for the same reason and currently ranks by **capacity alone**.
>
> The queue is two populations, not a continuum. `goldset.sample()` therefore stratifies by **source class** (directory vs news) instead of by confidence. Making confidence a usable control signal would mean deriving it from something that actually varies per record — corroboration count, source-trust spread, extraction agreement — which is unbuilt.

### 4.4 Freshness / staleness
Per-field horizons: power monthly, DC status news-driven (re-verify ≤45 d), supply-chain quarterly (with earnings). `validate_data.py --max-stale-days` flags stale records; **deadband/hysteresis** stops re-verifying on immaterial change (900→905 MW) to avoid churn.

### 4.5 Change & drift detection
Every field change is logged; **status transitions** feed the change feed; **anomaly detection** flags implausible jumps (capacity ×3 overnight) for review.

### 4.6 Reconciliation vs authoritative anchors
Periodically compare to ground truth you don't copy: **EIA generator totals**, **ISO queue counts**, **state DC public trackers** (as a benchmark), and **latest earnings** for every supply-chain node's `$` figure. Divergence beyond tolerance opens a review.

### 4.7 Human-in-the-loop review queue
**Active learning** routes the lowest-confidence, highest-value records to reviewers first (not uniform review). UI **disputes** become verification triggers and `review_log` training data.

### 4.8 Mapped to the loop mechanisms (`docs/loop-mechanisms-catalog.md`)
MAPE-K monitor/analyze on the metrics; a **balancing gate** protects the reinforcing flywheel from error cascade; **requisite variety** = diverse source types + different-vendor verify; **circuit breaker** quarantines a source that starts returning garbage; **anti-windup** caps the review backlog.

### 4.9 SLOs & alerts
Precision/recall vs `gold_set`; freshness lag (median announce→record < 48 h); % confirmed (target ≥ `meta.targets.confirmed_pct`); edge precision; cost per verified record (trending down = flywheel working); source-trust drift. Alert on breach.

---

## 5. Validation cadence

| Source | Pull | Re-verify horizon | Validation trigger |
|---|---|---|---|
| EIA-860M | monthly | monthly | on ingest + monthly reconcile |
| ISO queues | daily | daily | on ingest |
| News (GDELT/RSS) | continuous | n/a | on extract |
| Permits | weekly | on status change | on ingest |
| Earnings (supply chain) | quarterly + 8-K events | quarterly | on filing |
| Satellite (progress) | on-demand | per active build | on dispute / milestone |
| Full `data.json` build | every publish | — | `validate_data.py` gate (CI) |

---

## 6. What ships now vs next

**Now (shipped):** `data.schema.json` + `validate_data.py` — the **nine gates** of §4.1, CI-ready, exit 1 blocks. Run `python -m dcv validate` (or `python3 pipeline/validate_data.py data.json --max-stale-days 45`). Also shipped since this spec was first written: field-level provenance in the store (`Field<T>`, §2.1), the different-vendor cross-verify pass on the delta (`phaseb/verify.py`, re-runnable via `dcv reverify`), the **HITL review queue + U2 dispute wiring** (`review.py`, `POST /api/review` → `review_log` → L2 re-open), and the **gold-set harness** (`goldset.py` — sampler, per-field evidence format, `field_accuracy()`, `certify()`).

**Next:** Great Expectations / dbt tests on the store tables; reconciliation jobs against the §4.6 anchors.

> ⚠️ The gold-set harness exists but the gold set itself is **not populated** — it still holds 7 rows marked `verified_by="demo_seed_bootstrap"`, i.e. the project's own demo seed. A gate derived from the system it gates is not a gate. `certify()` therefore **refuses by default**, and refuses model-transcribed entries too: the pipeline's verifier of record is `claude-opus-4-8`, so Claude attesting to Claude certifies nothing. This needs human signoff to become real, and until it does, the L6 balancing gate on the L4 flywheel is **open**.

---

## 7. Open decisions

1. Store: DuckDB/Parquet (POC) vs Postgres (multi-user, history) — recommend Postgres once `change_log`/`review_log` matter.
2. Field-level provenance storage: JSONB `Field` columns vs a normalized `field_provenance` table.
3. Confidence formula: fixed weights vs learned calibration against the gold set.
4. Entity resolution: rules + alias table now; add embedding match later.
5. How much reconciliation divergence auto-opens a review vs just warns.

---

*Companion: `docs/phase-a-spec.md` (power sources), `docs/phase-b-spec.md` §12b (contract + extraction), `docs/loop-mechanisms-catalog.md` (the validation loops), `docs/loop-engineering-value-chain-proposal.md` (entities/edges/supply chain), `docs/demo-design-spec.md` (the read-model the UI consumes). Runnable: `data.schema.json`, `validate_data.py`.*

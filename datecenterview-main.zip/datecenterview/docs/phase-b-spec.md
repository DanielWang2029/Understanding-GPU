# Phase B — Agentic Data-Center Discovery & Extraction

*Investigation build spec for the dataCenterView project. Phase B is the layer with **no free feed** — it turns the open web into structured `data_center` candidate records with per-field citations. This is the core of the product and CleanView's actual moat, automated. Pairs with `docs/phase-a-spec.md` (power layer) and `docs/datacenterview-architecture-proposal.md` (full pipeline).*

---

## 0. What Phase B is (and isn't)

**Is:** the pipeline that discovers data-center project mentions across news, press releases, and company sites, then **extracts** them into structured records — each field carrying its own source URL + supporting quote. Output = *candidate* records.

**Isn't:** verification, confidence scoring, dedup, and scheduling — that's **Phase C**. Permits + satellite = Phase D. International = Phase E.

**The B↔C boundary (important):** Phase B produces a candidate with raw per-field provenance and a *light self-consistency* score. Phase C runs the **different-vendor adversarial verify**, assigns the final confidence, dedupes/merges into the database, and gates human review. B optimizes for **recall** (find everything); C optimizes for **precision** (confirm what's true). Keeping them separate is what keeps the design honest — the thing that finds a fact never also certifies it.

**Pilot first:** run B on **Texas** (highest data-center growth, clean single-ISO overlap with Phase A), measure precision/recall against a gold set, tune, *then* scale to all states.

---

## 1. Pipeline overview

```
 ┌────────────────────────── DISCOVERY (recall) ──────────────────────────┐
 │  a) Firehose      GDELT 2.0 + curated RSS (DCD, DCF, DCK, ConDive…)     │
 │  b) Agentic search  Exa / Perplexity / Tavily — entity·geo·event queries│
 │  c) Signal handoff  Phase-A BTM candidates · company IR/press pages     │
 └───────────────────────────────┬────────────────────────────────────────┘
                                  ▼   deduped CANDIDATE URL QUEUE
                    ┌─────────────────────────────┐
                    │  FETCH & CLEAN (Firecrawl)  │  URL → clean text + metadata
                    └──────────────┬──────────────┘
                    ┌──────────────▼──────────────┐
                    │  EXTRACT (LLM #1, cheap)    │  text → JSON, 1 quote/field, null if unstated
                    └──────────────┬──────────────┘
                    ┌──────────────▼──────────────┐
                    │  NORMALIZE                  │  entities · geocode · units · status enum
                    └──────────────┬──────────────┘
                    ▼   CANDIDATE RECORD (raw provenance + self-consistency)
              ══════ handoff to PHASE C (verify · confidence · dedup · review) ══════
```

Each stage is independently testable and rate-limited. The candidate queue is the cost-control valve — you decide how many candidates/day flow into the (paid) extraction + verification stages.

---

## 2. Discovery layer

Goal: surface every new or changed data-center project mention, cheaply, with high recall. Three complementary modes:

**a) Firehose monitoring — broad, cheap/free.**
- **GDELT 2.0 DOC API** — free global news index, updates every 15 min. Query by keyword lexicon; returns article URLs + metadata.
- **Curated RSS / news feeds** — DataCenterDynamics, Data Center Frontier, Data Center Knowledge, Construction Dive, utility-commission dockets, and local/regional business journals (where local data-center permits break first).

**b) Targeted agentic search — precision + gap-fill.** Exa / Perplexity / Tavily, three query patterns run on a schedule:
- *Entity-driven:* each known developer/hyperscaler + "data center" (catches the next project from an active builder).
- *Geography-driven:* state/county + "data center" + "MW" / "rezoning" / "special use permit".
- *Event-driven:* "breaks ground", "gigawatt", "campus", "$X billion", "anchor tenant".

**c) Signal handoffs.**
- **Phase-A BTM candidates** — a new large generator with a single off-taker is often a data center; feed those in as leads.
- **Company IR / press pages** — watch the ~40 most active developers' newsrooms directly.
- (Phase D adds permit portals — the earliest signal of all.)

**Keyword lexicon (seed):** `data center, hyperscale, campus, colocation, MW, GW, behind-the-meter, rezoning, special use permit, capex, anchor tenant, AI factory`, + the developer/hyperscaler name list.

**Output:** a **deduplicated candidate URL queue** (dedupe on canonical URL + normalized title hash), rate-limited into extraction.

---

## 3. Fetch & clean

**Firecrawl** (or self-hosted Playwright) → clean markdown/text + metadata (publisher, publish date, canonical URL, `retrieved_at`). Rules:
- **Paywalls:** never bypass. Use the visible snippet/metadata and flag `paywalled: true` (lower confidence, still a lead).
- Strip nav/boilerplate; keep body + any spec tables.
- Respect robots.txt / per-site ToS.

---

## 4. Extraction layer

**Model:** a cheap extraction LLM (Grok 4.20 non-reasoning / Claude Haiku) via **structured output / tool-calling** bound to a strict JSON schema (§11).

**Extraction rules (enforced in the prompt + validator):**
- Extract **only explicitly stated facts.** Never infer, estimate, or fill from world knowledge.
- For **every populated field**, capture `value` + a **supporting quote** from the source + the source URL.
- Use `null` when a field isn't stated — null is a valid, expected answer.
- **One article can contain many projects** (roundups) → return an array.
- Normalize units at extraction: `$10 billion → 10000000000`, `1.2 GW → 1200 MW`, parse sqft/acres.

**Guardrails (post-extraction validator):**
- Schema-validate; enforce `status` and `technology` enums.
- Reject a record with no `project_name` or no location.
- Reject any numeric field lacking a supporting quote (kills hallucinated capacities).
- Compute `self_consistency` (0–1) from: numbers explicitly quoted, internal agreement, source recency/type.

**Output:** a candidate `data_center` record with **field-level raw provenance** — ready for Phase C, not yet trusted.

---

## 5. Normalization (the unglamorous 30%)

- **Developer canonicalization:** alias map collapses "Amazon" / "AWS" / "Amazon Web Services" → one entity; maintain the map as an artifact.
- **Geography:** county + state → US Census geocoder (free) → centroid lat/lng + `geo_precision` (`exact` only if a street address is given).
- **Status → lifecycle enum:** `proposed, permitted, under_construction, operating, cancelled, on_hold` (map press phrasing: "plans / proposed" → proposed; "broke ground / under construction" → under_construction; "online / operational" → operating; "scrapped / withdrawn" → cancelled).
- **Identity key** for downstream dedup (Phase C): `normalize(project_name) + county + state + developer`, with `aka[]` aliases captured (e.g. *Stargate = Lancium Abilene*).

---

## 6. The candidate record B emits

```jsonc
{
  "_candidate": true,
  "identity_key": "stargate-i|taylor|tx|crusoe-energy",
  "aka": ["Lancium Abilene"],
  "project_name": "Stargate I (Abilene)",
  "developer":  { "value": "Crusoe Energy", "quote": "developed by Crusoe…", "source": "url", "extracted_at": "2026-07-13" },
  "tenant":     { "value": "Oracle", ... },
  "end_user":   { "value": "OpenAI", ... },
  "status":     { "value": "under_construction", ... },
  "capacity_mw":{ "value": 1200, "quote": "up to 1.2 GW across eight buildings", "source": "url" },
  "cap_ex_usd": { "value": 11600000000, ... },
  "building_sqft": { "value": null },
  "land_acres": { "value": 1150, ... },
  "location": { "county": "Taylor", "state": "TX", "country": "US",
                "lat": 32.45, "lng": -99.73, "geo_precision": "county" },
  "btm_generation": { "value": true, ... },
  "sources": [ {"url":"…","publisher":"DCD","published":"2026-…","paywalled":false} ],
  "extraction_model": "grok-4.20-0309-non-reasoning",
  "self_consistency": 0.78,
  "review_status": "candidate"          // Phase C moves this to approved/needs_review/reported
}
```

---

## 7. Handoff to Phase C

B delivers the candidate; C decides truth. Explicitly, **C** (spec'd separately) will:
1. Re-search each key field (`capacity_mw`, `status`, `location`) with a **different-vendor** model → agreement raises confidence, conflict flags it.
2. Assign `overall_confidence` = weighted-min across the three critical fields.
3. Dedupe/merge against the DB on `identity_key` (+ fuzzy name/geo), updating provenance and lifecycle.
4. Gate: **≥0.90 auto-approve · 0.60–0.89 human review · <0.60 hold as "reported."**
5. Emit to the change feed and the explorer via `data.json → datasets.data_center`.

---

## 8. Evaluation — the Texas pilot

Don't scale until B clears thresholds on Texas:

| Metric | Definition | Target (v1) |
|---|---|---|
| **Recall** | found ÷ gold-set projects | ≥ 0.80 |
| **Precision** | correct records ÷ extracted | ≥ 0.90 |
| **Field accuracy** | capacity/status/location correct | ≥ 0.85 |
| **Freshness lag** | announcement → record in DB | < 48 h (major) |
| **Dup rate** | duplicate records surviving | < 5% |
| **Cost / verified record** | spend ÷ confirmed | cents |

Build a **~100-project hand-verified Texas gold set** first (partly seeded from the current explorer + CleanView's public TX tracker for names only — never their data). Tune prompts, sources, and the keyword lexicon against it, then scale state-by-state.

---

## 9. Cost (Phase B in isolation)

B is the cheap half: per candidate = 1 discovery hit + 1 Firecrawl fetch + 1 cheap extraction. At ~1,500 candidates/mo ≈ **$10–30/mo** (GDELT/RSS are free; extraction on Grok 4.20 (non-reasoning) is ~$1; Firecrawl Hobby covers the pages). The expensive half is Phase C's cross-verification. Discipline: **process only new/changed candidates**, cache aggressively, cap the queue, alert on spend. Full model in the architecture proposal §7.

---

## 10. Quirks & gotchas (carry into the build)

- **The same project is announced many times** — dedupe across articles on `identity_key`; the first sighting sets `announced_date`.
- **Aspirational vs permitted capacity** — PR rounds up; keep the quote, let confidence reflect it.
- **Campus vs building vs phase** — a "campus" (e.g. Stargate, 8 buildings) is the parent; model phases as children or annotate, or capacity double-counts.
- **Rebrands / code names** — Stargate = Lancium Abilene; Crane = Three Mile Island Unit 1 → `aka[]`.
- **Tenant / end-user often undisclosed** — null now, back-fill later; don't guess.
- **Paywalls** — metadata only, flag it, never bypass.
- **Non-US noise** — filter to US in Phase B (international is Phase E).
- **Hallucinated specifics** — the "quote required for every number" rule is the main defense.
- **Rate/cost limits** on search + scrape — queue + backoff.

---

## 11. Appendix — extraction schema & prompt sketch

**JSON schema (extract target):** `project_name (req), aka[], developer, operator, tenant, end_user, status (enum), capacity_mw, capacity_mwh, building_sqft, land_acres, cap_ex_usd, btm_generation (bool), power_sources[], location{county,state,country,address?}, announced_date, operating_year` — every value object also carries `{quote, source_url}`.

**Extraction system prompt (sketch):**
> You extract US data-center project facts from the article below. Return JSON matching the schema. Rules: (1) Only facts explicitly stated in the text. (2) For every non-null field include a short verbatim `quote` and the `source_url`. (3) If a field isn't stated, return null — do not guess or use outside knowledge. (4) If the article covers multiple projects, return an array. (5) Normalize units (GW→MW, "$X billion"→number). (6) Map status to the enum. Do not invent capacities, dates, or locations.

**Example:** input = the Crane/Three Mile Island article → output = one record with `status: under_construction`, `capacity_mw: 835` (quote: "…deliver 835 megawatts…"), `technology: Nuclear`, `end_user: Microsoft`, `location: Dauphin, PA`, each with its source URL.

---

## 12. How it feeds the app

Approved records (post-C) flow into the explorer via `data.json → datasets.data_center`, each rendered with a **confidence badge** and its **source links** (the `source_1/2/3` pattern the prototype already mimics). New/changed records populate a **change feed**. Net effect on the demo: the seeded sample rows become hundreds of auto-discovered, cited, confidence-scored rows — with no UI change, since every view is a pure function of `data.json`.

---

## 12b. News, reports & the UI data contract *(added from demo feedback)*

Prototyping surfaced a class of bug — hand-typed news items whose title/date/URL drifted apart, and a developer chart hardcoded instead of computed. Both point to one rule: **nothing in the UI is hand-authored; every panel is a pure function of the pipeline's output.** Concretely:

- **News & reports are first-class extracted records**, produced by the same discovery→extraction pipeline as projects. Each carries `{title, publisher, published_date, canonical_url, summary, entities[]}` with provenance. Title, date, and URL travel together and are **never paraphrased apart from the source** — that is exactly what eliminates the mismatch bug.
- **News ↔ project linkage:** extraction tags which project(s)/developer(s) each article mentions, creating a join. Enables "click a project → see every article about it" and the reverse — a real feature that hand-typed items can't support.
- **Single UI data contract (`data.json`):** the pipeline emits one normalized file — `{ meta, datasets{ data_center[], power_project[], news[] }, entities[], edges[], feeds[], supply_chain{nodes,links} }` — and the dashboard *loads* it rather than embedding arrays. This is the seam between ingestion and view; version it with the schema. (The demo already realizes this full shape — see `docs/demo-design-spec.md`.)
- **Everything derived, nothing hardcoded:** KPIs, developer rankings (`GROUP BY developer`), geo aggregates, and filters are all computed from the dataset at render time. No static numbers that can fall out of sync.
- **Provenance is visible:** each record renders its sources, a confidence badge, and `last_verified`; "confirmed" (≥0.9) and "reported" (<0.6) look different; a top-level "as of" freshness stamp and a change feed complete the trust surface.
- **Layer registry:** datasets/layers are declared in config (dc · power · btm · news · later international) so adding a layer or a country is configuration, not code surgery.
- **Supplier edges (supply chain):** the same extractor can capture *who supplies what* — chips (Nvidia/AMD/Broadcom), servers (Dell/Supermicro/Foxconn), networking (Arista), power/cooling (Vertiv/Eaton/CoolIT) — as typed `supplies` edges feeding `supply_chain{}`. Public disclosures make per-project supplier links a natural extension (e.g. Stargate = Nvidia GB200 via Oracle; xAI Colossus = Supermicro + Dell + Nvidia; Meta = Nvidia + in-house MTIA). The demo's supply-chain Sankey already renders this layer at the market level; per-project supplier edges are the Phase B/C add.

---

## 13. Open decisions for the build

1. Start search vendor: **Exa** (cheap neural search) vs **Perplexity Sonar** (cited synthesis)?
2. Discovery v1: GDELT firehose + RSS only, or add agentic search immediately?
3. Extraction: which cheap model + which structured-output method (tool-calling vs JSON mode)?
4. Campus/phase data model (parent-child vs flat + annotation).
5. How much dedupe merging is automated vs left to human review in C.

---

*Design references established sources used earlier in this project: GDELT 2.0 (free global news), DataCenterDynamics / Data Center Frontier / Data Center Knowledge / Construction Dive (trade press), Exa·Perplexity·Tavily (search APIs), Firecrawl (scrape). Pricing in the architecture proposal, verified July 2026.*

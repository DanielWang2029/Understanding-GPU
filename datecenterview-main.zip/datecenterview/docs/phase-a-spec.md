# Phase A — Source Spec & Unified Schema

*Investigation deliverable for the dataCenterView project. This is a **build spec**, not running code — it gives a future Claude Code session everything needed to wire up the free structured layer. Source access verified July 2026.*

---

## 0. What Phase A is (and isn't)

**Is:** the free, structured **power-infrastructure** layer — EIA-860M (every US generator) + the 7 ISO interconnection queues (every proposed generation/storage project). Fully automatable, $0, no scraping, no legal ambiguity.

**Isn't:** a data-center feed. EIA and the ISO queues list **power projects**, not data centers. Phase A therefore adds a *new layer* to the dashboard — grid context + a **behind-the-meter (BTM) signal** for generation likely tied to a data center — and does **not** by itself grow the data-center count. That count grows in Phases B–C (agentic news/permits) and from PeeringDB.

**Relationship to the existing app:** `datacenterview-explorer.html` currently holds one dataset (`DC[]`, hand-curated data centers). Phase A introduces a second dataset, `POWER[]`, sharing a common location/geo model so both render on the same map/table with a layer toggle. See §6.

---

## 1. Source map (verified access points)

| Source | What | Endpoint / file | Format | Cadence | Auth |
|---|---|---|---|---|---|
| **EIA-860M** | All US generators (operable + planned + retired) | `https://api.eia.gov/v2/electricity/operating-generator-capacity` | JSON | Monthly | Free API key |
| **ERCOT** | TX queue (GIS Report) | MIS report id `15933` / Resource Adequacy page | XLSX | Monthly | Public portal login |
| **CAISO** | CA/NV/AZ queue | `https://www.caiso.com/documents/publicqueuereport.xlsx` | XLSX | ~Daily | None |
| **MISO** | Midwest/South queue | `https://www.misoenergy.org/api/giqueue/getprojects` | **JSON** | ~Daily | None |
| **SPP** | Central queue | `https://opsportal.spp.org/Studies/GenerateSummaryCSV` | CSV | ~Daily | None |
| **PJM** | Mid-Atlantic queue | Planning Center "New Services Queue" / Queue Scope | XLSX/tool | ~Daily | None |
| **NYISO** | NY queue | `https://www.nyiso.com/documents/20142/1407078/NYISO-Interconnection-Queue.xlsx` | XLSX | Monthly | None |
| **ISO-NE** | New England queue | Interconnection Request Queue (IRTT) | XLSX/PDF | ~Monthly | None |

### ⭐ Recommended shortcut — don't write 7 parsers

**[gridstatus](https://opensource.gridstatus.io/)** (open-source Python) already fetches and **normalizes all 7 ISO queues + EIA** into a single schema. It abstracts each ISO's format drift, portal quirks, and column differences. Baseline the build on gridstatus and only drop to raw endpoints where you need a field it drops.

Alternates for cross-checking: **interconnection.fyi** (daily-updated standardized queues) and **LBL Energy Markets & Policy** (annual research datasets).

---

## 2. EIA-860M endpoint detail

Base call:
```
GET https://api.eia.gov/v2/electricity/operating-generator-capacity
      ?api_key=KEY
      &frequency=monthly
      &data[]=nameplate-capacity-mw&data[]=net-summer-capacity-mw
      &facets[stateid][]=TX
      &facets[balancing_authority_code][]=ERCO
      &sort[0][column]=period&sort[0][direction]=desc
      &offset=0&length=5000
```
Quirks the build must handle:
- **5,000-row cap** per request (300 for XML) → paginate with `offset`/`length`.
- **Rate limits** → throttle; key auto-suspends briefly if exceeded.
- Endpoint is the API-v2 form of the monthly generator inventory (EIA-860M); a keyless **bulk file** also exists as a fallback.
- Facets available: `stateid`, `balancing_authority_code`, `energy_source_code`, `sector`, `status`, `prime_mover_code`.

Field set (confirmed against Cleanview's own docs, which use this source): `plant_id, plant_name, plant_state, county, latitude, longitude, entity_name, generator_id, nameplate_capacity_mw, net_summer_capacity_mw, energy_source_code, technology, prime_mover_code, status, operating_year/month, retirement_year/month, balancing_authority_code, sector`.

---

## 3. Unified schema — `power_project`

Normalize every EIA + ISO record into this shape. Designed to **coexist** with the `data_center` record (shared keys in **bold**).

```jsonc
{
  "id": "eia-66659-MAL",              // {source}-{natural key}
  "dataset": "power_project",          // vs "data_center"
  "source": "EIA-860M",                // EIA-860M | ERCOT | CAISO | ...
  "source_ref": "plant_id=66659;gen=MAL",
  "project_name": "Acid BESS",         // **shared**
  "developer": "Malaga BESS LLC",      // **shared** (entity_name / queue sponsor)
  "technology": "Battery",             // normalized enum (see §4)
  "energy_source_code": "MWH",         // EIA raw code, kept for traceability
  "capacity_mw": 97,                   // **shared** (nameplate)
  "capacity_mwh": 97,                  // storage only
  "status": "operating",               // **shared** normalized enum (see §4)
  "status_raw": "(OP) Operating",
  "operating_year": 2025,              // **shared**
  "location": {                        // **shared** geo model
    "county": "Fresno", "state": "CA", "country": "US",
    "lat": 36.69, "lng": -119.74, "geo_precision": "exact"
  },
  "balancing_authority": "CISO",
  "btm_datacenter_signal": false,      // see §5
  "last_verified": "2026-07-13"
}
```

---

## 4. Normalization maps (the real work)

Each ISO uses different column names, technology labels, and status vocabularies. Two lookup tables make the data uniform:

**Technology** — map EIA `energy_source_code` and each ISO's fuel label → one enum: `Solar, Wind, Battery, NaturalGas, Nuclear, Coal, Hydro, Geothermal, Hybrid, Other`.
(EIA: SUN→Solar, WND→Wind, MWH→Battery, NG→NaturalGas, WAT→Hydro, GEO→Geothermal, BIT/SUB→Coal, NUC→Nuclear.)

**Status** — collapse each source's vocabulary → lifecycle enum: `proposed, permitted, under_construction, operating, cancelled, retired, on_hold`.
(EIA: OP→operating, (P)/planned→proposed, RE→retired. ISO queues: "active/feasibility/facilities study" → proposed; "IA executed / under construction" → under_construction; "withdrawn" → cancelled; "in service" → operating.)

**Field mapping (abbreviated):**

| Unified | EIA-860M | ISO queue (typical) |
|---|---|---|
| project_name | plant_name | Project Name / Unit Name |
| developer | entity_name | Interconnection Customer / Sponsor |
| capacity_mw | nameplate_capacity_mw | Capacity (MW) / MW Max |
| technology | ← energy_source_code map | ← fuel-type map |
| status | ← status map | ← queue-status map |
| location.county/state | county / plant_state | County / State |
| lat/lng | latitude / longitude | *usually absent* → geocode from county |
| balancing_authority | balancing_authority_code | (implied by ISO) |
| source_ref | plant_id + generator_id | Queue ID / Position |

> ISO queue rows rarely carry lat/lng — geocode from county centroid (US Census, free) and set `geo_precision: "county"`.

---

## 5. Behind-the-meter data-center signal (the useful bridge)

EIA/ISO don't name data centers, but a subset of new generation is being built **to power one**. Flag `btm_datacenter_signal = true` when a record matches heuristics such as:
- Large (>100 MW) **new** gas or solar+storage with a **single non-utility off-taker** / `sector = IPP`;
- Interconnection marked behind-the-meter or "co-located load";
- Developer/entity or county matches a known data-center campus in `DC[]`;
- Sudden large load-plus-generation in a county with active DC permits.

Treat this as a **candidate signal for the agentic layer to confirm**, never as truth. It's a cheap way to surface unannounced data-center power deals from free data — a piece of CleanView's edge, for free.

---

## 6. How this extends `datacenterview-explorer.html`

Minimal, backward-compatible changes for the future build:
1. Add `dataset` field to every record (`"data_center"` | `"power_project"`); keep the existing `DC[]` as-is.
2. Add `POWER[]` populated from Phase A; both arrays share the same render path (map marker + table row) because the geo/name/capacity/status keys align.
3. **UI:** add a top-level layer toggle (Data Centers · Power Projects · BTM-linked) and a `technology` filter alongside the existing state/status/developer filters.
4. Add provenance columns (`source`, `last_verified`) — already implied by the architecture proposal's field-level model.
5. Color/shape: keep status colors; use marker **shape** for dataset (circle = data center, triangle = generator) so both can coexist on one map.

No rewrite — it's an additive layer on the current prototype.

---

## 7. Refresh & provenance

| Source | Pull cadence | Natural key for upsert |
|---|---|---|
| EIA-860M | Monthly | plant_id + generator_id |
| ISO queues | Daily (via gridstatus) | ISO + queue_id |

Every record stores `source`, `source_ref`, and `last_verified`. Status changes over time feed the **change feed** (Phase C). A generator often appears first in a queue (proposed) and later in EIA (operating) — link them via name+geo+capacity so the lifecycle is one row, not two.

---

## 8. Known gotchas (carry into the build)

- **EIA 5,000-row pagination** + rate limits.
- **ERCOT** requires a public-portal login for direct GIS files → gridstatus handles it; otherwise script the session.
- **Capacity definitions differ** (nameplate vs net summer/winter vs queue MW-max) — pick nameplate as canonical, keep others.
- **Status vocabularies** are per-ISO — the §4 map is mandatory, not optional.
- **Cross-source duplicates** (same project in queue *and* EIA) — dedupe on name+geo+capacity.
- **Planned projects lack coordinates** — county-centroid geocode, mark precision.
- **Column drift**: ISOs change queue columns without notice → prefer gridstatus, add schema validation + alert on unmapped columns.

---

## 9. Open decisions for the build

1. Store: DuckDB/Parquet (analytics-friendly, file-based) vs Postgres (if multi-user/live). Recommend DuckDB for the POC.
2. gridstatus as the sole ingestion path, or gridstatus + raw fallback for dropped fields?
3. Scope of the BTM heuristic in v1 (simple rules) vs deferring to the agentic verifier.
4. Do we ingest all technologies, or filter to those most relevant to data-center power (gas, solar, storage, nuclear) for v1?

---

*Sources: [EIA API v2 docs](https://www.eia.gov/opendata/documentation.php) · [EIA operating-generator-capacity](https://www.eia.gov/opendata/browser/electricity/operating-generator-capacity) · [ERCOT GIS Report](https://www.ercot.com/mp/data-products/data-product-details?id=PG7-200-ER) · [CAISO queue reports](https://www.caiso.com/library/interconnection-queue-reports) · [MISO GI queue](https://www.misoenergy.org/planning/resource-utilization/GI_Queue/) · [gridstatus](https://opensource.gridstatus.io/en/latest/interconnection_queues.html) · [interconnection.fyi](https://www.interconnection.fyi/). Verified July 2026.*

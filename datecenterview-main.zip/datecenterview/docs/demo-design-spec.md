# Demo Design Spec — `datacenterview-explorer.html`

*The design of the demo page: information architecture, per-view layout, the cross-view interaction model, the multi-source newsfeed, and the `data.json` contract that drives everything. This is the reference for evolving the prototype and for the eventual Claude Code build's front end.*

> **Layout update (2026-07):** the layout has been refined in **both** the Next.js `web/` app and the standalone `datacenterview-explorer.html` prototype — all content is **centered in a max-width column** (header, tabs, KPI row, cards), the Overview **A–E phase strip** and the provenance **footer** were removed (phase/status still live in the How-it-works Roadmap), the Explorer **filters moved to a centered top bar** with a **full-width map + table**, and the data-center **table renders at full length** (the page scrolls; no fixed-height scrollbox). The per-view descriptions below reflect this current design.

---

## 1. Principle — one contract drives every view

The page is a **pure function of `data.json`**. Nothing is hand-authored in the markup: KPIs, the flow charts, the value-chain summary, the newsfeed, the control panel — all computed at render time from the loaded data. Change the data file and the whole UI repopulates. This is what keeps the demo and the specs from drifting apart, and it's the same discipline the production app uses (the pipeline emits `data.json`; the UI consumes it).

**Loading:** production fetches `data.json` from the API. For the offline demo, `data.js` (auto-generated from `data.json`) assigns `window.DCV_DATA` so the page works on a double-click without a server.

---

## 2. Information architecture — 4 views

| View | Purpose |
|---|---|
| **Overview** | Three charts: **Market flow** (Sankey, 2 lenses) · **AI supply chain** (Sankey) · **Project value chain** (role-flow) — plus a centered KPI row |
| **Explorer** | Filter records + map/table; drill into one via the **detail drawer** |
| **Newsfeed** | Multi-source reader with project linkage |
| **How it works** *(hidden for now)* | Loops, control panel, data sources, roadmap, capabilities — still in code, tab removed |

---

## 3. View: Overview

**Layout:** centered KPI row → three stacked full-width cards: **Market flow** (Sankey, with a lens dropdown) → **AI supply chain** (Sankey) → **Project value chain** (role-flow, with a project selector). *(No pipeline funnel or provider-mix bar chart — both were removed as redundant with the Sankeys. The A–E phase strip was also removed from the Overview — redundant with the How-it-works Roadmap.)*

- **Chart 2 — Market flow (aggregate Sankey, two lenses):** a **flow-by** dropdown switches the downstream dimensions — **Status → region** (where capacity/capital concentrates) or **Value chain: developer → compute provider → end-user** (aggregated across the mapped chains) — plus a **MW / Capex $** metric toggle. Developer type is always the left column; clicking it explores. The aggregate value-chain view lives here as a *lens* — it's the same kind of chart as the status→region view, so it's not a separate chart.
- **Chart 3 — AI data-center supply chain (end-to-end Sankey):** the full stack left→right — **foundry/HBM → accelerators → servers/networking → power/cooling → operators → end-users**. Nodes are real companies (TSMC, SK Hynix, Nvidia, AMD, Broadcom, Dell, Supermicro, Foxconn, Arista, Vertiv, Eaton, CoolIT, …) sized by approximate annual AI/DC revenue (from earnings, shown on hover); flows are illustrative. Powered by `data.json → supply_chain{nodes,links}`. This is the "Bloomberg terminal" end-to-end view.
- **Chart 1 — Project value chain (role-column flow, *not* a Sankey):** a pure **drill-down** read as **who builds/powers → the project → who runs/consumes**, led by an **auto-generated plain-English summary** (e.g. *"Crusoe develops it, operated by Oracle, serving OpenAI; powered by Crusoe"* or *"Meta builds, operates and consumes Hyperion itself — a hyperscaler self-build"*). Each organization appears **once** with its role tag(s) — so a self-build shows one *Meta*, not four — colored by provider category, with per-participant confidence + source; click an org to explore. A Sankey was rejected here: at single-project scale its ribbon widths encode nothing, so a labeled role layout reads clearer. (The *aggregate* value chain is a lens of Chart 2.) Note: the Overview charts sit at different scopes (aggregate market · aggregate supply · single-project chain), so selecting a project does **not** force the others to reflect it — per-project supply-chain reflection waits on v1.0 supplier edges; drill-down happens via org clicks + the Explorer drawer.
Charts 2 & 3 render with **d3-sankey**; Chart 1 is dependency-free HTML. (The standalone compute-provider-mix bar chart was removed — it duplicated the market-flow Sankey's developer-type column, which is itself click-to-explore.)

**Interactions:** a Market-flow developer-type node → Explorer filtered to that provider category; a Project-value-chain org card → Explorer searched to that org; news project chips → the relevant project. (No "chain ↗" table link — the chain lives in the Explorer detail drawer, which deep-links back here via "see the flow ↗".)

---

## 4. View: Explorer

**Role vs Overview (no duplication):** Overview *visualizes* (aggregate Sankeys + the project role-flow); Explorer *investigates* (screen records, then deep-dive one). Explorer draws nothing Overview already draws — where they'd overlap (the value chain) the detail drawer shows a compact linked list and **deep-links** to Overview. Both are pure functions of the same read-model.

**Layout:** a centered **Filters** bar across the top → **Map + Table** full-width below · plus a slide-in **detail drawer** (right overlay).

- **Filters (top bar):** a centered horizontal row — dataset segment (Data Centers / Power / ⚡ BTM), search, state, status, developer or technology, **provider type** (developer category), and min-capacity. Provider-type is the single categorical control — clicking a provider node in Overview sets this dropdown, so there's exactly one place to filter by category.
- **Map + Table:** MapLibre + OSM, **full-width**; markers circles (data centers) / triangles (generators), colored by status, **faded when "reported."** The **Provenance** cell shows confidence badge + source count + **freshness age**. The table renders at **full length** (page scroll, no fixed-height box). Clicking a **project name** (or its map marker) opens the detail drawer.
- **Detail drawer (the deep dive):** click a project → a right overlay with **Fields**, **Provenance & freshness** (confidence, `last_verified` age, independent-source count with the "needs ≥2 to confirm" rule), **typed & trust-weighted Sources** (gov/SEC/permit/trade-press/company/research, weight inferred from domain), a **Status timeline** (v1.0 placeholder), a **compact Value chain** (+ "see the flow ↗" deep-link, *not* a second Sankey), a **Supply chain** placeholder, and a **Flag/dispute** button (human-in-the-loop → review queue). Field-level provenance, `status_history`, `change_log`, and per-project suppliers light up as v1.0 populates — the drawer already has the slots.
**Interactions:** click a project name → detail drawer; **chain ↗** / "see the flow ↗" → Overview (deep-link, no re-draw). (The computed Players rollups were removed — that ranking is available via the Market-flow Sankey's value-chain lens in Overview; Explorer stays focused on record-level screening + drill-down.)

---

## 5. View: Newsfeed (multi-source)

**Layout:** source **chips** (All + one per feed, with counts) → search box → the **feed**, full-width. *(The standalone Feeds-registry sidebar was removed — the chips already expose every source with counts.)*

- Items are sorted newest-first, each showing its **source feed**, **published date**, headline, a type/tag badge, **↔ project-link chips**, and a read link.

**Multi-source design:** the feed is driven by a pluggable **`feeds[]` registry** in `data.json`, and each news record carries a `source_feed` id. In the demo, items come from `data.json` (so it opens offline). In production the same UI is fed by live fetchers — **GDELT API + publisher RSS + a search API** — behind the identical registry.

> Caveat: browsers block direct cross-origin RSS, so a *live-fetching* build needs a small proxy/backend (or the Cowork-artifact fetch path). The layout and data shape are identical either way — only the fetch layer changes.

**Interaction:** source chip → filters the feed; project chip → jumps to that project (Chain if it's a flagship chain, else Explorer).

---

## 6. View: How it works *(currently hidden — tab removed, view still in code)*

**Layout:** a loop/pipeline flow diagram; then three cards — **Control panel** (computed: confirmed %, target precision, freshness target, in-review count, as-of), **Active-learning queue** (the lowest-confidence records, i.e. what a reviewer should tackle first), **Roadmap** (phases from `meta.phases`); then two cards — **Data sources** and **Who builds it** (capabilities summary).

Everything numeric here is computed from the data + `meta.targets`, so the "control panel" reflects the actual dataset, not static copy.

---

## 7. Cross-view interaction model

A light shared-selection model ties the views together:

- **`goProject(id)`** — select a project's chain (Overview). Falls back to a name search in Explorer if the project has no chain edges.
- **`goName(name)`** — Explorer, searched to an organization.
- **`goCategory(cat)`** — Explorer (data-center mode), setting the **Provider type** filter dropdown to that category.

Entry points: market-Sankey developer nodes, project-value-chain org cards, the detail drawer's "see the flow ↗", and news project chips all route through these three functions. That's what makes Overview and Explorer feel like one connected surface rather than separate tabs.

---

## 8. The `data.json` contract (current shape)

```jsonc
{
  "generated_at": "2026-07-13",
  "schema_version": "0.1",
  "meta": {
    "us_data_center_total": 2950, "us_power_project_total": 14000,
    "phases": [ {"id":"A","label":"…","status":"live|spec|designed|outlined"} ],
    "targets": { "precision":0.90, "freshness_hours":48, "confirmed_pct":0.75 }
  },
  "datasets": {
    "data_center":  [ { …, "developer_category":"neocloud", "confidence":0.9,
                        "review_status":"approved", "last_verified":"…", "sources":[…] } ],
    "power_project":[ { …, "technology":"Natural Gas", "btm":true, "linked":"Meta Hyperion",
                        "developer_category":"utility", "confidence":…, "sources":[…] } ],
    "news":         [ { "id":"n1","type":"news|report","title":"…","publisher":"…",
                        "published_date":"…","url":"…","tag":"…",
                        "source_feed":"dck","projects":["meta-hyperion"] } ]
  },
  "entities": [ { "id":"crusoe","name":"Crusoe Energy","category":"neocloud" } ],
  "edges":    [ { "project":"stargate-i","org":"crusoe","relation":"develops",
                  "confidence":0.9,"sources":[…] } ],
  "feeds":    [ { "id":"dcd","name":"Data Center Dynamics","type":"rss" } ],
  "supply_chain": { "nodes":[ { "id":"nvidia","label":"Nvidia","category":"gpu","rev":193.7,"note":"…" } ],
                    "links":[ { "source":"nvidia","target":"dell","value":26,"title":"Nvidia → Dell" } ] }
}
```

Relations: `develops · operates · leases_to · serves · powers · provides_compute`.
Provider categories: `hyperscaler · neocloud · wholesale_colo · retail_colo · developer · utility · enterprise · ai_lab · other`.

---

## 9. Extension points (swapping in the real pipeline)

- **More records:** append to `datasets.*`; all views scale automatically.
- **The chain at scale:** the production extractor emits `entities[]` + `edges[]` with per-edge provenance; the Chain view already renders any project that has edges. Add a provider classifier to populate `entity.category`.
- **Live news:** replace the seeded `news[]` with live fetchers keyed to the same `feeds[]` registry + `source_feed` field.
- **Confidence:** today's values are illustrative; Phase C's verification loop produces them for real. The UI already renders confirmed/reported and the active-learning queue off `confidence`.
- **Graph rendering:** the **Market flow** and **Supply chain** are d3-sankey (pure functions of `datasets` / `supply_chain`); the **Project value chain** is dependency-free HTML built from `edges[]` (role-grouped cards + an auto-generated summary sentence, self-build entities collapsed). Change a lens/metric or the summary logic in the builder only.

---

## 10. Build notes & limits

- Single self-contained file + `data.js`; external deps are MapLibre GL (map) and d3 + d3-sankey (the two Sankeys), all CDN, plus keyless OSM tiles. The project value-chain, tables, filters, drawer, and newsfeed are dependency-free.
- Sample data is source-attributed but **not exhaustive**; labels say so.
- Live cross-origin RSS needs a proxy/backend (see §5).
- Verified July 2026: JS clean; 4 views · 21 data centers + 16 power projects · 17 entities · 23 edges (6 chains) · 8 feeds · 24 supply-chain nodes; `validate_data.py` passes.

---

*Companion: `CLAUDE.md` (index), `docs/phase-a-spec.md` / `docs/phase-b-spec.md` (build specs, incl. §12b data contract), `docs/loop-engineering-value-chain-proposal.md` (the chain + loops this UI expresses), `docs/loop-mechanisms-catalog.md`, `docs/capabilities-and-roles.md`.*

# Capabilities & Roles

*What it takes to build and run dataCenterView. This project is investigation output for a **Claude Code-assisted build**, so this note maps the **capabilities** the work requires (not a heavy org chart) and is explicit about **what the agent carries vs what humans must own**. The headline: a small team — even one strong generalist plus Claude Code — can reach a real Phase A+B product, because the specs are written so the agent supplies most of the engineering. Humans supply direction, domain judgment, verification, and taste.*

---

## 1. The ten capability areas

For each: scope · why it matters · where it's load-bearing · agent leverage (**High** = Claude Code does most of it; **Med** = agent drafts, human steers; **Low** = human-owned judgment).

| # | Capability | Scope | Agent leverage |
|---|---|---|---|
| 1 | **Data engineering & the contract** | Schema, DuckDB/Postgres, the `data.json` contract, upserts, dedup/entity resolution, refresh jobs | **High** |
| 2 | **Source integration** | EIA API, ISO queues (`gridstatus`), Firecrawl, Exa/Perplexity/Tavily; rate limits, pagination, ToS handling | **High** |
| 3 | **LLM / agent engineering** | Structured extraction, tool-calling, prompt design, multi-model verification, RAG plumbing | **High** |
| 4 | **Evaluation & data quality** | Gold sets, precision/recall, confidence **calibration**, regression gates | **Med** (agent runs evals; human defines "correct") |
| 5 | **Loop / control-systems thinking** | Wiring the mechanisms — MAPE-K, active learning, deadband, requisite variety — instead of ad-hoc rules | **Low–Med** (design is human; implementation is agent) |
| 6 | **Entity resolution & graph modeling** | The value chain: `entities[]` + typed `edges[]`, provider classification, alias/dedup | **Med** |
| 7 | **Data-viz & product/UX** | Data-driven dashboard, map, chain view, the provenance/trust surface | **High** |
| 8 | **Domain expertise** | Power markets (ISO/EIA, BTM), data-center industry, the provider taxonomy | **Low** (judgment; agent assists research) |
| 9 | **Cost / FinOps & orchestration** | Delta-only processing, caching, budget governor, scheduling, spend alerts | **Med** |
| 10 | **Legal / compliance & governance** | ToS/robots, licensing, "don't copy CleanView," PII (contacts), source retention | **Low** (human-owned) |

The pattern: the **engineering-heavy** capabilities (1, 2, 3, 7) are exactly what Claude Code does well. The **judgment-heavy** capabilities (5, 8, 10) and the **definition of truth** (4) are where humans are irreplaceable.

---

## 2. Capability → phase map

Which capabilities are load-bearing in each phase (● primary · ○ supporting).

| Capability | A (power) | B (discover/extract) | C (verify/trust) | D (edge) | E (intl) |
|---|:--:|:--:|:--:|:--:|:--:|
| 1 Data engineering | ● | ● | ● | ○ | ● |
| 2 Source integration | ● | ● | ○ | ● | ● |
| 3 LLM/agent eng. | ○ | ● | ● | ● | ● |
| 4 Eval & quality | ○ | ● | ● | ○ | ● |
| 5 Loop/control | ○ | ○ | ● | ● | ○ |
| 6 Entity/graph | | ● | ● | ○ | ● |
| 7 Data-viz/product | ● | ○ | ● | ○ | ○ |
| 8 Domain | ○ | ● | ● | ● | ● |
| 9 Cost/orchestration | ○ | ● | ● | ● | ● |
| 10 Legal/governance | ○ | ● | ○ | ● | ● |

---

## 3. Capability → loop-mechanism map

Links the capabilities to the mechanisms in `docs/loop-mechanisms-catalog.md`.

| Loop mechanism | Owning capability |
|---|---|
| MAPE-K ingestion controller | 1 Data eng + 3 Agent eng |
| Maker-checker + **requisite variety** | 3 Agent eng + 5 Loop thinking |
| Active learning (uncertainty sampling) | 4 Eval + 5 Loop |
| Deadband / hysteresis (freshness) | 1 Data eng + 5 Loop |
| Feedforward (permits/queues) | 2 Source + 8 Domain |
| Balancing gate on the flywheel | 4 Eval + 5 Loop |
| Anti-windup / backpressure / cost governor | 9 FinOps + 1 Data eng |
| Confidence calibration | 4 Eval + 8 Domain |

---

## 4. Staffing models

### 4a. Solo + Claude Code — POC through Phase A + B pilot (this stage → first real build)
**1 strong data/ML generalist + Claude Code**, optionally a **fractional domain analyst**.
- The generalist personally owns: the schema/contract decisions, the gold-set definition, dispute adjudication, and the loop design. They direct Claude Code for everything else (ingestion code, extraction prompts, dashboard, tests).
- Realistic for Phase A (free ingest) and a Texas Phase B pilot.

### 4b. Lean team (3–4) — Phases B→C at scale
| Role | Focus | FTE |
|---|---|---|
| Data/Platform Engineer | contract, store, dedup, refresh, cost governor | 1 |
| AI/Agent Engineer | discovery/extraction/verification loops | 1 |
| Data-Quality / Eval Lead | gold sets, metrics, calibration, review queue | 0.5–1 |
| Domain Analyst (power + DC) | taxonomy, BTM/chain judgment, dispute review | 0.5–1 |
Product/frontend handled by the platform engineer + Claude Code until UX depth is needed.

### 4c. Scaled (6–8) — Phases D–E + productization
Add: **Product/Frontend Engineer** (chain view, trust UX, alerts), **Ops/Orchestration** (scheduling, monitoring, on-call for pipelines), **part-time Legal/Compliance** (permits ToS, international data, licensing), and a **fractional systems/loop architect** to keep the control loops honest as complexity grows.

---

## 5. Named roles & responsibilities

- **Data / Platform Engineer** — owns the `data.json` contract, DuckDB/Postgres, ingestion (gridstatus + EIA), dedup/entity resolution, scheduled refresh, cost governor. *Phases A–E. Agent leverage: High.*
- **AI / Agent Engineer** — owns discovery, extraction (quote-per-field), the multi-vendor verification loop, prompt/eval iteration. *Phases B–E. High.*
- **Data-Quality / Eval Lead** — owns gold sets, precision/recall gates, confidence calibration, the human-review/dispute queue, the balancing gate that protects the flywheel. *Phases B–E. Med — this role defines "correct," which the agent cannot.*
- **Domain Analyst (power + data centers)** — owns the provider taxonomy, BTM and value-chain judgment calls, adjudicates ambiguous edges, curates the gold set with the eval lead. *All phases. Low agent leverage — this is human judgment.*
- **Product / Frontend Engineer** — owns the dashboard, chain view, trust/provenance surface, alerts. *Phases C+. High.*
- **Systems / Loop Architect (fractional)** — owns the control-loop design (setpoints, active-learning policy, deadband/hysteresis, requisite-variety portfolio). Often the founder/generalist early. *Cross-cutting. Low–Med.*
- **Legal / Compliance advisor (part-time)** — owns ToS/robots posture, licensing, PII (contacts layer), international data rules. *Gate role. Low agent leverage.*

Early on, one generalist wears the Platform + Agent + Loop-Architect hats with Claude Code; the first *dedicated* hires are usually the **Eval Lead** and **Domain Analyst**, because they own the two things the agent can't: the definition of truth and domain judgment.

---

## 6. What Claude Code owns vs what humans must own

**Claude Code / agents can own (with human review):** scaffolding and pipeline code, source integrations, extraction and first-pass verification, tests, the dashboard, documentation, routine refactors, running evals, drafting prompts and taxonomies.

**Humans must own (do not abdicate):**
- **Setpoints & targets** — what coverage/precision/freshness "good" means.
- **The gold set & the definition of correct** — the ground truth evals are measured against.
- **Dispute adjudication & the final approval gate** — especially the high-uncertainty tail (active learning routes it here).
- **Taxonomy & edge judgment** — provider categories, ambiguous ownership calls.
- **Legal/licensing decisions** — the "don't copy CleanView / respect ToS" line.
- **Loop design & the balancing gate** — ensuring the reinforcing flywheel can't cascade errors.

This is the "verify, don't abdicate" principle: the agent produces at volume; humans set the targets, define truth, and hold the gate.

---

## 7. Skills-to-acquire checklist

Concrete competencies/tools to have on hand:
- **Python** (data + async API/scraping), **SQL**, **DuckDB** (POC) / **Postgres** (multi-user).
- **`gridstatus`**, **EIA API**, **Firecrawl**, one search API (**Exa** or **Perplexity Sonar**).
- **LLM structured output / tool-calling**; access to ≥2 vendors (for the diversity requirement).
- **Eval tooling** — a gold set + a precision/recall harness; confidence-calibration basics.
- **Entity resolution** — fuzzy match on name+geo+developer, alias tables.
- **Geocoding** — US Census (free); geo precision handling.
- **Front-end** — MapLibre + a data-driven view over the `data.json` contract.
- **Orchestration/FinOps** — a scheduler (the `schedule` skill pattern), caching, spend alerts.
- **Domain reading list** — EIA-860M & ISO queue docs, the provider taxonomy, DCD/Data Center Frontier for landscape fluency.

---

## 8. Hire vs upskill vs lean on the agent

- **Lean on Claude Code** for capabilities 1, 2, 3, 7, 9 — engineering the agent does well; a generalist can direct and verify.
- **Upskill / assign an owner** for capability 5 (loop thinking) — one person who genuinely understands feedback control changes the quality of the whole system.
- **Hire / partner** for capabilities 8 (domain) and 4 (eval judgment) as you scale — these are the human moat and can't be delegated to the model.
- **Retain (part-time)** for capability 10 (legal) — a gate, not a bottleneck.

---

## 9. Bottom line

The engineering surface is largely covered by Claude Code plus one strong generalist through Phase A+B. The capabilities that decide whether the product is *trustworthy and differentiated* — defining truth (evals), domain judgment (taxonomy/chain), and loop design (control) — are the human-owned ones, and they're where the first dedicated hires should go. Build the machine with the agent; keep the judgment with people.

---

*Companion docs: `CLAUDE.md` (index), `docs/phase-a-spec.md` / `docs/phase-b-spec.md` (build specs), `docs/datacenterview-architecture-proposal.md` (pipeline), `docs/loop-engineering-value-chain-proposal.md` & `docs/loop-mechanisms-catalog.md` (the loops these roles operate).*

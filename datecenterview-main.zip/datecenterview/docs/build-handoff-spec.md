# Build Handoff — dataCenterView → Claude Code

> **Purpose.** The decision-ready spec for the real engineering build. Read this + `CLAUDE.md` first. Covers: data/source refresh-readiness, the finalized architecture (backend · middle · frontend), the tech stack (incl. a full datastore evaluation), the newsfeed source-scouting method, the phased feature roadmap, and the loop-engineering skill set. Aligned with Hao July 2026.

---

## 0. Confirmed decisions (from alignment)

| Area | Decision |
|---|---|
| **Deployment** | **Local-first → small team/internal**, **Dockerized** (docker-compose local → same compose on a VM/Fly/Render for the team). No public multi-tenant yet. |
| **Backend / pipeline** | **Python** (ingestion, extraction, verification loops) |
| **API + UI** | **TypeScript / Next.js** (React) |
| **Datastore** | Evaluated in §3b → **Postgres = system of record + DuckDB = in-pipeline analytics**; adopt **Supabase** (managed Postgres) at team rollout |
| **UI data contract** | The existing **`data.json` read-model** (served static and/or via the API) |

---

## 1. Data & source refresh-readiness (item 1 — validated)

**Structural validation:** `validate_data.py` → **PASS** (0 errors). The 24 warnings are one class: *confirmed-but-single-source* records. **Gap to close in the build:** every "confirmed" value needs ≥2 independent sources (Phase C corroboration).

**Source registry — refreshable on an ongoing basis?**

| Source | Feeds | Format | Cadence | Refreshable | Cost |
|---|---|---|---|---|---|
| **EIA-860M** | generators | JSON API | monthly | ✅ | free (key) |
| **7 ISO queues** | proposed power | CSV/JSON/XLSX via `gridstatus` / interconnection.fyi | daily | ✅ | free |
| **GDELT 2.0** | global news firehose | DOC API + BigQuery + 15-min files | **15 min** | ✅ | free |
| **Trade-press RSS** | DCD · DCF · DCK · Construction Dive | RSS | continuous | ✅ | free |
| **Search API** | discovery/gap-fill | Exa / Perplexity | on-demand | ✅ | usage |
| **Permit portals** | county/state | scrape (Firecrawl) | weekly | ✅ (ToS care) | low |
| **Earnings / SEC** | supply chain $ | 10-K/8-K, IR | quarterly + events | ✅ | free |
| **Company IR** | announcements | RSS/scrape | event | ✅ | low |

**Verdict:** the *source landscape is sufficient to refresh indefinitely* — GDELT alone is "the closest thing to a free Reuters feed you can build a real pipeline on." The demo dataset (21 DC · 16 power · 11 news · 17 entities · 23 edges · 24 supply nodes) is a small illustrative sample; **real volume comes from running the pipeline.** Two build gaps: **(a)** 2nd-source corroboration, **(b)** scale.

---

## 2. Architecture (item 2 — three layers, daily-use)

```
 ┌──────────────── INGESTION / PIPELINE (Python, scheduled) ─────────────────┐
 │  A. power: EIA + ISO (gridstatus)      →                                    │
 │  B. discover: GDELT + RSS + Exa/Perplexity → extract (LLM #1) →             │
 │  C. verify: cross-vendor (LLM #2) → confidence gate → dedup/entity-resolve  │
 │  D/E: permits · satellite · intl (later)                                    │
 │  loops: MAPE-K · maker-checker · active-learning · deadband · cost-governor │
 └───────────────────────────────┬──────────────────────────────────────────┘
                                  ▼ upsert (field-level provenance)
 ┌──────────────── DATA LAYER (middle) ──────────────────────────────────────┐
 │  Postgres  = system of record (records · entities · edges · sources ·      │
 │              review_log · change_log · gold_set)                           │
 │  DuckDB    = in-process analytics (fast rollups, geo, dedup joins)         │
 │  Object store = raw source snapshots (Parquet / files) for provenance      │
 │  build step → emits data.json read-model + a change feed                   │
 └───────────────────────────────┬──────────────────────────────────────────┘
                                  ▼ REST/JSON
 ┌──────────────── API LAYER (TS, Next.js route handlers / FastAPI) ─────────┐
 │  /records /entities /edges /news /supply /review /dispute /changes         │
 │  serves the read-model + write-backs (approve / dispute / watchlist)       │
 └───────────────────────────────┬──────────────────────────────────────────┘
                                  ▼
 ┌──────────────── FRONTEND (Next.js / React) ───────────────────────────────┐
 │  Overview · Explorer · Newsfeed (+ How-it-works) — pure function of the    │
 │  read-model; provenance/confidence surface; detail drawer; role-flow chart │
 └───────────────────────────────────────────────────────────────────────────┘
```

**Daily-use requirements it must meet:**
- **Scheduled refresh** (nightly for DC/news, monthly for EIA, daily for ISO) via cron/GitHub Actions/Prefect; delta-only.
- **Freshness SLO** (median announce→record < 48h) + a **change feed** ("what moved").
- **Review queue** surfaced in the UI (active-learning: lowest-confidence first) + **dispute** write-back.
- **Cost governor** + daily spend alert.
- **Validator gate** (`validate_data.py` + store tests) blocks bad publishes.

**Deployment:** one `docker-compose.yml` — `postgres`, `pipeline`, `api`, `web`. Runs locally today; the *same compose* deploys to a small VM (or Fly/Render) for the team. Supabase swaps in for Postgres at that stage (adds auth + instant API, zero schema migration).

---

## 3. Tech stack & tools (item 3)

### 3a. Per-layer stack

| Layer | Choice | Notes |
|---|---|---|
| **Pipeline lang** | **Python 3.12**, `uv` (deps) | data + agent ecosystem |
| Data wrangling | **Polars** (+ pandas where needed), **DuckDB** | fast, columnar |
| Power ingest | **`gridstatus`** + EIA API v2 (`httpx`) | don't hand-write 7 parsers |
| Discovery | **GDELT** client + publisher RSS + **Exa** *or* **Perplexity Sonar** | seed §4 |
| Scrape/clean | **Firecrawl** (or Playwright self-host) | permits, articles |
| Extraction LLM | cheap model (Grok 4.1 Fast / Claude Haiku), **structured output** | quote-per-field |
| Verify LLM | **different vendor** than extractor | maker-checker |
| Schema/validation | **Pydantic** (models) + **`data.schema.json`** + **Great Expectations**/dbt tests | gate |
| Orchestration | **Prefect** (or plain APScheduler / **GitHub Actions** to start) | scheduled + retries |
| **Store (SoR)** | **Postgres 16** (JSONB provenance) + **Alembic** migrations | §3b |
| **Analytics** | **DuckDB** (in-pipeline) reads PG/Parquet → rollups → `data.json` | §3b |
| Geocode | **US Census** (free) | coords |
| **API** | **Next.js route handlers** (or FastAPI if Python-side); **Zod** contracts | typed |
| **Frontend** | **Next.js 15 + React + TypeScript + Tailwind** | app shell |
| UI data | **TanStack Query**; **MapLibre GL**; **d3-sankey**; role-flow = plain React | reuse demo patterns |
| Infra | **Docker + docker-compose**; GitHub Actions (CI + scheduled refresh); `.env`/secrets | one-command up |
| Obs/cost | structured logs + a **spend meter** + Sentry (optional) | alert on daily spend |

### 3b. Datastore — full evaluation (the sub-decision you asked for)

| Dimension | **DuckDB** | **Postgres** | **Supabase (managed PG)** |
|---|---|---|---|
| Type | Embedded OLAP (a file) | Client-server RDBMS | Hosted Postgres + batteries |
| Concurrent writers | ❌ single-writer | ✅ many | ✅ many |
| Analytics / rollups | ⭐ excellent (columnar) | good | good (it *is* PG) |
| System-of-record fit | weak (no server, no concurrent writes) | ⭐ strong | ⭐ strong |
| Field-level provenance | JSON ok | **JSONB** native + GIN index | JSONB native |
| History (`change_log`) | manual | triggers / temporal tables | same |
| Auth + instant API | none | build it | ⭐ **built-in** (RLS + REST + realtime) |
| Ops burden | none (a file) | run a server (trivial in Docker) | managed *(or self-host via Docker)* |
| Local-first | ⭐ perfect | easy (one container) | `supabase` CLI runs it locally in Docker |
| Team rollout | poor | good | ⭐ excellent (auth included) |
| Migration risk | — | — | it's Postgres → PG↔Supabase is trivial |
| Cost | free | free (self-host) | free tier → paid |

**Recommendation — use two, each for what it's best at:**
1. **Postgres = system of record** (Dockerized locally; the field-provenance schema from `docs/data-schema-and-validation-spec.md`). Handles concurrent writes, history, and scales to the team.
2. **DuckDB = in-pipeline analytics engine** — the Python pipeline uses DuckDB to run heavy rollups/dedup/geo joins fast (over Parquet snapshots and/or a Postgres scan), then emits `data.json`. DuckDB is *compute*, not storage-of-record.
3. **Supabase at team rollout** — swap the Postgres container for Supabase to get **auth + instant API + row-level security** with near-zero migration (same Postgres). Supabase also runs locally via its Docker CLI, so it stays local-first-compatible.

**Rejected:** DuckDB-as-SoR (single-writer breaks multi-user + scheduled pipeline writing while the API reads); SQLite (weak on the analytical rollups the dashboard needs). Net: **Postgres SoR + DuckDB compute now → Supabase when the team logs in.**

---

## 4. Newsfeed — scouting & identifying the right sources (item 4)

The `feeds[]` registry is **config, not code** — sources are added/retired by data. The scouting pipeline:

**1. Seed the registry (tiered by trust):**
- *Firehose:* GDELT 2.0 (global, 15-min).
- *Trade press (RSS):* Data Center Dynamics, Data Center Frontier, Data Center Knowledge, Construction Dive, plus local/regional business journals.
- *Primary/regulatory:* utility-commission dockets, county/state permit portals, EIA/ISO.
- *Company:* the ~40 most active developers' IR/newsrooms.
- *Search:* Exa/Perplexity for gap-fill and net-new.

**2. Discover NEW sources automatically (don't hand-maintain the list):**
- **GDELT domain analysis** — for articles matching the DC lexicon, rank the *publishing domains* by volume + precision; promote recurring high-signal domains into the registry.
- **Citation mining** — parse which outlets the trusted trade press links to; those become candidate sources.
- **Permit-portal crawl** — enumerate county/state planning portals in the states with active DC growth (TX, VA, GA, AZ, OH, …).
- **Search-driven** — periodic Exa/Perplexity queries ("new data center", "gigawatt", "rezoning", developer names) surface sources not yet in the registry.

**3. Score every source (keep the good, cut the noisy):**
- **Trust weight** (gov/SEC 1.0 → reputable trade press 0.8 → company PR 0.7 → social 0.4).
- **Relevance precision** — % of a source's fetched items that pass the DC classifier; track per source over time.
- **Freshness/volume** — items/day and lead time vs the pack.
- **Circuit breaker** — a source whose precision drops below threshold (spam/rebrand) is auto-quarantined for review.

**4. Filter & dedup:**
- A **keyword lexicon** + a cheap **relevance classifier** gate the firehose.
- **Dedup** the same story across outlets by canonical-URL + title-hash + `identity_key`; first sighting sets `announced_date`.

**5. Governance:** respect robots.txt / per-site ToS; **never bypass paywalls** (use metadata, flag `paywalled`); keep the source URL + retrieved-at on every item.

**Output:** each news record carries `source_feed` + `projects[]` links + provenance — exactly the `data.json → news[]` shape the UI already renders.

---

## 5. Feature roadmap — prioritized phases (item 5)

| Phase | Goal | Key deliverables | Exit criteria |
|---|---|---|---|
| **P0 — Scaffold** | repo ready | monorepo (pipeline/api/web), Postgres schema + Alembic, `docker-compose up`, `validate_data.py` in CI, seed `data.json` renders in Next.js | one-command local run; validator gates CI |
| **P1 — MVP (local-first)** | real data flowing | Phase A power ingest (EIA + ISO via gridstatus → Postgres) · Phase B **Texas pilot** (discover→extract→candidate records) · emit `data.json` · Next.js **Overview + Explorer + Newsfeed** | ≥ hundreds of real records; Texas precision/recall measured vs a ~100-project gold set |
| **P2 — Verify & trust** | trustworthy | Phase C: **cross-vendor verify**, confidence scoring, dedup/entity-resolution, **review queue UI**, **change feed**, scheduled nightly refresh, freshness SLO, cost governor | ≥2 sources on confirmed records; validator + eval gates green nightly |
| **P3 — Team rollout** | shared use | swap Postgres→**Supabase** (auth + API), deploy compose to a VM, **watchlists/alerts**, provenance-rich **export** | 2nd user logs in; alerts fire on the change feed |
| **P4 — Proprietary edge** | be first | **permit-portal** ingestion, **satellite** progress checks, **Grok X-signal**, **supplier edges** (per-project chips/servers/cooling) | unannounced projects surfaced pre-news; supply chain per project |
| **P5 — International** | worldwide | ENTSO-E + regional permits + global news; unify schema | first non-US country live |

Build order note: **P0 + P1 together**; P1 is where the loops first close on one state.

---

## 6. Loop-engineering skills for the project (item 6 — finalized)

Package each pipeline stage as a reusable **skill** (Claude Code slash-command / Agent-SDK skill), so the build invokes loops rather than re-deriving them. Each maps to a mechanism from `docs/loop-mechanisms-catalog.md`.

| Skill | Does | Loop mechanism |
|---|---|---|
| **`phase-a-ingest`** | EIA + ISO (gridstatus) → normalized `power_project` rows | feedforward (leading indicators) |
| **`dc-discover`** | GDELT + RSS + Exa/Perplexity → deduped candidate URLs | MAPE-K monitor; requisite variety |
| **`dc-extract`** | article → structured record, one source-quote per field | schema-gated extraction |
| **`cross-verify`** | different-vendor re-check of key fields → confidence | **maker-checker** (negative feedback) |
| **`chain-classify`** | tag orgs → provider taxonomy; build `edges[]` | double-loop (heuristics improve) |
| **`supplier-classify`** | map project → chip/server/cooling vendors → `supply_chain`/edges | requisite variety |
| **`refresh`** | scheduled re-verify, only on material change | **deadband / hysteresis**; adaptive polling |
| **`validate`** | `data.schema.json` + referential + trust gate (CI) | balancing gate (blocks bad publish) |
| **`review-triage`** | surface lowest-confidence × highest-value to a human | **active learning** |
| **`eval`** | precision/recall vs the gold set; block regressions | eval loop; SLOs |
| **`cost-governor`** | cap candidates/day; spend where uncertainty is highest | anti-windup / backpressure |

**Reuse now:** `skill-creator` (author the above), the `schedule` skill (the freshness loop), and the `deep-research` pattern (its fan-out→fetch→adversarial-verify→synthesize *is* the discover→extract→verify loop). **The one to assign a human owner:** loop design (setpoints, active-learning policy, the balancing gate) — the model implements, a person tunes.

---

## 7. Repo layout & first commit (kickoff for Claude Code)

```
datacenterview/
├─ docker-compose.yml            # postgres · pipeline · api · web
├─ pipeline/            (Python)  # ingest · discover · extract · verify · emit
│  ├─ sources/  loops/  schema/  duckdb/  emit_data_json.py
│  ├─ data.schema.json  validate_data.py   (moved from demo)
│  └─ tests/  gold_set/
├─ db/                            # Alembic migrations (Postgres SoR)
├─ api/                (TS)       # Next.js route handlers / or FastAPI
├─ web/                (Next.js)  # Overview · Explorer · Newsfeed
│  └─ (port the demo's data.json contract + charts)
├─ data.json / data.js           # the read-model (demo → generated)
└─ docs/                          # all the specs in this folder
```
**First tasks for the Claude Code build:** (1) scaffold monorepo + `docker-compose up`; (2) Postgres schema + Alembic from `docs/data-schema-and-validation-spec.md`; (3) wire `validate_data.py` into CI; (4) `phase-a-ingest` → Postgres → emit `data.json`; (5) port the demo UI into Next.js against the same contract; (6) `dc-discover`+`dc-extract` on Texas.

---

## 8. Open decisions to lock during P0/P1

1. **Search vendor:** Exa (cheap neural search) vs Perplexity Sonar (cited synthesis) — pick one for P1, keep the other swappable.
2. **2nd LLM vendor** for `cross-verify` (must differ from the extractor).
3. **Orchestrator:** GitHub Actions (simplest) vs Prefect (retries/observability) — Actions for P1, Prefect by P2.
4. **API host:** Next.js route handlers (one app) vs a separate FastAPI (Python-native) — default to Next handlers unless the pipeline needs to serve directly.

---

*Companions: `CLAUDE.md` (index) · `docs/data-schema-and-validation-spec.md` (schema + validation) · `docs/phase-a-spec.md` / `docs/phase-b-spec.md` (ingest specs) · `docs/datacenterview-architecture-proposal.md` (pipeline + cost) · `docs/loop-mechanisms-catalog.md` (the loops) · `docs/capabilities-and-roles.md` (who builds it) · `docs/demo-design-spec.md` (the UI contract to port).*

# Documentation Reading Guide

Product, architecture, research, handoff, and operational documentation lives here. Start
with the repository [`README.md`](../README.md) for setup and operations, then
[`CLAUDE.md`](../CLAUDE.md) for the current system state and constraints.

## Authority And Freshness

When documents disagree, use this order of authority:

1. Running code, migrations, `pipeline/data.schema.json`, and tests describe implemented behavior.
2. [`data-collection-and-architecture-plan.md`](data-collection-and-architecture-plan.md) §7 is the canonical implementation order and shipped-status record.
3. [`PRD-compute-terminal.md`](PRD-compute-terminal.md) v2.2 defines the current product shape.
4. Older proposals and build specifications explain decisions but may contain historical counts, prices, schemas, or unfinished tasks that have since shipped.

## Core Reading Sequence

This is the shortest path for a new contributor who needs the product and architecture before
changing code:

1. **Product:** [`PRD-compute-terminal.md`](PRD-compute-terminal.md)
   defines the users, three-tab experience, graph navigation, and product scope.
2. **Base architecture:** [`build-handoff-spec.md`](build-handoff-spec.md) §§0-3
   explains the Python/Postgres/DuckDB/Next.js stack and three-layer architecture. Its roadmap
   and first-commit sections are historical; use the data plan for current sequencing.
3. **Data contract:** [`data-schema-and-validation-spec.md`](data-schema-and-validation-spec.md)
   explains the Postgres system of record, emitted read model, field-level provenance, and
   validation model. It describes the v1.0 foundation; inspect the current schema and migrations
   for implemented v1.2 details.
4. **Terminal design:** [`TDD-compute-terminal.md`](TDD-compute-terminal.md)
   connects the PRD to the graph, financial, pricing, verification, and user-feedback loops.
   Read later changes in the PRD and data plan alongside it.
5. **Current execution plan:**
   [`data-collection-and-architecture-plan.md`](data-collection-and-architecture-plan.md),
   especially §§0, 6, 7, and 7b, reconciles the desired terminal with the running pipeline and
   records what shipped, what remains, and why the work was re-sequenced.

After this sequence, read only the focused track relevant to the change.

## Focused Tracks

### Ingestion And Trust

1. [`phase-a-spec.md`](phase-a-spec.md) — structured EIA and ISO power ingestion.
2. [`phase-b-spec.md`](phase-b-spec.md) — web discovery, extraction, normalization, and candidates.
3. [`datacenterview-architecture-proposal.md`](datacenterview-architecture-proposal.md) — original end-to-end agentic pipeline and cross-vendor verification rationale.
4. [`verifier-selection-findings.md`](verifier-selection-findings.md) — measured verifier decision, limitations, cost model, and next experiment.

Treat the phase specifications and architecture proposal as design foundations; the pipeline
code and the current data plan contain later implementation changes.

### Frontend And Product UX

1. [`PRD-compute-terminal.md`](PRD-compute-terminal.md) — current product behavior.
2. [`demo-design-spec.md`](demo-design-spec.md) — original standalone explorer and read-model contract.
3. [`TDD-compute-terminal.md`](TDD-compute-terminal.md) — terminal architecture and loop design.
4. [`data-collection-and-architecture-plan.md`](data-collection-and-architecture-plan.md) §§1-2 and 7c — view-to-data mapping and user-loop contracts.

The demo specification retains useful interaction and data-contract context, but its four-view
standalone IA predates the current three-tab Compute Terminal.

### Design Rationale And Research

Read these when revisiting a decision rather than for routine implementation:

1. [`cleanview-teardown.md`](cleanview-teardown.md) — competitor and source landscape.
2. [`loop-engineering-value-chain-proposal.md`](loop-engineering-value-chain-proposal.md) — why the product uses feedback loops and a navigable value-chain graph.
3. [`loop-mechanisms-catalog.md`](loop-mechanisms-catalog.md) — concrete control mechanisms and failure modes.
4. [`compute-terminal-findings-and-options.md`](compute-terminal-findings-and-options.md) — evidence and options behind the compute-terminal pivot.
5. [`capabilities-and-roles.md`](capabilities-and-roles.md) — team capabilities and human/agent ownership.

## Historical Handoff

[`claude-code-kickoff-prompt.md`](claude-code-kickoff-prompt.md) records the original P0/P1
implementation prompt. It is useful for provenance, but it is not a current task list and should
not be used to restart already-shipped scaffolding work.
